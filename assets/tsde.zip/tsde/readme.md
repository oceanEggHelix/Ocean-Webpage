📦 TSDE v0.9 Beta - Installationsanleitung
🎯 Blender Addon Installation in 3 Minuten
SCHRITT 1: Blender öffnen
bash
# Blender starten (Version 4.0 oder höher)
# Ja, wirklich. Doppelklick auf Blender-Icon.
SCHRITT 2: Addon installieren
python
# Oben in Blender:
Edit → Preferences → Add-ons
![Blender Preferences öffnen]

python
# Im Addon-Fenster:
┌─────────────────────────────────┐
│ [Install...]  ← DIESEN BUTTON!  │
└─────────────────────────────────┘
python
# Dateiauswahl-Fenster:
┌──────────────────────────────────────┐
│ Dateiname: TSDE_v0.9_Beta.zip        │
│                                      │
│ Dateityp: Addons (*.zip)             │
│                                      │
│        [Abbrechen]  [Install Add-on] │
└──────────────────────────────────────┘
👉 Deine TSDE.zip auswählen
👉 [Install Add-on] klicken

SCHRITT 3: Addon aktivieren
python
# In der Addon-Liste:
┌─────────────────────────────────────┐
│ Search: TSDE                        │
│                                     │
│ ☐ TSDE Loader (System)              │
│                                     │
│ ─────────────────────────────────── │
│                                     │
│ [✔] TSDE Loader (System)            │  ← HÄKCHEN SETZEN!
└─────────────────────────────────────┘
SCHRITT 4: Prüfen ob's läuft
python
# Im 3D-Viewport:
- N-Taste drücken (Sidebar ein/aus)
- Ganz rechts siehst du den "TSDE" Tab
text
┌─────────────────┐
│ ✦ TSDE         │ ← Wenn das da ist: FERTIG! 🎉
│ ├─ 1. Spline   │
│ ├─ 2. Setup    │
│ ├─ 3. Engine   │
│ ├─ 4. Live     │
│ ├─ 5. Recorder │
│ ├─ 6. Render   │
│ └─ 7. Settings │
└─────────────────┘
🚨 FEHLERBEHEBUNG
❌ Addon wird nicht angezeigt:
bash
1. Blender KOMPLETT schließen
2. Diesen Ordner löschen:
   C:\Users\benja\AppData\Roaming\Blender Foundation\Blender\4.5\scripts\addons\TSDE\
3. Blender neu starten
4. Nochmal installieren
❌ Fehlermeldungen in der Konsole:
bash
1. View → Areas → Toggle System Console
2. Schau was da steht
3. Screenshot machen und mir schicken 😅
❌ TSDE Tab ist leer:
bash
# Blender NEU STARTEN!
# Ja, wirklich. Einfach neu starten.
✅ ERFOLGREICH INSTALLIERT
Jetzt kannst du:

🏗️ Rigs bauen mit einem Klick

🎮 Engine starten und live steuern

📹 Recorden mit 240Hz

🎬 Rendern mit Roll

⚡ Time Stretch von 0.1x bis 10x

📞 SUPPORT
text
Bei Problemen:
- Konsole checken
- Screenshot machen
- Mir schicken

Kontakt: benjaminu@live.de
© 2025 Benjamin Thorsten Unger
Geboren 10.04.1987, Nürtingen
Alle Rechte vorbehalten