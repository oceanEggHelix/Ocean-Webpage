# In deinem README.md
# ============================================================
# 📜 LIZENZ
# ============================================================
# 
# TSDE Engine ist **dual-lizenziert**:
# 
# 1. **AGPL v3** für:
#    - Hobbyisten
#    - Bildungseinrichtungen
#    - Open Source Projekte
#    - Persönliche Nutzung
# 
# 2. **Kommerzielle Lizenz** für:
#    - Firmen
#    - Kommerzielle Produkte
#    - Eingebettete Systeme
#    - Closed-Source-Projekte
# 
# Kontakt für kommerzielle Lizenzen: [benjaminu@live.de]
# ============================================================