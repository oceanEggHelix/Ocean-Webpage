# tsde_gui/model.py
class GuiTrack:
    def __init__(self, name, curve, max_speed):
        self.name = name
        self.curve = curve
        self.max_speed = max_speed

class GuiTrackGroup:
    def __init__(self, name):
        self.name = name
        self.tracks = []