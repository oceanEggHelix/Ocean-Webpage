from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from tsde_gui.graphs import GraphGroup


class TrackLaneWidget(QFrame):
    # Signal wenn sich die Höhen im Splitter ändern oder Track getoggled wird
    heights_changed = Signal(list)  # [curve_height, pedal_height]
    toggled = Signal(bool)  # True = sichtbar, False = ausgeblendet
    
    def __init__(self, track, curve=None, parent=None):
        super().__init__(parent)

        self.track = track
        self.PADDING = 8
        self.is_visible = True  # Track ist standardmäßig sichtbar

        self.setStyleSheet("""
            TrackLaneWidget {
                background-color: #ffffff;
                border: 1px solid #ddd;
                border-radius: 6px;
                margin: 2px 0px;
            }
            TrackLaneWidget:hover {
                border: 1px solid #aaa;
                background-color: #fafafa;
            }
        """)

        # Hauptlayout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(self.PADDING, self.PADDING, 
                                 self.PADDING, self.PADDING)
        layout.setSpacing(8)

        # Header mit Track-Name und Toggle-Button
        self._build_header(layout)
        
        # Graph-Gruppe mit Splitter
        self._build_graph_group(layout, curve)

    def _build_header(self, parent_layout):
        header = QFrame()
        header.setStyleSheet("""
            QFrame {
                background-color: #f5f5f5;
                border-bottom: 1px solid #ddd;
                border-radius: 4px;
            }
        """)
        
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(8, 4, 8, 4)
        
        # Toggle-Button (Auge-Symbol)
        self.toggle_btn = QPushButton()
        self.toggle_btn.setFixedSize(24, 24)
        self.toggle_btn.setCursor(Qt.PointingHandCursor)
        self.toggle_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                border-radius: 12px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: rgba(0, 0, 0, 0.1);
            }
        """)
        self.update_toggle_button()
        self.toggle_btn.clicked.connect(self.toggle_visibility)
        header_layout.addWidget(self.toggle_btn)
        
        # Track-Name
        name_label = QLabel(f"🎯 {self.track.name}")
        font = QFont()
        font.setBold(True)
        font.setPointSize(10)
        name_label.setFont(font)
        name_label.setStyleSheet("color: #333;")
        header_layout.addWidget(name_label)
        
        header_layout.addStretch()
        
        # Info-Label mit Zeitbereich und Punktanzahl
        info_text = ""
        if hasattr(self.track, 't_min') and hasattr(self.track, 't_max'):
            info_text += f"{self.track.t_min:.2f}s - {self.track.t_max:.2f}s"
        
        if hasattr(self.track, 'current_times') and self.track.current_times is not None:
            info_text += f" | {len(self.track.current_times)} Punkte"
        
        info_label = QLabel(info_text)
        info_label.setStyleSheet("color: #666; font-size: 9pt;")
        header_layout.addWidget(info_label)
        
        parent_layout.addWidget(header)

    def update_toggle_button(self):
        """Aktualisiert das Toggle-Button-Symbol"""
        if self.is_visible:
            self.toggle_btn.setText("👁️")  # Auge = sichtbar
            self.toggle_btn.setToolTip("Track ausblenden")
        else:
            self.toggle_btn.setText("👁️‍🗨️")  # Auge mit Strich = unsichtbar
            self.toggle_btn.setToolTip("Track einblenden")

    def toggle_visibility(self):
        """Schaltet die Sichtbarkeit des Tracks um"""
        self.is_visible = not self.is_visible
        self.update_toggle_button()
        
        # Graph-Gruppe ein-/ausblenden
        self.graph_group.setVisible(self.is_visible)
        
        # Header-Style anpassen wenn ausgeblendet
        if self.is_visible:
            self.setStyleSheet("""
                TrackLaneWidget {
                    background-color: #ffffff;
                    border: 1px solid #ddd;
                    border-radius: 6px;
                    margin: 2px 0px;
                }
                TrackLaneWidget:hover {
                    border: 1px solid #aaa;
                    background-color: #fafafa;
                }
            """)
        else:
            self.setStyleSheet("""
                TrackLaneWidget {
                    background-color: #f0f0f0;
                    border: 1px dashed #aaa;
                    border-radius: 6px;
                    margin: 2px 0px;
                }
            """)
        
        self.toggled.emit(self.is_visible)

    def _build_graph_group(self, parent_layout, curve):
        # Graph-Gruppe erstellen
        self.graph_group = GraphGroup()
        self.graph_group.set_track(self.track)
        if curve:
            self.graph_group.set_curve(curve, self.track)
        
        self.graph_group.height_changed.connect(self._on_heights_changed)
        parent_layout.addWidget(self.graph_group)

    def _on_heights_changed(self):
        """Wird aufgerufen wenn der Splitter bewegt wurde"""
        heights = self.graph_group.get_heights()
        self.heights_changed.emit(heights)

    def set_content_width(self, width):
        """Setzt die Content-Breite für beide Graphen"""
        if width <= 0:
            return
            
        total_width = width + 2 * self.PADDING
        self.setFixedWidth(total_width)
        
        self.graph_group.set_content_width(width)

    def set_marker(self, time_pos):
        """
        Setzt die Marker-Position.
        time_pos ist die normierte Zeit (0-1) von der Timeline.
        """
        # 1. PedalGraph bekommt die Zeit
        if hasattr(self.graph_group, 'pedal_graph'):
            self.graph_group.pedal_graph.set_marker(time_pos)
        
        # 2. CurveGraph braucht die Position aus den Samples
        if hasattr(self.graph_group, 'curve_graph'):
            if hasattr(self.track, 'current_times') and len(self.track.current_times) > 0:
                # Zeit in Sample-Index umrechnen
                num_samples = len(self.track.current_times)
                idx = int(time_pos * num_samples)
                idx = min(idx, num_samples - 1)
                
                # t-Wert an dieser Position
                t_value = self.track.current_times[idx]
                
                # CurveGraph bekommt die Position
                self.graph_group.curve_graph.set_marker(t_value)
            else:
                # Fallback: gleiche Zeit verwenden
                self.graph_group.curve_graph.set_marker(time_pos)
        
    def set_zoom_range(self, zoom_start, zoom_end):
        """Setzt den Zoom-Bereich für beide Graphen"""
        self.graph_group.set_zoom_range(zoom_start, zoom_end)
    
    def get_graph_heights(self):
        """Gibt die aktuellen Höhen der Graphen zurück"""
        return self.graph_group.get_heights()
    
    def set_graph_heights(self, curve_height, pedal_height):
        """Setzt die Höhen der Graphen"""
        self.graph_group.set_heights([curve_height, pedal_height])
    
    def reset_graph_heights(self):
        """Setzt die Höhen auf Standard zurück"""
        self.graph_group.reset_heights()
    
    def is_track_visible(self):
        """Gibt zurück ob der Track sichtbar ist"""
        return self.is_visible