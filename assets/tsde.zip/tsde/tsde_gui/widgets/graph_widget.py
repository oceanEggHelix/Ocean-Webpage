from PySide6.QtWidgets import QWidget
from PySide6.QtGui import QPainter, QPen
from PySide6.QtCore import Qt


class CurveGraph(QWidget):
    """
    Zeichnet die komplette Kurve + einen Marker,
    der die aktuelle Engine-Position zeigt.
    """

    def __init__(self, curve=None, parent=None):
        super().__init__(parent)
        self.curve = curve
        self.samples = 200
        self.scale = 10.0
        self.t_current = 0.0
        self.track_index = 0   # <<< WICHTIG: Welcher Track liefert den Marker?

    def set_curve(self, curve, track_index=0):
        """Kurve + zugehörigen Track setzen."""
        self.curve = curve
        self.track_index = track_index
        self.update()

    def paintEvent(self, event):
        if self.curve is None:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()

        # Kurve zeichnen
        pen_curve = QPen(Qt.cyan, 2)
        painter.setPen(pen_curve)

        pts = []
        for i in range(self.samples):
            t = i / (self.samples - 1)
            p = self.curve.evaluate(t)

            x = int(t * w)
            # --- Auto-Y-Scaling ---
            # Alle X-Werte der Kurve sammeln
            values = [self.curve.evaluate(i/(self.samples-1)).x for i in range(self.samples)]

            min_v = min(values)
            max_v = max(values)

            # Verhindert Division durch 0
            if max_v - min_v < 1e-6:
                max_v += 1e-6

            # Skala berechnen
            scale_y = h / (max_v - min_v)

            # Y-Wert transformieren
            y = int(h - (p.x - min_v) * scale_y)

            pts.append((x, y))

        for i in range(len(pts) - 1):
            painter.drawLine(
                pts[i][0], pts[i][1],
                pts[i + 1][0], pts[i + 1][1]
            )

        # Marker zeichnen
        marker_x = int(self.t_current * w)

        pen_marker = QPen(Qt.red, 2)
        painter.setPen(pen_marker)
        painter.drawLine(marker_x, 0, marker_x, h)

        painter.end()