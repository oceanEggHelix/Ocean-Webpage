# tsde_gui/recorder_panel.py - KOMPAKT & RESPONSIV!
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, 
    QFrame, QComboBox, QFileDialog, QMessageBox, QSpinBox,
    QGroupBox, QMainWindow, QSizePolicy
)
from PySide6.QtCore import Qt, QTimer, Signal, QSize
from PySide6.QtGui import QFont
import tsde_engine.core.ipc as ipc
import time
from datetime import datetime

from tsde_gui.theme import Theme


# ------------------------------------------------------------------------
# Compact Status Widget - KLEINER!
# ------------------------------------------------------------------------
class CompactStatusWidget(QFrame):
    """Kompakte Status-Anzeige"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameStyle(QFrame.StyledPanel)
        self.setStyleSheet(f"""
            QFrame {{
                background-color: {Theme.BACKGROUND_MEDIUM.name()};
                border: 1px solid {Theme.PRIMARY.name()};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 5, 8, 5)
        layout.setSpacing(10)
        
        # Status Icon + Text in einem
        self.status_icon = QLabel("⏹")
        self.status_icon.setStyleSheet("font-size: 16pt;")
        layout.addWidget(self.status_icon)
        
        self.status_text = QLabel("Bereit")
        self.status_text.setStyleSheet(f"""
            font-weight: bold;
            font-size: 10pt;
            color: {Theme.TEXT_PRIMARY.name()};
        """)
        layout.addWidget(self.status_text)
        
        layout.addSpacing(10)
        
        # Dauer
        layout.addWidget(QLabel("Dauer:"))
        self.duration_label = QLabel("0.0s")
        self.duration_label.setStyleSheet("font-weight: bold; font-family: monospace;")
        layout.addWidget(self.duration_label)
        
        # Tracks
        layout.addWidget(QLabel("Tracks:"))
        self.tracks_label = QLabel("4")
        self.tracks_label.setStyleSheet("font-weight: bold; color: #4CAF50;")
        layout.addWidget(self.tracks_label)
        

    
    def update_status(self, is_recording=False, session_name=None, duration=0.0, tracks=4):
        if is_recording:
            self.status_icon.setText("●")
            self.status_icon.setStyleSheet("font-size: 16pt; color: #ff0000;")
            self.status_text.setText("REC")
            self.status_text.setStyleSheet("font-weight: bold; font-size: 10pt; color: #ff0000;")
        else:
            self.status_icon.setText("⏹")
            self.status_icon.setStyleSheet("font-size: 16pt; color: #888888;")
            self.status_text.setText("Bereit")
            self.status_text.setStyleSheet(f"font-weight: bold; font-size: 10pt; color: {Theme.TEXT_PRIMARY.name()};")
        
        #self.session_label.setText(session_name if session_name else "")
        self.duration_label.setText(f"{duration:.1f}s")
        self.tracks_label.setText(str(tracks))


# ------------------------------------------------------------------------
# Recorder Panel - KOMPAKT & RESPONSIV!
# ------------------------------------------------------------------------
class RecorderPanel(QFrame):
    
    recording_started = Signal(str)
    recording_stopped = Signal(dict)
    recording_saved = Signal(str)
    recording_loaded = Signal(dict)
    
    def __init__(self, parent=None, debug_level=1):
        super().__init__(parent)
        
        self.setFrameStyle(QFrame.StyledPanel)
        self.setStyleSheet(f"""
            QFrame {{
                background-color: white;
                border: 2px solid {Theme.ACCENT.name()};
                border-radius: 8px;
            }}
        """)
        
        # Size Policy für Responsivität
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        
        self.debug_level = debug_level
        self.is_recording = False
        self.session_name = None
        self.recording_start_time = 0.0
        self.current_session = None
        self.editor_window = None
        self._waiting_for_save = False
        self._save_filepath = None
        
        # Timer
        self.duration_timer = QTimer()
        self.duration_timer.timeout.connect(self._update_duration)
        self.duration_timer.setInterval(100)
        
        self.status_timer = QTimer()
        self.status_timer.timeout.connect(self._check_engine_messages)
        self.status_timer.setInterval(100)
        
        self._setup_ui()
        self._init_recorder()
        self.status_timer.start()
    
    def _debug(self, msg):
        if self.debug_level >= 1:
            print(f"[RECORDER] {msg}")
    
    def _setup_ui(self):
        """KOMPAKTES Layout"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(8)
        
        # ============ ZEILE 1: STATUS + SESSION ============
        status_row = QHBoxLayout()
        status_row.setSpacing(10)
        
        # Kompaktes Status-Widget
        self.status_widget = CompactStatusWidget()
        status_row.addWidget(self.status_widget, 3)  # 3/4 der Breite
        
        # Session-Auswahl kompakt
        session_frame = QFrame()
        session_frame.setFrameStyle(QFrame.StyledPanel)
        session_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {Theme.BACKGROUND_MEDIUM.name()};
                border: 1px solid {Theme.BORDER_MEDIUM.name()};
                border-radius: 5px;
                padding: 3px;
            }}
        """)
        session_layout = QHBoxLayout(session_frame)
        session_layout.setContentsMargins(5, 3, 5, 3)
        session_layout.setSpacing(5)
        
        session_layout.addWidget(QLabel("Session:"))
        self.cmb_session = QComboBox()
        self.cmb_session.setEditable(True)
        self.cmb_session.setMinimumWidth(150)
        self.cmb_session.addItem(f"Recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        self.cmb_session.setCurrentIndex(0)
        session_layout.addWidget(self.cmb_session)
        
        status_row.addWidget(session_frame, 1)  # 1/4 der Breite
        main_layout.addLayout(status_row)
        
        # ============ ZEILE 2: RECORD BUTTON + EXPORT ============
        control_row = QHBoxLayout()
        control_row.setSpacing(8)
        
        # RECORD Button - dominanter!
        self.btn_record = QPushButton("● RECORD")
        self.btn_record.setCheckable(True)
        self.btn_record.setMinimumHeight(45)
        self.btn_record.setStyleSheet(f"""
            QPushButton {{
                background-color: #666666;
                color: white;
                font-weight: bold;
                font-size: 14pt;
                border: 2px solid #444444;
                border-radius: 6px;
                padding: 8px 15px;
            }}
            QPushButton:checked {{
                background-color: #ff0000;
                border: 2px solid #aa0000;
            }}
            QPushButton:hover {{
                background-color: #ff4444;
            }}
        """)
        self.btn_record.clicked.connect(self.toggle_recording)
        control_row.addWidget(self.btn_record, 2)  # Nimmt mehr Platz
        
        # Export-Gruppe kompakt
        export_frame = QFrame()
        export_frame.setFrameStyle(QFrame.StyledPanel)
        export_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {Theme.BACKGROUND_MEDIUM.name()};
                border: 1px solid {Theme.BORDER_MEDIUM.name()};
                border-radius: 5px;
                padding: 3px;
            }}
        """)
        export_layout = QHBoxLayout(export_frame)
        export_layout.setContentsMargins(5, 3, 5, 3)
        export_layout.setSpacing(5)
        
        # Dezimierung klein
        export_layout.addWidget(QLabel("1/"))
        self.spin_decimate = QSpinBox()
        self.spin_decimate.setRange(1, 240)
        self.spin_decimate.setValue(1)
        self.spin_decimate.setFixedWidth(50)
        export_layout.addWidget(self.spin_decimate)
        
        # Buttons kompakt
        self.btn_save = QPushButton("💾 Save")
        self.btn_save.setFixedHeight(28)
        self.btn_save.setStyleSheet(f"""
            QPushButton {{
                background-color: {Theme.PRIMARY.name()};
                color: white;
                font-weight: bold;
                font-size: 9pt;
                border-radius: 4px;
                padding: 3px 8px;
            }}
            QPushButton:hover {{
                background-color: {Theme.PRIMARY_DARK.name()};
            }}
        """)
        self.btn_save.clicked.connect(self.save_recording)
        export_layout.addWidget(self.btn_save)
        
        self.btn_load = QPushButton("📂 Load")
        self.btn_load.setFixedHeight(28)
        self.btn_load.setStyleSheet(f"""
            QPushButton {{
                background-color: {Theme.SECONDARY.name()};
                color: white;
                font-weight: bold;
                font-size: 9pt;
                border-radius: 4px;
                padding: 3px 8px;
            }}
            QPushButton:hover {{
                background-color: {Theme.SECONDARY_DARK.name()};
            }}
        """)
        self.btn_load.clicked.connect(self.load_recording)
        export_layout.addWidget(self.btn_load)
        
        # Editor Button klein
        self.btn_editor = QPushButton("✏️ Edit")
        self.btn_editor.setFixedHeight(28)
        self.btn_editor.setStyleSheet(f"""
            QPushButton {{
                background-color: {Theme.ACCENT.name()};
                color: white;
                font-weight: bold;
                font-size: 9pt;
                border-radius: 4px;
                padding: 3px 8px;
            }}
            QPushButton:hover {{
                background-color: {Theme.ACCENT_DARK.name()};
            }}
        """)
        self.btn_editor.clicked.connect(self.open_editor)
        export_layout.addWidget(self.btn_editor)
        
        control_row.addWidget(export_frame, 3)  # Nimmt weniger Platz
        main_layout.addLayout(control_row)
    
    # --------------------------------------------------------------------
    # RECORDER FUNKTIONEN (unverändert)
    # --------------------------------------------------------------------
    
    def _init_recorder(self):
        if ipc.is_running():
            ipc.send("init_recorder")
    
    def toggle_recording(self):
        if not ipc.is_running():
            QMessageBox.warning(self, "Fehler", "Engine läuft nicht!")
            self.btn_record.setChecked(False)
            return
        
        if self.btn_record.isChecked():
            session_name = self.cmb_session.currentText().strip()
            if not session_name:
                session_name = f"Recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                self.cmb_session.setCurrentText(session_name)
            
            self._debug(f"🔴 START: {session_name}")
            ipc.send("start_recording", session_name=session_name)
            
            self.is_recording = True
            self.session_name = session_name
            self.recording_start_time = time.time()
            
            self.status_widget.update_status(
                is_recording=True,
                session_name=session_name,
                duration=0.0,
                tracks=4
            )
            
            self.duration_timer.start()
            self.recording_started.emit(session_name)
            
        else:
            self._debug("⏹ STOP")
            ipc.send("stop_recording")
            
            duration = time.time() - self.recording_start_time
            self.is_recording = False
            
            self.status_widget.update_status(
                is_recording=False,
                session_name=self.session_name,
                duration=duration,
                tracks=4
            )
            
            self.duration_timer.stop()
            self.recording_stopped.emit({"duration": duration})
    
    def _update_duration(self):
        if self.is_recording:
            duration = time.time() - self.recording_start_time
            self.status_widget.duration_label.setText(f"{duration:.1f}s")
    
    def save_recording(self):
        if not ipc.is_running():
            QMessageBox.warning(self, "Fehler", "Engine läuft nicht!")
            return
        
        default_name = self.session_name or f"recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        default_path = f"{default_name}.json"
        
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Recording speichern", default_path, "JSON (*.json)"
        )
        if not filepath:
            return
        
        self._debug(f"💾 Speichere: {filepath}")
        
        self._waiting_for_save = True
        self._save_filepath = filepath
        
        ipc.send(
            "save_recording",
            filepath=filepath,
            trim_start=0.0,
            trim_end=1.0,
            normalize=True,
            decimate=self.spin_decimate.value()
        )
        
        QTimer.singleShot(3000, self._check_save_timeout)
    
    def _check_save_timeout(self):
        if self._waiting_for_save:
            self._waiting_for_save = False
            QMessageBox.information(
                self, "Recording gespeichert",
                f"✅ {self._save_filepath}\n\n• Datei wurde gespeichert"
            )
    
    def load_recording(self):
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Recording laden", "", "JSON (*.json)"
        )
        if not filepath:
            return
        
        if not ipc.is_running():
            ipc.start_engine(debug_level=1)
            time.sleep(0.5)
        
        self._debug(f"📂 Lade: {filepath}")
        ipc.send("load_recording", filepath=filepath)
        self.recording_loaded.emit({"filepath": filepath})
    
    def open_editor(self):
        try:
            from tsde_engine.editor_gui.editor_panel import EditorPanel
            from PySide6.QtWidgets import QMainWindow
            from PySide6.QtCore import Qt

            # Falls Editor schon offen → nach vorne holen
            if hasattr(self, 'editor_window') and self.editor_window and self.editor_window.isVisible():
                self.editor_window.raise_()
                self.editor_window.activateWindow()
                return

            # NEU: Editor-Fenster als TOP-LEVEL Fenster (ganz ohne Parent)
            self.editor_window = QMainWindow()
            self.editor_window.setWindowTitle("🎨 TSDE Editor")
            self.editor_window.resize(1400, 900)
            
            # 🔥 ALLE Vererbung verhindern
            self.editor_window.setAttribute(Qt.WA_StyledBackground, True)
            self.editor_window.setStyleSheet("")  # Stylesheet leeren
            
            # EditorPanel einbetten
            self.editor = EditorPanel()
            self.editor_window.setCentralWidget(self.editor)
            
            # 🔥 Editor-Panel zwingen, sein eigenes Theme zu laden
            self.editor.setStyleSheet("")  # Auch hier Stylesheet leeren
            self.editor.update()
            
            self.editor_window.show()

        except Exception as e:
            self._debug(f"❌ Editor Fehler: {e}")
            QMessageBox.critical(self, "Fehler", f"Editor konnte nicht geöffnet werden:\n{e}")
    
    def _check_engine_messages(self):
        if not ipc.is_running():
            return
        
        messages = ipc.poll_recorder()
        if messages:
            self._process_messages(messages)
    
    def _process_messages(self, messages):
        if messages.get('recording_saved'):
            data = messages['recording_saved']
            if data.get('success') and self._waiting_for_save:
                self._waiting_for_save = False
                samples = data.get('total_samples', 0)
                duration = data.get('duration', 0.0)
                tracks = data.get('tracks', 4)
                filepath = data.get('filepath', self._save_filepath)
                
                self._debug(f"✅ Engine bestätigt: {samples} Samples, {duration:.1f}s, {tracks} Tracks")
                
                QMessageBox.information(
                    self, "Recording gespeichert",
                    f"✅ {filepath}\n\n"
                    f"• {samples:,} Samples\n"
                    f"• {duration:.1f}s\n"
                    f"• {tracks} Tracks"
                )
                self.recording_saved.emit(filepath)
        
        elif messages.get('recording_loaded'):
            data = messages['recording_loaded']
            if data.get('success'):
                session_name = data.get('session_name')
                samples = data.get('total_samples', 0)
                duration = data.get('duration', 0.0)
                tracks = data.get('tracks', 4)
                
                self._debug(f"📂 Geladen: {session_name} ({samples} Samples)")
                
                QMessageBox.information(
                    self, "Recording geladen",
                    f"✅ {session_name}\n\n"
                    f"• {samples:,} Samples\n"
                    f"• {duration:.1f}s\n"
                    f"• {tracks} Tracks"
                )
    
    def closeEvent(self, event):
        self.duration_timer.stop()
        self.status_timer.stop()
        event.accept()


# ------------------------------------------------------------------------
# Factory-Funktion
# ------------------------------------------------------------------------
def create_recorder_panel(parent=None, debug_level=1):
    return RecorderPanel(parent, debug_level)