# tsde_gui/gui_main.py

import sys
from PySide6.QtWidgets import QApplication
from tsde_gui.layout import EngineTerminal

def start_gui():
    app = QApplication(sys.argv)
    win = EngineTerminal()
    win.show()
    sys.exit(app.exec())