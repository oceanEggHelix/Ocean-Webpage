from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, Signal, QRect, QPoint
from PySide6.QtGui import QPainter, QPen, QColor, QBrush, QFont, QLinearGradient, QPolygon


class TimelineWidget(QWidget):
    position_changed = Signal(float)
    zoom_changed = Signal(float, float)  # Signal für Zoom-Änderungen

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(60)

        self.duration = 0.0
        self.current_pos = 0.0
        self.dragging = False
        
        # Zoom-Bereich (normalisiert 0-1)
        self.zoom_start = 0.0
        self.zoom_end = 1.0
        
        # Für Zoom per Maus
        self.zoom_dragging = False
        self.zoom_start_x = 0
        
        # Einheitliches Padding
        self.PADDING = 8
        self.TICK_HEIGHT = 10
        self.MARKER_SIZE = 8

        # Farben
        self.bg_start = QColor(40, 40, 45)
        self.bg_end = QColor(30, 30, 35)
        self.tick_color = QColor(100, 100, 110)
        self.text_color = QColor(200, 200, 210)
        self.marker_color = QColor(255, 120, 120)
        self.border_color = QColor(70, 70, 80)
        self.zoom_color = QColor(100, 200, 255, 50)  # Halbtransparentes Blau für Zoom-Bereich

    def set_duration(self, duration):
        self.duration = duration
        self.update()

    def set_position(self, pos):
        self.current_pos = max(0.0, min(1.0, pos))
        self.update()
        
    def set_zoom_range(self, start, end):
        """Setzt den sichtbaren Zoom-Bereich"""
        self.zoom_start = max(0.0, min(1.0, start))
        self.zoom_end = max(0.0, min(1.0, end))
        if self.zoom_end <= self.zoom_start:
            self.zoom_end = self.zoom_start + 0.01
        self.update()

    def get_content_rect(self):
        """Gibt den inneren Bereich ohne Padding zurück"""
        return self.rect().adjusted(self.PADDING, self.PADDING, 
                                   -self.PADDING, -self.PADDING)
                                   
    def map_t_to_x(self, t, content_rect):
        """Konvertiert globale Zeit t zu x-Position im Widget (mit Zoom)"""
        # t ist im globalen Bereich 0-1
        # Zoom: nur Bereich zwischen zoom_start und zoom_end ist sichtbar
        
        if t < self.zoom_start:
            return content_rect.left()
        if t > self.zoom_end:
            return content_rect.right()
            
        # t im sichtbaren Bereich auf Widget-Breite mappen
        visible_range = self.zoom_end - self.zoom_start
        t_visible = (t - self.zoom_start) / visible_range
        
        return content_rect.left() + t_visible * content_rect.width()
        
    def map_x_to_t(self, x, content_rect):
        """Konvertiert x-Position im Widget zu globaler Zeit t"""
        # Relative Position im Widget
        rel_x = (x - content_rect.left()) / content_rect.width()
        rel_x = max(0.0, min(1.0, rel_x))
        
        # Auf globalen Bereich mappen
        visible_range = self.zoom_end - self.zoom_start
        return self.zoom_start + rel_x * visible_range

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Hintergrund mit Farbverlauf
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, self.bg_start)
        gradient.setColorAt(1, self.bg_end)
        painter.fillRect(self.rect(), gradient)

        # Rahmen
        painter.setPen(QPen(self.border_color, 1))
        painter.drawRect(self.rect().adjusted(0, 0, -1, -1))

        # Content-Bereich (für Ticks und Marker)
        content_rect = self.get_content_rect()
        w = content_rect.width()
        h = content_rect.height()

        # Zoom-Bereich hervorheben (optional)
        # painter.fillRect(content_rect, QBrush(self.zoom_color))

        # Ticks und Zeitangaben
        painter.setPen(QPen(self.tick_color, 1))
        font = painter.font()
        font.setPointSize(8)
        painter.setFont(font)

        # Ticks im sichtbaren Zoom-Bereich
        num_ticks = 11  # Anzahl Ticks im sichtbaren Bereich
        for i in range(num_ticks):
            t_visible = i / (num_ticks - 1)
            # Globale Zeit basierend auf Zoom
            t = self.zoom_start + t_visible * (self.zoom_end - self.zoom_start)
            
            # x-Position mit Zoom-Funktion
            x = self.map_t_to_x(t, content_rect)
            
            # Tick zeichnen
            painter.drawLine(int(x), content_rect.bottom() - self.TICK_HEIGHT, 
                           int(x), content_rect.bottom() - 4)

            # Zeitangabe
            if self.duration > 0:
                time_sec = t * self.duration
                painter.setPen(self.text_color)
                
                # Text zentriert über dem Tick
                text_rect = QRect(int(x - 30), content_rect.top(), 
                                 60, 20)
                painter.drawText(text_rect, Qt.AlignCenter, 
                               f"{time_sec:.1f}s")
                
                painter.setPen(QPen(self.tick_color, 1))

        # Marker-Linie mit Zoom
        marker_x = self.map_t_to_x(self.current_pos, content_rect)
        painter.setPen(QPen(self.marker_color, 2))
        painter.drawLine(marker_x, content_rect.top(), 
                        marker_x, content_rect.bottom())

        # Marker-Kopf (Dreieck)
        painter.setBrush(QBrush(self.marker_color))
        painter.setPen(Qt.NoPen)
        
        # Dreieck als QPolygon erstellen
        points = [
            QPoint(marker_x, content_rect.top() + self.MARKER_SIZE),
            QPoint(marker_x - self.MARKER_SIZE, content_rect.top()),
            QPoint(marker_x + self.MARKER_SIZE, content_rect.top())
        ]
        triangle = QPolygon(points)
        painter.drawPolygon(triangle)

        painter.end()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            # Prüfen ob Alt-Taste für Zoom gedrückt
            if event.modifiers() & Qt.AltModifier:
                self.zoom_dragging = True
                self.zoom_start_x = event.position().x()
            else:
                self.dragging = True
                self._update_position(event.position().x())

    def mouseMoveEvent(self, event):
        if self.zoom_dragging:
            # Zoom-Bereich auswählen
            current_x = event.position().x()
            content_rect = self.get_content_rect()
            
            # Start und Ende des Zoom-Bereichs
            x1 = min(self.zoom_start_x, current_x)
            x2 = max(self.zoom_start_x, current_x)
            
            # In globale Zeiten umrechnen
            t1 = self.map_x_to_t(x1, content_rect)
            t2 = self.map_x_to_t(x2, content_rect)
            
            # Zoom-Bereich setzen
            self.zoom_start = max(0.0, min(1.0, t1))
            self.zoom_end = max(0.0, min(1.0, t2))
            if self.zoom_end <= self.zoom_start:
                self.zoom_end = self.zoom_start + 0.01
                
            self.zoom_changed.emit(self.zoom_start, self.zoom_end)
            self.update()
            
        elif self.dragging:
            self._update_position(event.position().x())

    def mouseReleaseEvent(self, event):
        self.dragging = False
        self.zoom_dragging = False

    def wheelEvent(self, event):
        """Mausrad für Zoom (mit Strg)"""
        if event.modifiers() & Qt.ControlModifier:
            # Zoom mit Mausrad
            zoom_factor = 1.1
            if event.angleDelta().y() > 0:
                # Reinzoomen
                new_range = (self.zoom_end - self.zoom_start) / zoom_factor
            else:
                # Rauszoomen
                new_range = (self.zoom_end - self.zoom_start) * zoom_factor
                new_range = min(1.0, new_range)
            
            # Um Mausposition zentrieren
            content_rect = self.get_content_rect()
            mouse_x = event.position().x()
            t_center = self.map_x_to_t(mouse_x, content_rect)
            
            self.zoom_start = max(0.0, t_center - new_range / 2)
            self.zoom_end = min(1.0, t_center + new_range / 2)
            
            # Korrigieren falls außerhalb
            if self.zoom_start < 0:
                self.zoom_start = 0
                self.zoom_end = new_range
            if self.zoom_end > 1:
                self.zoom_end = 1
                self.zoom_start = 1 - new_range
                
            self.zoom_changed.emit(self.zoom_start, self.zoom_end)
            self.update()
        else:
            # Normales Scrollen (Position ändern)
            step = 0.05
            if event.angleDelta().y() > 0:
                self.current_pos = min(1.0, self.current_pos + step)
            else:
                self.current_pos = max(0.0, self.current_pos - step)
            self.position_changed.emit(self.current_pos)
            self.update()

    def _update_position(self, x):
        content_rect = self.get_content_rect()
        # Position mit Zoom berücksichtigen
        t = self.map_x_to_t(x, content_rect)
        self.current_pos = max(0.0, min(1.0, t))
        self.position_changed.emit(self.current_pos)
        self.update()