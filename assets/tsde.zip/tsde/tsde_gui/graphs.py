from PySide6.QtWidgets import QWidget, QSizePolicy, QVBoxLayout, QSplitter
from PySide6.QtGui import QPainter, QPen, QLinearGradient, QBrush, QColor, QMouseEvent
from PySide6.QtCore import Qt, QRectF, QPoint, Signal
import numpy as np
from enum import Enum
from scipy import interpolate, signal  # Für Spline und Filter

from tsde_gui.theme import Theme  # Theme importieren


# ------------------------------------------------------------
# PEDAL-MODUS ENUM
# ------------------------------------------------------------
class PedalMode(Enum):
    SAMPLES = "Samples"           # Alle recorded Samples
    SPLINE = "Spline"             # Interpolierter Spline mit Stützpunkten
    FILTERED = "Gefiltert"        # Gefilterte Version
    SMOOTHED = "Geglättet"        # Einfach geglättet (Moving Average)


# ------------------------------------------------------------
# SPLITTER-WIDGET FÜR GRAPH-GRUPPE
# ------------------------------------------------------------
class GraphGroup(QWidget):
    """Container für CurveGraph und PedalGraph mit vertikalem Splitter"""
    
    height_changed = Signal()  # Signal wenn Höhen sich ändern
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Splitter erstellen
        self.splitter = QSplitter(Qt.Vertical)
        self.splitter.setHandleWidth(6)
        self.splitter.setChildrenCollapsible(False)
        
        # Style für Splitter-Handle
        self.splitter.setStyleSheet("""
            QSplitter::handle {
                background-color: #cccccc;
                border: 1px solid #aaaaaa;
                height: 6px;
            }
            QSplitter::handle:hover {
                background-color: #999999;
            }
            QSplitter::handle:pressed {
                background-color: #666666;
            }
        """)
        
        # Graphen erstellen
        self.curve_graph = CurveGraph()
        self.pedal_graph = PedalGraph()
        
        # Zum Splitter hinzufügen
        self.splitter.addWidget(self.curve_graph)
        self.splitter.addWidget(self.pedal_graph)
        
        # Standard-Höhen setzen (2:1 Verhältnis)
        total_height = 220  # 140 + 80
        self.splitter.setSizes([140, 80])
        
        layout.addWidget(self.splitter)
        
        # Splitter-Signal verbinden
        self.splitter.splitterMoved.connect(self._on_splitter_moved)
    
    def _on_splitter_moved(self, pos, index):
        """Wird aufgerufen wenn Splitter bewegt wird"""
        self.height_changed.emit()
    
    def set_track(self, track):
        """Setzt Track für beide Graphen"""
        self.curve_graph.track = track
        self.pedal_graph.set_track(track)
    
    def set_curve(self, curve, track=None):
        """Setzt Curve für CurveGraph"""
        self.curve_graph.set_curve(curve, track)
    
    def set_marker(self, t_global):
        #print(f"CurveGraph.set_marker: {t_global:.4f}")
        """Setzt Marker-Position für beide Graphen"""
        self.curve_graph.set_marker(t_global)
        self.pedal_graph.set_marker(t_global)
    
    def set_content_width(self, width):
        """Setzt Breite für beide Graphen"""
        self.curve_graph.setFixedWidth(width + 16)  # 2 * PADDING
        self.pedal_graph.set_content_width(width)
    
    def set_zoom_range(self, start, end):
        """Setzt Zoom-Bereich für beide Graphen"""
        self.curve_graph.set_zoom_range(start, end)
        self.pedal_graph.set_zoom_range(start, end)
    
    def get_heights(self):
        """Gibt aktuelle Höhen zurück"""
        return self.splitter.sizes()
    
    def set_heights(self, heights):
        """Setzt Höhen (Liste mit 2 Werten)"""
        if len(heights) == 2:
            self.splitter.setSizes(heights)
    
    def reset_heights(self):
        """Setzt Höhen auf Standard zurück"""
        self.splitter.setSizes([140, 80])


# ------------------------------------------------------------
# BASIS-GRAPH (mit fix für rechten Rand)
# ------------------------------------------------------------
class BaseGraph(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        # Einheitliches Padding
        self.PADDING = 8
        
        # Zoom-Bereich (normalisiert 0-1)
        self.zoom_start = 0.0
        self.zoom_end = 1.0
        
        # Farben aus dem Theme
        self.bg_start = Theme.BACKGROUND_DARK
        self.bg_end = Theme.BACKGROUND_LIGHT
        self.border_color = Theme.BORDER_MEDIUM
        self.text_color = Theme.TEXT_SECONDARY
        self.grid_color = Theme.BORDER_LIGHT

        # Wichtig: Größenpolitik ändern für dynamische Höhe
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        
        self.content_width = 0

    def set_content_width(self, width):
        """Setzt die Breite des Inhaltsbereichs (ohne Padding)"""
        self.content_width = width
        # +1 Pixel extra für den rechten Rand (Fix für abgeschnittene Linien)
        total_width = width + 2 * self.PADDING 
        self.setFixedWidth(total_width)
        
    def set_zoom_range(self, start, end):
        """Setzt den sichtbaren Zoom-Bereich (normalisiert 0-1)"""
        self.zoom_start = max(0.0, min(1.0, start))
        self.zoom_end = max(0.0, min(1.0, end))
        if self.zoom_end <= self.zoom_start:
            self.zoom_end = self.zoom_start + 0.01
        self.update()

    def get_content_rect(self):
        """Gibt den inneren Bereich ohne Padding zurück"""
        # +1 Pixel für den rechten Rand (damit Linien bis zum Rand gehen)
        return self.rect().adjusted(self.PADDING, self.PADDING, 
                                   -self.PADDING + 1, -self.PADDING)

    def map_x_to_t(self, x, content_rect):
        """Konvertiert x-Position zu normalisierter Zeit (0-1)"""
        if x < content_rect.left():
            return 0.0
        if x > content_rect.right():
            return 1.0
        
        t_visible = (x - content_rect.left()) / content_rect.width()
        return self.zoom_start + t_visible * (self.zoom_end - self.zoom_start)

    def draw_background(self, painter):
        """Zeichnet den Hintergrund mit Farbverlauf und Rahmen"""
        rect = self.rect()
        
        gradient = QLinearGradient(rect.topLeft(), rect.bottomLeft())
        gradient.setColorAt(0, self.bg_start)
        gradient.setColorAt(1, self.bg_end)
        painter.fillRect(rect, gradient)

        painter.setPen(QPen(self.border_color, 1))
        painter.drawRect(rect.adjusted(0, 0, -1, -1))

    def draw_grid(self, painter, content_rect):
        """Zeichnet ein dezentes Raster im Hintergrund"""
        painter.setPen(QPen(self.grid_color, 1, Qt.DotLine))
        
        for i in range(1, 4):
            y = content_rect.top() + i * content_rect.height() / 4
            painter.drawLine(content_rect.left(), int(y), 
                           content_rect.right(), int(y))
    
    def map_t_to_x(self, t, content_rect):
        """Konvertiert globale Zeit t zu x-Position im Widget (mit Zoom)"""
        if t < self.zoom_start:
            return content_rect.left()
        if t > self.zoom_end:
            return content_rect.right()
            
        visible_range = self.zoom_end - self.zoom_start
        t_visible = (t - self.zoom_start) / visible_range
        
        return content_rect.left() + t_visible * content_rect.width()


# ------------------------------------------------------------
# GEO-KURVE (einfach wie Live-Widget)
# ------------------------------------------------------------
class CurveGraph(QWidget):  # NICHT von BaseGraph erben!
    def __init__(self, parent=None):
        super().__init__(parent)

        self.curve = None
        self.track = None
        self.t_current = 0.0  # Aktuelle Position (0-1)
        
        # Theme-Farben
        self.curve_color = Theme.GRAPH_CURVE
        self.marker_color = Theme.GRAPH_MARKER
        self.grid_color = Theme.GRAPH_GRID
        self.background_color = Theme.GRAPH_BACKGROUND
        self.axis_color = Theme.GRAPH_AXIS
        
        # Skalierung
        self.min_y = -1
        self.max_y = 1
        
        self.setMinimumHeight(150)

    def set_curve(self, curve, track=None):
        self.curve = curve
        self.track = track

        if curve:
            y_vals = []
            for i in range(200):
                t = i / 199
                try:
                    y_vals.append(curve.evaluate(t).x)
                except:
                    pass

            if y_vals:
                self.min_y = min(y_vals)
                self.max_y = max(y_vals)
                pad = (self.max_y - self.min_y) * 0.1
                self.min_y -= pad
                self.max_y += pad

        self.update()

    def set_marker(self, t_pos):
        """t_pos ist die Position auf der Kurve (0-1)"""
        self.t_current = max(0.0, min(1.0, t_pos))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Hintergrund
        painter.fillRect(self.rect(), self.background_color)

        w = self.width()
        h = self.height()

        if not self.curve:
            painter.setPen(self.axis_color)
            painter.drawText(self.rect(), Qt.AlignCenter, "Keine Kurve geladen")
            return

        # Gitter
        self._draw_grid(painter, w, h)

        # Achsen
        self._draw_axes(painter, w, h)

        # Kurve
        self._draw_curve(painter, w, h)

        # Marker
        self._draw_marker(painter, w, h)

        # Info
        self._draw_info(painter, w, h)

    def _draw_grid(self, painter, w, h):
        painter.setPen(QPen(self.grid_color, 1, Qt.DotLine))
        for i in range(1, 10):
            x = i * w / 10
            y = i * h / 10
            painter.drawLine(int(x), 0, int(x), h)
            painter.drawLine(0, int(y), w, int(y))

    def _draw_axes(self, painter, w, h):
        painter.setPen(QPen(self.axis_color, 2))
        painter.drawLine(0, h, w, h)  # X-Achse
        painter.drawLine(0, 0, 0, h)  # Y-Achse

        painter.setPen(self.axis_color)
        
        # Y-Achse
        for i in range(0, 11, 2):
            y = int((1 - i/10) * h)
            value = self.min_y + (self.max_y - self.min_y) * i/10
            painter.drawText(5, y + 15, f"{value:.1f}")

        # X-Achse
        for i in range(0, 11, 2):
            x = int(i * w / 10)
            value = i/10
            painter.drawText(x - 10, h - 5, f"{value:.1f}")
        painter.drawText(w - 40, h - 5, "Position auf Kurve (t)")

    def _draw_curve(self, painter, w, h):
        painter.setPen(QPen(self.curve_color, 2))
        
        pts = []
        for i in range(200):
            t = i / 199
            try:
                p = self.curve.evaluate(t)
                x = int(t * w)
                y_norm = (p.x - self.min_y) / (self.max_y - self.min_y)
                y = int(h - y_norm * h)
                pts.append((x, y))
            except:
                pass

        for i in range(len(pts) - 1):
            painter.drawLine(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])

    def _draw_marker(self, painter, w, h):
        marker_x = int(self.t_current * w)
        
        # Marker-Linie
        painter.setPen(QPen(self.marker_color, 2))
        painter.drawLine(marker_x, 0, marker_x, h)

        try:
            p = self.curve.evaluate(self.t_current)
            y_norm = (p.x - self.min_y) / (self.max_y - self.min_y)
            point_y = int(h - y_norm * h)
            
            # Punkt auf Kurve
            painter.setBrush(QBrush(self.marker_color))
            painter.drawEllipse(marker_x - 5, point_y - 5, 10, 10)
            
            # Verbindungslinie
            painter.setPen(QPen(self.marker_color, 1, Qt.DashLine))
            painter.drawLine(marker_x, point_y, marker_x, h)
            
            # Wert
            painter.setPen(self.axis_color)
            painter.drawText(marker_x + 5, point_y - 10, f"X={p.x:.1f}")
            
        except:
            pass

    def _draw_info(self, painter, w, h):
        if not self.track:
            return
            
        painter.setPen(self.axis_color)
        title = f"Track: {self.track.name}"
        if hasattr(self.curve, 'length_total'):
            title += f" | Länge: {self.curve.length_total:.1f} mm"
        painter.drawText(50, 20, title)
        
        pos_text = f"t={self.t_current:.3f}"
        try:
            p = self.curve.evaluate(self.t_current)
            pos_text += f" | X={p.x:.1f} mm"
        except:
            pass
        painter.drawText(50, 40, pos_text)


# ------------------------------------------------------------
# PEDAL-KURVE (mit X-Verschiebung) - ZEITBASIERT!
# ------------------------------------------------------------
class PedalGraph(BaseGraph):
    mode_changed = Signal(PedalMode)
    spline_points_updated = Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)

        self.track = None
        self.marker_pos = 0.0  # Zeit-Position (0-1) von der Timeline
        
        # Daten für die Anzeige (über die Zeit)
        self.time_data = None   # Zeitstempel für x-Achse
        self.pedal_data = None  # Referenz auf track.pedals (keine Kopie!)
        
        # Modi
        self.mode = PedalMode.SAMPLES
        self.filter_strength = 0.1
        self.spline_points = []      # Stützpunkte für Spline (Zeit, Wert)
        self.spline_resolution = 500
        
        # Bearbeitungs-Variablen
        self.dragging = False
        self.drag_index = -1
        self.point_radius = 5
        self.hover_index = -1
        self.editing_spline = True
        self.x_movable = True

        self.setMouseTracking(True)

        # Theme-Farben
        self.curve_color = Theme.ACCENT
        self.marker_color = Theme.ACCENT_DARK
        self.zero_line_color = Theme.BORDER_DARK
        self.fill_color = QColor("#ff6b6b50")
        self.point_color = Theme.ACCENT
        self.hover_color = QColor("#ffaa00")
        self.drag_color = QColor("#ffff00")
        self.sample_color = QColor("#888888")
        self.spline_control_color = QColor("#ffaa00")

    def set_track(self, track):
        """Setzt Track und bereitet Zeitdaten für x-Achse vor"""
        self.track = track
        self.dragging = False
        self.drag_index = -1
        self.hover_index = -1
        self.spline_points = []
        
        # 🔥 WICHTIG: track.pedals MUSS existieren!
        if track and hasattr(track, 'pedals') and track.pedals is not None:
            num_samples = len(track.pedals)
            
            # 🔥 Zeitachse von 0 bis 1
            self.time_data = np.linspace(0, 1, num_samples)
            
            # 🔥 WICHTIG: Das ist eine REFERENZ, keine Kopie!
            self.pedal_data = track.pedals
            
            # 🔥 Stelle sicher dass es eine Liste ist (für einfache Manipulation)
            if isinstance(self.pedal_data, np.ndarray):
                self.pedal_data = self.pedal_data.tolist()
                track.pedals = self.pedal_data  # Auch im Track aktualisieren!
            
            print(f"✅ PedalGraph: {len(self.time_data)} Samples")
            print(f"   Pedalbereich: {min(self.pedal_data):.3f} bis {max(self.pedal_data):.3f}")
            print(f"   ID der pedal_data: {id(self.pedal_data)}")
        else:
            self.time_data = None
            self.pedal_data = None
            print("❌ PedalGraph: Keine Daten")
        
        self.update()

    def set_marker(self, t_global):
        """
        Setzt die Marker-Position.
        t_global ist die normierte Zeit (0-1) von der Timeline!
        """
        if not self.track:
            return

        self.marker_pos = max(0.0, min(1.0, t_global))
        self.update()
    
    def set_mode(self, mode: PedalMode):
        self.mode = mode
        self.update()
        self.mode_changed.emit(mode)
    
    def set_filter_strength(self, strength):
        self.filter_strength = max(0.01, min(0.5, strength))
        self.update()
    
    def set_x_movable(self, movable):
        self.x_movable = movable
    
    def generate_spline_from_samples(self, num_points=10):
        """Generiert Stützpunkte aus den Samples (für initialen Spline)"""
        if self.time_data is None or self.pedal_data is None:
            return
        
        # Für Spline brauchen wir Zeit als x-Achse
        times = self.time_data
        pedals = self.pedal_data
        
        if len(times) < 2:
            return
        
        # Gleichmäßig verteilte Punkte über die Zeit
        indices = np.linspace(0, len(times)-1, num_points, dtype=int)
        self.spline_points = [
            (float(times[i]), float(pedals[i])) for i in indices
        ]
        self.spline_points_updated.emit()
        self.update()
    
    def apply_spline(self):
        """Wendet den Spline auf die Track-Daten an"""
        if self.time_data is None or len(self.spline_points) < 2:
            return
        
        points = sorted(self.spline_points, key=lambda p: p[0])
        times = [p[0] for p in points]
        values = [p[1] for p in points]
        
        try:
            if len(points) >= 4:
                spline = interpolate.CubicSpline(times, values, bc_type='natural')
            else:
                spline = interpolate.interp1d(times, values, kind='linear', 
                                            fill_value='extrapolate')
            
            # Wende auf originale Sample-Zeiten an
            new_pedals = spline(self.time_data)
            new_pedals = np.clip(new_pedals, -1.0, 1.0)
            
            # 🔥 ALLE Arrays aktualisieren
            for i in range(len(new_pedals)):
                if i < len(self.pedal_data):
                    self.pedal_data[i] = new_pedals[i]
                if hasattr(self.track, 'current_pedals') and i < len(self.track.current_pedals):
                    self.track.current_pedals[i] = new_pedals[i]
            
            print(f"✅ Spline angewendet: Neuer Pedalbereich: {min(self.pedal_data):.3f} bis {max(self.pedal_data):.3f}")
            
            self.update()
            
        except Exception as e:
            print(f"Spline-Fehler: {e}")
    
    def apply_filter(self, filter_type='lowpass'):
        """Wendet Filter auf Pedaldaten an"""
        if self.pedal_data is None:
            return
        
        pedals = np.array(self.pedal_data)
        
        if filter_type == 'lowpass':
            b = signal.firwin(31, self.filter_strength)
            filtered = signal.filtfilt(b, 1, pedals)
        elif filter_type == 'median':
            kernel_size = max(3, int(21 * self.filter_strength))
            if kernel_size % 2 == 0:
                kernel_size += 1
            filtered = signal.medfilt(pedals, kernel_size)
        elif filter_type == 'savgol':
            window = max(5, int(31 * self.filter_strength))
            if window % 2 == 0:
                window += 1
            order = min(3, window-2)
            filtered = signal.savgol_filter(pedals, window, order)
        else:  # Moving Average
            window = max(3, int(21 * self.filter_strength))
            filtered = np.convolve(pedals, np.ones(window)/window, mode='same')
        
        # 🔥 ALLE Arrays aktualisieren
        for i in range(len(filtered)):
            if i < len(self.pedal_data):
                self.pedal_data[i] = filtered[i]
            if hasattr(self.track, 'current_pedals') and i < len(self.track.current_pedals):
                self.track.current_pedals[i] = filtered[i]
        
        self.update()
    
    def add_spline_point(self, t, value):
        """Fügt einen neuen Stützpunkt hinzu (t ist Zeit!)"""
        self.spline_points.append((t, value))
        self.spline_points = sorted(self.spline_points, key=lambda p: p[0])
        self.spline_points_updated.emit()
        self.update()
    
    def remove_spline_point(self, index):
        if 0 <= index < len(self.spline_points):
            del self.spline_points[index]
            self.spline_points_updated.emit()
            self.update()
    
    def _get_display_curve(self):
        """Gibt die anzuzeigenden Daten basierend auf Modus zurück"""
        if self.time_data is None or self.pedal_data is None:
            return [], []
        
        if self.mode == PedalMode.SAMPLES:
            return self.time_data, self.pedal_data
        
        elif self.mode == PedalMode.SPLINE and len(self.spline_points) >= 2:
            # Generiere hochaufgelöste Spline-Kurve über die Zeit
            t_min, t_max = min(self.time_data), max(self.time_data)
            t_dense = np.linspace(t_min, t_max, self.spline_resolution)
            
            points = sorted(self.spline_points, key=lambda p: p[0])
            s_times = [p[0] for p in points]
            s_values = [p[1] for p in points]
            
            try:
                if len(points) >= 4:
                    spline = interpolate.CubicSpline(s_times, s_values, bc_type='natural')
                else:
                    spline = interpolate.interp1d(s_times, s_values, kind='linear',
                                                 fill_value='extrapolate')
                values_dense = spline(t_dense)
                values_dense = np.clip(values_dense, -1.0, 1.0)
                return t_dense, values_dense
            except:
                return self.time_data, self.pedal_data
        
        elif self.mode in [PedalMode.FILTERED, PedalMode.SMOOTHED]:
            # Gefilterte Version - hier bereits in pedal_data
            return self.time_data, self.pedal_data
        
        return self.time_data, self.pedal_data
    
    def _get_points_for_display(self, content_rect, times, values):
        """
        Konvertiert Zeit/Wert-Paare zu Bildschirmkoordinaten.
        times: absolute Zeiten in Sekunden
        values: Pedalwerte -1..1
        """
        if len(times) == 0:
            return []
        
        # Zeitbereich für Normalisierung (0-1 für x-Achse)
        t_min = times[0]
        t_max = times[-1]
        span = max(1e-6, t_max - t_min)
        
        h = content_rect.height()
        y_zero = content_rect.top() + h / 2
        
        pts = []
        for t, v in zip(times, values):
            # Zeit normalisieren (0-1)
            t_norm = (t - t_min) / span
            # x-Position mit Zoom-Funktion
            x = self.map_t_to_x(t_norm, content_rect)
            # y-Position (Pedal -1..1 -> Bildschirm)
            y = y_zero - (v * h / 2)
            pts.append((int(x), int(y)))
        
        return pts

    def _find_spline_point_at_pos(self, pos, content_rect):
        """Findet Spline-Stützpunkt an Position"""
        if not self.spline_points:
            return -1
        
        # Zeitbereich für Normalisierung
        t_min = self.time_data[0] if self.time_data is not None else 0
        t_max = self.time_data[-1] if self.time_data is not None else 1
        span = max(1e-6, t_max - t_min)
        h = content_rect.height()
        y_zero = content_rect.top() + h / 2
        
        for i, (t, v) in enumerate(self.spline_points):
            t_norm = (t - t_min) / span
            x = self.map_t_to_x(t_norm, content_rect)
            y = y_zero - (v * h / 2)
            
            if (pos - QPoint(int(x), int(y))).manhattanLength() < 10:
                return i
        return -1

    def mousePressEvent(self, event: QMouseEvent):
        if self.time_data is None:
            return
            
        content = self.get_content_rect()
        if not content.contains(event.pos()):
            return

        if event.button() == Qt.LeftButton:
            if self.mode == PedalMode.SPLINE and self.editing_spline:
                idx = self._find_spline_point_at_pos(event.pos(), content)
                if idx >= 0:
                    self.dragging = True
                    self.drag_index = idx
                    self.setCursor(Qt.ClosedHandCursor)
                    event.accept()
            else:
                idx = self._find_point_at_pos(event.pos(), content)
                if idx >= 0:
                    self.dragging = True
                    self.drag_index = idx
                    self.setCursor(Qt.ClosedHandCursor)
                    event.accept()

    def mouseDoubleClickEvent(self, event: QMouseEvent):
        """Doppelklick fügt neuen Spline-Punkt hinzu"""
        if self.time_data is None or self.mode != PedalMode.SPLINE or not self.editing_spline:
            super().mouseDoubleClickEvent(event)
            return
        
        content = self.get_content_rect()
        if not content.contains(event.pos()):
            return
        
        # Zeit aus X-Position berechnen
        t_norm = self.map_x_to_t(event.pos().x(), content)
        t_min = self.time_data[0]
        t_max = self.time_data[-1]
        t = t_min + t_norm * (t_max - t_min)
        
        # Pedalwert aus Y-Position berechnen
        h = content.height()
        y_zero = content.top() + h / 2
        value = (y_zero - event.pos().y()) / (h / 2)
        value = max(-1.0, min(1.0, value))
        
        self.add_spline_point(t, value)
        event.accept()

    def _find_point_at_pos(self, pos, content_rect):
        """Findet den Index des Sample-Punkts an der Position"""
        if self.time_data is None:
            return -1
            
        pts = self._get_points_for_display(content_rect, self.time_data, self.pedal_data)
        for i, (x, y) in enumerate(pts):
            if (pos - QPoint(x, y)).manhattanLength() < 10:
                return i
        return -1

    def _sort_spline_points(self):
        if not self.spline_points:
            return
        
        self.spline_points = sorted(self.spline_points, key=lambda p: p[0])
        
        # Sicherstellen dass Punkte im Zeitbereich bleiben
        if self.time_data is not None:
            t_min = self.time_data[0]
            t_max = self.time_data[-1]
            
            for i, (t, v) in enumerate(self.spline_points):
                if t < t_min:
                    self.spline_points[i] = (t_min, v)
                elif t > t_max:
                    self.spline_points[i] = (t_max, v)

    def mouseMoveEvent(self, event: QMouseEvent):
        #print("🟡 mouseMoveEvent")
        if self.time_data is None:
            return
            
        content = self.get_content_rect()
        
        if self.dragging and self.drag_index >= 0:
            y_zero = content.top() + content.height() / 2
            y = event.pos().y()
            
            new_pedal = -(y - y_zero) / (content.height() / 2)
            new_pedal = max(-1.0, min(1.0, new_pedal))
            
            if self.mode == PedalMode.SPLINE and self.drag_index < len(self.spline_points):
                t, _ = self.spline_points[self.drag_index]
                
                if self.x_movable:
                    t_norm = self.map_x_to_t(event.pos().x(), content)
                    t_min = self.time_data[0]
                    t_max = self.time_data[-1]
                    new_t = t_min + t_norm * (t_max - t_min)
                    
                    new_t = max(t_min, min(t_max, new_t))
                    
                    if self.drag_index > 0:
                        prev_t = self.spline_points[self.drag_index - 1][0]
                        new_t = max(new_t, prev_t + 0.001)
                    
                    if self.drag_index < len(self.spline_points) - 1:
                        next_t = self.spline_points[self.drag_index + 1][0]
                        new_t = min(new_t, next_t - 0.001)
                    
                    self.spline_points[self.drag_index] = (new_t, new_pedal)
                else:
                    self.spline_points[self.drag_index] = (t, new_pedal)
                
                self.spline_points_updated.emit()
            else:
                if 0 <= self.drag_index < len(self.pedal_data):
                    # 🔥 WICHTIG: ALLE Arrays aktualisieren!
                    old_value = self.pedal_data[self.drag_index]
                    
                    # 1. pedal_data im Graph aktualisieren
                    self.pedal_data[self.drag_index] = new_pedal
                    
                    # 2. track.pedals aktualisieren (das ist dieselbe Referenz, aber sicherheitshalber)
                    if hasattr(self.track, 'pedals'):
                        self.track.pedals[self.drag_index] = new_pedal
                    
                    # 3. track.current_pedals aktualisieren falls vorhanden
                    if hasattr(self.track, 'current_pedals') and self.track.current_pedals is not None:
                        if self.drag_index < len(self.track.current_pedals):
                            self.track.current_pedals[self.drag_index] = new_pedal
                    
                    print(f"🔵 Pedal geändert: Index {self.drag_index}: {old_value:.3f} -> {new_pedal:.3f}")
                    print(f"   Neuer Pedalbereich: {min(self.pedal_data):.3f} bis {max(self.pedal_data):.3f}")
            
            self.update()
            event.accept()
        else:
            old_hover = self.hover_index
            if self.mode == PedalMode.SPLINE:
                self.hover_index = self._find_spline_point_at_pos(event.pos(), content)
            else:
                self.hover_index = self._find_point_at_pos(event.pos(), content)
            
            if self.hover_index >= 0:
                self.setCursor(Qt.PointingHandCursor)
            else:
                self.setCursor(Qt.ArrowCursor)
            
            if old_hover != self.hover_index:
                self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if self.dragging:
            self.dragging = False
            self.drag_index = -1
            self.setCursor(Qt.ArrowCursor)
            
            if self.mode == PedalMode.SPLINE:
                self._sort_spline_points()
                # 🔥 WICHTIG: Spline auf pedal_data anwenden!
                self.apply_spline()
            
            event.accept()

    def leaveEvent(self, event):
        self.hover_index = -1
        self.setCursor(Qt.ArrowCursor)
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        if self.time_data is None or self.pedal_data is None:
            # 🔥 Wenn keine Daten, trotzdem Hintergrund zeichnen
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)
            self.draw_background(painter)
            painter.setPen(self.text_color)
            painter.drawText(self.rect(), Qt.AlignCenter, "Keine Pedaldaten")
            painter.end()
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        self.draw_background(painter)

        content = self.get_content_rect()
        self.draw_grid(painter, content)
        
        h = content.height()

        # Null-Linie
        painter.setPen(QPen(self.zero_line_color, 1, Qt.DashLine))
        y_zero = content.top() + h / 2
        painter.drawLine(content.left(), int(y_zero), 
                        content.right(), int(y_zero))

        # Anzuzeigende Kurve holen
        display_times, display_values = self._get_display_curve()
        
        if len(display_times) > 1:
            pts = self._get_points_for_display(content, display_times, display_values)
            
            # Kurve zeichnen
            if self.mode == PedalMode.SAMPLES:
                painter.setPen(QPen(self.sample_color, 1.5))
            else:
                painter.setPen(QPen(self.curve_color, 2.5))
            
            for i in range(len(pts) - 1):
                painter.drawLine(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])
            
            # Punkte zeichnen
            if self.mode == PedalMode.SAMPLES:
                painter.setPen(QPen(Qt.black, 1))
                painter.setBrush(QBrush(self.sample_color))
                for x, y in pts:
                    painter.drawEllipse(QPoint(x, y), 2, 2)
            
            elif self.mode == PedalMode.SPLINE:
                spline_pts = self._get_points_for_display(content, 
                                                         [p[0] for p in self.spline_points],
                                                         [p[1] for p in self.spline_points])
                for i, (x, y) in enumerate(spline_pts):
                    if i == self.drag_index:
                        painter.setBrush(QBrush(self.drag_color))
                        painter.setPen(QPen(Qt.black, 2))
                        radius = self.point_radius + 2
                    elif i == self.hover_index:
                        painter.setBrush(QBrush(self.hover_color))
                        painter.setPen(QPen(Qt.black, 1))
                        radius = self.point_radius + 1
                    else:
                        painter.setBrush(QBrush(self.spline_control_color))
                        painter.setPen(QPen(Qt.white, 1))
                        radius = self.point_radius
                    
                    painter.drawEllipse(QPoint(x, y), radius, radius)

        # Marker zeichnen (Zeit-Position von der Timeline)
        marker_x = self.map_t_to_x(self.marker_pos, content)
        painter.setPen(QPen(self.marker_color, 2.5))
        painter.drawLine(int(marker_x), content.top(), 
                        int(marker_x), content.bottom())
        
        painter.end()

        