# tsde_gui/theme.py
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPalette, QFont

class Theme:
    """Globale Design-Konstanten und Stylesheets"""
    
    # ==================== Farben ====================
    # Primärfarben als QColor-Objekte
    PRIMARY = QColor("#4a86e8")      # Blau
    PRIMARY_LIGHT = QColor("#6fa1eb")
    PRIMARY_DARK = QColor("#3a6bb4")
    
    # Sekundärfarben
    SECONDARY = QColor("#34a853")    # Grün
    SECONDARY_LIGHT = QColor("#5bb974")
    SECONDARY_DARK = QColor("#2a8642")
    
    # Akzentfarben
    ACCENT = QColor("#ff6b6b")       # Rot
    ACCENT_LIGHT = QColor("#ff8e8e")
    ACCENT_DARK = QColor("#cc5656")
    
    # Warnfarben
    WARNING = QColor("#ff9800")      # Orange
    WARNING_LIGHT = QColor("#ffad33")
    WARNING_DARK = QColor("#cc7a00")
    
    # Hintergründe
    BACKGROUND_DARK = QColor("#2c3e50")
    BACKGROUND_LIGHT = QColor("#f8f9fa")
    BACKGROUND_MEDIUM = QColor("#e8f4fd")
    
    # Text
    TEXT_PRIMARY = QColor("#333333")
    TEXT_SECONDARY = QColor("#666666")
    TEXT_LIGHT = QColor("#ffffff")
    TEXT_DARK = QColor("#000000")
    
    # Ränder & Linien
    BORDER_LIGHT = QColor("#dddddd")
    BORDER_MEDIUM = QColor("#cccccc")
    BORDER_DARK = QColor("#F10E0E")
    
    # Statusfarben (als QColor)
    STATUS_RUNNING = QColor("#4CAF50")
    STATUS_STOPPED = QColor("#ff6b6b")
    STATUS_READY = QColor("#4a86e8")
    STATUS_WARNING = QColor("#ff9800")
    
    # Graph-Farben
    GRAPH_CURVE = QColor("#00ffff")  # Cyan als QColor
    GRAPH_MARKER = QColor("#ff0000")  # Rot als QColor
    GRAPH_GRID = QColor("#555555")
    GRAPH_BACKGROUND = QColor("#000000")
    GRAPH_AXIS = QColor("#ffffff")
    
    # ==================== Fonts ====================
    @staticmethod
    def font_regular(size=10):
        font = QFont()
        font.setPointSize(size)
        return font
    
    @staticmethod
    def font_bold(size=10):
        font = QFont()
        font.setPointSize(size)
        font.setBold(True)
        return font
    
    @staticmethod
    def font_title(size=14):
        font = QFont()
        font.setPointSize(size)
        font.setBold(True)
        return font
    
    @staticmethod
    def font_large(size=16):
        font = QFont()
        font.setPointSize(size)
        font.setBold(True)
        return font
    
    # ==================== Größen ====================
    SPACING_SMALL = 5
    SPACING_MEDIUM = 10
    SPACING_LARGE = 15
    
    MARGIN_SMALL = 5
    MARGIN_MEDIUM = 10
    MARGIN_LARGE = 15
    
    BORDER_RADIUS_SMALL = 3
    BORDER_RADIUS_MEDIUM = 5
    BORDER_RADIUS_LARGE = 8
    
    # ==================== Icons ====================
    ICONS = {
        'folder': '📁',
        'track': '🎯',
        'group': '📂',
        'play': '▶',
        'stop': '⏹',
        'reset': '🔄',
        'import': '📂',
        'status': '🚀',
        'engine': '⚙️',
        'data': '📊',
        'graph': '📈',
        'pedal': '🎛️',
        'global': '🌍',
        'error': '❌',
        'warning': '⚠️',
        'success': '✅',
        'clock': '⏱️',
        'speed': '⚡',
        'length': '📏',
        'wait': '⏳',
        'pause': '⏸️'
    }
    
    # ==================== Helper Methods ====================
    @staticmethod
    def color_to_str(color):
        """Konvertiert QColor zu Hex-String für Stylesheets"""
        return color.name()
    
    @staticmethod
    def get_stylesheet():
        """Gibt das komplette Stylesheet zurück (OHNE QPushButton Styles)"""
        return f"""
            /* Haupt-Widget */
            QWidget {{
                background-color: {Theme.BACKGROUND_LIGHT.name()};
                color: {Theme.TEXT_PRIMARY.name()};
                font-family: 'Segoe UI', Arial, sans-serif;
            }}
            
            /* KEINE QPushButton Styles hier - Buttons bleiben Standard */
            
            /* Labels */
            QLabel {{
                color: {Theme.TEXT_PRIMARY.name()};
            }}
            
            QLabel[type="title"] {{
                font-size: 14pt;
                font-weight: bold;
                color: {Theme.PRIMARY_DARK.name()};
            }}
            
            QLabel[type="subtitle"] {{
                font-size: 12pt;
                font-weight: bold;
                color: {Theme.TEXT_PRIMARY.name()};
            }}
            
            QLabel[type="value"] {{
                font-weight: bold; 
                background-color: {Theme.BACKGROUND_MEDIUM.name()}; 
                border: 1px solid {Theme.PRIMARY.name()};
                border-radius: {Theme.BORDER_RADIUS_SMALL}px;
                padding: 2px 5px;
            }}
            
            QLabel[type="status"] {{
                background-color: {Theme.BACKGROUND_DARK.name()}; 
                color: white; 
                padding: 10px; 
                font-weight: bold;
                border-top: 2px solid {Theme.PRIMARY.name()};
            }}
            
            QLabel[type="info"] {{
                color: {Theme.TEXT_SECONDARY.name()};
                font-size: 10pt;
            }}
            
            /* Slider */
            QSlider::groove:horizontal {{
                border: 1px solid {Theme.BORDER_MEDIUM.name()};
                height: 8px;
                background: {Theme.BACKGROUND_MEDIUM.name()};
                margin: 2px 0;
                border-radius: 4px;
            }}
            
            QSlider::handle:horizontal {{
                background: {Theme.PRIMARY.name()};
                border: 1px solid {Theme.PRIMARY_DARK.name()};
                width: 18px;
                height: 18px;
                margin: -5px 0;
                border-radius: 9px;
            }}
            
            QSlider::handle:horizontal:hover {{
                background: {Theme.PRIMARY_LIGHT.name()};
            }}
            
            /* Table */
            QTableWidget {{
                background-color: white;
                gridline-color: {Theme.BORDER_LIGHT.name()};
                border: 1px solid {Theme.BORDER_MEDIUM.name()};
                border-radius: {Theme.BORDER_RADIUS_SMALL}px;
            }}
            
            QHeaderView::section {{
                background-color: {Theme.PRIMARY.name()};
                color: white;
                padding: 6px;
                border: none;
                font-weight: bold;
            }}
            
            QTableWidget::item {{
                padding: 4px;
            }}
            
            QTableWidget::item:selected {{
                background-color: {Theme.PRIMARY_LIGHT.name()};
                color: white;
            }}
            
            /* Tab Widget */
            QTabWidget::pane {{
                border: 1px solid {Theme.BORDER_MEDIUM.name()};
                background-color: white;
                border-radius: {Theme.BORDER_RADIUS_MEDIUM}px;
                margin-top: -1px;
            }}
            
            QTabBar::tab {{
                background-color: {Theme.BACKGROUND_MEDIUM.name()};
                color: {Theme.TEXT_PRIMARY.name()};
                padding: 8px 16px;
                margin-right: 2px;
                border-top-left-radius: {Theme.BORDER_RADIUS_SMALL}px;
                border-top-right-radius: {Theme.BORDER_RADIUS_SMALL}px;
                border: 1px solid {Theme.BORDER_MEDIUM.name()};
                border-bottom: none;
            }}
            
            QTabBar::tab:selected {{
                background-color: {Theme.PRIMARY.name()};
                color: white;
            }}
            
            QTabBar::tab:hover:!selected {{
                background-color: {Theme.PRIMARY_LIGHT.name()};
                color: white;
            }}
            
            /* Frame */
            QFrame[style="panel"] {{
                background-color: white;
                border: 1px solid {Theme.BORDER_MEDIUM.name()};
                border-radius: {Theme.BORDER_RADIUS_MEDIUM}px;
                padding: {Theme.MARGIN_MEDIUM}px;
            }}
            
            QFrame[style="group"] {{
                background-color: {Theme.BACKGROUND_MEDIUM.name()};
                border: 2px solid {Theme.PRIMARY.name()};
                border-radius: {Theme.BORDER_RADIUS_LARGE}px;
                padding: {Theme.MARGIN_LARGE}px;
            }}
            
            /* Scroll Area */
            QScrollArea {{
                border: none;
                background-color: transparent;
            }}
            
            QScrollBar:vertical {{
                border: none;
                background: {Theme.BACKGROUND_MEDIUM.name()};
                width: 10px;
                margin: 0px;
                border-radius: 5px;
            }}
            
            QScrollBar::handle:vertical {{
                background: {Theme.PRIMARY.name()};
                min-height: 20px;
                border-radius: 5px;
            }}
            
            QScrollBar::handle:vertical:hover {{
                background: {Theme.PRIMARY_LIGHT.name()};
            }}
            
            /* ComboBox */
            QComboBox {{
                border: 1px solid {Theme.BORDER_MEDIUM.name()};
                border-radius: {Theme.BORDER_RADIUS_SMALL}px;
                padding: 5px;
                background-color: white;
                min-height: 25px;
            }}
            
            QComboBox:hover {{
                border-color: {Theme.PRIMARY.name()};
            }}
            
            QComboBox::drop-down {{
                border: none;
            }}
        """
    
    @staticmethod
    def apply_theme(widget):
        """Wendet das Theme auf ein Widget an"""
        widget.setStyleSheet(Theme.get_stylesheet())