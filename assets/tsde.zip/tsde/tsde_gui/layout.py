# tsde_gui/layout.py
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QFileDialog,
    QMessageBox, QLabel, QSlider, QTableWidget, QTableWidgetItem,
    QHBoxLayout, QComboBox, QTabWidget,
    QScrollArea, QSizePolicy, QFrame
)
from PySide6.QtCore import Qt, QTimer, QSize 
from PySide6.QtGui import QPainter, QPen, QColor, QBrush
import json
import tsde_engine.core.ipc as ipc
import time
from datetime import datetime, timedelta
import os

# Importiere das globale Design
from tsde_gui.theme import Theme


# ------------------------------------------------------------------------
# CurveGraph Widget - Kurven Abwicklung entlang der Zeit
# ------------------------------------------------------------------------
class CurveGraph(QWidget):
    """
    Zeichnet die Kurve in X-Richtung abgewickelt:
    - X-Achse: Zeit (t von 0.0 bis 1.0)
    - Y-Achse: Kurven-X-Koordinate (p.x)
    - Marker bewegt sich mit der Zeit von links nach rechts
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.curve = None
        self.samples = 200
        self.scale = 10.0
        self.t_current = 0.0
        self.track_index = 0
        self.track_name = ""
        self.show_grid = True
        self.auto_scale = True
        
        # Styling aus Theme - als QColor-Objekte
        self.curve_color = Theme.GRAPH_CURVE
        self.marker_color = Theme.GRAPH_MARKER
        self.grid_color = Theme.GRAPH_GRID
        self.background_color = Theme.GRAPH_BACKGROUND
        self.axis_color = Theme.GRAPH_AXIS
        
        # Skalierung
        self.min_x = 0      # X-Achse: Zeit (immer 0-1)
        self.max_x = 1
        self.min_y = -1     # Y-Achse: Kurven-X-Koordinate
        self.max_y = 1
        
        # Size Policy für besseres Layout
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.setMinimumHeight(200)

    def set_curve(self, curve, track_name="", track_index=0):
        """Kurve + zugehörigen Track setzen."""
        self.curve = curve
        self.track_index = track_index
        self.track_name = track_name
        
        if curve and self.auto_scale:
            self._calculate_auto_scale()
        
        self.update()

    def set_current_position(self, t_local):
        """Setzt die aktuelle Position des Markers (0.0 bis 1.0)."""
        self.t_current = max(0.0, min(1.0, t_local))
        self.update()

    def sizeHint(self):
        """Bevorzugte Größe des Widgets."""
        return QSize(600, 250)

    def _calculate_auto_scale(self):
        """Berechnet automatische Skalierung für Y-Achse (Kurven-X-Werte)."""
        if not self.curve:
            return
            
        # Sample die Kurve um Y-Werte (Kurven-X-Koordinaten) zu finden
        samples = 100
        y_vals = []  # Speichere Kurven-X-Werte für Y-Achse
        
        for i in range(samples):
            t = i / (samples - 1)
            try:
                p = self.curve.evaluate(t)
                y_vals.append(p.x)  # X-Koordinate der Kurve wird Y-Achse
            except:
                pass
        
        if y_vals:
            self.min_y = min(y_vals)
            self.max_y = max(y_vals)
        else:
            self.min_y = -1
            self.max_y = 1
        
        # Etwas Padding hinzufügen
        y_range = self.max_y - self.min_y
        if y_range > 0:
            self.min_y -= y_range * 0.1
            self.max_y += y_range * 0.1
        else:
            self.min_y -= 1.0
            self.max_y += 1.0
        
        # Sicherstellen, dass es nicht 0 ist
        if abs(self.max_y - self.min_y) < 1e-6:
            self.min_y = -1
            self.max_y = 1
        
        # X-Achse ist immer 0-1 für die Zeit
        self.min_x = 0
        self.max_x = 1

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Hintergrund - Theme.GRAPH_BACKGROUND ist QColor
        painter.fillRect(self.rect(), self.background_color)

        w = self.width()
        h = self.height()

        if not self.curve:
            self._draw_no_curve_message(painter, w, h)
            painter.end()
            return

        # Gitter zeichnen
        if self.show_grid:
            self._draw_grid(painter, w, h)

        # Achsen zeichnen
        self._draw_axes(painter, w, h)

        # Kurve zeichnen
        self._draw_curve(painter, w, h)

        # Marker zeichnen
        self._draw_marker(painter, w, h)

        # Titel und Info
        self._draw_info(painter, w, h)

        painter.end()

    def _draw_no_curve_message(self, painter, w, h):
        painter.setPen(self.axis_color)  # Theme.GRAPH_AXIS verwenden
        painter.drawText(self.rect(), Qt.AlignCenter, "Keine Kurve geladen")

    def _draw_grid(self, painter, w, h):
        # QPen mit QColor-Objekt erstellen - RICHTIGE SYNTAX
        pen_grid = QPen(self.grid_color, 1, Qt.DotLine)
        painter.setPen(pen_grid)

        # Vertikale Linien (Zeit)
        for i in range(1, 10):
            x = int(i * w / 10)
            painter.drawLine(x, 0, x, h)

        # Horizontale Linien (Kurven-X-Koordinate)
        for i in range(1, 10):
            y = int(i * h / 10)
            painter.drawLine(0, y, w, y)

    def _draw_axes(self, painter, w, h):
        # Achsen-Linien - RICHTIGE SYNTAX
        pen_axis = QPen(self.axis_color, 2)
        painter.setPen(pen_axis)
        painter.drawLine(0, h, w, h)  # X-Achse (unten)
        painter.drawLine(0, 0, 0, h)  # Y-Achse (links)
        
        # Achsen-Beschriftung
        painter.setPen(self.axis_color)
        
        # Y-Achse (Kurven-X-Werte)
        for i in range(0, 11, 2):
            y = int((1 - i/10) * h)
            value = self.min_y + (self.max_y - self.min_y) * i/10
            painter.drawText(5, y + 15, f"{value:.1f}")
        
        
        # X-Achse (Zeit)
        for i in range(0, 11, 2):
            x = int(i * w / 10)
            value = i/10
            painter.drawText(x - 10, h - 5, f"{value:.1f}")
        painter.drawText(w - 40, h - 5, "Zeit (t)")

    def _draw_curve(self, painter, w, h):
        """Zeichnet die Kurve: X=Zeit, Y=Kurven-X-Koordinate"""
        if not self.curve:
            return
        
        # QPen mit QColor-Objekt - RICHTIGE SYNTAX
        pen_curve = QPen(self.curve_color, 2)
        painter.setPen(pen_curve)

        pts = []
        for i in range(self.samples):
            t = i / (self.samples - 1)
            try:
                p = self.curve.evaluate(t)
                
                # X-Achse = Zeit
                x = int(t * w)
                
                # Y-Achse = Kurven-X-Koordinate
                y_norm = (p.x - self.min_y) / (self.max_y - self.min_y) if (self.max_y - self.min_y) > 0 else 0
                y = int(h - y_norm * h)  # Y invertieren (0 oben)
                
                pts.append((x, y))
            except Exception as e:
                print(f"Fehler beim Zeichnen der Kurve t={t}: {e}")
                # Fallback: Lineare Position
                x = int(t * w)
                y = int(h * 0.5)
                pts.append((x, y))

        # Linien zeichnen
        if len(pts) >= 2:
            for i in range(len(pts) - 1):
                painter.drawLine(
                    pts[i][0], pts[i][1],
                    pts[i + 1][0], pts[i + 1][1]
                )

    def _draw_marker(self, painter, w, h):
        """Zeichnet den Zeit-Marker und Punkt auf der Kurve"""
        # Marker Position (Zeit auf X-Achse)
        marker_x = int(self.t_current * w)

        # Marker Linie - RICHTIGE SYNTAX
        pen_marker = QPen(self.marker_color, 2)
        painter.setPen(pen_marker)
        painter.drawLine(marker_x, 0, marker_x, h)

        # Punkt auf der Kurve
        try:
            p = self.curve.evaluate(self.t_current)
            
            # Punkt-Koordinaten berechnen
            point_x = marker_x
            
            # Y-Koordinate basierend auf Kurven-X-Wert
            y_norm = (p.x - self.min_y) / (self.max_y - self.min_y) if (self.max_y - self.min_y) > 0 else 0
            point_y = int(h - y_norm * h)
            
            # Großer Punkt zeichnen
            painter.setBrush(QBrush(self.marker_color))
            painter.drawEllipse(point_x - 5, point_y - 5, 10, 10)
            
            # Verbindungslinie zur X-Achse
            pen_dash = QPen(self.marker_color, 1, Qt.DashLine)
            painter.setPen(pen_dash)
            painter.drawLine(point_x, point_y, point_x, h)
            
            # Wert anzeigen
            painter.setPen(self.axis_color)
            value_text = f"X={p.x:.1f}"
            painter.drawText(point_x + 5, point_y - 10, value_text)
            
        except Exception as e:
            print(f"Fehler beim Zeichnen des Markers t={self.t_current}: {e}")

    def _draw_info(self, painter, w, h):
        """Zeichnet Titel und aktuelle Informationen"""
        if not self.track_name:
            return
        
        painter.setPen(self.axis_color)
        
        # Titel
        title = f"Track: {self.track_name}"
        if hasattr(self.curve, 'length_total'):
            title += f" | Länge: {self.curve.length_total:.1f} mm"
        painter.drawText(50, 20, title)
        
        # Aktuelle Position
        pos_text = f"Zeit: t={self.t_current:.3f}"
        
        # Aktuelle Kurvenposition
        try:
            p = self.curve.evaluate(self.t_current)
            pos_text += f" | X={p.x:.1f}, Y={p.y:.1f}, Z={p.z:.1f} mm"
        except:
            pass
            
        painter.drawText(50, 40, pos_text)
        

# ------------------------------------------------------------------------
# Main GUI mit Kurven-Anzeige
# ------------------------------------------------------------------------
class EngineTerminal(QWidget):
    def __init__(self, parent=None, debug_level=1):
        super().__init__(parent)
        
        # Wende globales Design an
        self.setStyleSheet(Theme.get_stylesheet())
        
        self.gui_debug_level = debug_level
        self._debug_print(1, "EngineTerminal init")

        self.setWindowTitle("TSDE Engine Terminal")
        self.resize(1400, 900)

        self.setup = None
        self.pedal_sliders = {}
        self.track_data_cache = {}
        self.start_times = {}
        self.actual_completion_times = {}  # NEU: Tatsächliche gemessene Zeiten
        self.last_t_local_values = {}  # Speichert letzte t_local Werte
        self.round_start_times = {}  # NEU: Startzeit für jede Runde
        self.round_counter = {}  # NEU: Zählt Runden für jede Spur
        self.empty_poll_count = 0
        
        # Kurven-Daten
        self.curves = {}  # track_name -> curve objekt
        self.curve_widgets = {}  # track_name -> CurveGraph Widget
        
        # Haupt-Layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        # ============================================================
        # Debug-Control Panel
        # ============================================================
        debug_panel = QFrame()
        debug_panel.setFrameStyle(QFrame.StyledPanel)
        debug_panel.setStyleSheet(f"""
            QFrame {{
                background-color: {Theme.BACKGROUND_MEDIUM.name()}; 
                padding: 5px;
                border: 1px solid #cccccc;
                border-radius: 5px;
            }}
        """)
        debug_layout = QHBoxLayout(debug_panel)
        debug_layout.setContentsMargins(5, 5, 5, 5)

        self.lbl_status = QLabel("Status: Bereit")
        debug_layout.addWidget(self.lbl_status)

        debug_layout.addStretch()

        self.cmb_debug_level = QComboBox()
        self.cmb_debug_level.addItems([
            "Debug: Off (0)",
            "Debug: Basic (1)", 
            "Debug: Medium (2)",
            "Debug: Full (3)"
        ])
        self.cmb_debug_level.setCurrentIndex(self.gui_debug_level)
        self.cmb_debug_level.currentIndexChanged.connect(self._on_debug_level_changed)
        debug_layout.addWidget(QLabel("Debug Level:"))
        debug_layout.addWidget(self.cmb_debug_level)

        # Debug-Buttons mit Theme-Farben
        debug_button_style = f"""
            QPushButton {{
                background-color: {Theme.PRIMARY.name()};
                color: white;
                border: 2px solid {Theme.PRIMARY_DARK.name()};
                border-radius: {Theme.BORDER_RADIUS_MEDIUM}px;
                padding: 6px 12px;
                font-weight: bold;
                font-size: 10pt;
                min-height: 15px;
                min-width: 100px;
            }}
            QPushButton:hover {{
                background-color: {Theme.PRIMARY_DARK.name()};
            }}
            QPushButton:pressed {{
                background-color: #2a5599;
            }}
        """

        self.btn_engine_info = QPushButton("Engine Info")
        self.btn_engine_info.setStyleSheet(debug_button_style)
        self.btn_engine_info.clicked.connect(self._show_engine_info)
        debug_layout.addWidget(self.btn_engine_info)

        self.btn_clear_queues = QPushButton("Clear Queues")
        self.btn_clear_queues.setStyleSheet(debug_button_style)
        self.btn_clear_queues.clicked.connect(self._clear_queues)
        debug_layout.addWidget(self.btn_clear_queues)

        layout.addWidget(debug_panel)

        # ============================================================
        # Haupt-Buttons - Konsistentes Design
        # ============================================================
        btn_panel = QFrame()
        btn_panel.setFrameStyle(QFrame.StyledPanel)
        btn_panel.setStyleSheet("""
            QFrame {
                background-color: white; 
                border: 1px solid #cccccc; 
                border-radius: 5px;
            }
        """)
        btn_layout = QHBoxLayout(btn_panel)
        btn_layout.setContentsMargins(10, 10, 10, 10)

        # Haupt-Buttons mit Theme-Farben
        main_button_style = f"""
            QPushButton {{
                background-color: {Theme.PRIMARY.name()};
                color: white;
                border: 2px solid {Theme.PRIMARY_DARK.name()};
                border-radius: {Theme.BORDER_RADIUS_MEDIUM}px;
                padding: 12px 24px;
                font-weight: bold;
                font-size: 11pt;
                min-height: 15px;
                min-width: 120px;
            }}
            QPushButton:hover {{
                background-color: {Theme.PRIMARY_DARK.name()};
            }}
            QPushButton:pressed {{
                background-color: #2a5599;
            }}
            QPushButton:disabled {{
                background-color: {Theme.PRIMARY_LIGHT.name()};
                color: #cccccc;
                border-color: {Theme.PRIMARY.name()};
            }}
        """

        self.btn_import = QPushButton("📂 Setup laden")
        self.btn_import.setMinimumHeight(15)
        self.btn_import.setStyleSheet(main_button_style)
        self.btn_import.clicked.connect(self.import_setup)

        self.btn_start = QPushButton("🔧 Engine starten")  # Nur Prozess starten
        self.btn_start.setMinimumHeight(15)
        self.btn_start.setStyleSheet(main_button_style)
        self.btn_start.clicked.connect(self.start_engine)

        # NEU: Play/Pause Buttons
        self.btn_play = QPushButton("▶ Play")
        self.btn_play.setMinimumHeight(15)
        self.btn_play.setStyleSheet(main_button_style)
        self.btn_play.setEnabled(False)  # Erst aktiv wenn Engine läuft UND Setup geladen
        self.btn_play.clicked.connect(self.play_engine)

        self.btn_pause = QPushButton("⏸ Pause")
        self.btn_pause.setMinimumHeight(15)
        self.btn_pause.setStyleSheet(main_button_style)
        self.btn_pause.setEnabled(False)  # Erst aktiv wenn Play gedrückt
        self.btn_pause.clicked.connect(self.pause_engine)

        self.btn_stop = QPushButton("⏹ Engine stoppen")
        self.btn_stop.setMinimumHeight(15)
        self.btn_stop.setStyleSheet(main_button_style)
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.stop_engine)

        self.btn_reset = QPushButton("🔄 Reset Tracks")
        self.btn_reset.setMinimumHeight(15)
        self.btn_reset.setStyleSheet(main_button_style)
        self.btn_reset.setEnabled(False)
        self.btn_reset.clicked.connect(self.reset_tracks)

        # ============================================================
        # Recorder Button - öffnet separates Fenster
        # ============================================================
        recorder_btn_layout = QHBoxLayout()
        recorder_btn_layout.addStretch()

        self.btn_recorder_window = QPushButton("🎬 Recorder Fenster öffnen")
        self.btn_recorder_window.setMinimumHeight(40)
        self.btn_recorder_window.setStyleSheet(f"""
            QPushButton {{
                background-color: {Theme.ACCENT.name()};
                color: white;
                font-weight: bold;
                font-size: 12pt;
                border: 2px solid {Theme.ACCENT_DARK.name()};
                border-radius: 8px;
                padding: 10px 20px;
            }}
            QPushButton:hover {{
                background-color: {Theme.ACCENT_DARK.name()};
            }}
        """)
        self.btn_recorder_window.clicked.connect(self.open_recorder_window)
        recorder_btn_layout.addWidget(self.btn_recorder_window)

        layout.addLayout(recorder_btn_layout)

        # Recorder-Fenster Referenz
        self.recorder_window = None


        # Layout: Import + Start + Play + Pause + Stop + Reset
        btn_layout.addWidget(self.btn_import)
        btn_layout.addWidget(self.btn_start)
        btn_layout.addWidget(self.btn_play)
        btn_layout.addWidget(self.btn_pause)
        btn_layout.addWidget(self.btn_stop)
        btn_layout.addWidget(self.btn_reset)
        btn_layout.addWidget(self.btn_recorder_window)

        layout.addWidget(btn_panel)


        # ============================================================
        # Individual Pedal Controls
        # ============================================================
        self.pedal_panel = QFrame()
        self.pedal_panel.setFrameStyle(QFrame.StyledPanel)
        self.pedal_panel.setStyleSheet(f"background-color: white;")
        self.pedal_panel.setVisible(False)
        pedal_main_layout = QVBoxLayout(self.pedal_panel)
        
        pedal_label = QLabel("🎛️ Individuelle Pedal Controls:")
        pedal_label.setStyleSheet("font-weight: bold; font-size: 12pt; margin-bottom: 10px;")
        pedal_main_layout.addWidget(pedal_label)
        
        self.pedal_scroll = QScrollArea()
        self.pedal_scroll.setWidgetResizable(True)
        self.pedal_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.pedal_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        self.pedal_container = QWidget()
        self.pedal_layout = QVBoxLayout(self.pedal_container)
        self.pedal_layout.setContentsMargins(10, 10, 10, 10)
        self.pedal_scroll.setWidget(self.pedal_container)
        
        pedal_main_layout.addWidget(self.pedal_scroll)
        layout.addWidget(self.pedal_panel)

        # ============================================================
        # Tab-Widget für Daten und Kurven
        # ============================================================
        self.tab_widget = QTabWidget()
        
        # Tab 1: Track Data Table
        self.table_tab = QWidget()
        table_layout = QVBoxLayout(self.table_tab)
        table_layout.setContentsMargins(10, 10, 10, 10)
        
        table_label = QLabel("📊 Track Data (Live)")
        table_label.setStyleSheet("font-weight: bold; font-size: 14pt; margin-bottom: 10px;")
        table_layout.addWidget(table_label)
        
        # TABELLENSTRUKTUR: 8 Spalten mit klaren Zeitangaben
        self.debug = QTableWidget(0, 8)
        self.debug.setHorizontalHeaderLabels([
            "Track", "t_local", "dist", "pedal", 
            "Geschw. (mm/s)", "Ist-Zeit (0->t)", "Rundenzeit (0->1)", "Runde #"
        ])
        self.debug.horizontalHeader().setStretchLastSection(True)
        
        # Spaltenbreiten
        self.debug.setColumnWidth(0, 120)  # Track
        self.debug.setColumnWidth(1, 100)  # t_local
        self.debug.setColumnWidth(2, 120)  # dist
        self.debug.setColumnWidth(3, 100)  # pedal
        self.debug.setColumnWidth(4, 140)  # Geschw.
        self.debug.setColumnWidth(5, 140)  # Ist-Zeit (0->t)
        self.debug.setColumnWidth(6, 140)  # Rundenzeit (0->1)
        self.debug.setColumnWidth(7, 80)   # Runde #
        
        self.debug.setAlternatingRowColors(True)
        table_layout.addWidget(self.debug)
        self.tab_widget.addTab(self.table_tab, "📊 Track Daten")
        
        # Tab 2: Kurven Visualisierung
        self.curve_tab = QWidget()
        self.curve_layout = QVBoxLayout(self.curve_tab)
        self.curve_layout.setContentsMargins(10, 10, 10, 10)
        
        curve_label = QLabel("📈 Kurven Visualisierung (Live)")
        curve_label.setStyleSheet("font-weight: bold; font-size: 14pt; margin-bottom: 10px;")
        self.curve_layout.addWidget(curve_label)
        
        # ScrollArea für Kurven
        self.curves_scroll = QScrollArea()
        self.curves_scroll.setWidgetResizable(True)
        self.curves_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.curves_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        self.curve_container = QWidget()
        self.curves_container_layout = QVBoxLayout(self.curve_container)
        self.curves_container_layout.setContentsMargins(5, 5, 5, 5)
        self.curves_container_layout.setSpacing(15)
        
        self.curves_scroll.setWidget(self.curve_container)
        self.curve_layout.addWidget(self.curves_scroll)
        
        self.tab_widget.addTab(self.curve_tab, "📈 Kurven")
        
        layout.addWidget(self.tab_widget, 1)  # Stretch-Faktor 1

    

        # ============================================================
        # Status Bar
        # ============================================================
        self.status_bar = QLabel("🚀 GUI bereit | Engine: gestoppt")
        self.status_bar.setStyleSheet(f"""
            background-color: {Theme.BACKGROUND_DARK.name()}; 
            color: white; 
            padding: 10px; 
            font-weight: bold;
            border-top: 2px solid {Theme.PRIMARY.name()};
        """)
        self.status_bar.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_bar)

        # ============================================================
        # Polling Timer
        # ============================================================
        self.timer = QTimer()
        self.timer.timeout.connect(self.poll_engine)
        
        self._debug_print(2, "GUI Initialisierung abgeschlossen")

    # ------------------------------------------------------------
    # Kurven-Handling - Jetzt mit Track-Typ Unterstützung!
    # ------------------------------------------------------------
    def _load_curves_from_setup(self):
        """Lädt Kurven aus dem Setup und erstellt CurveGraph Widgets."""
        if not self.setup:
            return
            
        self.curves.clear()
        self.curve_widgets.clear()
        
        # Alte Widgets löschen
        for i in reversed(range(self.curves_container_layout.count())):
            item = self.curves_container_layout.itemAt(i)
            w = item.widget()
            if w:
                w.deleteLater()
        
        track_index = 0
        for group in self.setup["groups"]:
            # Gruppe Container
            group_frame = QFrame()
            group_frame.setFrameStyle(QFrame.StyledPanel)
            group_frame.setStyleSheet(f"""
                QFrame {{
                    background-color: {Theme.BACKGROUND_MEDIUM.name()};
                    border: 2px solid {Theme.PRIMARY.name()};
                    border-radius: 8px;
                }}
            """)
            group_layout = QVBoxLayout(group_frame)
            group_layout.setContentsMargins(15, 15, 15, 15)
            group_layout.setSpacing(10)
            
            group_label = QLabel(f"📁 Gruppe: {group['name']}")
            group_label.setStyleSheet(f"""
                font-weight: bold; 
                font-size: 14pt; 
                color: {Theme.PRIMARY_DARK.name()};
                margin-bottom: 10px;
            """)
            group_layout.addWidget(group_label)
            
            for track in group["tracks"]:
                track_name = track["name"]
                track_type = track.get("track_type", "motion")  # 🔥 Track-Typ auslesen
                
                # 🔥 Unterschiedliche Darstellung je nach Track-Typ
                if track_type == "motion":
                    # Motion Track: Normale Kurve laden
                    try:
                        from tsde_engine.curves.curve_loader import load_csv_curve
                        curve_info = track["curve"]
                        
                        self._debug_print(2, f"Lade Kurve für Motion Track: {track_name}")
                        
                        # Prüfe ob Pfad existiert
                        if not curve_info["path"] or not os.path.exists(curve_info["path"]):
                            self._debug_print(1, f"⚠️ Kurvenpfad für {track_name} existiert nicht: {curve_info['path']}")
                            self._create_error_widget(group_layout, track_name, "Kurvenpfad nicht gefunden")
                            continue
                        
                        curve = load_csv_curve(
                            curve_info["path"], 
                            curve_info.get("segment_length", 0.01)
                        )
                        
                        self.curves[track_name] = curve
                        
                        # Motion Track Widget erstellen
                        self._create_motion_track_widget(group_layout, track_name, track, curve, track_index)
                        
                    except Exception as e:
                        self._debug_print(1, f"Fehler beim Laden der Kurve {track_name}: {e}")
                        self._create_error_widget(group_layout, track_name, str(e))
                
                elif track_type == "empty":
                    # 🔥 Empty Track: Keine Kurve, nur Info
                    self._debug_print(2, f"Empty Track (keine Kurve): {track_name}")
                    self._create_empty_track_widget(group_layout, track_name)
                    
                else:  # param track
                    # 🔥 Param Track: Zeige Parameter-Info
                    self._debug_print(2, f"Param Track: {track_name}")
                    param_name = track.get("param_name", "Parameter")
                    param_unit = track.get("param_unit", "")
                    param_min = track.get("param_min", 0.0)
                    param_max = track.get("param_max", 1.0)
                    self._create_param_track_widget(group_layout, track_name, param_name, param_unit, param_min, param_max)
                
                track_index += 1
            
            # Gruppe zum Haupt-Layout hinzufügen
            self.curves_container_layout.addWidget(group_frame)
        
        # Stretch am Ende
        self.curves_container_layout.addStretch()

    def _create_motion_track_widget(self, parent_layout, track_name, track, curve, track_index):
        """Erstellt Widget für Motion Track mit Kurvengraph"""
        track_frame = QFrame()
        track_frame.setFrameStyle(QFrame.StyledPanel)
        track_frame.setStyleSheet(f"""
            QFrame {{
                background-color: white;
                border: 1px solid {Theme.BORDER_LIGHT.name()};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        track_inner_layout = QVBoxLayout(track_frame)
        track_inner_layout.setContentsMargins(10, 10, 10, 10)
        track_inner_layout.setSpacing(5)
        
        # Track Header
        header_layout = QHBoxLayout()
        
        name_label = QLabel(f"🎯 {track_name} [Motion]")
        name_label.setStyleSheet("font-weight: bold; font-size: 12pt; color: #2E7D32;")  # Dunkelgrün
        header_layout.addWidget(name_label)
        
        header_layout.addStretch()
        
        info_label = QLabel(
            f"⚡ Max: {track['max_speed']} mm/s | "
            f"📏 Länge: {curve.length_total:.1f} mm"
        )
        info_label.setStyleSheet(f"color: {Theme.TEXT_SECONDARY.name()}; font-size: 10pt;")
        header_layout.addWidget(info_label)
        
        track_inner_layout.addLayout(header_layout)
        
        # CurveGraph Widget
        curve_widget = CurveGraph()
        curve_widget.set_curve(curve, track_name, track_index)
        track_inner_layout.addWidget(curve_widget)
        
        parent_layout.addWidget(track_frame)
        
        self.curve_widgets[track_name] = curve_widget

    def _create_empty_track_widget(self, parent_layout, track_name):
        """Erstellt Widget für Empty Track (nur Text, kein Graph)"""
        track_frame = QFrame()
        track_frame.setFrameStyle(QFrame.StyledPanel)
        track_frame.setStyleSheet(f"""
            QFrame {{
                background-color: #f5f5f5;
                border: 2px dashed {Theme.PRIMARY_LIGHT.name()};
                border-radius: 5px;
                padding: 10px;
            }}
        """)
        track_layout = QHBoxLayout(track_frame)
        track_layout.setContentsMargins(10, 10, 10, 10)
        
        # Icon
        icon_label = QLabel("📦")
        icon_label.setStyleSheet("font-size: 24px;")
        track_layout.addWidget(icon_label)
        
        # Text
        text_layout = QVBoxLayout()
        name_label = QLabel(f"{track_name}")
        name_label.setStyleSheet("font-weight: bold; font-size: 12pt; color: #757575;")
        text_layout.addWidget(name_label)
        
        type_label = QLabel("Empty Track (keine Geometrie)")
        type_label.setStyleSheet(f"color: {Theme.TEXT_SECONDARY.name()}; font-style: italic;")
        text_layout.addWidget(type_label)
        
        track_layout.addLayout(text_layout)
        track_layout.addStretch()
        
        parent_layout.addWidget(track_frame)
        
        # Für Empty Tracks: Kein CurveGraph, aber wir fügen ein Dummy-Objekt ein
        # damit _update_curve_markers keinen Fehler wirft
        class DummyCurveWidget:
            def set_current_position(self, t):
                pass  # Tut nichts
        
        self.curve_widgets[track_name] = DummyCurveWidget()

    def _create_param_track_widget(self, parent_layout, track_name, param_name, param_unit, param_min, param_max):
        """Erstellt Widget für Param Track mit Parameter-Info"""
        track_frame = QFrame()
        track_frame.setFrameStyle(QFrame.StyledPanel)
        track_frame.setStyleSheet(f"""
            QFrame {{
                background-color: #f3e5f5;
                border: 2px solid {Theme.ACCENT.name()};
                border-radius: 5px;
                padding: 10px;
            }}
        """)
        track_layout = QVBoxLayout(track_frame)
        track_layout.setContentsMargins(10, 10, 10, 10)
        
        # Header
        header_layout = QHBoxLayout()
        
        icon_label = QLabel("⚙️")
        icon_label.setStyleSheet("font-size: 24px;")
        header_layout.addWidget(icon_label)
        
        name_label = QLabel(f"{track_name}")
        name_label.setStyleSheet("font-weight: bold; font-size: 12pt; color: #7B1FA2;")  # Lila
        header_layout.addWidget(name_label)
        
        header_layout.addStretch()
        
        track_layout.addLayout(header_layout)
        
        # Parameter Info
        info_frame = QFrame()
        info_frame.setStyleSheet(f"""
            QFrame {{
                background-color: white;
                border: 1px solid {Theme.BORDER_LIGHT.name()};
                border-radius: 3px;
                margin-top: 5px;
            }}
        """)
        info_layout = QHBoxLayout(info_frame)
        
        param_text = f"Parameter: {param_name}"
        if param_unit:
            param_text += f" [{param_unit}]"
        param_text += f" | Bereich: {param_min} - {param_max}"
        
        param_label = QLabel(param_text)
        param_label.setStyleSheet("color: #7B1FA2; padding: 5px;")
        info_layout.addWidget(param_label)
        
        track_layout.addWidget(info_frame)
        
        # Status-Anzeige für aktuelle Werte (wird später aktualisiert)
        status_layout = QHBoxLayout()
        status_layout.addWidget(QLabel("Aktueller Wert:"))
        self.param_value_labels = getattr(self, 'param_value_labels', {})
        value_label = QLabel("--")
        value_label.setStyleSheet("""
            font-weight: bold;
            background-color: white;
            border: 1px solid #7B1FA2;
            border-radius: 3px;
            padding: 2px 8px;
        """)
        status_layout.addWidget(value_label)
        status_layout.addStretch()
        track_layout.addLayout(status_layout)
        
        self.param_value_labels[track_name] = value_label
        
        parent_layout.addWidget(track_frame)
        
        # Für Param Tracks: Auch Dummy für Marker-Updates
        class DummyCurveWidget:
            def set_current_position(self, t):
                pass
        
        self.curve_widgets[track_name] = DummyCurveWidget()

    def _create_error_widget(self, parent_layout, track_name, error_msg):
        """Erstellt Fehler-Widget für fehlgeschlagene Kurvenladung"""
        error_frame = QFrame()
        error_frame.setStyleSheet(f"""
            QFrame {{
                background-color: #ffe6e6;
                border: 1px solid {Theme.ACCENT.name()};
                border-radius: 5px;
                padding: 10px;
            }}
        """)
        error_layout = QHBoxLayout(error_frame)
        
        error_icon = QLabel("❌")
        error_layout.addWidget(error_icon)
        
        error_label = QLabel(f"{track_name}: Fehler beim Laden - {error_msg}")
        error_label.setStyleSheet(f"color: {Theme.ACCENT_DARK.name()}; font-weight: bold;")
        error_layout.addWidget(error_label)
        
        parent_layout.addWidget(error_frame)
        
        # Auch für fehlerhafte Tracks: Dummy für Marker-Updates
        class DummyCurveWidget:
            def set_current_position(self, t):
                pass
        
        self.curve_widgets[track_name] = DummyCurveWidget()


        # 🔥 NEU: Hier kommt die update-Methode hin!
    def _update_curve_markers(self, track_data):
        """Aktualisiert die Marker auf allen Kurven."""
        for track in track_data:
            track_name = track["name"]
            t_local = track["t_local"]
            
            if track_name in self.curve_widgets:
                # Rufe set_current_position auf - für DummyWidgets passiert nichts
                self.curve_widgets[track_name].set_current_position(t_local)
            
            # Für Param Tracks: Aktualisiere Wert-Anzeige
            if hasattr(self, 'param_value_labels') and track_name in self.param_value_labels:
                pedal = track["pedal"]
                # Konvertiere Pedal (-1..1) zu binärem Wert (0 oder 1)
                binary_value = 1 if pedal > 0 else 0
                self.param_value_labels[track_name].setText(str(binary_value))

    # ------------------------------------------------------------
    # Debug-Helper
    # ------------------------------------------------------------
    def _debug_print(self, level, message, **kwargs):
        if self.gui_debug_level >= level:
            prefix = f"[GUI DEBUG{level}]"
            if kwargs:
                print(f"{prefix} {message}", **kwargs)
            else:
                print(f"{prefix} {message}")

    def _update_status(self, message, color="white"):
        self.status_bar.setText(message)
        if color != "white":
            self.status_bar.setStyleSheet(f"""
                background-color: {Theme.BACKGROUND_DARK.name()}; 
                color: {color}; 
                padding: 10px; 
                font-weight: bold;
                border-top: 2px solid {Theme.PRIMARY.name()};
            """)

    # ------------------------------------------------------------
    # Pedal-Handling - OHNE GLOBALE PEDAL-STEUERUNG
    # ------------------------------------------------------------
    def _format_pedal_value(self, value):
        """Formatiert Pedal-Wert für Anzeige"""
        if value > 0:
            return f"+{value}%"
        elif value < 0:
            return f"{value}%"
        else:
            return "0%"

    def _get_pedal_color(self, value):
        """Gibt Farbe basierend auf Pedal-Richtung zurück"""
        if value > 0:
            return "#ccffcc"  # Hellgrün für Vorwärts
        elif value < 0:
            return "#ffcccc"  # Hellrot für Rückwärts
        else:
            return Theme.BACKGROUND_MEDIUM.name()

    def _get_pedal_border_color(self, value):
        """Gibt Randfarbe basierend auf Pedal-Richtung zurück"""
        if value > 0:
            return "#00aa00"  # Dunkelgrün
        elif value < 0:
            return "#aa0000"  # Dunkelrot
        else:
            return Theme.PRIMARY.name()

    def _save_pedal_values(self):
        if not self.pedal_sliders:
            return
            
        pedal_values = {}
        for track_name, (slider, _, _) in self.pedal_sliders.items():
            # Speichere als -1.0 bis +1.0
            pedal_values[track_name] = slider.value() / 100.0
        
        temp_file = "pedal_values_temp.json"
        try:
            with open(temp_file, 'w') as f:
                json.dump(pedal_values, f)
            self._debug_print(2, f"Pedal-Werte gespeichert: {pedal_values}")
        except Exception as e:
            self._debug_print(1, f"Fehler beim Speichern der Pedal-Werte: {e}")

    def _load_pedal_values(self):
        temp_file = "pedal_values_temp.json"
        try:
            with open(temp_file, 'r') as f:
                pedal_values = json.load(f)
            self._debug_print(2, f"Pedal-Werte geladen: {pedal_values}")
            return pedal_values
        except:
            return None

    # ------------------------------------------------------------
    # Zeit-Berechnungen - MESSUNG DER TATSÄCHLICHEN ENGINE-ZEIT
    # ------------------------------------------------------------
    def _calculate_current_speed(self, t_local, pedal_value, track_data):
        if not track_data:
            return "--"
            
        max_speed = track_data.get('max_speed', 150)
        current_speed = max_speed * pedal_value
        
        return f"{current_speed:+.1f}"  # Vorzeichen anzeigen

    def _calculate_elapsed_time_current_segment(self, track_name, t_local):
        """Berechnet die Ist-Zeit für die aktuelle Runde (0->t)"""
        if track_name not in self.round_start_times:
            if t_local > 0.01:  # Schwellwert, um Rauschen zu vermeiden
                # Startzeit für aktuelle Runde speichern
                self.round_start_times[track_name] = datetime.now()
                return "0:00"
            else:
                return "0:00"
        
        start_time = self.round_start_times[track_name]
        elapsed = datetime.now() - start_time
        total_seconds = elapsed.total_seconds()
        
        return self._format_time_seconds(total_seconds)

    def _get_last_round_time(self, track_name):
        """Gibt die Zeit der letzten abgeschlossenen Runde zurück"""
        if track_name in self.actual_completion_times:
            time_seconds = self.actual_completion_times[track_name]
            return self._format_time_seconds(time_seconds)
        else:
            return "--"

    def _get_round_counter(self, track_name):
        """Gibt die Rundennummer zurück"""
        return self.round_counter.get(track_name, 0)

    def _format_time_seconds(self, total_seconds):
        """Formatiert Sekunden in lesbares Zeitformat"""
        if total_seconds < 60:
            return f"{total_seconds:.1f}s"
        elif total_seconds < 3600:
            minutes = int(total_seconds // 60)
            seconds = int(total_seconds % 60)
            return f"{minutes}:{seconds:02d}"
        else:
            hours = int(total_seconds // 3600)
            minutes = int((total_seconds % 3600) // 60)
            return f"{hours}:{minutes:02d}h"

    # ------------------------------------------------------------
    # Debug-Control Handlers
    # ------------------------------------------------------------
    def _on_debug_level_changed(self, index):
        old_level = self.gui_debug_level
        self.gui_debug_level = index
        
        ipc.set_ipc_debug_level(index)
        
        if ipc.is_running():
            ipc.send("debug_level", level=index)
        
        self._debug_print(1, f"Debug-Level von {old_level} auf {index} geändert")
        self._update_status(f"Debug-Level: {index}")

    def _show_engine_info(self):
        info = ipc.get_engine_info()
        
        message = (
            f"Engine Status: {'läuft' if info['running'] else 'gestoppt'}\n"
            f"Debug-Level: {info['debug_level']}\n"
            f"PID: {info['pid'] or 'N/A'}\n"
            f"Queues: Out={info['queue_sizes']['out']}, In={info['queue_sizes']['in']}"
        )
        
        QMessageBox.information(self, "Engine Info", message)
        self._debug_print(2, f"Engine Info angezeigt: {message}")

    def _clear_queues(self):
        cleared = ipc.clear_queues()
        if cleared > 0:
            self._debug_print(1, f"{cleared} Elemente aus Queues entfernt")
            self._update_status(f"Queues geleert: {cleared} Elemente", "#4a86e8")
        else:
            self._debug_print(2, "Queues bereits leer")

    # ------------------------------------------------------------
    # Setup laden
    # ------------------------------------------------------------
    def import_setup(self):
        self._debug_print(1, "import_setup() aufgerufen")

        path, _ = QFileDialog.getOpenFileName(self, "Setup laden", "", "JSON (*.json)")
        if not path:
            self._debug_print(1, "Keine Datei ausgewählt")
            return

        try:
            with open(path, "r") as f:
                self.setup = json.load(f)
            
            # Track-Daten cachen
            self.track_data_cache.clear()
            for group in self.setup["groups"]:
                for track in group["tracks"]:
                    self.track_data_cache[track["name"]] = {
                        'max_speed': track["max_speed"],
                        'total_length': 1000  # Placeholder
                    }
            
            self._debug_print(2, f"Setup geladen: {len(self.setup['groups'])} Gruppen, {len(self.track_data_cache)} Tracks")
            
            # Pedal-Werte laden
            saved_pedals = self._load_pedal_values()
            
            # UI aufbauen
            self._build_pedal_ui(saved_pedals)
            
            # Kurven laden und visualisieren
            self._load_curves_from_setup()
            
            self._update_status(f"✅ Setup geladen: {path}")
            QMessageBox.information(self, "Setup", "Setup erfolgreich geladen.")
            
        except Exception as e:
            self._debug_print(0, f"Fehler beim Laden des Setups: {e}")
            QMessageBox.critical(self, "Fehler", f"Setup konnte nicht geladen werden:\n{str(e)}")

    # ------------------------------------------------------------
    # Pedal‑UI - MIT MITTELSTELLUNG, OHNE GLOBALE PEDAL-STEUERUNG
    # ------------------------------------------------------------
    def _build_pedal_ui(self, saved_pedals=None):
        self._debug_print(1, "Baue Pedal-UI mit Mittelstellung")

        for i in reversed(range(self.pedal_layout.count())):
            item = self.pedal_layout.itemAt(i)
            w = item.widget()
            if w:
                w.deleteLater()

        self.pedal_sliders.clear()

        for group in self.setup["groups"]:
            self._debug_print(2, f"Erstelle Gruppe: {group['name']}")
            
            group_frame = QFrame()
            group_frame.setFrameStyle(QFrame.StyledPanel)
            group_frame.setStyleSheet(f"""
                QFrame {{
                    background-color: {Theme.BACKGROUND_MEDIUM.name()};
                    border: 1px solid {Theme.BORDER_MEDIUM.name()};
                    border-radius: 5px;
                }}
            """)
            group_inner_layout = QVBoxLayout(group_frame)
            group_inner_layout.setContentsMargins(10, 10, 10, 10)
            
            group_label = QLabel(f"📁 {group['name']}:")
            group_label.setStyleSheet(f"""
                font-weight: bold; 
                color: {Theme.PRIMARY_DARK.name()}; 
                margin-bottom: 5px;
            """)
            group_inner_layout.addWidget(group_label)
            
            for track in group["tracks"]:
                name = track["name"]
                self._debug_print(3, f"Erstelle Slider für Track: {name}")

                track_layout = QHBoxLayout()
                track_layout.setSpacing(10)
                
                label = QLabel(f"  {name}")
                label.setFixedWidth(120)
                label.setStyleSheet("font-weight: bold;")
                
                # Slider mit Mittelstellung -100 bis +100
                slider = QSlider(Qt.Horizontal)
                slider.setMinimum(-100)  # -100% (Rückwärts)
                slider.setMaximum(100)   # +100% (Vorwärts)
                slider.setMinimumWidth(200)
                
                # Startwert ist 0 (Mittelstellung)
                start_value = 0
                if saved_pedals and name in saved_pedals:
                    # Alte Werte (0-1) in neue Skala (-100 bis +100) konvertieren
                    old_value = saved_pedals[name]
                    if isinstance(old_value, float):
                        start_value = int(old_value * 100)  # 0-1 zu 0-100
                    else:
                        start_value = int(old_value)
                
                slider.setValue(start_value)
                
                # Anzeige: Vorzeichen zeigen Richtung an
                value_label = QLabel(self._format_pedal_value(start_value))
                value_label.setFixedWidth(70)  # Etwas breiter für Vorzeichen
                value_label.setAlignment(Qt.AlignCenter)
                value_label.setStyleSheet(f"""
                    font-weight: bold; 
                    background-color: {self._get_pedal_color(start_value)}; 
                    border: 1px solid {self._get_pedal_border_color(start_value)};
                    border-radius: 3px;
                    padding: 2px;
                """)

                def create_slider_handler(track_name, value_label):
                    def handler(val):
                        pedal_value = val / 100.0  # -1.0 bis +1.0
                        self._debug_print(2, f"Sende Pedal für '{track_name}': {pedal_value:.2f}")
                        
                        # Aktualisiere Anzeige mit Farbe basierend auf Richtung
                        value_label.setText(self._format_pedal_value(val))
                        value_label.setStyleSheet(f"""
                            font-weight: bold; 
                            background-color: {self._get_pedal_color(val)}; 
                            border: 1px solid {self._get_pedal_border_color(val)};
                            border-radius: 3px;
                            padding: 2px;
                        """)
                        
                        if ipc.is_running():
                            ipc.send("set_pedal", track=track_name, value=pedal_value)
                        
                        self._save_pedal_values()
                    return handler
                
                slider.valueChanged.connect(create_slider_handler(name, value_label))
                
                # Style für Slider mit Farbverlauf
                slider.setStyleSheet(f"""
                    QSlider::groove:horizontal {{
                        border: 1px solid #bbb;
                        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                            stop:0 #eee, stop:1 #ccc);
                        height: 10px;
                        border-radius: 4px;
                    }}
                    
                    QSlider::sub-page:horizontal {{
                        background: qlineargradient(x1: 0, y1: 0, x2: 1, y1: 0,
                            stop: 0 #ff4444, stop: 0.5 #888888, stop: 1 #44ff44);
                        border: 1px solid #777;
                        height: 10px;
                        border-radius: 4px;
                    }}
                    
                    QSlider::add-page:horizontal {{
                        background: #fff;
                        border: 1px solid #777;
                        height: 10px;
                        border-radius: 4px;
                    }}
                    
                    QSlider::handle:horizontal {{
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                            stop:0 #eee, stop:1 #ccc);
                        border: 1px solid #777;
                        width: 18px;
                        margin: -2px 0;
                        border-radius: 3px;
                    }}
                    
                    QSlider::handle:horizontal:hover {{
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                            stop:0 #fff, stop:1 #ddd);
                        border: 1px solid #444;
                    }}
                """)
                
                track_layout.addWidget(label)
                track_layout.addWidget(slider)
                track_layout.addWidget(value_label)
                
                group_inner_layout.addLayout(track_layout)
                self.pedal_sliders[name] = (slider, value_label, start_value / 100.0)
            
            self.pedal_layout.addWidget(group_frame)

        self.pedal_panel.setVisible(True)
        self._debug_print(1, f"Pedal-UI mit {len(self.pedal_sliders)} Sliders erstellt (Mittelstellung)")

    # ------------------------------------------------------------
    # Engine starten/stoppen
    # ------------------------------------------------------------
    def start_engine(self):
        """Startet NUR den Engine-Prozess - noch keine Bewegung!"""
        self._debug_print(1, "start_engine() aufgerufen")
        self._update_status("⏳ Engine-Prozess startet...", "#4CAF50")

        if not self.setup:
            self._debug_print(0, "ERROR – Kein Setup geladen")
            QMessageBox.warning(self, "Fehler", "Bitte zuerst ein Setup laden.")
            self._update_status("❌ Fehler: Kein Setup geladen", "#ff6b6b")
            return

        try:
            self._save_pedal_values()
            
            self._debug_print(1, "Rufe ipc.start_engine() auf")
            ipc.start_engine(debug_level=self.gui_debug_level)
            
            self._debug_print(2, "Warte auf Engine-Initialisierung...")
            self._update_status("⚙️ Engine initialisiert...", "#4CAF50")
            time.sleep(0.5)
            
        except Exception as e:
            self._debug_print(0, f"Engine Start fehlgeschlagen: {e}")
            QMessageBox.critical(self, "Engine Fehler", str(e))
            self._update_status(f"❌ Start fehlgeschlagen: {e}", "#ff6b6b")
            return

        self._debug_print(1, "Sende Setup an Engine")
        self._update_status("📥 Lade Setup in Engine...", "#4CAF50")
        ipc.send("setup", data=self.setup)
        
        wait_time = 3.0
        self._debug_print(2, f"Warte {wait_time}s für Setup-Laden...")
        time.sleep(wait_time)
        
        self._debug_print(1, "Sende gespeicherte Pedal-Werte an Engine")
        for track_name, (slider, label, last_value) in self.pedal_sliders.items():
            current_value = slider.value() / 100.0  # -1.0 bis +1.0
            ipc.send("set_pedal", track=track_name, value=current_value)
            self._debug_print(2, f"Pedal für '{track_name}' gesendet: {current_value}")
        
        # KEIN "play" Kommando mehr hier!
        # ipc.send("play")  <- ENTFERNT
        
        # GUI-Zeitmessung zurücksetzen
        self.start_times.clear()
        self.round_start_times.clear()
        self.actual_completion_times.clear()
        self.last_t_local_values.clear()
        self.round_counter.clear()
        
        # Button-Status: Engine läuft, aber PAUSIERT
        self.btn_start.setEnabled(False)    # Engine läuft -> Start DEAKTIVIEREN
        self.btn_play.setEnabled(True)      # Play AKTIVIEREN (Engine ist pausiert)
        self.btn_pause.setEnabled(False)    # Pause deaktivieren (noch nicht playing)
        self.btn_stop.setEnabled(True)      # Stop AKTIVIEREN
        self.btn_reset.setEnabled(True)     # Reset AKTIVIEREN
        self.btn_import.setEnabled(False)   # Import DEAKTIVIEREN
        
        # Polling starten (um Daten zu empfangen, auch im Pause-Zustand)
        poll_interval = 33  # ~30 FPS
        self._debug_print(2, f"Starte Polling-Timer ({poll_interval}ms)")
        self.timer.start(poll_interval)
        
        self._update_status("⏸ Engine bereit - PAUSE - Play drücken zum Starten", "#ff9800")
        self._debug_print(1, "Engine-Prozess gestartet (PAUSIERT)")

    def play_engine(self):
        """Setzt die Engine auf PLAY - Bewegung beginnt!"""
        self._debug_print(1, "play_engine() aufgerufen")
        
        if ipc.is_running():
            ipc.send("play")  # WICHTIG: Startet Zeitmessung und Ticks!
            
            # Button-Status aktualisieren
            self.btn_play.setEnabled(False)   # Play deaktivieren (läuft bereits)
            self.btn_pause.setEnabled(True)   # Pause aktivieren
            self.btn_reset.setEnabled(True)   # Reset bleibt aktiv
            
            self._update_status("▶ Engine läuft - PLAY", "#4CAF50")
            self._debug_print(1, "Engine auf PLAY gesetzt")
        else:
            self._debug_print(1, "Kann Play nicht senden - Engine läuft nicht")
            QMessageBox.warning(self, "Fehler", "Engine läuft nicht")

    def pause_engine(self):
        """Pausiert die Engine - Bewegung stoppt, Zeitmessung pausiert."""
        self._debug_print(1, "pause_engine() aufgerufen")
        
        if ipc.is_running():
            ipc.send("pause")  # WICHTIG: Pausiert Zeitmessung und Ticks!
            
            # Button-Status aktualisieren
            self.btn_play.setEnabled(True)    # Play wieder aktivieren
            self.btn_pause.setEnabled(False)  # Pause deaktivieren (bereits pausiert)
            self.btn_reset.setEnabled(True)   # Reset bleibt aktiv
            
            self._update_status("⏸ Engine pausiert - PAUSE", "#ff9800")
            self._debug_print(1, "Engine auf PAUSE gesetzt")
        else:
            self._debug_print(1, "Kann Pause nicht senden - Engine läuft nicht")
            QMessageBox.warning(self, "Fehler", "Engine läuft nicht")

    def reset_tracks(self):
        """Setzt alle Tracks zurück und bleibt im aktuellen Play/Pause Zustand."""
        self._debug_print(1, "reset_tracks() aufgerufen")
        
        if ipc.is_running():
            ipc.send("reset")
            
            # WICHTIG: NICHT automatisch "play" senden!
            # Der aktuelle Play/Pause Zustand bleibt erhalten
            
            # GUI-interne Zeitmessung zurücksetzen
            self.start_times.clear()
            self.round_start_times.clear()
            self.actual_completion_times.clear()
            self.last_t_local_values.clear()
            self.round_counter.clear()
            
            # Pedals zurücksetzen (aber auf 0 = Mittelstellung)
            for track_name, (slider, label, _) in self.pedal_sliders.items():
                slider.setValue(0)
                label.setText("0%")
                label.setStyleSheet(f"""
                    font-weight: bold; 
                    background-color: {self._get_pedal_color(0)}; 
                    border: 1px solid {self._get_pedal_border_color(0)};
                    border-radius: 3px;
                    padding: 2px;
                """)
                ipc.send("set_pedal", track=track_name, value=0.0)
            
            self._debug_print(1, "Alle Tracks zurückgesetzt, Pedals auf Mittelstellung")
            self._update_status("🔄 Alle Tracks zurückgesetzt", "#4a86e8")
        else:
            self._debug_print(1, "Kann nicht zurücksetzen - Engine läuft nicht")
            QMessageBox.warning(self, "Fehler", "Engine läuft nicht")

    def stop_engine(self):
        """Stoppt den Engine-Prozess komplett."""
        self._debug_print(1, "stop_engine() aufgerufen")
        self._update_status("⏹️ Engine stoppt...", "#ff9800")
        
        self.timer.stop()
        self._debug_print(2, "Polling-Timer gestoppt")
        
        self._save_pedal_values()
        ipc.stop_engine()
        
        # Button-Status: Alles zurückgesetzt
        self.btn_start.setEnabled(True)    # Start AKTIVIEREN
        self.btn_play.setEnabled(False)    # Play DEAKTIVIEREN
        self.btn_pause.setEnabled(False)   # Pause DEAKTIVIEREN
        self.btn_stop.setEnabled(False)    # Stop DEAKTIVIEREN
        self.btn_reset.setEnabled(False)   # Reset DEAKTIVIEREN
        self.btn_import.setEnabled(True)   # Import AKTIVIEREN
        
        self.debug.setRowCount(0)
        
        self._update_status("⏹️ Engine gestoppt - Pedal-Werte gespeichert", "white")
        self._debug_print(1, "Engine erfolgreich gestoppt")
        
        QMessageBox.information(self, "Engine", "Engine gestoppt. Pedal-Werte wurden gespeichert.")

    # ------------------------------------------------------------
    # Polling - MIT TATSÄCHLICHER ZEITMESSUNG (gemessene Systemzeit)
    # ------------------------------------------------------------
    def poll_engine(self):
        if self.gui_debug_level >= 3:
            self._debug_print(3, "poll_engine() tick")

        if not ipc.is_running():
            self._debug_print(1, "Engine läuft nicht mehr")
            self.timer.stop()
            self._update_status("❌ Engine nicht erreichbar", "#ff6b6b")
            return

        data = ipc.poll()
        
        if not data:
            self.empty_poll_count += 1
            if self.empty_poll_count <= 3:
                self._debug_print(2, f"Keine Daten von Engine (Versuche: {self.empty_poll_count})")
            elif self.empty_poll_count == 10:
                self._debug_print(1, "10x keine Daten - Engine könnte Probleme haben")
                self._update_status("⚠️ Warnung: Engine sendet keine Daten", "#ff9800")
            return
        
        if self.empty_poll_count > 0:
            self._debug_print(2, f"Endlich Daten nach {self.empty_poll_count} leeren Polls")
            self.empty_poll_count = 0
        
        if self.gui_debug_level >= 2:
            self._debug_print(2, f"{len(data)} Tracks empfangen")

        # Tabellen-Daten aktualisieren
        self.debug.setRowCount(len(data))

        for row, t in enumerate(data):
            track_name = t["name"]
            t_local = t["t_local"]
            distance = t["dist"]
            pedal = t["pedal"]
            
            track_data = self.track_data_cache.get(track_name, {})
            current_speed = self._calculate_current_speed(t_local, pedal, track_data)
            
            # ECHTE ENGINE-ZEIT AUS DEM PAYLOAD VERWENDEN!
            time_elapsed = t.get("time_elapsed", 0.0)  # Exakte Zeit seit Reset/Start
            time_elapsed_from_dist = t.get("time_elapsed_from_dist", 0.0)  # Zeit basierend auf Distanz
            time_total = t.get("time_total", 0.0)  # Theoretische Gesamtzeit
            time_remaining = t.get("time_remaining", 0.0)  # Verbleibende Zeit
            
            # Rundenzeiten basierend auf ENGINE-ZEIT (nicht Systemzeit)
            last_t_local = self.last_t_local_values.get(track_name, 0)
            
            # 1. Neue Runde erkannt - Engine-Zeit als Startzeit speichern
            if last_t_local < 0.05 and t_local > 0.05:
                self.start_times[track_name] = time_elapsed
                self.round_counter[track_name] = self.round_counter.get(track_name, 0) + 1
                self._debug_print(3, f"Track '{track_name}': Neue Runde bei t={t_local:.3f}, "
                                f"Engine-Zeit={time_elapsed:.3f}s")
            
            # 2. Vergangene Zeit für aktuelle Runde (0->t)
            elapsed_current_round = 0.0
            if track_name in self.start_times:
                elapsed_current_round = time_elapsed - self.start_times[track_name]
            
            # 3. Rundenabschluss erkannt (t_local > 0.99 und war zuvor < 0.99)
            if last_t_local < 0.99 and t_local >= 0.99:
                if track_name in self.start_times:
                    round_duration = time_elapsed - self.start_times[track_name]
                    self.actual_completion_times[track_name] = round_duration
                    self._debug_print(2, f"Track '{track_name}': Runde abgeschlossen in "
                                    f"{round_duration:.3f}s (Engine-Zeit)")
                    
                    # Vergleich mit theoretischer Zeit
                    if self.gui_debug_level >= 2:
                        self._debug_print(2, f"  Theoretisch: {time_total:.3f}s, "
                                        f"Differenz: {abs(round_duration - time_total):.3f}s")
            
            # 4. Speichere aktuellen t_local für nächsten Vergleich
            self.last_t_local_values[track_name] = t_local
            
            # Formatierte Zeiten für Anzeige
            elapsed_time_str = f"{elapsed_current_round:.1f}s"  # Ist-Zeit (0->t)
            last_round_time = self._get_last_round_time(track_name)
            round_num = self.round_counter.get(track_name, 0)
            
            # Tabelleneinträge setzen
            self.debug.setItem(row, 0, QTableWidgetItem(track_name))
            self.debug.setItem(row, 1, QTableWidgetItem(f"{t_local:.4f}"))
            self.debug.setItem(row, 2, QTableWidgetItem(f"{distance:.2f}"))
            self.debug.setItem(row, 3, QTableWidgetItem(f"{pedal:+.1%}"))
            self.debug.setItem(row, 4, QTableWidgetItem(current_speed))
            self.debug.setItem(row, 5, QTableWidgetItem(elapsed_time_str))  # Ist-Zeit (0->t)
            self.debug.setItem(row, 6, QTableWidgetItem(last_round_time))   # Gemessene Rundenzeit
            self.debug.setItem(row, 7, QTableWidgetItem(str(round_num)))    # Runde #
            
            # Farbige Hintergründe basierend auf Status
            if t_local >= 0.99:
                # Runde abgeschlossen
                for col in range(8):
                    item = self.debug.item(row, col)
                    if item:
                        item.setBackground(Theme.SECONDARY_LIGHT)
            elif pedal > 0:
                # Vorwärts
                for col in range(8):
                    item = self.debug.item(row, col)
                    if item:
                        item.setBackground(QColor("#ccffcc"))
            elif pedal < 0:
                # Rückwärts
                for col in range(8):
                    item = self.debug.item(row, col)
                    if item:
                        item.setBackground(QColor("#ffcccc"))
            else:
                # Neutral
                for col in range(8):
                    item = self.debug.item(row, col)
                    if item:
                        item.setBackground(Theme.BACKGROUND_MEDIUM)

        # Kurven-Marker aktualisieren
        self._update_curve_markers(data)

        # Status aktualisieren - KORRIGIERT: finished_tweets -> finished_tracks
        if data:
            total_tracks = len(data)
            running_tracks = sum(1 for t in data if t["t_local"] < 0.99)
            finished_tracks = total_tracks - running_tracks
            
            # Engine-Zeit aus erstem Track nehmen (sind alle gleich)
            engine_time = data[0].get("time_elapsed", 0.0) if data else 0.0
            
            status_msg = (f"✅ Engine läuft | t0-1: {engine_time:.1f}s | "
                        f"Tracks: {total_tracks} total, "
                        f"{running_tracks} aktiv, {finished_tracks} fertig")  # 🔴 HIER WAR DER FEHLER!
            self._update_status(status_msg, "#4CAF50")


    # ------------------------------------------------------------
    # Recorder Signal Handler
    # ------------------------------------------------------------
    def _on_recording_started(self, session_name):
        """Wird aufgerufen wenn Recording startet"""
        self._debug_print(1, f"🎬 Recording gestartet: {session_name}")
        self._update_status(f"🎬 RECORDING: {session_name}", "#ff0000")
        
    def _on_recording_stopped(self, session_info):
        """Wird aufgerufen wenn Recording stoppt"""
        self._debug_print(1, f"🎬 Recording gestoppt")
        self._update_status("✅ Recording gestoppt", "#4CAF50")
        
    def _on_recording_saved(self, filepath):
        """Wird aufgerufen wenn Recording gespeichert wurde"""
        self._debug_print(1, f"💾 Recording gespeichert: {filepath}")
        QMessageBox.information(self, "Recording gespeichert", 
                            f"Datei: {filepath}")
        
    def _on_recording_loaded(self, session_info):
        """Wird aufgerufen wenn Recording geladen wurde"""
        self._debug_print(1, f"📂 Recording geladen")
        self._update_status("📂 Recording geladen", "#4a86e8")

    # ------------------------------------------------------------
    # Recorder Öffnen Extra fenster
    # ------------------------------------------------------------
    def open_recorder_window(self):
        """Öffnet Recorder in separatem Fenster - mit Debug-Level"""
        try:
            from tsde_gui.recorder_panel import RecorderPanel
            from PySide6.QtWidgets import QMainWindow
            
            if self.recorder_window is None or not self.recorder_window.isVisible():
                self.recorder_window = QMainWindow(self)
                self.recorder_window.setWindowTitle("TSDE Recorder - 240 Hz")
                self.recorder_window.resize(500, 120)
                self.recorder_window.setStyleSheet(Theme.get_stylesheet())
                
                # 🔥 WICHTIG: Debug-Level von Hauptpage übergeben!
                recorder = RecorderPanel(debug_level=self.gui_debug_level)
                self.recorder_window.setCentralWidget(recorder)
                
                self.recorder_window.show()
                self._debug_print(1, "🎬 Recorder Fenster geöffnet")
            else:
                self.recorder_window.raise_()
                self.recorder_window.activateWindow()
                
        except Exception as e:
            self._debug_print(1, f"❌ Fehler beim Öffnen des Recorder-Fensters: {e}")
            QMessageBox.warning(self, "Fehler", 
                            f"Recorder-Fenster konnte nicht geöffnet werden:\n{e}")

    # ------------------------------------------------------------
    # Fenster schließen
    # ------------------------------------------------------------
    def closeEvent(self, event):
        self._debug_print(1, "closeEvent() - GUI wird geschlossen")
        
        self.timer.stop()
        self._save_pedal_values()
        
        if ipc.is_running():
            self._debug_print(1, "Stoppe Engine vor Schließen")
            ipc.stop_engine()
        
        self._debug_print(1, "GUI geschlossen")
        event.accept()


# Factory-Funktion
def create_engine_terminal(parent=None, debug_level=1):
    return EngineTerminal(parent, debug_level)