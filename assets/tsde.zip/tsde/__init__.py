bl_info = {
    "name": "TSDE Loader",
    "author": "Benjamin Thorsten Unger",
    "version": (0, 9, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar",
    "description": "Lädt den TSDE Host aus der TSDE Engine",
    "category": "System",
}

from .tsde_engine import host  # direkt aus Unterpaket

def register():
    host.register()

def unregister():
    host.unregister()