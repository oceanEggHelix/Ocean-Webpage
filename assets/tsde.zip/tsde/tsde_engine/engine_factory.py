import json
from tsde_engine.curves.curve_loader import load_csv_curve
from tsde_engine.setup.track_factory import make_track
from tsde_engine.core.trackgroup import TrackGroup
from tsde_engine.core.engine import Engine
from tsde_engine.core.time import Time
from tsde_engine.core.state import State


def engine_factory():
    """
    Erstellt eine leere Engine - wird später mit Setup aus apply_setup befüllt!
    """
    time_core = Time()
    state = State()
    
    # Leere Engine ohne Tracks
    engine = Engine(time_core, [], state)
    engine.trackgroups = []  # Leere Trackgroups
    
    return engine


def create_engine_from_setup(setup_data):
    """
    Erstellt eine Engine aus den Setup-Daten (wird in apply_setup verwendet)
    
    Args:
        setup_data: Dict mit Gruppen und Tracks aus dem JSON
        
    Returns:
        Engine: Konfigurierte Engine mit allen Tracks
    """
    groups = []

    # Gruppen aus JSON bauen
    for g in setup_data["groups"]:
        tracks = []

        for t in g["tracks"]:
            track_type = t.get("track_type", "motion")
            
            if track_type == "motion":
                # Motion Track: Normale CSV-Kurve laden
                curve_info = t["curve"]
                
                # Prüfe ob Pfad existiert
                if not curve_info["path"]:
                    print(f"[WARN] Kein Kurvenpfad für Motion Track {t['name']}")
                    continue
                
                # Kurve laden
                curve = load_csv_curve(
                    curve_info["path"],
                    curve_info.get("segment_length", 0.01)
                )
                
                # 🔥 WICHTIG: Pfad in der Kurve speichern!
                curve.path = curve_info["path"]
                
                max_speed = t["max_speed"]
                
            else:
                # Empty oder Param Track: Dummy-Kurve ohne Geometrie
                class DummyCurve:
                    def __init__(self):
                        self.length_total = 0.0
                        self.path = ""  # Dummy-Pfad
                    
                    def evaluate(self, t):
                        # Einfaches Tupel statt Point-Klasse
                        return (0.0, 0.0, 0.0)
                
                curve = DummyCurve()
                max_speed = 0.0  # Empty/Param haben keine Bewegung

            # Track erzeugen
            track = make_track(curve, t["name"], max_speed)
            track.track_type = track_type
            
            # 🔥 Zusätzlich: Pfad auch am Track speichern für einfachen Zugriff
            track.curve_path = curve.path if hasattr(curve, 'path') else ""
            
            # Zusätzliche Parameter für Param-Tracks
            if track_type == "param":
                track.param_name = t.get("param_name", "")
                track.param_unit = t.get("param_unit", "")
                track.param_min = t.get("param_min", 0.0)
                track.param_max = t.get("param_max", 1.0)
            
            tracks.append(track)

        # TrackGroup erzeugen
        group = TrackGroup(g["name"], tracks)
        groups.append(group)

    # Engine erzeugen
    time_core = Time()
    state = State()

    # Erste Gruppe als Haupt‑Trackliste (falls vorhanden)
    main_tracks = groups[0].tracks if groups else []
    engine = Engine(time_core, main_tracks, state)

    # Alle Gruppen für GUI/Plugins verfügbar machen
    engine.trackgroups = groups

    return engine