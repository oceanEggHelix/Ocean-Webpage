# tsde_engine/main_gui.py

from tsde_gui.gui_main import start_gui

if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    start_gui()