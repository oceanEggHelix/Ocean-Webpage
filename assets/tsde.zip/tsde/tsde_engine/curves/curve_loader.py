# ------------------------------------------------------------------------
# TSDE Engine – Loader (curve_loader)
# ------------------------------------------------------------------------
# Verantwortlichkeiten:
# - Einlesen von CSV-basierten Kurvenpunkten
# - Übergabe an Preprocess für gleichmäßiges Resampling
# - Erzeugung einer Curve-Instanz für die Engine
#
# Hinweise:
# - Loader kennt KEINE Engine-Logik
# - Loader ist nur Input-Adapter
# - Punkte sind Core-Vec3 (host-unabhängig)
#
# Bug / TODO Section:
# - Später: Unterstützung für weitere Formate (JSON, Blender-Splines)
# - Später: Fehlerbehandlung für ungültige Dateien
# ------------------------------------------------------------------------

from __future__ import annotations

from ..core.vector import Vec3
from .preprocess import resample_spline_points
from ..core.curve import Curve


def load_csv_curve(path: str, segment_length=0.01):
    raw_points = []

    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            parts = line.split()
            if len(parts) != 3:
                continue

            x, y, z = map(float, parts)
            raw_points.append(Vec3(x, y, z))

    uniform = resample_spline_points(raw_points, segment_length)
    return Curve(uniform)