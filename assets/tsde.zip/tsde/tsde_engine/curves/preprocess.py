# ------------------------------------------------------------------------
# TSDE Engine – Preprocess
# ------------------------------------------------------------------------
# Verantwortlichkeiten:
# - Resampling von Punktlisten
# - Vorbereitung von Kurven für die Engine
# - KEINE Engine-Logik
# ------------------------------------------------------------------------

from __future__ import annotations
from math import ceil


def resample_spline_points(points, segment_length):
    """Resample points into globally constant distances."""

    if len(points) < 2:
        return points.copy()

    new_points = [points[0].copy()]
    current_pos = points[0].copy()
    target_dist = segment_length

    i = 1

    while i < len(points):
        next_pt = points[i]
        seg_vec = next_pt - current_pos
        seg_len = seg_vec.length

        if seg_len >= target_dist:
            direction = seg_vec.normalized()
            new_pt = current_pos + direction * target_dist
            new_points.append(new_pt)
            current_pos = new_pt
            target_dist = segment_length
        else:
            current_pos = next_pt
            target_dist -= seg_len
            i += 1

    new_points.append(points[-1].copy())
    return new_points