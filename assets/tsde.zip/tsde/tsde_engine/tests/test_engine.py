from tsde_engine.engine_factory import engine_factory
import time

engine = engine_factory()

# TEST: alle Pedale auf 1 setzen
for t in engine.tracks:
    t.channel.pedal = 1.0

print("=== ENGINE TEST START ===")

for i in range(10):
    engine.tick(1/240)
    print(f"Tick {i:03d}")

    for t in engine.tracks:
        ch = t.channel
        print(f"  {t.name}: pedal={ch.pedal:.2f}, dist={ch.distance:.3f}, t_local={ch.t_local:.3f}")

    time.sleep(0.01)

print("=== ENGINE TEST END ===")