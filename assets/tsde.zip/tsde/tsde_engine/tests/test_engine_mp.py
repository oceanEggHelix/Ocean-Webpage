from tsde_engine.engine_factory import engine_factory
import time

def main():
    engine = engine_factory()

    print("=== MULTI-TRACK SPEED TEST ===")

    results = []

    for group in engine.trackgroups:
        for track in group.tracks:

            # Channel vorbereiten
            ch = track.channel
            ch.reset()
            ch.pedal = 1.0

            length = track.curve.length_total
            vmax = ch.v_max
            dt = 1.0 / 240.0

            tick_count = 0
            start = time.perf_counter()

            # Track fahren lassen
            while ch.t_local < 1.0:
                engine.tick(dt)
                tick_count += 1

            end = time.perf_counter()
            duration = end - start

            results.append({
                "name": track.name,
                "length": length,
                "vmax": vmax,
                "ticks": tick_count,
                "duration": duration,
                "ideal": length / vmax,
                "diff": duration - (length / vmax),
            })

    print("\n=== ERGEBNISSE ===")
    for r in results:
        print(
            f"{r['name']:10s} | "
            f"L={r['length']:7.1f} mm | "
            f"v={r['vmax']:6.1f} mm/s | "
            f"Ticks={r['ticks']:4d} | "
            f"t_real={r['duration']:.6f} s | "
            f"t_ideal={r['ideal']:.6f} s | "
            f"Δ={r['diff']:+.6f} s"
        )

if __name__ == "__main__":
    main()