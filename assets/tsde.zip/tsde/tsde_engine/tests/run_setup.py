# run_setup.py

from PySide6.QtWidgets import QApplication
from tsde_engine.setup.setup_window import SetupWindow
import sys

app = QApplication(sys.argv)

dlg = SetupWindow()
dlg.exec()
