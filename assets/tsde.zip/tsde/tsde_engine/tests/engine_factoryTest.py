from tsde_engine.engine_factory import engine_factory

engine = engine_factory()
print("Engine geladen:", engine)

# Pedal setzen (Runtime, nicht Setup!)
for t in engine.tracks:
    t.channel.velocity = 1.0   # Vollgas

for i in range(10):
    state = engine.tick()
    print(i, state.values)