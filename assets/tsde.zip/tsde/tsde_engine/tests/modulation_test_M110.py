# ------------------------------------------------------------------------
# TSDE Engine – Modulator Test
# ------------------------------------------------------------------------
# Zweck:
#   Testet:
#       - Channel Core
#       - Modulator (constant_lens_feed)
#       - Fake-Kurve mit konstanter Krümmung
#       - Update-Schleife
#
#   Ergebnis:
#       - t_local steigt sauber
#       - distance steigt sauber
#       - Modulator beeinflusst v_eff
# ------------------------------------------------------------------------

# ------------------------------------------------------------------------
# TSDE Engine – Modulator Test (Außenradius)
# ------------------------------------------------------------------------

from tsde_engine.core.channel import Channel
from tsde_engine.modulation.cnc import constant_lens_feed_outer



class TestCurve:
    def __init__(self, length=200.0, curvature=0.02):
        self.length_total = length
        self._curvature = curvature

    def curvature_at(self, t):
        return self._curvature


curve = TestCurve(length=200.0, curvature=0.02)

pivot = Channel(
    curve=curve,
    v_max_mm_s=100.0,
    modulator=constant_lens_feed_outer
)

pivot.focal_length = 35.0
pivot.velocity = 1.0


print("Starte Außenradius-Test...\n")

for i in range(20):
    t = pivot.update(0.016)
    print(
        f"Step {i:02d} | "
        f"t_local={t:.4f} | "
        f"distance={pivot.distance:8.3f} | "
        f"M={pivot.modulator(pivot):6.3f}"
    )

print("\nTest abgeschlossen.")
