from tsde_engine.engine_factory import engine_factory
import time

def get_vmax(channel):
    for key in ("max_speed_mm_s", "max_speed", "v_max", "speed_mm_s"):
        if hasattr(channel, key):
            return getattr(channel, key)
    raise AttributeError("Channel hat kein Max-Speed-Attribut")

def main():
    engine = engine_factory()

    group = engine.trackgroups[0]
    track = group.tracks[0]

    vmax = get_vmax(track.channel)
    length = track.curve.length_total

    print("=== SPEED TEST ===")
    print(f"Track: {track.name}")
    print(f"v_max: {vmax} mm/s")
    print(f"Kurvenlänge: {length} mm")

    # WICHTIG: Reset zuerst, Pedal danach
    track.channel.reset()
    track.channel.pedal = 1.0

    dt = 1.0 / 240.0
    tick_count = 0

    start = time.perf_counter()

    while track.channel.t_local < 1.0:
        engine.tick(dt)
        tick_count += 1

    end = time.perf_counter()
    duration = end - start

    ideal = length / vmax

    print("\n=== ERGEBNIS ===")
    print(f"Ticks: {tick_count}")
    print(f"Systemzeit: {duration:.6f} s")
    print(f"Ideale Zeit: {ideal:.6f} s")
    print(f"Abweichung: {duration - ideal:+.6f} s")

if __name__ == "__main__":
    main()