#!/usr/bin/env python3
# test_editor.py - Standalone Editor Test

import sys
import os
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from PySide6.QtWidgets import QApplication, QMainWindow
from tsde_gui.editor_panel import EditorPanel
from tsde_gui.theme import Theme

class EditorTestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🎨 TSDE Editor - Standalone Test")
        self.resize(1200, 800)
        self.setStyleSheet(Theme.get_stylesheet())
        
        # Editor Panel
        self.editor = EditorPanel()
        self.setCentralWidget(self.editor)
        
        print("✅ Editor bereit!")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = EditorTestWindow()
    window.show()
    sys.exit(app.exec())