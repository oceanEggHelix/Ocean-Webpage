from multiprocessing import Queue
from tsde_engine.engine_factory import engine_factory
from tsde_engine.core.engine_process import EngineProcess
import time

def main():
    out_q = Queue()
    in_q = Queue()

    proc = EngineProcess(engine_factory, out_q, in_q, hz=240)
    proc.start()

    print("Engine läuft…")
    time.sleep(2)

    print("Pause…")
    in_q.put({"cmd": "pause"})
    time.sleep(2)

    print("Weiter…")
    in_q.put({"cmd": "play"})
    time.sleep(2)

    print("Reset…")
    in_q.put({"cmd": "reset"})
    time.sleep(2)

    print("Stop…")
    in_q.put({"cmd": "stop"})
    proc.join()

if __name__ == "__main__":
    main()