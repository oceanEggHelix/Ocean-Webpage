# tsde_engine/recorder/recording_data_np.py
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple, Literal
import json
import numpy as np
import os
from datetime import datetime

# 🔥 TrackType Definition
TrackType = Literal["motion", "empty", "param"]

@dataclass
class TrackRecordingNP:
    """
    Aufnahme eines Tracks - MIT NUMPY!
    - samples als numpy arrays für Performance
    - Jetzt mit Kurvendaten für Visualisierung!
    - Unterstützt verschiedene Track-Typen: motion, empty, param
    """
    track_name: str
    track_type: TrackType = "motion"  # NEU: Typ des Tracks
    
    # Nur für motion tracks relevant
    curve_path: str = ""
    max_speed: float = 0.0
    curve_length: float = 0.0
    
    # Pedal-Daten (vom Recording)
    times: np.ndarray = field(default_factory=lambda: np.array([]))      # t-Werte (0-1)
    pedals: np.ndarray = field(default_factory=lambda: np.array([]))     # Pedal-Werte
    
    # 🔥 Kurven-Daten für Visualisierung (geometrische Kurve) - nur für motion
    curve_t: np.ndarray = field(default_factory=lambda: np.array([]))    # Sampling-Punkte
    curve_x: np.ndarray = field(default_factory=lambda: np.array([]))    # X-Koordinaten
    curve_y: np.ndarray = field(default_factory=lambda: np.array([]))    # Y-Koordinaten
    
    # Absolute Zeit (optional)
    abs_times: np.ndarray = field(default_factory=lambda: np.array([]))
    distances: np.ndarray = field(default_factory=lambda: np.array([]))
    
    # Schnittmarken
    t_start: float = 0.0
    t_end: float = 1.0
    
    # 🔥 Parameter für empty/param Tracks
    param_name: str = ""           # Name des Parameters (z.B. "brightness", "volume")
    param_unit: str = ""           # Einheit (optional)
    param_min: float = 0.0         # Minimalwert
    param_max: float = 1.0         # Maximalwert
    
    def __post_init__(self):
        """Nach Initialisierung: Sortieren und Kurve laden (nur für motion)"""
        # 🔥 Kurve laden wenn Pfad vorhanden und motion track
        if self.track_type == "motion" and self.curve_path and os.path.exists(self.curve_path) and len(self.curve_t) == 0:
            self._load_curve_data()
    
    def _load_curve_data(self, num_samples=200):
        """Lädt die geometrische Kurve und sampled sie - NUR für motion tracks"""
        if self.track_type != "motion":
            return
            
        try:
            from tsde_engine.curves.curve_loader import load_csv_curve
            curve = load_csv_curve(self.curve_path, 0.01)
            
            # Kurve samplen
            self.curve_t = np.linspace(0, 1, num_samples)
            self.curve_x = np.array([curve.evaluate(t).x for t in self.curve_t])
            self.curve_y = np.array([curve.evaluate(t).y for t in self.curve_t])
            
            # Kurvenlänge aktualisieren falls nicht gesetzt
            if self.curve_length == 0:
                self.curve_length = curve.length_total
                
        except Exception as e:
            print(f"[WARN] Kurve konnte nicht geladen werden: {e}")
    
    def _sort(self):
        """Sortiert Arrays nach Zeit"""
        if len(self.times) == 0:
            return
        idx = np.argsort(self.times)
        self.times = self.times[idx]
        self.pedals = self.pedals[idx]
        if len(self.abs_times) == len(self.times):
            self.abs_times = self.abs_times[idx]
        if len(self.distances) == len(self.times):
            self.distances = self.distances[idx]
    
    @property
    def num_samples(self) -> int:
        """Anzahl der Pedal-Samples"""
        return len(self.times)
    
    @property
    def sample_rate(self) -> float:
        """Berechnet Sample-Rate"""
        if len(self.times) < 2:
            return 0.0
        dt = np.mean(np.diff(self.times[:100]))
        return 1.0 / dt if dt > 0 else 0.0
    
    def add_sample(self, t: float, pedal: float, abs_time: float = 0.0, dist: float = 0.0):
        """Fügt ein Pedal-Sample hinzu"""
        self.times = np.append(self.times, t)
        self.pedals = np.append(self.pedals, pedal)
        self.abs_times = np.append(self.abs_times, abs_time)
        self.distances = np.append(self.distances, dist)
    
    def add_samples(self, times: np.ndarray, pedals: np.ndarray, 
                   abs_times: Optional[np.ndarray] = None,
                   distances: Optional[np.ndarray] = None):
        """Fügt mehrere Samples auf einmal hinzu"""
        self.times = np.concatenate([self.times, times])
        self.pedals = np.concatenate([self.pedals, pedals])
        
        if abs_times is not None:
            self.abs_times = np.concatenate([self.abs_times, abs_times])
        if distances is not None:
            self.distances = np.concatenate([self.distances, distances])
    
    def trim(self, t_start: float, t_end: float) -> 'TrackRecordingNP':
        """Erzeugt neues Recording mit getrimmtem Bereich"""
        mask = (self.times >= t_start) & (self.times <= t_end)
        
        trimmed = TrackRecordingNP(
            track_name=self.track_name,
            track_type=self.track_type,  # Typ übernehmen
            curve_path=self.curve_path,
            max_speed=self.max_speed,
            curve_length=self.curve_length,
            times=self.times[mask].copy(),
            pedals=self.pedals[mask].copy(),
            t_start=t_start,
            t_end=t_end,
            # Parameter für empty/param übernehmen
            param_name=self.param_name,
            param_unit=self.param_unit,
            param_min=self.param_min,
            param_max=self.param_max
        )
        
        # Kurvendaten übernehmen (nur für motion tracks)
        if self.track_type == "motion" and len(self.curve_t) > 0:
            trimmed.curve_t = self.curve_t.copy()
            trimmed.curve_x = self.curve_x.copy()
            trimmed.curve_y = self.curve_y.copy()
        
        if len(self.abs_times) == len(self.times):
            trimmed.abs_times = self.abs_times[mask].copy()
        if len(self.distances) == len(self.times):
            trimmed.distances = self.distances[mask].copy()
        
        return trimmed
    
    def normalize(self) -> 'TrackRecordingNP':
        """Normalisiert t auf 0-1 für geschnittenen Bereich"""
        if len(self.times) == 0 or self.t_end == self.t_start:
            return self
        
        t_range = self.t_end - self.t_start
        
        normalized = TrackRecordingNP(
            track_name=self.track_name,
            track_type=self.track_type,  # Typ übernehmen
            curve_path=self.curve_path,
            max_speed=self.max_speed,
            curve_length=self.curve_length,
            times=(self.times - self.t_start) / t_range,
            pedals=self.pedals.copy(),
            t_start=0.0,
            t_end=1.0,
            # Parameter für empty/param übernehmen
            param_name=self.param_name,
            param_unit=self.param_unit,
            param_min=self.param_min,
            param_max=self.param_max
        )
        
        # Kurvendaten übernehmen (nur für motion tracks)
        if self.track_type == "motion" and len(self.curve_t) > 0:
            normalized.curve_t = self.curve_t.copy()
            normalized.curve_x = self.curve_x.copy()
            normalized.curve_y = self.curve_y.copy()
        
        return normalized
    
    def get_pedal_at_t(self, t_norm: float, method: str = 'nearest') -> float:
        """
        Findet Pedalwert zu Zeit t_norm
        
        Args:
            t_norm: Zeit (0-1)
            method: 'nearest', 'linear', 'zero' (Hold)
        """
        if len(self.times) == 0:
            return 0.0
        
        if method == 'nearest':
            idx = np.argmin(np.abs(self.times - t_norm))
            return self.pedals[idx]
        
        elif method == 'linear':
            return float(np.interp(t_norm, self.times, self.pedals))
        
        elif method == 'zero':
            idx = np.searchsorted(self.times, t_norm) - 1
            idx = max(0, min(idx, len(self.pedals) - 1))
            return self.pedals[idx]
        
        return 0.0
    
    def get_pedal_array(self, num_points: int = 1000) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generiert gleichmäßig verteilte Pedal-Werte für Visualisierung
        
        Returns:
            (t_values, pedal_values) als numpy arrays
        """
        t_values = np.linspace(0, 1, num_points)
        pedal_values = np.interp(t_values, self.times, self.pedals)
        return t_values, pedal_values
    
    # In tsde_engine/recorder/recording_data_np.py

    def to_dict(self) -> dict:
        """Konvertiert zu Dict für JSON - JETZT MIT TRACK-TYPEN!"""
        # 🔥 BASIS: Altes Format komplett erhalten!
        data = {
            "track_name": self.track_name,
            "curve_path": self.curve_path,
            "max_speed": self.max_speed,
            "curve_length": self.curve_length,
            "t_start": self.t_start,
            "t_end": self.t_end,
            "track_type": self.track_type,  # 🔥 GANZ WICHTIG: DIREKT INS BASIS-DICT!
            "samples": [
                {"t": t, "pedal": p}
                for t, p in zip(self.times, self.pedals)
            ]
        }
        
        # 🔥 Kurven-Daten mit speichern (für Editor)
        if len(self.curve_t) > 0:
            data["curve_preview"] = {
                "t": self.curve_t.tolist(),
                "x": self.curve_x.tolist(),
                "y": self.curve_y.tolist()
            }
        
        # 🔥 Param-Track spezifische Daten (nur wenn vorhanden)
        if self.track_type in ["empty", "param"] and self.param_name:
            data.update({
                "param_name": self.param_name,
                "param_unit": self.param_unit,
                "param_min": self.param_min,
                "param_max": self.param_max
            })
        
        return data
        
    @classmethod
    def from_dict(cls, data: dict) -> 'TrackRecordingNP':
        """Erstellt TrackRecording aus Dict"""
        samples = data["samples"]
        times = np.array([s["t"] for s in samples])
        pedals = np.array([s["pedal"] for s in samples])
        
        # Track-Typ bestimmen (Default: motion für Kompatibilität)
        track_type = data.get("track_type", "motion")
        
        track = cls(
            track_name=data["track_name"],
            track_type=track_type,
            curve_path=data.get("curve_path", ""),
            max_speed=data.get("max_speed", 0.0),
            curve_length=data.get("curve_length", 0.0),
            times=times,
            pedals=pedals,
            t_start=data.get("t_start", 0.0),
            t_end=data.get("t_end", 1.0),
            # Parameter für empty/param Tracks
            param_name=data.get("param_name", ""),
            param_unit=data.get("param_unit", ""),
            param_min=data.get("param_min", 0.0),
            param_max=data.get("param_max", 1.0)
        )
        
        # Kurven-Preview laden falls vorhanden (nur für motion)
        if track_type == "motion" and "curve_preview" in data:
            preview = data["curve_preview"]
            track.curve_t = np.array(preview["t"])
            track.curve_x = np.array(preview["x"])
            track.curve_y = np.array(preview["y"])
        
        return track
    
    def to_editable(self):
        """Konvertiert zu EditableTrack für Editor"""
        from tsde_engine.recorder.editor_data import EditableTrack
        return EditableTrack(
            name=self.track_name,
            original_times=self.times.copy(),
            original_pedals=self.pedals.copy()
        )
    
    # 🔥 Factory Methods für verschiedene Track-Typen
    @classmethod
    def create_motion_track(cls, track_name: str, curve_path: str, max_speed: float, curve_length: float = 0.0) -> 'TrackRecordingNP':
        """Erstellt einen Motion-Track (Bewegung entlang Geometrie)"""
        return cls(
            track_name=track_name,
            track_type="motion",
            curve_path=curve_path,
            max_speed=max_speed,
            curve_length=curve_length
        )
    
    @classmethod
    def create_empty_track(cls, track_name: str) -> 'TrackRecordingNP':
        """Erstellt einen leeren Empty-Track (nur Pedal-Werte, keine Geometrie)"""
        return cls(
            track_name=track_name,
            track_type="empty"
        )
    
    @classmethod
    def create_param_track(cls, track_name: str, param_name: str = "", 
                          param_unit: str = "", param_min: float = 0.0, 
                          param_max: float = 1.0) -> 'TrackRecordingNP':
        """Erstellt einen Parameter-Track (für Steuerung von Effekten/Lichtern etc.)"""
        return cls(
            track_name=track_name,
            track_type="param",
            param_name=param_name,
            param_unit=param_unit,
            param_min=param_min,
            param_max=param_max
        )


@dataclass
class RecordingSessionNP:
    """Komplette Aufnahmesession mit Numpy"""
    name: str
    date: str
    duration: float
    tracks: Dict[str, TrackRecordingNP] = field(default_factory=dict)
    
    t_start: float = 0.0
    t_end: float = 1.0
    
    @property
    def total_samples(self) -> int:
        """Gesamtanzahl Samples über alle Tracks"""
        return sum(t.num_samples for t in self.tracks.values())
    
    def trim_global(self, t_start: float, t_end: float) -> 'RecordingSessionNP':
        """Trimmt ALLE Tracks gleichzeitig - 🔥 JETZT VORHANDEN!"""
        trimmed = RecordingSessionNP(
            name=f"{self.name}_trimmed",
            date=datetime.now().isoformat(),
            duration=self.duration
        )
        
        for name, track in self.tracks.items():
            trimmed.tracks[name] = track.trim(t_start, t_end)
        
        trimmed.t_start = t_start
        trimmed.t_end = t_end
        
        return trimmed
    
    def to_dict(self) -> dict:
        """Konvertiert zu Dict für JSON"""
        return {
            "name": self.name,
            "date": self.date,
            "duration": self.duration,
            "t_start": self.t_start,
            "t_end": self.t_end,
            "tracks": {
                name: track.to_dict()
                for name, track in self.tracks.items()
            }
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'RecordingSessionNP':
        """Erstellt Session aus Dict"""
        session = cls(
            name=data["name"],
            date=data["date"],
            duration=data["duration"],
            t_start=data.get("t_start", 0.0),
            t_end=data.get("t_end", 1.0)
        )
        
        for name, track_data in data["tracks"].items():
            session.tracks[name] = TrackRecordingNP.from_dict(track_data)
        
        return session
    
    def get_summary(self) -> dict:
        """Gibt Zusammenfassung zurück"""
        return {
            "name": self.name,
            "date": self.date,
            "duration": self.duration,
            "tracks": len(self.tracks),
            "total_samples": self.total_samples,
            "avg_sample_rate": self.total_samples / self.duration if self.duration > 0 else 0,
            "t_range": (self.t_start, self.t_end)
        }