# ------------------------------------------------------------------------
# TSDE Engine – Buffer
# ------------------------------------------------------------------------
# Verantwortlichkeiten:
# - Hilfsfunktionen für Recorder
# - Analyse von Punktlisten
# ------------------------------------------------------------------------

from __future__ import annotations


def find_closest_t(pos, points):
    """Finds the normalized t (0–1) of the closest point to pos."""

    if not points or pos is None:
        return 0.0

    closest_idx = 0
    min_dist = float("inf")

    for i, p in enumerate(points):
        d = (p - pos).length
        if d < min_dist:
            min_dist = d
            closest_idx = i

    if len(points) == 1:
        return 0.0

    return closest_idx / (len(points) - 1)