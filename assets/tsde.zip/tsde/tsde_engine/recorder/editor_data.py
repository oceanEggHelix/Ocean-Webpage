# tsde_engine/recorder/editor_data.py
import numpy as np
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class EditAction:
    """Eine editierbare Aktion für Undo/Redo"""
    times: np.ndarray
    pedals: np.ndarray
    description: str = ""


class EditableTrack:
    """
    Track für Live-Editierung im Editor
    - Numpy arrays für Performance
    - Undo/Redo Stack
    - Verschiedene Editier-Operationen
    """
    
    def __init__(self, name: str, original_times: np.ndarray, original_pedals: np.ndarray):
        self.name = name
        self.original_times = original_times.copy()
        self.original_pedals = original_pedals.copy()
        
        # Editierte Version (wird modifiziert)
        self.edited_times = original_times.copy()
        self.edited_pedals = original_pedals.copy()
        
        # Undo/Redo
        self.undo_stack: List[EditAction] = []
        self.redo_stack: List[EditAction] = []
        
        # Selektierter Bereich
        self.selected_region: Optional[Tuple[float, float]] = None
        self.selected_points: np.ndarray = np.array([], dtype=int)
    
    @property
    def current_times(self) -> np.ndarray:
        return self.edited_times
    
    @property
    def current_pedals(self) -> np.ndarray:
        return self.edited_pedals
    
    @property
    def num_samples(self) -> int:
        return len(self.edited_times)
    
    # ============ UNDO/REDO ============
    
    def _push_undo(self, description: str = "Edit"):
        """Speichert aktuellen Zustand für Undo"""
        self.undo_stack.append(EditAction(
            times=self.edited_times.copy(),
            pedals=self.edited_pedals.copy(),
            description=description
        ))
        self.redo_stack.clear()
        
        # Stack-Größe begrenzen
        if len(self.undo_stack) > 50:
            self.undo_stack.pop(0)
    
    def undo(self) -> bool:
        """Macht letzte Änderung rückgängig"""
        if not self.undo_stack:
            return False
        
        # Aktuellen Zustand für Redo speichern
        self.redo_stack.append(EditAction(
            times=self.edited_times.copy(),
            pedals=self.edited_pedals.copy(),
            description="Redo"
        ))
        
        # Letzten Zustand wiederherstellen
        last = self.undo_stack.pop()
        self.edited_times = last.times
        self.edited_pedals = last.pedals
        
        return True
    
    def redo(self) -> bool:
        """Stellt rückgängig gemachte Änderung wieder her"""
        if not self.redo_stack:
            return False
        
        # Aktuellen Zustand für Undo speichern
        self.undo_stack.append(EditAction(
            times=self.edited_times.copy(),
            pedals=self.edited_pedals.copy(),
            description="Undo"
        ))
        
        # Nächsten Zustand wiederherstellen
        next_state = self.redo_stack.pop()
        self.edited_times = next_state.times
        self.edited_pedals = next_state.pedals
        
        return True
    
    # ============ EDITIER-FUNKTIONEN ============
    
    def set_pedal_at_time(self, t: float, new_pedal: float, radius: float = 0.01):
        """
        Ändert Pedal an bestimmter Stelle (gewichteter Einfluss)
        
        Args:
            t: Zielzeit (0-1)
            new_pedal: Neuer Pedalwert (-1..1)
            radius: Einflussradius (in t-Einheiten)
        """
        self._push_undo(f"Set pedal at {t:.3f}")
        
        # Finde Samples im Radius
        distances = np.abs(self.edited_times - t)
        mask = distances < radius
        
        if not np.any(mask):
            # Keine Samples in der Nähe - neuen Punkt einfügen?
            return
        
        # Gewichtete Änderung (näher = stärker)
        weights = 1 - (distances[mask] / radius)
        self.edited_pedals[mask] = (
            self.edited_pedals[mask] * (1 - weights) + new_pedal * weights
        )
    
    def set_pedal_at_index(self, idx: int, new_pedal: float):
        """Ändert Pedal an bestimmtem Index"""
        if 0 <= idx < len(self.edited_pedals):
            self._push_undo(f"Set point {idx}")
            self.edited_pedals[idx] = np.clip(new_pedal, -1, 1)
    
    def move_point(self, idx: int, new_t: float, new_pedal: float):
        """Verschiebt einen Punkt (Zeit und/oder Pedal)"""
        if 0 <= idx < len(self.edited_times):
            self._push_undo(f"Move point {idx}")
            self.edited_times[idx] = np.clip(new_t, 0, 1)
            self.edited_pedals[idx] = np.clip(new_pedal, -1, 1)
            self._sort()
    
    def smooth_region(self, t_start: float, t_end: float, strength: float = 0.5):
        """
        Glättet einen Bereich mit Moving Average
        
        Args:
            t_start: Startzeit
            t_end: Endzeit
            strength: Glättungsstärke (0-1)
        """
        self._push_undo(f"Smooth [{t_start:.2f}-{t_end:.2f}]")
        
        mask = (self.edited_times >= t_start) & (self.edited_times <= t_end)
        if not np.any(mask):
            return
        
        # Moving Average
        kernel_size = max(3, int(len(self.edited_times[mask]) * strength))
        kernel = np.ones(kernel_size) / kernel_size
        
        # Pad für Rand-Effekte
        padded = np.pad(self.edited_pedals[mask], kernel_size//2, mode='edge')
        smoothed = np.convolve(padded, kernel, mode='valid')
        
        # Auf Original-Länge kürzen
        self.edited_pedals[mask] = smoothed[:len(self.edited_pedals[mask])]
    
    def add_peak(self, t: float, height: float, width: float = 0.05):
        """Fügt einen Peak (Dreieck) ein"""
        self._push_undo(f"Add peak at {t:.3f}")
        
        mask = np.abs(self.edited_times - t) < width
        if not np.any(mask):
            return
        
        # Dreiecksform
        distances = np.abs(self.edited_times[mask] - t) / width
        peak_shape = 1 - distances
        self.edited_pedals[mask] = height * peak_shape
    
    def scale_region(self, t_start: float, t_end: float, factor: float):
        """Skaliert Pedal-Werte in einem Bereich"""
        self._push_undo(f"Scale [{t_start:.2f}-{t_end:.2f}] by {factor:.2f}")
        
        mask = (self.edited_times >= t_start) & (self.edited_times <= t_end)
        if np.any(mask):
            self.edited_pedals[mask] = np.clip(
                self.edited_pedals[mask] * factor, -1, 1
            )
    
    def invert_region(self, t_start: float, t_end: float):
        """Invertiert Pedal-Werte in einem Bereich (positiv <-> negativ)"""
        self._push_undo(f"Invert [{t_start:.2f}-{t_end:.2f}]")
        
        mask = (self.edited_times >= t_start) & (self.edited_times <= t_end)
        if np.any(mask):
            self.edited_pedals[mask] = -self.edited_pedals[mask]
    
    def _sort(self):
        """Sortiert nach Zeit"""
        idx = np.argsort(self.edited_times)
        self.edited_times = self.edited_times[idx]
        self.edited_pedals = self.edited_pedals[idx]
    
    # ============ AUSWAHL ============
    
    def select_region(self, t_start: float, t_end: float):
        """Markiert einen Bereich für Bearbeitung"""
        self.selected_region = (t_start, t_end)
        self.selected_points = np.where(
            (self.edited_times >= t_start) & (self.edited_times <= t_end)
        )[0]
    
    def clear_selection(self):
        """Löscht Auswahl"""
        self.selected_region = None
        self.selected_points = np.array([], dtype=int)
    
    # ============ EXPORT ============
    
    def export_for_player(self) -> dict:
        """Exportiert editierte Version für Player"""
        return {
            "name": self.name,
            "times": self.edited_times.tolist(),
            "pedals": self.edited_pedals.tolist(),
            "num_samples": self.num_samples
        }
    
    def export_original(self) -> dict:
        """Exportiert Original-Version"""
        return {
            "name": self.name,
            "times": self.original_times.tolist(),
            "pedals": self.original_pedals.tolist(),
            "num_samples": len(self.original_times)
        }
    
    def reset_to_original(self):
        """Setzt auf Original zurück"""
        self._push_undo("Reset to original")
        self.edited_times = self.original_times.copy()
        self.edited_pedals = self.original_pedals.copy()

        # GANZ AM ENDE der Datei einfügen:

class EditableSession:
    """
    Komplette editierbare Session mit mehreren Tracks
    """
    def __init__(self, name: str, tracks: List[EditableTrack]):
        self.name = name
        self.tracks = tracks
        
    def get_track(self, name: str) -> Optional[EditableTrack]:
        """Findet Track nach Namen"""
        for track in self.tracks:
            if track.name == name:
                return track
        return None
    
    @property
    def total_samples(self) -> int:
        """Gesamtanzahl Samples über alle Tracks"""
        return sum(t.num_samples for t in self.tracks)
    
    def get_track_names(self) -> List[str]:
        """Gibt alle Track-Namen zurück"""
        return [t.name for t in self.tracks]
    
    def reset_all_to_original(self):
        """Setzt alle Tracks auf Original zurück"""
        for track in self.tracks:
            track.reset_to_original()


class EditableTrack:
    def __init__(self, name, times, pedals):
        self.name = name
        self._current_times = times
        self._current_pedals = pedals
        self.t_min = 0.0
        self.t_max = 1.0
    
    @property
    def current_times(self):
        return self._current_times
    
    @current_times.setter
    def current_times(self, value):
        self._current_times = value
        if len(value) > 0:
            self.t_min = float(value.min())
            self.t_max = float(value.max())
    
    @property
    def current_pedals(self):
        return self._current_pedals
    
    @current_pedals.setter
    def current_pedals(self, value):
        self._current_pedals = value            