# tsde_engine/recorder/deterministic_recorder.py
import time
import json
import numpy as np
from datetime import datetime
from collections import deque
from typing import List, Dict, Optional, Tuple
from .recording_data_np import RecordingSessionNP, TrackRecordingNP


class DeterministicRecorder:
    """
    DETERMINISTISCHER Recorder - 240 Hz VOLLAUFLÖSUNG!
    - Speichert JEDEN Tick der Engine als numpy arrays
    - Unterstützt Motion, Empty und Param Tracks
    - KEINE Sample-Rate Begrenzung
    - 80% weniger Speicher als Python-Listen!
    """
    
    def __init__(self, engine):
        """
        Args:
            engine: Die echte TSDE Engine (nicht der Process!)
        """
        self.engine = engine
        self.is_recording = False
        self.recording_start_time = 0.0
        self.current_session: Optional[RecordingSessionNP] = None
        self.engine_process = None  # Für Zeitmessung
        
        # ✅ Temporäre Buffer während Recording (für Performance)
        self._temp_buffers = {}  # track_name -> {times: [], pedals: [], times_abs: [], dists: []}
        
    def set_engine_process(self, engine_process):
        """Optional: EngineProcess für Zeitmessung setzen"""
        self.engine_process = engine_process
        
    def get_elapsed_time(self):
        """Holt die vergangene Zeit vom EngineProcess oder berechnet selbst"""
        if self.engine_process:
            return self.engine_process.get_elapsed_time()
        return time.perf_counter() - self.recording_start_time
        
    
    def start_recording(self, session_name: str = None):
        if not self.engine:
            return False
        
        self.is_recording = True
        self.recording_start_time = self.engine_process.get_elapsed_time() if self.engine_process else time.perf_counter()
        
        session_name = session_name or f"Recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        self.current_session = RecordingSessionNP(
            name=session_name,
            date=datetime.now().isoformat(),
            duration=0.0
        )
        
        self._temp_buffers.clear()
        
        for group in self.engine.trackgroups:
            for track in group.tracks:
                # 🔥 Track-Typ auslesen
                track_type = getattr(track, 'track_type', 'motion')
                
                # 🔥 Pfad direkt vom Track-Objekt!
                curve_path = getattr(track.curve, 'path', "")
                
                # 🔥 Unterschiedliche Track-Typen erstellen
                if track_type == "motion":
                    track_rec = TrackRecordingNP.create_motion_track(
                        track_name=track.name,
                        curve_path=curve_path,
                        max_speed=track.channel.v_max,
                        curve_length=track.curve.length_total
                    )
                elif track_type == "empty":
                    track_rec = TrackRecordingNP.create_empty_track(
                        track_name=track.name
                    )
                else:  # param
                    track_rec = TrackRecordingNP.create_param_track(
                        track_name=track.name,
                        param_name=getattr(track, 'param_name', ''),
                        param_unit=getattr(track, 'param_unit', ''),
                        param_min=getattr(track, 'param_min', 0.0),
                        param_max=getattr(track, 'param_max', 1.0)
                    )
                
                self.current_session.tracks[track.name] = track_rec
                
                self._temp_buffers[track.name] = {
                    'times': [],
                    'pedals': [],
                    'abs_times': [],
                    'dists': []
                }
        
        self.record_sample()
        print(f"[RECORDER] ✅ Recording gestartet: {session_name}")
        return True
        
    
    def record_sample(self):
        """Nimmt EIN Sample auf - JEDER TICK WIRD AUFGENOMMEN!"""
        if not self.is_recording or not self.current_session:
            return
        
        if self.engine_process:
            current_time = self.engine_process.get_elapsed_time()
        else:
            current_time = time.perf_counter()
            
        rel_time = current_time - self.recording_start_time
        
        # ✅ Samples in temporäre Buffer sammeln
        for group in self.engine.trackgroups:
            for track in group.tracks:
                ch = track.channel
                
                if track.name in self._temp_buffers:
                    buf = self._temp_buffers[track.name]
                    
                    # 🔥 Unterschiedliche t-Berechnung je nach Track-Typ
                    track_type = getattr(track, 'track_type', 'motion')
                    
                    if track_type == "motion":
                        # Motion Track: echte geometrische Distanz
                        dist = ch.distance
                        t = dist / track.curve.length_total if track.curve.length_total > 0 else 0.0
                    else:
                        # 🔥 FIX: Empty/Param Track - Sample-Index als Roh-t!
                        # Während Recording wissen wir die Duration noch nicht
                        current_index = len(buf['times'])
                        t = float(current_index)  # Roh-Index (0,1,2,3...)
                        dist = 0.0
                    
                    buf['times'].append(t)
                    buf['dists'].append(dist)
                    buf['pedals'].append(ch.pedal)
                    buf['abs_times'].append(rel_time)
                    
    
    def stop_recording(self) -> Optional[RecordingSessionNP]:
        """Stoppt Recording - JETZT MIT NORMALISIERUNG FÜR EMPTY TRACKS!"""
        if not self.is_recording or not self.current_session:
            return None
        
        self.is_recording = False
        
        # Dauer berechnen
        if self.engine_process:
            end_time = self.engine_process.get_elapsed_time()
        else:
            end_time = time.perf_counter()
            
        self.current_session.duration = end_time - self.recording_start_time
        
        # ✅ Temporäre Buffer zu numpy arrays konvertieren
        total_samples = 0
        for track_name, buf in self._temp_buffers.items():
            if track_name in self.current_session.tracks:
                track = self.current_session.tracks[track_name]
                
                # Konvertiere Listen zu numpy arrays
                times = np.array(buf['times'])
                pedals = np.array(buf['pedals'])
                abs_times = np.array(buf['abs_times'])
                dists = np.array(buf['dists'])
                
                # 🔥 FIX: Für Empty/Param Tracks: t auf 0-1 normalisieren!
                if track.track_type != "motion" and len(times) > 0:
                    max_index = len(times) - 1
                    if max_index > 0:
                        times = times / max_index  # Normalisieren auf 0-1
                        print(f"[RECORDER] 🔄 Normalisiere {track_name}: {len(times)} Samples auf t=0-1")
                    else:
                        times = np.zeros_like(times)
                
                # In TrackRecording speichern
                track.times = times
                track.pedals = pedals
                track.abs_times = abs_times
                track.distances = dists
                
                total_samples += len(times)
        
        # Temporäre Buffer löschen
        self._temp_buffers.clear()
        
        # Statistik ausgeben
        avg_hz = total_samples / self.current_session.duration if self.current_session.duration > 0 else 0
        print(f"[RECORDER] ✅ Recording gestoppt: {total_samples} Samples, "
            f"{self.current_session.duration:.1f}s, {avg_hz:.1f} Hz")
        
        return self.current_session
    
    # ------------------------------------------------------------
    # Buffer Zugriff (angepasst für numpy)
    # ------------------------------------------------------------
    
    def get_track_buffer(self, track_name: str, max_samples: int = 1000) -> List[dict]:
        """Gibt Live-Buffer für bestimmten Track zurück (für GUI)"""
        if not self.current_session or track_name not in self.current_session.tracks:
            return []
        
        track = self.current_session.tracks[track_name]
        
        # Dezimieren für GUI
        if track.num_samples > max_samples:
            step = track.num_samples // max_samples
            indices = np.arange(0, track.num_samples, step)
            
            return [
                {
                    't': track.times[i],
                    'pedal': track.pedals[i],
                    'time': track.abs_times[i] if i < len(track.abs_times) else 0.0,
                    'dist': track.distances[i] if i < len(track.distances) else 0.0
                }
                for i in indices
            ]
        else:
            return [
                {
                    't': track.times[i],
                    'pedal': track.pedals[i],
                    'time': track.abs_times[i] if i < len(track.abs_times) else 0.0,
                    'dist': track.distances[i] if i < len(track.distances) else 0.0
                }
                for i in range(track.num_samples)
            ]
    
    def get_buffer_size(self, track_name: str = None) -> int:
        """Gibt Buffer-Größe zurück"""
        if not self.current_session:
            return 0
            
        if track_name:
            if track_name in self.current_session.tracks:
                return self.current_session.tracks[track_name].num_samples
            return 0
        else:
            return sum(t.num_samples for t in self.current_session.tracks.values())
    
    # ------------------------------------------------------------
    # Speichern/Laden (angepasst für numpy)
    # ------------------------------------------------------------
    
    def save_recording(self, filepath: str, 
                      trim: Tuple[float, float] = None,
                      normalize: bool = False,
                      decimate: int = 1):
        """Speichert Recording - 240 Hz original oder dezimiert"""
        if not self.current_session:
            return False
        
        session = self.current_session
        
        # 1. Optional: Trimmen
        if trim:
            t_start, t_end = trim
            session = session.trim_global(t_start, t_end)
        
        # 2. Optional: Dezimieren
        if decimate > 1:
            decimated_tracks = {}
            for name, track in session.tracks.items():
                # Nimm jeden decimate-ten Sample
                indices = np.arange(0, track.num_samples, decimate)
                
                # 🔥 Track-Typ beachten beim Erstellen
                if track.track_type == "motion":
                    new_track = TrackRecordingNP.create_motion_track(
                        track_name=track.track_name,
                        curve_path=track.curve_path,
                        max_speed=track.max_speed,
                        curve_length=track.curve_length
                    )
                elif track.track_type == "empty":
                    new_track = TrackRecordingNP.create_empty_track(
                        track_name=track.track_name
                    )
                else:  # param
                    new_track = TrackRecordingNP.create_param_track(
                        track_name=track.track_name,
                        param_name=track.param_name,
                        param_unit=track.param_unit,
                        param_min=track.param_min,
                        param_max=track.param_max
                    )
                
                new_track.times = track.times[indices].copy()
                new_track.pedals = track.pedals[indices].copy()
                new_track.t_start = track.t_start
                new_track.t_end = track.t_end
                
                decimated_tracks[name] = new_track
            session.tracks = decimated_tracks
        
        # 3. Optional: Normalisieren (NUR wenn explizit gewünscht!)
        if normalize:
            normalized_tracks = {}
            for name, track in session.tracks.items():
                normalized_tracks[name] = track.normalize()
            session.tracks = normalized_tracks
            session.t_start = 0.0
            session.t_end = 1.0
        
        # 4. Speichern
        try:
            with open(filepath, 'w') as f:
                json.dump(session.to_dict(), f, indent=2)
            
            total_samples = session.total_samples
            print(f"[RECORDER] ✅ Gespeichert: {filepath}")
            print(f"           {total_samples} Samples, {session.duration:.1f}s")
            return True
        except Exception as e:
            print(f"[RECORDER] ❌ Fehler beim Speichern: {e}")
            return False
    
    def load_recording(self, filepath: str) -> Optional[RecordingSessionNP]:
        """Lädt gespeichertes Recording"""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            
            session = RecordingSessionNP.from_dict(data)
            self.current_session = session
            
            print(f"[RECORDER] ✅ Geladen: {filepath}")
            total_samples = session.total_samples
            print(f"           {total_samples} Samples, {session.duration:.1f}s")
            
            return session
        except Exception as e:
            print(f"[RECORDER] ❌ Fehler beim Laden: {e}")
            return None
    
    def get_pedal_sequence(self, track_name: str, 
                          max_samples: int = 1000) -> Tuple[List[float], List[float]]:
        """
        Gibt Pedal-Sequenz für Visualisierung zurück
        
        Returns:
            (times, values) als Python-Listen für JSON-Serialisierung
        """
        if not self.current_session or track_name not in self.current_session.tracks:
            return [], []
        
        track = self.current_session.tracks[track_name]
        
        if max_samples and track.num_samples > max_samples:
            # Gleichmäßig verteilte Samples für smoothe Darstellung
            indices = np.linspace(0, track.num_samples - 1, max_samples, dtype=int)
            times = track.times[indices].tolist()
            values = track.pedals[indices].tolist()
        else:
            times = track.times.tolist()
            values = track.pedals.tolist()
        
        return times, values
    
    def get_pedal_array(self, track_name: str, num_points: int = 1000) -> Tuple[np.ndarray, np.ndarray]:
        """
        Gibt gleichmäßig interpolierte Pedal-Kurve zurück
        
        Returns:
            (times, values) als numpy arrays
        """
        if not self.current_session or track_name not in self.current_session.tracks:
            return np.array([]), np.array([])
        
        track = self.current_session.tracks[track_name]
        return track.get_pedal_array(num_points)