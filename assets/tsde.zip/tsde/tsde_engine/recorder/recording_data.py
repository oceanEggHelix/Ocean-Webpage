# tsde_engine/recorder/recording_data.py
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import json
from datetime import datetime

@dataclass
class RecordingSample:
    """Ein einzelnes Sample - NUR Rohdaten, KEINE Interpretation"""
    t: float          # Original t_local (0-1)
    pedal: float      # Pedalwert (-1.0 bis +1.0)
    time: float       # Absolute Engine-Zeit (t0-1)
    dist: float       # Zurückgelegte Distanz

@dataclass
class TrackRecording:
    """Aufnahme eines Tracks - NUR Samples und Schnittmarken"""
    track_name: str
    curve_path: str
    max_speed: float
    curve_length: float
    samples: List[RecordingSample] = field(default_factory=list)
    
    # 🔥 NEU: Track-Typ (motion, empty, param)
    track_type: str = "motion"
    
    # 🔥 NEU: Param-Track Felder
    param_name: str = ""
    param_unit: str = ""
    param_min: float = 0.0
    param_max: float = 1.0
    
    # Schnittmarken (in originaler t-Skala)
    t_start: float = 0.0
    t_end: float = 1.0
    
    # 🔥 NEU: Für Editor-Daten (Spline, Modus, etc.)
    editor_data: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Nach Initialisierung: Samples sortieren"""
        if self.samples:
            self.samples.sort(key=lambda s: s.t)
    
    @property
    def sample_rate(self) -> float:
        """Berechnet tatsächliche Sample-Rate"""
        if len(self.samples) < 2:
            return 0.0
        t_vals = [s.t for s in self.samples[:100]]
        if len(t_vals) < 2:
            return 0.0
        avg_dt = sum(t_vals[i+1] - t_vals[i] for i in range(len(t_vals)-1)) / (len(t_vals)-1)
        return 1.0 / avg_dt if avg_dt > 0 else 0.0
    
    def add_sample(self, sample: RecordingSample):
        """Fügt Sample hinzu"""
        self.samples.append(sample)
    
    def sort_samples(self):
        """Explizite Sortierung"""
        self.samples.sort(key=lambda s: s.t)
    
    def trim(self, t_start: float, t_end: float) -> 'TrackRecording':
        """Erzeugt neues Recording mit getrimmtem Bereich"""
        trimmed = TrackRecording(
            track_name=self.track_name,
            curve_path=self.curve_path,
            max_speed=self.max_speed,
            curve_length=self.curve_length,
            track_type=self.track_type,      # 🔥 Typ mitnehmen
            param_name=self.param_name,      # 🔥 Param-Felder mitnehmen
            param_unit=self.param_unit,
            param_min=self.param_min,
            param_max=self.param_max
        )
        trimmed.samples = [s for s in self.samples if t_start <= s.t <= t_end]
        trimmed.t_start = t_start
        trimmed.t_end = t_end
        # 🔥 Editor-Daten mitnehmen (optional)
        if self.editor_data:
            trimmed.editor_data = self.editor_data.copy()
        return trimmed
    
    def normalize(self) -> 'TrackRecording':
        """Normalisiert t auf 0-1 für geschnittenen Bereich"""
        if not self.samples or self.t_end == self.t_start:
            return self
            
        normalized = TrackRecording(
            track_name=self.track_name,
            curve_path=self.curve_path,
            max_speed=self.max_speed,
            curve_length=self.curve_length,
            track_type=self.track_type,      # 🔥 Typ mitnehmen
            param_name=self.param_name,      # 🔥 Param-Felder mitnehmen
            param_unit=self.param_unit,
            param_min=self.param_min,
            param_max=self.param_max
        )
        
        t_range = self.t_end - self.t_start
        
        for s in self.samples:
            normalized.samples.append(RecordingSample(
                t=(s.t - self.t_start) / t_range,
                pedal=s.pedal,
                time=s.time,
                dist=s.dist
            ))
        
        normalized.t_start = 0.0
        normalized.t_end = 1.0
        normalized.sort_samples()
        
        # 🔥 Editor-Daten mitnehmen (optional)
        if self.editor_data:
            normalized.editor_data = self.editor_data.copy()
        
        return normalized
    
    def get_pedal_at_t(self, t_norm: float) -> float:
        """Findet den Pedalwert zum normalisierten t (nächster Wert)"""
        if not self.samples:
            return 0.0
        closest = min(self.samples, key=lambda s: abs(s.t - t_norm))
        return closest.pedal
    
    def to_dict(self) -> dict:
        """Konvertiert zu Dict für JSON"""
        data = {
            "track_name": self.track_name,
            "curve_path": self.curve_path,
            "max_speed": self.max_speed,
            "curve_length": self.curve_length,
            "t_start": self.t_start,
            "t_end": self.t_end,
            "track_type": self.track_type,  # 🔥 Typ speichern
            "samples": [
                {
                    "t": s.t,
                    "pedal": s.pedal
                }
                for s in self.samples
            ]
        }
        
        # 🔥 Param-Track Felder speichern falls vorhanden
        if self.track_type == "param":
            data["param_name"] = self.param_name
            data["param_unit"] = self.param_unit
            data["param_min"] = self.param_min
            data["param_max"] = self.param_max
        
        # 🔥 Editor-Daten hinzufügen falls vorhanden
        if self.editor_data:
            data["editor_data"] = self.editor_data
        
        return data
    
    @classmethod
    def from_dict(cls, data: dict) -> 'TrackRecording':
        """Erstellt TrackRecording aus Dict"""
        track = cls(
            track_name=data["track_name"],
            curve_path=data["curve_path"],
            max_speed=data["max_speed"],
            curve_length=data["curve_length"],
            t_start=data.get("t_start", 0.0),
            t_end=data.get("t_end", 1.0),
            track_type=data.get("track_type", "motion"),  # 🔥 Typ laden
            param_name=data.get("param_name", ""),        # 🔥 Param-Felder laden
            param_unit=data.get("param_unit", ""),
            param_min=data.get("param_min", 0.0),
            param_max=data.get("param_max", 1.0)
        )
        
        for s_data in data["samples"]:
            track.samples.append(RecordingSample(
                t=s_data["t"],
                pedal=s_data["pedal"],
                time=0.0,
                dist=0.0
            ))
        
        # 🔥 Editor-Daten laden falls vorhanden
        if "editor_data" in data:
            track.editor_data = data["editor_data"]
        
        track.sort_samples()
        return track


@dataclass
class RecordingSession:
    """Komplette Aufnahmesession"""
    name: str
    date: str
    duration: float
    tracks: Dict[str, TrackRecording] = field(default_factory=dict)
    
    # Globale Schnittmarken
    t_start: float = 0.0
    t_end: float = 1.0
    
    # 🔥 NEU: Globale Editor-Daten
    editor_data: Dict[str, Any] = field(default_factory=dict)
    
    def trim_global(self, t_start: float, t_end: float) -> 'RecordingSession':
        """Trimmt ALLE Tracks gleichzeitig"""
        trimmed = RecordingSession(
            name=f"{self.name}_trimmed",
            date=datetime.now().isoformat(),
            duration=self.duration
        )
        
        for name, track in self.tracks.items():
            trimmed.tracks[name] = track.trim(t_start, t_end)
        
        trimmed.t_start = t_start
        trimmed.t_end = t_end
        trimmed.editor_data = self.editor_data.copy() if self.editor_data else {}
        
        return trimmed
    
    def to_dict(self) -> dict:
        """Konvertiert zu Dict für JSON"""
        data = {
            "name": self.name,
            "date": self.date,
            "duration": self.duration,
            "t_start": self.t_start,
            "t_end": self.t_end,
            "tracks": {
                name: track.to_dict()
                for name, track in self.tracks.items()
            }
        }
        
        # 🔥 Editor-Daten hinzufügen falls vorhanden
        if self.editor_data:
            data["editor_data"] = self.editor_data
        
        return data
    
    @classmethod
    def from_dict(cls, data: dict) -> 'RecordingSession':
        """
        Erstellt RecordingSession aus Dict.
        """
        session = cls(
            name=data["name"],
            date=data["date"],
            duration=data["duration"],
            t_start=data.get("t_start", 0.0),
            t_end=data.get("t_end", 1.0)
        )
        
        for name, track_data in data["tracks"].items():
            session.tracks[name] = TrackRecording.from_dict(track_data)
        
        # 🔥 Editor-Daten laden falls vorhanden
        if "editor_data" in data:
            session.editor_data = data["editor_data"]
        
        return session
    
    def get_summary(self) -> dict:
        """Gibt eine Zusammenfassung der Session zurück"""
        total_samples = sum(len(t.samples) for t in self.tracks.values())
        avg_hz = total_samples / self.duration if self.duration > 0 else 0
        
        summary = {
            "name": self.name,
            "date": self.date,
            "duration": self.duration,
            "tracks": len(self.tracks),
            "total_samples": total_samples,
            "avg_sample_rate": avg_hz,
            "t_range": (self.t_start, self.t_end)
        }
        
        # Track-Typen zählen
        track_types = {}
        for track in self.tracks.values():
            track_types[track.track_type] = track_types.get(track.track_type, 0) + 1
        summary["track_types"] = track_types
        
        # Editor-Daten Info hinzufügen falls vorhanden
        if self.editor_data:
            summary["has_editor_data"] = True
        
        return summary