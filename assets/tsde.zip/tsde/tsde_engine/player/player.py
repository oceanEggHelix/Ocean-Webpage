# tsde_engine/player/player.py

import json
import numpy as np
import time
from ..curves.curve_loader import load_csv_curve

class Replayer:
    """
    Deterministischer Replayer - spielt Recording Frame-für-frame ab
    - KEINE Echtzeit-Engine mehr
    - Berechnet exakte Positionen für Ziel-FPS
    - Liefert Frame für Frame an Blender
    """
    
    def __init__(self):
        self.recording = None
        self.tracks = {}
        self.curves = {}
        self.duration = 0.0
        self.total_frames = 0
        self.current_frame = 0
        self.fps = 24
        self.time_factor = 1.0
        self.t_start = 0.0
        self.t_end = 1.0
        
    def load_recording(self, filepath):
        """Lädt Recording-JSON"""
        try:
            with open(filepath, 'r') as f:
                self.recording = json.load(f)
            
            self.duration = self.recording.get("duration", 0.0)
            
            # Tracks und Kurven vorbereiten
            for track_name, track_data in self.recording.get("tracks", {}).items():
                self.tracks[track_name] = track_data
                
                # Kurve laden für Motion Tracks
                if track_data.get("track_type") == "motion":
                    curve_path = track_data.get("curve_path")
                    if curve_path:
                        try:
                            curve = load_csv_curve(curve_path, 0.01)
                            self.curves[track_name] = curve
                        except Exception as e:
                            print(f"⚠️ Kurve nicht geladen: {curve_path} - {e}")
            
            print(f"✅ Recording geladen: {filepath}")
            print(f"   Dauer: {self.duration:.2f}s")
            print(f"   Tracks: {len(self.tracks)}")
            
            return True
            
        except Exception as e:
            print(f"❌ Fehler beim Laden: {e}")
            return False
    
    def prepare_render(self, fps, time_factor=1.0, t_start=0.0, t_end=1.0):
        """Bereitet Render mit Ziel-FPS vor"""
        self.fps = fps
        self.time_factor = time_factor
        self.t_start = max(0.0, min(t_start, 1.0))
        self.t_end = max(0.0, min(t_end, 1.0))
        
        # Effektive Dauer im Render
        effective_duration = self.duration * time_factor * (t_end - t_start)
        self.total_frames = int(effective_duration * fps)
        
        print(f"🎬 Render vorbereitet:")
        print(f"   FPS: {fps}")
        print(f"   Time Factor: {time_factor}")
        print(f"   Bereich: {t_start:.1%} - {t_end:.1%}")
        print(f"   Frames: {self.total_frames}")
        
        return self.total_frames
    
    def get_frame(self, frame_index):
        """Gibt Frame-Daten für Index zurück"""
        if frame_index >= self.total_frames:
            return None
        
        # Normierte Position im Render (0-1)
        render_t = frame_index / max(1, self.total_frames - 1)
        
        # Auf Recording-Zeit umrechnen (mit Time-Stretch)
        record_t = self.t_start + render_t * (self.t_end - self.t_start)
        
        frame_data = {}
        
        for track_name, track_data in self.tracks.items():
            track_type = track_data.get("track_type", "motion")
            
            if track_type == "motion":
                # Motion Track: Position aus Kurve
                pos = self._get_motion_position(track_name, track_data, record_t)
                if pos:
                    frame_data[track_name] = pos
                    
            elif track_type == "empty":
                # Empty Track: Pedal-Wert
                pedal = self._get_pedal_value(track_data, record_t)
                frame_data[track_name] = pedal
        
        return frame_data
    
    def _get_motion_position(self, track_name, track_data, record_t):
        """Berechnet Position für Motion Track"""
        samples = track_data.get("samples", [])
        if not samples:
            return None
        
        # Finde passenden Sample-Index
        idx = int(record_t * len(samples))
        idx = min(idx, len(samples) - 1)
        
        # t-Wert aus Sample
        t_val = samples[idx]["t"]
        
        # Position aus Kurve
        curve = self.curves.get(track_name)
        if curve:
            try:
                p = curve.evaluate(t_val)
                return {"x": p.x, "y": p.y, "z": p.z}
            except:
                return None
        return None
    
    def _get_pedal_value(self, track_data, record_t):
        """Holt Pedal-Wert für Empty Track"""
        samples = track_data.get("samples", [])
        if not samples:
            return 0.0
        
        idx = int(record_t * len(samples))
        idx = min(idx, len(samples) - 1)
        
        return samples[idx].get("pedal", 0.0)
    
    def get_all_frames(self):
        """Generiert ALLE Frames (für Debug)"""
        frames = []
        for i in range(self.total_frames):
            frame = self.get_frame(i)
            frames.append(frame)
        return frames
    
    def get_frame_count(self):
        return self.total_frames
    
    def get_duration(self):
        return self.duration
    
    def get_track_names(self):
        return list(self.tracks.keys())