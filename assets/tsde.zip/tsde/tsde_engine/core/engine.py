# ------------------------------------------------------------------------
# TSDE Engine – Core Engine
# ------------------------------------------------------------------------
# Verantwortlichkeiten:
# - Zeit ticken
# - Tracks evaluieren
# - State aktualisieren
# - deterministischen Frame-State liefern
#
# Bugs / Notes:
# - Engine selbst enthält KEINE Modulation
# - Engine verändert KEINE Zeit (Time bleibt heilig)
# - Engine kennt KEINE Kurven direkt (nur Tracks)
# ------------------------------------------------------------------------

from __future__ import annotations

# interne Imports (relativ!)
from .time import Time
from .state import State
from .track import Track


class Engine:
    def __init__(self, time, tracks, state):
        self.time = time
        self.trackgroups = []      # <--- NEU
        self.tracks = tracks
        self.state = state

    def tick(self, dt=None):
        if dt is None:
            dt = self.time.tick()

        #print(f"\n=== TICK dt={dt:.6f} ===")

        for track in self.tracks:
            t_local = track.channel.update(dt)
            track.apply(t_local, self.state)

        return self.state

    def reset(self):
        """Setzt Zeit + alle Channels zurück."""
        # Zeit zurücksetzen
        if hasattr(self.time, "reset"):
            self.time.reset()
        else:
            self.time.t = 0.0

        # Channels zurücksetzen
        for track in self.tracks:
            ch = track.channel
            if hasattr(ch, "reset"):
                ch.reset()
            else:
                ch.distance = 0.0
                ch.t_local = 0.0

        print("Engine wurde zurückgesetzt.")

    