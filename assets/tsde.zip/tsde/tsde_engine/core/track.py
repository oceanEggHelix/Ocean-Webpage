# ------------------------------------------------------------------------
# TSDE Engine – Track
# ------------------------------------------------------------------------
# Zweck:
#   Ein Track verbindet:
#       - eine Kurve (Spline)
#       - einen Channel (Zeit + Velocity)
#       - einen State-Key (z.B. "pivot", "lens", "roll", ...)
#
#   Track selbst kennt KEINE Zeit, KEINE Velocity, KEINE Modulation.
#   Track ist rein funktional:
#       t_local rein → Kurve evaluieren → Wert in State schreiben
#
# Warum das wichtig ist:
#   - Track bleibt deterministisch und host-unabhängig
#   - Engine kann beliebig viele Tracks parallel fahren (CNC-Mehrkanal)
#   - Jeder Track kann eigene Velocity haben (über seinen Channel)
#   - Track ist die kleinste Bewegungseinheit der Engine
#
# Design-Prinzipien:
#   - Minimalistisch: keine unnötige Logik
#   - Klar getrennt: Channel = Zeit/Velocity, Track = Auswertung
#   - Erweiterbar: Modulations-Stack, Debug-Infos, Typvalidierung
#
# TODO / Erweiterungen:
#   - Modulations-Stack (additiv, multiplikativ)
#   - Typvalidierung (Vector3, Float, Quaternion)
#   - Debug-Infos pro Track (z.B. letzter Wert)
# ------------------------------------------------------------------------

from __future__ import annotations

class Track:
    def __init__(self, curve, name):
        self.curve = curve
        self.name = name      # <--- wichtig!
        self.channel = None   # wird später gesetzt (TrackFactory)

    def apply(self, t_local, state):
        value = self.curve.evaluate(t_local)

        # Debug-Ausgabe
        #print(f"[TRACK {self.name}] t={t_local:.6f} → {value}")

        # Wert in den State schreiben
        state.set(self.name, value)