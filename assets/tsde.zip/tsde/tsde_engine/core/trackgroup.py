# ------------------------------------------------------------------------
# TSDE Engine – TrackGroup
# ------------------------------------------------------------------------
# Zweck:
#   Eine TrackGroup ist eine logische Sammlung von Tracks, die gemeinsam
#   von der Engine verarbeitet werden. Jeder Track besitzt:
#       - eine eigene Kurve
#       - einen eigenen Channel (mit eigener Velocity)
#       - einen eigenen State-Key (z.B. "pivot", "lens", "roll", ...)
#
#   Die TrackGroup selbst enthält KEINE Zeit, KEINE Modulation,
#   KEINE Engine-Logik. Sie ist rein organisatorisch.
#
# Warum das wichtig ist:
#   - Ermöglicht Mehrkanal-Systeme (CNC-Style)
#   - Kamera-Setups wie Pivot + Lens können sauber gruppiert werden
#   - Beliebig viele Splines können parallel laufen
#   - Alle Tracks bleiben automatisch synchron, weil sie dieselbe Zeitbasis
#     der Engine nutzen (dt kommt global aus Time)
#
# Design-Prinzipien:
#   - Minimalistisch: keine unnötige Logik
#   - Deterministisch: Reihenfolge ist definiert
#   - Erweiterbar: später Modulations-Gruppen, Layer, Noise möglich
#
# TODO / Erweiterungen:
#   - Gruppenweite Velocity-Modulation
#   - Aktivieren/Deaktivieren einzelner Gruppen
#   - Debug-Tagging pro Gruppe
# ------------------------------------------------------------------------

class TrackGroup:
    def __init__(self, name, tracks):
        """
        Erstellt eine logische Gruppe von Tracks.

        Parameter:
            name   (str)   – Name der Gruppe (z.B. "camera", "noise", "rig")
            tracks (list)  – Liste von Track-Objekten

        Hinweis:
            Die Gruppe selbst führt KEINE Berechnungen aus.
            Die Engine iteriert später einfach über alle Tracks aller Gruppen.
        """
        self.name = name
        self.tracks = tracks

    def __iter__(self):
        """Erlaubt: for track in group"""
        return iter(self.tracks)

    def __len__(self):
        """Erlaubt: len(group)"""
        return len(self.tracks)

    def add(self, track):
        """Fügt einen einzelnen Track hinzu."""
        self.tracks.append(track)

    def extend(self, track_list):
        """Fügt mehrere Tracks hinzu."""
        self.tracks.extend(track_list)