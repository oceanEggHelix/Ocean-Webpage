# ------------------------------------------------------------------------
# TSDE Engine – Core Vector (Vec3)
# ------------------------------------------------------------------------
# Minimaler, host-unabhängiger 3D-Vektor für den gesamten Core.
# Enthält genau die Arithmetik, die Engine, Preprocessor und Curve brauchen:
# - Subtraktion
# - Addition
# - Skalare Multiplikation
# - Länge
# - Normalisierung
# - Kopieren
# - Lineare Interpolation (lerp)
# ------------------------------------------------------------------------

from __future__ import annotations
import math


class Vec3:
    __slots__ = ("x", "y", "z")

    def __init__(self, x, y, z):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)

    # ------------------------------------------------------------
    # Arithmetik
    # ------------------------------------------------------------
    def __sub__(self, other: "Vec3") -> "Vec3":
        return Vec3(self.x - other.x, self.y - other.y, self.z - other.z)

    def __add__(self, other: "Vec3") -> "Vec3":
        return Vec3(self.x + other.x, self.y + other.y, self.z + other.z)

    def __mul__(self, scalar: float) -> "Vec3":
        return Vec3(self.x * scalar, self.y * scalar, self.z * scalar)

    __rmul__ = __mul__  # erlaubt: scalar * Vec3

    @property
    def length(self) -> float:
        return math.sqrt(self.x*self.x + self.y*self.y + self.z*self.z)

    def normalized(self) -> "Vec3":
        length = self.length
        if length == 0:
            return Vec3(0.0, 0.0, 0.0)
        return Vec3(self.x / length, self.y / length, self.z / length)

    # ------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------
    def copy(self) -> "Vec3":
        return Vec3(self.x, self.y, self.z)

    def lerp(self, other: "Vec3", t: float) -> "Vec3":
        return self + (other - self) * t

    def __iter__(self):
        yield self.x
        yield self.y
        yield self.z

    def __repr__(self):
        return f"Vec3({self.x}, {self.y}, {self.z})"