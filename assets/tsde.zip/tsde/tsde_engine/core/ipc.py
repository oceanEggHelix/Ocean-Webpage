# tsde_gui/ipc.py
from multiprocessing import Queue
from tsde_engine.core.engine_process import EngineProcess
from tsde_engine.engine_factory import engine_factory
from tsde_engine.player.player import Replayer
import time
import threading

# Haupt-Queues
out_q = Queue()      # Für Track-Daten (GUI Tabelle)
in_q = Queue()       # Für Kommandos an Engine
recorder_q = Queue() # Für Recorder-Nachrichten

# 🔥 NEU: Render-Queues
render_q = Queue()        # Für Frame-Daten beim Rendern
render_result_q = Queue() # Für Render-Ergebnisse/Status

proc = None
_ipc_debug_level = 0

# 🔥 NEU: Render-Modus Variablen - DAS HIER MUSS DA SEIN!
_render_mode = False
_render_thread = None
_replayer = None
_current_frame = 0
_total_frames = 0

# ... restlicher Code ...

# ------------------------------------------------------------
# Debug-Helper für IPC
# ------------------------------------------------------------
def _ipc_debug(level, message, **kwargs):
    """Gibt IPC Debug-Nachrichten basierend auf debug_level aus."""
    global _ipc_debug_level
    if _ipc_debug_level >= level:
        prefix = f"[IPC DEBUG{level}]"
        if kwargs:
            print(f"{prefix} {message}", **kwargs)
        else:
            print(f"{prefix} {message}")

# ------------------------------------------------------------
# Öffentliche Funktionen
# ------------------------------------------------------------
def start_engine(debug_level=1):
    """Startet die Engine mit optionalem Debug-Level."""
    global proc, _ipc_debug_level
    _ipc_debug_level = debug_level
    
    if proc is None:
        _ipc_debug(1, f"Starte Engine mit Debug-Level {debug_level}")
        # 🔥 Engine bekommt ALLE Queues!
        proc = EngineProcess(engine_factory, out_q, recorder_q, in_q, hz=240, debug_level=debug_level)
        proc.start()
        _ipc_debug(2, f"Engine Prozess gestartet, PID: {proc.pid}")
    else:
        _ipc_debug(1, "Engine ist bereits gestartet")

def stop_engine():
    """Stoppt die Engine ordnungsgemäß."""
    global proc, in_q, out_q, recorder_q, _ipc_debug_level
    
    if proc is not None and proc.is_alive():
        _ipc_debug(1, "Sende Stop-Kommando an Engine")
        
        # Stop-Kommando senden
        in_q.put({"cmd": "stop"})
        
        # Warten bis Prozess beendet ist
        _ipc_debug(2, "Warte auf Engine-Beendigung (max. 2s)")
        proc.join(timeout=2.0)
        
        if proc.is_alive():
            _ipc_debug(1, "Engine reagiert nicht - terminate()")
            proc.terminate()
            proc.join(timeout=1.0)
        
        proc = None
        
        # Alle Queues leeren
        queue_items = 0
        for q in [out_q, recorder_q, in_q]:
            while not q.empty():
                try:
                    q.get_nowait()
                    queue_items += 1
                except:
                    break
            
        if queue_items > 0:
            _ipc_debug(2, f"{queue_items} Elemente aus Queues entfernt")
        
        _ipc_debug(1, "Engine erfolgreich gestoppt")
    else:
        _ipc_debug(1, "Keine laufende Engine zum Stoppen")

def send(cmd: str, **kwargs):
    """Sendet ein Kommando an die Engine."""
    global proc, _ipc_debug_level
    
    if proc is not None and proc.is_alive():
        if _ipc_debug_level >= 2:
            details = ", ".join([f"{k}={v}" for k, v in kwargs.items()])
            _ipc_debug(2, f"Sende Kommando: {cmd}" + (f" ({details})" if details else ""))
        
        in_q.put({"cmd": cmd, **kwargs})
    elif _ipc_debug_level >= 1:
        _ipc_debug(1, f"Kann Kommando '{cmd}' nicht senden - Engine nicht aktiv")

# ------------------------------------------------------------
# poll() - NUR für Track-Daten (GUI Tabelle)
# ------------------------------------------------------------
def poll():
    """
    Holt NUR Track-Daten (Listen) für die GUI-Tabelle.
    Gibt IMMER eine Liste zurück (kann leer sein).
    """
    global out_q, _ipc_debug_level
    
    track_data = []
    latest_track_data = None
    
    while not out_q.empty():
        try:
            item = out_q.get_nowait()
            if isinstance(item, list):
                latest_track_data = item
                if _ipc_debug_level >= 3:
                    _ipc_debug(3, f"📊 Track-Daten: {len(item)} Tracks")
        except:
            break
    
    if latest_track_data is not None:
        track_data = latest_track_data
    
    return track_data

# ------------------------------------------------------------
# 🎬 poll_recorder() - NUR für Recorder-Nachrichten! (JETZT DIREKT!)
# ------------------------------------------------------------
def poll_recorder():
    """
    Holt NUR Recorder-bezogene Nachrichten aus der separaten Queue.
    Wird vom RecorderPanel für LIVE Updates verwendet!
    """
    global recorder_q, _ipc_debug_level
    
    result = {
        "recording": None,
        "pedal_curve": None,
        "recording_loaded": None,
        "recording_saved": None
    }
    
    items_processed = 0
    
    while not recorder_q.empty():
        try:
            item = recorder_q.get_nowait()
            items_processed += 1
            
            if isinstance(item, dict):
                msg_type = item.get('type', '')
                
                if msg_type == 'recording_status':
                    result["recording"] = item
                    if _ipc_debug_level >= 2:
                        status = item.get('status', 'unknown')
                        _ipc_debug(2, f"🎬 Recording-Status: {status}")
                
                elif msg_type == 'pedal_curve':
                    result["pedal_curve"] = item
                    if _ipc_debug_level >= 2:
                        track = item.get('track', 'unknown')
                        samples = len(item.get('times', []))
                        _ipc_debug(2, f"📈 Pedal-Kurve: {track} ({samples} Samples)")
                
                elif msg_type == 'recording_loaded':
                    result["recording_loaded"] = item
                    if _ipc_debug_level >= 2:
                        name = item.get('session_name', 'unknown')
                        samples = item.get('total_samples', 0)
                        _ipc_debug(2, f"📂 Recording geladen: {name} ({samples} Samples)")
                
                elif msg_type == 'recording_saved':
                    result["recording_saved"] = item
                    if _ipc_debug_level >= 2:
                        path = item.get('filepath', 'unknown')
                        samples = item.get('total_samples', 0)
                        _ipc_debug(2, f"💾 Recording gespeichert: {path} ({samples} Samples)")
        except:
            break
    
    if _ipc_debug_level >= 3 and items_processed > 0:
        _ipc_debug(3, f"🎬 Recorder: {items_processed} Nachrichten verarbeitet")
    
    return result

# ------------------------------------------------------------
# poll_messages() - ALLE Nachrichten (für Debug)
# ------------------------------------------------------------
def poll_messages():
    """
    Holt ALLE Nachrichten aus ALLEN Queues.
    Nur für Debug-Zwecke!
    """
    global out_q, recorder_q, _ipc_debug_level
    
    result = {
        "tracks": [],
        "recorder": {},
        "other": []
    }
    
    # Track-Daten aus out_q
    while not out_q.empty():
        try:
            item = out_q.get_nowait()
            if isinstance(item, list):
                result["tracks"] = item
        except:
            break
    
    # Recorder-Daten aus recorder_q
    result["recorder"] = poll_recorder()
    
    return result

def is_running():
    """Prüfe ob die Engine läuft."""
    global proc, _ipc_debug_level
    
    running = proc is not None and proc.is_alive()
    
    if _ipc_debug_level >= 3:
        status = "läuft" if running else "gestoppt"
        _ipc_debug(3, f"Engine Status: {status}")
    
    return running

def set_ipc_debug_level(level: int):
    """Setzt den Debug-Level für IPC-Funktionen."""
    global _ipc_debug_level
    old_level = _ipc_debug_level
    _ipc_debug_level = max(0, min(level, 3))
    
    if old_level != _ipc_debug_level:
        _ipc_debug(1, f"IPC Debug-Level von {old_level} auf {_ipc_debug_level} geändert")
    
    return _ipc_debug_level

def get_ipc_debug_level():
    """Gibt den aktuellen IPC Debug-Level zurück."""
    global _ipc_debug_level
    return _ipc_debug_level

# ------------------------------------------------------------
# Erweiterte Funktionen
# ------------------------------------------------------------
def get_engine_info():
    """Gibt Informationen über die Engine zurück."""
    global proc
    
    info = {
        "running": is_running(),
        "debug_level": get_ipc_debug_level(),
        "pid": proc.pid if proc else None,
        "queue_sizes": {
            "out": out_q.qsize(),
            "recorder": recorder_q.qsize(),
            "in": in_q.qsize()
        }
    }
    
    if _ipc_debug_level >= 2:
        _ipc_debug(2, f"Engine Info: running={info['running']}, "
                    f"PID={info['pid']}, "
                    f"queues(out/rec/in)={info['queue_sizes']['out']}/{info['queue_sizes']['recorder']}/{info['queue_sizes']['in']}")
    
    return info

def clear_queues():
    """Leert alle Queues."""
    global out_q, recorder_q, in_q, _ipc_debug_level
    
    out_count = 0
    rec_count = 0
    in_count = 0
    
    for q in [out_q, recorder_q, in_q]:
        while not q.empty():
            try:
                q.get_nowait()
                if q is out_q:
                    out_count += 1
                elif q is recorder_q:
                    rec_count += 1
                else:
                    in_count += 1
            except:
                break
    
    total = out_count + rec_count + in_count
    if total > 0:
        _ipc_debug(1, f"Queues geleert: out={out_count}, recorder={rec_count}, in={in_count}")
    
    return total


# ------------------------------------------------------------
# 🔥 NEU: RENDER-FUNKTIONEN
# ------------------------------------------------------------

def start_render(recording_path, fps=24, time_factor=1.0, t_start=0.0, t_end=1.0):
    """
    Startet Render-Modus in separatem Thread
    """
    global _render_mode, _render_thread, _replayer, _current_frame, _total_frames
    global render_q, render_result_q
    
    if _render_mode:
        _ipc_debug(1, "⚠️ Render läuft bereits!")
        return False
    
    # Replayer initialisieren
    _replayer = Replayer()
    if not _replayer.load_recording(recording_path):
        _ipc_debug(1, f"❌ Recording konnte nicht geladen werden: {recording_path}")
        return False
    
    # Render vorbereiten
    _total_frames = _replayer.prepare_render(fps, time_factor, t_start, t_end)
    _current_frame = 0
    _render_mode = True
    
    # Queues leeren
    while not render_q.empty():
        try:
            render_q.get_nowait()
        except:
            break
    
    _ipc_debug(1, f"🎬 Render gestartet: {_total_frames} Frames @ {fps}fps")
    _ipc_debug(1, f"   Bereich: {t_start:.1%} - {t_end:.1%}, Factor: {time_factor}")
    
    # Render-Thread starten
    _render_thread = threading.Thread(target=_render_worker)
    _render_thread.daemon = True
    _render_thread.start()
    
    return True

def _render_worker():
    """
    Arbeiter-Thread für Render
    Generiert Frames und legt sie in Queue
    """
    global _render_mode, _current_frame, _total_frames, _replayer
    global render_q, render_result_q
    
    try:
        while _render_mode and _current_frame < _total_frames:
            # Frame generieren
            frame_data = _replayer.get_frame(_current_frame)
            
            if frame_data:
                # Frame in Queue für Blender
                render_q.put({
                    "frame": _current_frame,
                    "data": frame_data
                })
                
                if _ipc_debug_level >= 2 and _current_frame % 100 == 0:
                    _ipc_debug(2, f"📤 Frame {_current_frame}/{_total_frames} gesendet")
            
            _current_frame += 1
            time.sleep(0.0001)  # Kleine Pause für CPU-Entlastung
        
        # Ende-Signal
        render_q.put(None)
        
        # Ergebnis-Status
        render_result_q.put({
            "status": "completed",
            "total_frames": _total_frames
        })
        
        _ipc_debug(1, f"✅ Render abgeschlossen: {_total_frames} Frames")
        
    except Exception as e:
        _ipc_debug(1, f"❌ Render-Fehler: {e}")
        render_result_q.put({
            "status": "error",
            "error": str(e)
        })
    
    finally:
        _render_mode = False

def poll_render_frame():
    """
    Holt nächsten Frame für Render (wird von Blender aufgerufen)
    Gibt None wenn Render fertig
    """
    global render_q
    
    try:
        # Kurzer Timeout damit Blender nicht blockiert
        item = render_q.get(timeout=0.1)
        return item
    except:
        return None

def get_render_progress():
    """Gibt aktuellen Render-Fortschritt zurück"""
    global _render_mode, _current_frame, _total_frames
    
    if not _render_mode:
        return {
            "running": False,
            "current": _current_frame if _current_frame >= _total_frames else 0,
            "total": _total_frames,
            "progress": 1.0 if _current_frame >= _total_frames else 0.0
        }
    
    progress = _current_frame / _total_frames if _total_frames > 0 else 0
    
    return {
        "running": True,
        "current": _current_frame,
        "total": _total_frames,
        "progress": progress
    }

def stop_render():
    """Stoppt Render vorzeitig"""
    global _render_mode, _render_thread
    
    _ipc_debug(1, "🛑 Render wird gestoppt...")
    _render_mode = False
    
    if _render_thread and _render_thread.is_alive():
        _render_thread.join(timeout=2.0)
    
    # Queue leeren
    while not render_q.empty():
        try:
            render_q.get_nowait()
        except:
            break
    
    render_result_q.put({
        "status": "stopped",
        "current_frame": _current_frame
    })
    
    _ipc_debug(1, f"✅ Render gestoppt bei Frame {_current_frame}")
    return True

def wait_for_render_complete(timeout=None):
    """
    Wartet auf Render-Abschluss (für sequentielle Verarbeitung)
    """
    try:
        result = render_result_q.get(timeout=timeout)
        return result
    except:
        return None



# ------------------------------------------------------------
# Recorder IPC Kommandos 
# ------------------------------------------------------------
def init_recorder():
    """Initialisiert Recorder in Engine"""
    send("init_recorder")

def start_recording(session_name=None):
    """Startet Recording mit optionalem Session-Namen"""
    if session_name:
        send("start_recording", session_name=session_name)
    else:
        send("start_recording")

def stop_recording():
    """Stoppt Recording"""
    send("stop_recording")

def pause_recording():
    """Pausiert Recording"""
    send("pause_recording")

def resume_recording():
    """Setzt Recording fort"""
    send("resume_recording")

def save_recording(filepath, trim_start=0.0, trim_end=1.0, 
                  normalize=True, decimate=1):
    """Speichert Recording mit Optionen"""
    send("save_recording", 
         filepath=filepath,
         trim_start=trim_start,
         trim_end=trim_end,
         normalize=normalize,
         decimate=decimate)

def load_recording(filepath):
    """Lädt Recording"""
    send("load_recording", filepath=filepath)

def get_recording_status():
    """Fragt Recording-Status ab"""
    send("get_recording_status")

def get_track_buffer(track_name):
    """Holt Live-Buffer für Track"""
    send("get_track_buffer", track=track_name)

def get_pedal_sequence(track_name, max_samples=1000):
    """Holt Pedal-Sequenz für Visualisierung"""
    send("get_pedal_sequence", track=track_name, max_samples=max_samples)