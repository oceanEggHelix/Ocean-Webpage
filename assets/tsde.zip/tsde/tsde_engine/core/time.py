# ------------------------------------------------------------------------
# TSDE Engine – <time>
# ------------------------------------------------------------------------

from __future__ import annotations



# time.py
class Time:
    def __init__(self, dt=1/240):   ##### war 480
        self.dt = dt
        self.global_t = 0.0

    def tick(self):
        self.global_t += self.dt
        return self.dt   # <<< WICHTIG
    
    def reset(self):
        self.t = 0.0