# ------------------------------------------------------------------------
# TSDE Engine – <channel>
# ------------------------------------------------------------------------

from __future__ import annotations 

# core/channel.py
class Channel:
    def __init__(self, curve, v_max_mm_s=100.0, modulator=None):
        self.curve = curve
        self.v_max = float(v_max_mm_s)
        self.pedal = 0.0
        self.distance = 0.0
        self.t_local = 0.0
        self.paused = False  # 🔥 NEU: Pause-Status für Channel

        # Modulator ist eine Funktion oder ein Objekt
        self.modulator = modulator or (lambda ch: 1.0)


    @property
    def velocity(self):
        return self.pedal

    @velocity.setter
    def velocity(self, v):
        self.pedal = float(v)

    def update(self, dt):
        if self.paused:  # 🔥 NEU: Wenn pausiert, nichts tun!
            return self.t_local
            
        M = self.modulator(self)   # ⭐ hier hängt alles dran
        v_eff = self.pedal * self.v_max * M

        self.distance += v_eff * dt
        length = self.curve.length_total

        if length > 0:
            self.distance = self.distance % length
            self.t_local = self.distance / length
        else:
            self.t_local = 0.0

        return self.t_local

    def pause(self):  # 🔥 NEU: Pause-Funktion
        self.paused = True
        
    def resume(self):  # 🔥 NEU: Resume-Funktion
        self.paused = False

    def reset(self):
        self.distance = 0.0
        self.t_local = 0.0
        self.paused = False