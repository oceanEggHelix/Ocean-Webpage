# ------------------------------------------------------------------------
# TSDE Engine – State
# ------------------------------------------------------------------------
# Verantwortlichkeiten:
# - Hält alle berechneten Werte eines Engine-Ticks
# - Dient als zentrales Austauschobjekt zwischen Engine, Tracks, Recorder
# - Ermöglicht Host-Adaptern (z.B. Blender) den Zugriff auf aktuelle Werte
#
# Hinweise:
# - State ist bewusst generisch gehalten (Dictionary-basiert)
# - Neue Kanäle können jederzeit hinzugefügt werden, ohne die Klasse zu ändern
# - State speichert KEINE Zeit, KEINE Kurven, KEINE Modulation
#
# Bug / TODO Section:
# - Später: Typisierung pro Kanal (Vector, Float, Quaternion)
# - Später: Validierung von Werten (z.B. None vermeiden)
# - Später: Snapshot-Funktion für Recorder/Exporter
# - Später: Delta-State für Optimierungen
# ------------------------------------------------------------------------

from __future__ import annotations


class State:
    """Hält alle berechneten Werte eines Engine-Ticks."""

    def __init__(self):
        self.values = {}

    def set(self, channel: str, value):
        """Setzt einen Wert für einen bestimmten Kanal."""
        self.values[channel] = value

    def get(self, channel: str):
        """Liest einen Wert aus."""
        return self.values.get(channel, None)

    # Komfort-Properties für typische Kanäle
    @property
    def pivot(self):
        return self.values.get("pivot", None)

    @pivot.setter
    def pivot(self, v):
        self.values["pivot"] = v

    @property
    def lens(self):
        return self.values.get("lens", None)

    @lens.setter
    def lens(self, v):
        self.values["lens"] = v