from multiprocessing import Process
from tsde_engine.core.trackgroup import TrackGroup
from tsde_engine.setup.track_factory import make_track
import time
import statistics
from collections import deque

# ------------------------------------------------------------
# RECORDER IMPORTS - 240 Hz VOLLAUFLÖSUNG!
# ------------------------------------------------------------
from tsde_engine.recorder.deterministic_recorder import DeterministicRecorder


class EngineProcess(Process):
    def __init__(self, engine_factory, out_queue, recorder_queue, in_queue, hz=240, debug_level=0):
        """
        debug_level:
          0 = Keine Debug-Ausgaben
          1 = Wichtige Ereignisse (Start/Stop/Setup/Recording)
          2 = + Tick-Informationen (reduziert)
          3 = + Alle Ticks + Details + Recording-Info
        """
        super().__init__()
        self.engine_factory = engine_factory
        self.out_queue = out_queue          # Track-Daten für GUI Tabelle
        self.recorder_queue = recorder_queue  # 🔥 SEPARATE Queue für Recorder!
        self.in_queue = in_queue            # Kommandos von GUI
        self.debug_level = debug_level

        self.target_hz = hz
        self.dt = 1.0 / hz
        self.running = True
        self.paused = True                  # Startet pausiert!
        self.engine = None
        self.setup_data = None
        
        # Performance-Messung
        self.tick_count = 0
        self.measured_hz = 0.0
        self.last_measurement_time = time.perf_counter()
        self.measurement_tick_count = 0
        
        # Tick-Dauern
        self.loop_durations = deque(maxlen=240)
        self.channel_durations = deque(maxlen=240)
        self.sleep_durations = deque(maxlen=240)
        
        self.min_loop_duration = float('inf')
        self.max_loop_duration = 0.0
        self.total_loop_time = 0.0
        
        # Debug-Konfiguration
        self.tick_debug_interval = 60
        self.last_debug_tick = 0
        self.last_sleep_time = 0.0
        
        # ------------------------------------------------------------
        # EXAKTE ZEITMESSUNG FÜR T0-1
        # ------------------------------------------------------------
        self.global_start_time = None
        self.global_pause_time = None
        self.total_paused_duration = 0.0
        self.is_global_paused = True
        
        # ------------------------------------------------------------
        # RECORDER - 240 Hz VOLLAUFLÖSUNG!
        # ------------------------------------------------------------
        self.recorder = None
        self.recording_enabled = True

    # ------------------------------------------------------------
    # Debug-Helper
    # ------------------------------------------------------------
    def debug_print(self, level, message, **kwargs):
        if self.debug_level >= level:
            if kwargs:
                print(f"[ENGINE DEBUG{level}] {message}", **kwargs)
            else:
                print(f"[ENGINE DEBUG{level}] {message}")

    def debug_tick_info(self, tick_count, loop_duration=None, channel_duration=None):
        if self.debug_level >= 3:
            perf_info = ""
            if loop_duration is not None and channel_duration is not None:
                perf_info = (f" | Loop: {loop_duration*1000:.3f}ms"
                           f" | Channel: {channel_duration*1000:.3f}ms"
                           f" | Sleep: {self.last_sleep_time*1000:.3f}ms"
                           f" | Hz: {self.measured_hz:.1f}")
            
            rec_status = ""
            if self.recorder and self.recorder.is_recording:
                rec_status = f" | REC: {self.recorder.get_buffer_size()} Samples"
            
            elapsed = self.get_elapsed_time()
            
            self.debug_print(3, f"=== TICK {tick_count} | dt={self.dt*1000:.2f}ms{perf_info} | "
                              f"t0-1: {elapsed:.3f}s{rec_status} ===")
            for group in self.engine.trackgroups:
                self.debug_print(3, f"[GROUP] {group.name}")
                for track in group.tracks:
                    ch = track.channel
                    expected_time = 0.0
                    if ch.pedal > 0 and ch.v_max > 0:
                        expected_time = ch.distance / (ch.pedal * ch.v_max)
                    
                    self.debug_print(3, f"  {track.name:8s} | "
                                      f"t_local={ch.t_local:.4f} | "
                                      f"dist={ch.distance:.3f}/{track.curve.length_total:.1f} | "
                                      f"pedal={ch.pedal:.2f} | "
                                      f"erw_zeit={expected_time:.3f}s")
        
        elif self.debug_level >= 2:
            if tick_count - self.last_debug_tick >= self.tick_debug_interval:
                hz_info = f" | Hz: {self.measured_hz:.1f}/{self.target_hz}" if self.measured_hz > 0 else ""
                
                rec_status = ""
                if self.recorder and self.recorder.is_recording:
                    rec_status = f" | REC: {self.recorder.get_buffer_size()} S"
                
                elapsed = self.get_elapsed_time()
                
                self.debug_print(2, f"=== TICK {tick_count} (alle {self.tick_debug_interval}) | "
                                  f"dt={self.dt*1000:.2f}ms{hz_info} | t0-1: {elapsed:.3f}s{rec_status} ===")
                for group in self.engine.trackgroups:
                    self.debug_print(2, f"[GROUP] {group.name}")
                    for track in group.tracks:
                        ch = track.channel
                        expected_time = 0.0
                        if ch.pedal > 0 and ch.v_max > 0:
                            expected_time = ch.distance / (ch.pedal * ch.v_max)
                        
                        self.debug_print(2, f"  {track.name:8s} | "
                                          f"t_local={ch.t_local:.4f} | "
                                          f"dist={ch.distance:.3f}/{track.curve.length_total:.1f} | "
                                          f"erw_zeit={expected_time:.3f}s")
                self.last_debug_tick = tick_count

    # ------------------------------------------------------------
    # EXAKTE ZEITMESSUNG METHODEN
    # ------------------------------------------------------------
    def reset_global_time(self):
        self.global_start_time = None
        self.global_pause_time = None
        self.total_paused_duration = 0.0
        self.is_global_paused = True
        self.debug_print(2, "Globale Zeitmessung zurückgesetzt")

    def start_global_time(self):
        """Startet oder setzt die globale Zeitmessung fort."""
        now = time.perf_counter()
        if self.global_start_time is None:
            self.global_start_time = now
            self.total_paused_duration = 0.0
            self.debug_print(2, f"Globale Zeitmessung gestartet: {now:.6f}")
        elif self.is_global_paused:
            pause_duration = now - self.global_pause_time
            self.total_paused_duration += pause_duration
            self.debug_print(2, f"Globale Zeitmessung fortgesetzt. Pausendauer: {pause_duration:.3f}s")
            
            # 🔥 ENTFERNT: Recorder wird hier nicht mehr gesteuert!
            #if self.recorder and not self.recorder.is_recording:
             #   self.recorder.resume_recording()
                
        self.is_global_paused = False

    def pause_global_time(self):
        if not self.is_global_paused and self.global_start_time is not None:
            self.global_pause_time = time.perf_counter()
            self.is_global_paused = True
            self.debug_print(2, f"Globale Zeitmessung pausiert: {self.global_pause_time:.6f}")
            
            # 🔥 ENTFERNT: Recorder wird hier nicht mehr gesteuert!
            #if self.recorder and self.recorder.is_recording:
              #  self.recorder.pause_recording()

    def get_elapsed_time(self):
        if self.global_start_time is None:
            return 0.0
        
        now = time.perf_counter()
        if self.is_global_paused:
            return self.global_pause_time - self.global_start_time - self.total_paused_duration
        else:
            return now - self.global_start_time - self.total_paused_duration

    def calculate_track_times(self, track):
        ch = track.channel
        time_elapsed = self.get_elapsed_time()
        time_total = 0.0
        time_remaining = 0.0
        
        if ch.pedal > 0 and ch.v_max > 0:
            time_total = track.curve.length_total / (ch.pedal * ch.v_max)
            time_elapsed_from_dist = ch.distance / (ch.pedal * ch.v_max)
            time_remaining = max(0.0, time_total - time_elapsed_from_dist)
        
        return {
            "time_elapsed": time_elapsed,
            "time_elapsed_from_dist": ch.distance / (ch.pedal * ch.v_max) if ch.pedal > 0 and ch.v_max > 0 else 0.0,
            "time_total": time_total,
            "time_remaining": time_remaining
        }

    # ------------------------------------------------------------
    # Performance-Messung
    # ------------------------------------------------------------
    def _update_performance_metrics(self, loop_duration, channel_duration, sleep_duration):
        self.loop_durations.append(loop_duration)
        self.total_loop_time += loop_duration
        
        if channel_duration is not None:
            self.channel_durations.append(channel_duration)
        
        if sleep_duration is not None:
            self.sleep_durations.append(sleep_duration)
        
        if loop_duration < self.min_loop_duration:
            self.min_loop_duration = loop_duration
        if loop_duration > self.max_loop_duration:
            self.max_loop_duration = loop_duration
        
        self.tick_count += 1
        self.measurement_tick_count += 1
        
        if self.measurement_tick_count >= 60:
            current_time = time.perf_counter()
            elapsed = current_time - self.last_measurement_time
            
            if elapsed > 0:
                self.measured_hz = 60 / elapsed
                self.last_measurement_time = current_time
                self.measurement_tick_count = 0
                
                if self.debug_level >= 2:
                    self._log_performance_stats()

    def _log_performance_stats(self):
        if not self.loop_durations:
            return
            
        avg_loop = statistics.mean(self.loop_durations) * 1000
        max_loop = self.max_loop_duration * 1000
        min_loop = self.min_loop_duration * 1000
        jitter = max_loop - min_loop
        
        available_time_per_tick = 1000 / self.target_hz
        cpu_usage = (avg_loop / available_time_per_tick) * 100
        
        avg_channel = statistics.mean(self.channel_durations) * 1000 if self.channel_durations else 0
        avg_sleep = statistics.mean(self.sleep_durations) * 1000 if self.sleep_durations else 0
        
        elapsed = self.get_elapsed_time()
        
        rec_info = ""
        if self.recorder and self.recorder.is_recording:
            rec_info = f" | REC: {self.recorder.get_buffer_size()} Samples"
        
        self.debug_print(2, 
            f"Perf: {self.measured_hz:.1f}/{self.target_hz} Hz | "
            f"Loop: {avg_loop:.2f}ms (min:{min_loop:.2f}, max:{max_loop:.2f}) | "
            f"Channel: {avg_channel:.2f}ms | Sleep: {avg_sleep:.2f}ms | "
            f"Jitter: {jitter:.2f}ms | CPU: {cpu_usage:.1f}% | "
            f"t0-1: {elapsed:.3f}s{rec_info}"
        )
        
        if self.debug_level >= 1:
            if cpu_usage > 90:
                self.debug_print(1, f"⚠️  Hohe CPU-Auslastung: {cpu_usage:.1f}%")
            if self.measured_hz < self.target_hz * 0.8:
                self.debug_print(1, f"⚠️  Niedrige FPS: {self.measured_hz:.1f} Hz (Ziel: {self.target_hz})")

    def get_performance_stats(self):
        if not self.loop_durations:
            return {
                "target_hz": self.target_hz,
                "measured_hz": 0.0,
                "tick_count": self.tick_count,
                "status": "no_data",
                "time_elapsed": self.get_elapsed_time(),
                "recording": self.recorder.is_recording if self.recorder else False,
                "recording_samples": self.recorder.get_buffer_size() if self.recorder else 0
            }
        
        avg_loop = statistics.mean(self.loop_durations) * 1000
        max_loop = self.max_loop_duration * 1000
        min_loop = self.min_loop_duration * 1000
        
        available_time_per_tick = 1000 / self.target_hz if self.target_hz > 0 else 0
        cpu_usage = (avg_loop / available_time_per_tick) * 100 if available_time_per_tick > 0 else 0
        
        avg_channel = statistics.mean(self.channel_durations) * 1000 if self.channel_durations else 0
        avg_sleep = statistics.mean(self.sleep_durations) * 1000 if self.sleep_durations else 0
        
        return {
            "target_hz": self.target_hz,
            "measured_hz": self.measured_hz,
            "tick_count": self.tick_count,
            "avg_loop_ms": avg_loop,
            "avg_channel_ms": avg_channel,
            "avg_sleep_ms": avg_sleep,
            "max_loop_ms": max_loop,
            "min_loop_ms": min_loop,
            "jitter_ms": max_loop - min_loop,
            "cpu_usage_percent": cpu_usage,
            "total_runtime_s": self.total_loop_time,
            "status": "running" if self.running else "stopped",
            "paused": self.paused,
            "engine_loaded": self.engine is not None,
            "available_ms_per_tick": available_time_per_tick,
            "time_elapsed": self.get_elapsed_time(),
            "recording": self.recorder.is_recording if self.recorder else False,
            "recording_samples": self.recorder.get_buffer_size() if self.recorder else 0,
            "recording_duration": self.recorder.recording_start_time if self.recorder and self.recorder.is_recording else 0.0
        }

    # ------------------------------------------------------------
    # BEFEHLE VERARBEITEN - MIT RECORDER!
    # ------------------------------------------------------------
    def handle_command(self, cmd):
        c = cmd.get("cmd")
        
        # ============ ENGINE CONTROL ============
        if c == "play":
            self.paused = False
            self.start_global_time()
            
            # 🔥 ALLE Channels fortsetzen
            if self.engine:
                for group in self.engine.trackgroups:
                    for track in group.tracks:
                        track.channel.resume()
                self.debug_print(1, f"▶ Alle Channels gestartet")
            
            self.debug_print(1, "▶ Play aktiviert")
        
        elif c == "pause":
            self.paused = True
            self.pause_global_time()
            
            # 🔥 ALLE Channels pausieren
            if self.engine:
                for group in self.engine.trackgroups:
                    for track in group.tracks:
                        track.channel.pause()
                self.debug_print(1, f"⏸ Alle Channels pausiert")
            
            self.debug_print(1, "⏸ Pause aktiviert")

        elif c == "stop":
            self.running = False
            self.debug_print(1, "⏹ Stop-Kommando empfangen")

        elif c == "reset":
            if self.engine:
                self.debug_print(1, "🔄 Reset aller Tracks")
                for group in self.engine.trackgroups:
                    for track in group.tracks:
                        track.channel.reset()
                        track.channel.pedal = 1.0
                self.reset_global_time()
                
                if self.recorder and self.recorder.is_recording:
                    self.debug_print(1, "🎬 Recording läuft weiter nach Reset")

        elif c == "set_pedal":
            if self.engine:
                track_name = cmd["track"]
                value = cmd["value"]
                self.debug_print(2, f"Pedal für Track '{track_name}': {value:.2f}")
                for group in self.engine.trackgroups:
                    for track in group.tracks:
                        if track.name == track_name:
                            track.channel.pedal = value

        elif c == "setup":
            self.setup_data = cmd["data"]
            self.debug_print(1, f"📂 Setup-Kommando empfangen ({len(self.setup_data['groups'])} Gruppen)")
            self.apply_setup(self.setup_data)
            self.reset_global_time()
            
        elif c == "debug_level":
            new_level = cmd.get("level", 1)
            old_level = self.debug_level
            self.debug_level = new_level
            self.debug_print(1, f"Debug-Level von {old_level} auf {new_level} geändert")
            
        elif c == "get_performance":
            stats = self.get_performance_stats()
            self.out_queue.put({
                "type": "performance",
                "data": stats
            })
            
        elif c == "get_time_info":
            if self.engine:
                time_info = []
                for group in self.engine.trackgroups:
                    for track in group.tracks:
                        track_times = self.calculate_track_times(track)
                        time_info.append({
                            "name": track.name,
                            "time_elapsed": track_times["time_elapsed"],
                            "time_elapsed_from_dist": track_times["time_elapsed_from_dist"],
                            "time_total": track_times["time_total"],
                            "time_remaining": track_times["time_remaining"],
                            "dist": track.channel.distance,
                            "curve_length": track.curve.length_total,
                            "pedal": track.channel.pedal,
                            "v_max": track.channel.v_max
                        })
                self.out_queue.put({
                    "type": "time_info",
                    "data": time_info
                })
        
        # ============ RECORDER CONTROL ============
        elif c == "init_recorder":
            if not self.recorder:
                self.recorder = DeterministicRecorder(self.engine)
                self.recorder.set_engine_process(self)
                self.debug_print(1, "🎬 Recorder initialisiert (240 Hz)")
                self.recorder_queue.put({
                    "type": "recorder_status",
                    "status": "initialized",
                    "success": True
                })
        
        elif c == "start_recording":
            if self.recorder is None:
                self.recorder = DeterministicRecorder(self.engine)
                self.recorder.set_engine_process(self)
                self.debug_print(1, "🎬 Recorder initialisiert mit Engine")
            
            session_name = cmd.get("session_name")
            success = self.recorder.start_recording(session_name)
            
            if success:
                self.debug_print(1, f"🎬 Recording GESTARTET - 240 Hz VOLLAUFLÖSUNG!")
                if session_name:
                    self.debug_print(1, f"   Session: {session_name}")
            
            self.recorder_queue.put({
                "type": "recording_status",
                "status": "started",
                "success": success,
                "session_name": session_name,
                "timestamp": self.get_elapsed_time()
            })
        
        elif c == "stop_recording":
            if self.recorder:
                session = self.recorder.stop_recording()
                
                if session:
                    total_samples = session.total_samples
                    tracks = len(session.tracks)
                    avg_hz = total_samples / session.duration if session.duration > 0 else 0
                    
                    self.debug_print(1, f"🎬 Recording GESTOPPT - {total_samples} Samples, "
                                    f"{session.duration:.1f}s, {avg_hz:.1f} Hz")
                    
                    self.recorder_queue.put({
                        "type": "recording_status",
                        "status": "stopped",
                        "data": {
                            "is_recording": False,
                            "session_name": session.name,
                            "duration": session.duration,
                            "total_samples": total_samples,
                            "tracks": tracks
                        }
                    })
        
        elif c == "pause_recording":
            if self.recorder:
                self.recorder.pause_recording()
                self.debug_print(1, "🎬 Recording PAUSIERT")
                self.recorder_queue.put({
                    "type": "recording_status",
                    "status": "paused",
                    "success": True
                })
        
        elif c == "resume_recording":
            if self.recorder:
                self.recorder.resume_recording()
                self.debug_print(1, "🎬 Recording FORTGESETZT")
                self.recorder_queue.put({
                    "type": "recording_status",
                    "status": "resumed",
                    "success": True
                })
        
        elif c == "save_recording":
            if self.recorder:
                filepath = cmd.get("filepath")
                trim_start = cmd.get("trim_start")
                trim_end = cmd.get("trim_end")
                normalize = cmd.get("normalize", True)
                decimate = cmd.get("decimate", 1)
                
                trim = (trim_start, trim_end) if trim_start is not None and trim_end is not None else None
                
                self.debug_print(1, f"💾 Speichere Recording: {filepath}")
                if trim:
                    self.debug_print(1, f"   Trim: t={trim_start:.3f}-{trim_end:.3f}")
                if decimate > 1:
                    self.debug_print(1, f"   Dezimierung: 1/{decimate} = {240//decimate} Hz")
                
                success = self.recorder.save_recording(filepath, trim, normalize, decimate)
                
                if success:
                    self.debug_print(1, f"✅ Recording gespeichert: {filepath}")
                    total_samples = self.recorder.current_session.total_samples if self.recorder.current_session else 0
                    duration = self.recorder.current_session.duration if self.recorder.current_session else 0
                    
                    self.recorder_queue.put({
                        "type": "recording_saved",
                        "success": success,
                        "filepath": filepath,
                        "total_samples": total_samples,
                        "duration": duration,
                        "trimmed": trim is not None,
                        "normalized": normalize,
                        "decimate": decimate
                    })
                else:
                    self.debug_print(1, f"❌ Fehler beim Speichern: {filepath}")
                    self.recorder_queue.put({
                        "type": "recording_saved",
                        "success": False,
                        "filepath": filepath
                    })
        
        elif c == "load_recording":
            filepath = cmd.get("filepath")
            
            if not self.recorder:
                self.recorder = DeterministicRecorder(self.engine)
                self.recorder.set_engine_process(self)
            
            self.debug_print(1, f"📂 Lade Recording: {filepath}")
            session = self.recorder.load_recording(filepath)
            
            if session:
                total_samples = session.total_samples
                
                self.debug_print(1, f"✅ Recording geladen: {session.name}")
                self.debug_print(1, f"   Dauer: {session.duration:.1f}s, Samples: {total_samples}")
                
                self.recorder_queue.put({
                    "type": "recording_loaded",
                    "success": True,
                    "session_name": session.name,
                    "duration": session.duration,
                    "total_samples": total_samples,
                    "tracks": len(session.tracks)
                })
            else:
                self.debug_print(1, f"❌ Fehler beim Laden: {filepath}")
                self.recorder_queue.put({
                    "type": "recording_loaded",
                    "success": False
                })
        
        elif c == "get_recording_status":
            if self.recorder:
                status = {
                    "is_recording": self.recorder.is_recording,
                    "buffer_size": self.recorder.get_buffer_size(),
                    "session_name": self.recorder.current_session.name if self.recorder.current_session else None,
                    "duration": self.recorder.current_session.duration if self.recorder.current_session else 0.0
                }
            else:
                status = {
                    "is_recording": False,
                    "buffer_size": 0,
                    "session_name": None,
                    "duration": 0.0
                }
            
            self.recorder_queue.put({
                "type": "recording_status",
                "status": "query",
                "data": status
            })
        
        elif c == "get_track_buffer":
            if self.recorder:
                track_name = cmd.get("track")
                buffer_data = self.recorder.get_track_buffer(track_name)
                
                self.recorder_queue.put({
                    "type": "track_buffer",
                    "track": track_name,
                    "samples": buffer_data,
                    "count": len(buffer_data)
                })
        
        elif c == "get_all_buffers":
            if self.recorder:
                buffers = self.recorder.get_all_buffers()
                self.recorder_queue.put({
                    "type": "all_buffers",
                    "buffers": buffers,
                    "tracks": list(buffers.keys())
                })
        
        elif c == "get_pedal_sequence":
            if self.recorder:
                track = cmd.get("track")
                max_samples = cmd.get("max_samples", 1000)
                
                times, values = self.recorder.get_pedal_sequence(track, max_samples)
                
                self.recorder_queue.put({
                    "type": "pedal_curve",
                    "track": track,
                    "times": times,
                    "values": values,
                    "count": len(times)
                })

    # ------------------------------------------------------------
    # HAUPTLOOP - MIT KORREKTER PAUSE!
    # ------------------------------------------------------------
    def run(self):
        self.debug_print(1, f"🚀 Engine process gestartet (Target: {self.target_hz}Hz)")
        
        next_tick = time.perf_counter()
        self.reset_global_time()

        while self.running:
            loop_start = time.perf_counter()
            
            # Kommandos abarbeiten
            while not self.in_queue.empty():
                self.handle_command(self.in_queue.get())

            if self.engine is None:
                time.sleep(0.01)
                continue

            # 🔥 WICHTIG: NUR wenn NICHT pausiert, dann channels updaten!
            now = time.perf_counter()
            
            if now >= next_tick:
                channel_start = time.perf_counter()
                
                # NUR im aktiven Zustand channels updaten!
                if not self.paused:
                    for group in self.engine.trackgroups:
                        for track in group.tracks:
                            track.channel.update(self.dt)
                
                channel_duration = time.perf_counter() - channel_start

                # Recording - nur wenn aktiv
                if self.recorder and self.recorder.is_recording:
                    self.recorder.record_sample()
                    
                    if self.tick_count % 10 == 0:
                        if self.recorder.current_session:
                            current_duration = self.get_elapsed_time() - self.recorder.recording_start_time
                            
                            status_data = {
                                "is_recording": True,
                                "session_name": self.recorder.current_session.name,
                                "duration": current_duration,
                                "buffer_size": self.recorder.get_buffer_size(),
                                "sample_rate": 240.0
                            }
                            
                            self.recorder_queue.put({
                                "type": "recording_status",
                                "status": "live",
                                "data": status_data
                            })

                # Payload an GUI (immer senden - mit aktuellen Werten)
                payload = []
                for group in self.engine.trackgroups:
                    for track in group.tracks:
                        ch = track.channel
                        track_times = self.calculate_track_times(track)
                        payload.append({
                            "name": track.name,
                            "t_local": ch.t_local,
                            "dist": ch.distance,
                            "pedal": ch.pedal,
                            "max_speed": ch.v_max,
                            "curve_length": track.curve.length_total,
                            "time_elapsed": track_times["time_elapsed"],
                            "time_elapsed_from_dist": track_times["time_elapsed_from_dist"],
                            "time_total": track_times["time_total"],
                            "time_remaining": track_times["time_remaining"]
                        })

                self.out_queue.put(payload)
                
                loop_duration_so_far = time.perf_counter() - loop_start
                self.debug_tick_info(self.tick_count + 1, loop_duration_so_far, channel_duration)
                
                next_tick += self.dt
                sleep_duration = 0.0
                
            else:
                sleep_duration = max(0.0, next_tick - now)
                self.last_sleep_time = sleep_duration
                time.sleep(sleep_duration)
                channel_duration = None
            
            loop_duration = time.perf_counter() - loop_start
            
            # Performance-Metriken NUR im aktiven Zustand
            if self.engine is not None and not self.paused:
                self._update_performance_metrics(loop_duration, channel_duration, sleep_duration)

        self._log_final_stats()

        if self.recorder and self.recorder.current_session:
            session = self.recorder.current_session
            total_samples = sum(t.num_samples for t in session.tracks.values())
            
            self.debug_print(1, "=" * 70)
            self.debug_print(1, "🎬 FINAL RECORDING STATISTICS")
            self.debug_print(1, "=" * 70)
            self.debug_print(1, f"Session: {session.name}")
            self.debug_print(1, f"Dauer: {session.duration:.3f}s")
            self.debug_print(1, f"Tracks: {len(session.tracks)}")
            self.debug_print(1, f"Gesamt Samples: {total_samples}")
            if session.duration > 0:
                self.debug_print(1, f"Durchschn. Sample-Rate: {total_samples/session.duration:.1f} Hz")
            self.debug_print(1, "=" * 70)

        self.debug_print(1, "✅ Process beendet.")

    def _log_final_stats(self):
        if self.tick_count == 0:
            return
            
        stats = self.get_performance_stats()
        
        self.debug_print(1, "=" * 70)
        self.debug_print(1, "📊 ENGINE FINAL PERFORMANCE REPORT")
        self.debug_print(1, "=" * 70)
        self.debug_print(1, f"Gesamt-Ticks: {stats['tick_count']:,}")
        self.debug_print(1, f"Ziel-Hz: {stats['target_hz']} | Verfügbar pro Tick: {stats['available_ms_per_tick']:.2f}ms")
        self.debug_print(1, f"Gemessene Hz: {stats['measured_hz']:.1f} ({stats['measured_hz']/stats['target_hz']*100:.1f}% vom Ziel)")
        self.debug_print(1, f"Durchschn. Loop: {stats['avg_loop_ms']:.3f}ms (inkl. Sleep: {stats['avg_sleep_ms']:.3f}ms)")
        self.debug_print(1, f"Durchschn. Channel-Update: {stats['avg_channel_ms']:.3f}ms")
        self.debug_print(1, f"Min/Max Loop: {stats['min_loop_ms']:.3f}ms / {stats['max_loop_ms']:.3f}ms")
        self.debug_print(1, f"Jitter: {stats['jitter_ms']:.3f}ms")
        self.debug_print(1, f"CPU-Auslastung: {stats['cpu_usage_percent']:.1f}%")
        self.debug_print(1, f"Gesamtlaufzeit: {stats['total_runtime_s']:.2f}s")
        self.debug_print(1, f"Exakte Laufzeit (t0-1): {stats['time_elapsed']:.3f}s")
        self.debug_print(1, "=" * 70)


    # ------------------------------------------------------------
    # Setup anwenden - MIT TRACK-TYPEN!
    # ------------------------------------------------------------
    def apply_setup(self, data):
        self.debug_print(1, "📂 Lade Setup...")
        
        # 🔥 WICHTIG: Verwende die neue Factory-Funktion
        from tsde_engine.engine_factory import create_engine_from_setup
        self.engine = create_engine_from_setup(data)
        
        # 🔥 Der ganze manuelle Code zum Erstellen der Tracks entfällt,
        # weil create_engine_from_setup das jetzt macht!
        
        self.debug_print(1, f"✅ Setup geladen: {len(self.engine.trackgroups)} Gruppen")
        self.reset_global_time()
        
        if self.debug_level >= 2:
            for g in self.engine.trackgroups:
                self.debug_print(2, f"  Gruppe '{g.name}': {len(g.tracks)} Tracks")
                if self.debug_level >= 3:
                    for track in g.tracks:
                        track_type = getattr(track, 'track_type', 'motion')
                        if track_type == "motion":
                            self.debug_print(3, f"    - {track.name} ({track_type}): "
                                            f"v_max={track.channel.v_max}, "
                                            f"Kurvenlänge={track.curve.length_total:.1f}")
                        elif track_type == "empty":
                            self.debug_print(3, f"    - {track.name} ({track_type}): "
                                            f"v_max={track.channel.v_max} (keine Bewegung)")
                        else:  # param
                            self.debug_print(3, f"    - {track.name} ({track_type}): "
                                            f"{track.param_name} ({track.param_min}-{track.param_max} {track.param_unit})")