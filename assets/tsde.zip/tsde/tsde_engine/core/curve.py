# ------------------------------------------------------------------------
# TSDE Engine – Curve
# ------------------------------------------------------------------------
# Verantwortlichkeiten:
# - Hält eine Liste gleichmäßig gesampelter Punkte
# - Evaluiert die Kurve für einen normierten Zeitwert t (0–1)
# - Liefert deterministische, lineare Interpolation zwischen Punkten
#
# Hinweise:
# - Curve kennt KEINE Zeit, KEINE Modulation, KEINE Engine-Logik
# - Curve ist rein: t rein → Punkt raus
# - Punkte müssen vorher durch Preprocess reparametrisiert werden
#
# Bug / TODO Section:
# - Später: Unterstützung für Splines höherer Ordnung (Bezier, Catmull-Rom)
# - Später: Caching von Segmentlängen für Performance
# - Später: Extrapolation außerhalb 0–1 (optional)
# ------------------------------------------------------------------------

from __future__ import annotations


class Curve:
    def __init__(self, points):
        self.points = points
        self.length_total = self.compute_length()

    def compute_length(self):
        import math
        pts = self.points
        if len(pts) < 2:
            return 0.0

        total = 0.0
        for i in range(len(pts)-1):
            a = pts[i]
            b = pts[i+1]
            dx = b.x - a.x
            dy = b.y - a.y
            dz = b.z - a.z
            total += math.sqrt(dx*dx + dy*dy + dz*dz)
        return total

    def evaluate(self, t: float):
        pts = self.points
        if not pts or len(pts) < 2:
            return None

        if t <= 0.0:
            return pts[0].copy()
        if t >= 1.0:
            return pts[-1].copy()

        total_len = len(pts) - 1
        f = t * total_len
        i = int(f)
        frac = f - i

        return pts[i].lerp(pts[i + 1], frac)
    
    def to_serializable(self):
        # Punkte als Tupel exportieren
        return [(p.x, p.y, p.z) for p in self.points]

    @classmethod
    def from_serializable(cls, data):
        from tsde_engine.math.point import Point
        from tsde_engine.curves.curve_loader import load_csv_curve

        # CSV-Quelle
        if isinstance(data, dict) and data.get("source") == "csv":
            path = data["path"]
            seg = data.get("segment_length", 0.01)
            return load_csv_curve(path, seg)

        # Punktliste
        pts = [Point(*row[:3]) for row in data]
        return cls(pts)