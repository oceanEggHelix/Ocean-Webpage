# tsde_engine/editor_gui/export/export_manager.py

from tsde_engine.recorder.recording_data import RecordingSession, TrackRecording, RecordingSample
import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import numpy as np

class ExportManager:
    """Exportiert Editor-Daten im gleichen Format wie Recording"""
    
    @staticmethod
    def export_session(
        session_data: Dict,
        tracks_data: Dict,
        curves_data: Dict,
        filepath: str,
        include_spline: bool = True
    ) -> bool:
        """
        Exportiert aktuelle Editor-Session als Recording-JSON
        
        Args:
            session_data: Session-Infos (name, duration)
            tracks_data: Track-Objekte mit current_times und pedals
            curves_data: Kurven-Daten (für Pfade und Längen)
            filepath: Zielpfad für JSON
            include_spline: Ob Spline-Punkte mit exportiert werden sollen
        """
        try:
            # RecordingSession bauen
            recording = RecordingSession(
                name=session_data.get("name", "Unbenannt"),
                date=datetime.now().isoformat(),
                duration=session_data["duration"]
            )
            
            # Tracks konvertieren
            for track_name, track in tracks_data.items():
                # Ohne Bewegung macht Export keinen Sinn
                if not hasattr(track, 'current_times') or track.current_times is None:
                    continue
                    
                samples: List[RecordingSample] = []

                # ❗ Echte Zeitachse des Pedals verwenden, falls vorhanden
                times = getattr(track, 'time_data', None)
                if times is None:
                    # Fallback: current_times
                    times = track.current_times
                times = np.array(times, dtype=float)

                pedals = getattr(track, 'pedals', None)
                if pedals is None:
                    pedals = np.zeros_like(times, dtype=float)
                else:
                    pedals = np.array(pedals, dtype=float)

                # Samples bauen
                for i in range(len(times)):
                    t_val = float(times[i])
                    pedal_val = float(pedals[i]) if i < len(pedals) else 0.0
                    pedal_rounded = round(pedal_val * 100) / 100

                    samples.append(RecordingSample(
                        t=t_val,
                        pedal=pedal_rounded,
                        time=0.0,
                        dist=0.0
                    ))
                
                # Curve-Path und Länge aus curves_data
                curve_path = ""
                curve_length = 0.0
                
                if track_name in curves_data and curves_data[track_name]:
                    curve = curves_data[track_name]
                    
                    if hasattr(curve, 'source_path'):
                        curve_path = curve.source_path
                    else:
                        curve_path = f"curves/{track_name}.csv"
                    
                    if hasattr(curve, 'length_total'):
                        curve_length = curve.length_total
                    elif hasattr(track, 'curve_length'):
                        curve_length = track.curve_length
                
                # t_start / t_end korrekt aus den Samples ableiten
                if len(samples) > 0:
                    t_start = float(samples[0].t)
                    t_end   = float(samples[-1].t)
                else:
                    t_start = 0.0
                    t_end   = 1.0
                
                # 🔥 NEU: track_type aus dem Track-Objekt holen
                track_type = getattr(track, 'track_type', 'motion')
                
                # TrackRecording erstellen
                track_rec = TrackRecording(
                    track_name=track_name,
                    curve_path=curve_path,
                    max_speed=getattr(track, 'max_speed', 100.0),
                    curve_length=curve_length,
                    t_start=t_start,
                    t_end=t_end
                )
                
                # 🔥 NEU: track_type setzen
                track_rec.track_type = track_type
                
                # 🔥 NEU: Param-Track spezifische Felder
                if track_type == "param":
                    track_rec.param_name = getattr(track, 'param_name', '')
                    track_rec.param_unit = getattr(track, 'param_unit', '')
                    track_rec.param_min = getattr(track, 'param_min', 0.0)
                    track_rec.param_max = getattr(track, 'param_max', 1.0)
                
                # Samples hinzufügen
                for sample in samples:
                    track_rec.add_sample(sample)
                
                # Editor-Daten setzen (Spline-Punkte etc.)
                if include_spline and hasattr(track, 'pedal_graph') and track.pedal_graph is not None:
                    pg = track.pedal_graph
                    
                    editor_data = {}
                    
                    if hasattr(pg, 'spline_points') and pg.spline_points:
                        editor_data["spline_points"] = [
                            {"t": float(t), "pedal": float(p)}
                            for t, p in pg.spline_points
                        ]
                        print(f"   📊 {track_name}: {len(pg.spline_points)} Spline-Punkte exportiert")
                    
                    if hasattr(pg, 'mode'):
                        if hasattr(pg.mode, 'value'):
                            editor_data["mode"] = pg.mode.value
                        else:
                            editor_data["mode"] = str(pg.mode)
                    
                    if hasattr(pg, 'vmax_value'):
                        editor_data["vmax"] = pg.vmax_value
                    
                    track_rec.editor_data = editor_data
                
                recording.tracks[track_name] = track_rec
            
            # Als JSON speichern
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(recording.to_dict(), f, indent=2, ensure_ascii=False)
            
            print(f"✅ Export erfolgreich: {filepath}")
            summary = recording.get_summary()
            print(f"   - {len(recording.tracks)} Tracks")
            print(f"   - {summary['total_samples']} Samples")
            for t_name, t_rec in recording.tracks.items():
                print(f"   - {t_name}: Typ={t_rec.track_type}, Länge={t_rec.curve_length:.1f} mm")
                if t_rec.track_type == "param":
                    print(f"     📊 Param: {t_rec.param_name} ({t_rec.param_min}-{t_rec.param_max} {t_rec.param_unit})")
                if t_rec.editor_data and "spline_points" in t_rec.editor_data:
                    print(f"     📍 {len(t_rec.editor_data['spline_points'])} Spline-Punkte")
            return True
            
        except Exception as e:
            print(f"❌ Export fehlgeschlagen: {e}")
            import traceback
            traceback.print_exc()
            return False