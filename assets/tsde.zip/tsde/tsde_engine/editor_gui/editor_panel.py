# editor_gui/editor_panel.py - Haupteditor mit allen Funktionen

from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QScrollArea, QWidget,
    QPushButton, QLabel, QFileDialog, QMessageBox, QSizePolicy
)
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
import numpy as np
import json
import os
import re

from .theme import Theme
from .widgets.vtk.vtk_view import VTK3DView
from .widgets.timeline.timeline_widget import TimelineWidget
from .widgets.tracks.tracks_container import TracksContainer
from .widgets.tracks.track_lane import TrackLane
from .widgets.graphs.pedal_mode import PedalMode
from .export.export_manager import ExportManager

# Dummy-Klassen für den Fall, dass die echten Imports nicht verfügbar sind
try:
    from tsde_engine.recorder.editor_data import EditableTrack, EditableSession
except ImportError:
    class EditableTrack:
        def __init__(self, name, times, pedals):
            self.name = name
            self.current_times = times
            self.current_pedals = pedals
            self.pedals = pedals
            self.t_min = 0.0
            self.t_max = 1.0
            self.duration = 0.0
            self.max_speed = 100.0
    
    class EditableSession:
        def __init__(self, name, tracks): pass


class EditorPanel(QFrame):
    """Haupteditor - mit VTK, Timeline, Control-Funktionen und scrollbaren Tracks"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setObjectName("editorPanel")
        self.setStyleSheet(f"""
            QFrame#editorPanel {{
                background: {Theme.rgba('bg_primary')};
                border: none;
            }}
        """)
        
        # === Daten ===
        self.session = None
        self.current_pos = 0.0
        self.is_playing = False
        self.duration = 0.0
        self.zoom_start = 0.0
        self.zoom_end = 1.0
        self.tracks_data = {}  # Speichert Track-Objekte für VTK
        self.curves_data = {}  # Speichert Kurven für VTK
        self.current_vtk_track = None  # Aktuell im VTK angezeigter Track
        self.current_vtk_group = None  # Aktuell im VTK angezeigte Gruppe
        self._updating_position = False  # Verhindert Endlosschleifen
        self._updating_play_state = False  # Verhindert Endlosschleifen bei Play
        
        # NEU: Letzte ausgewählte Tracks/Gruppen speichern
        self.last_track_name = None
        self.last_group_name = None
        
        # NEU: Preview-Mode State
        self.preview_mode = False  # True wenn Rig-Preview aktiv
        self.preview_btn = None    # Wird in _build_ui erstellt
        
        # NEU: State für Kamera-Rig Frame - EINKLAPPBAR
        self.rig_frame_width = 300  # Volle Breite wenn ausgeklappt
        self.rig_collapsed = False  # Startet ausgeklappt
        
        self.PADDING = Theme.MARGIN
        self.SCROLLBAR_ESTIMATE = 16
        self.TRACKS_RIGHT_OFFSET = -30
        
        # Timer
        self._resize_timer = QTimer()
        self._resize_timer.setSingleShot(True)
        self._resize_timer.setInterval(50)
        self._resize_timer.timeout.connect(self._update_content_width)
        
        # UI aufbauen
        self._build_ui()
        
        # Playback-Verbindungen einrichten
        self._setup_playback_connections()
        
        # 🔥 NEU: Setup laden für Gruppenstruktur
        self.load_setup()

        # Nach dem UI-Aufbau: Kamera-Rig Overlay aus VTK holen
        QTimer.singleShot(100, self._integrate_camera_rig)
    
    def _build_ui(self):
        """Baut die gesamte UI auf"""
        # Hauptlayout - vertikal
        layout = QVBoxLayout(self)
        layout.setContentsMargins(Theme.MARGIN, Theme.MARGIN, 
                                Theme.MARGIN, Theme.MARGIN)
        layout.setSpacing(Theme.SPACING_LARGE)
        
        # === 4-SPALTEN-LAYOUT (TSDE | Rig | VTK | Mod) ===
        top_layout = QHBoxLayout()
        top_layout.setSpacing(Theme.SPACING)  # Abstand zwischen Widgets
        
        # === SPALTE 1: TSDE Frame (variabel - dehnt sich aus) ===
        self.left_frame = QFrame()
        self.left_frame.setObjectName("leftFrame")
        self.left_frame.setMinimumWidth(250)  # Minimale Breite
        self.left_frame.setMaximumWidth(16777215)  # Qt-Wert für unbegrenzt (oder einfach weglassen)
        self.left_frame.setFixedHeight(350)
        self.left_frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)  # Expanding = variabel!
        self.left_frame.setStyleSheet(f"""
            #leftFrame {{
                background: {Theme.rgba('bg_secondary', 100)};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_LARGE}px;
            }}
        """)

        left_layout = QVBoxLayout(self.left_frame)
        left_layout.setContentsMargins(20, 15, 20, 15)
        left_layout.setSpacing(12)
        left_layout.setAlignment(Qt.AlignTop)

        # === HEADER: TSDE Editor Schriftzug ===
        title = QLabel("TSDE Motion-Synth")
        title.setAlignment(Qt.AlignLeft)
        title.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgb('text_secondary')};
                font-size: 24pt;
                font-weight: bold;
                background: transparent;
                padding: 5px 0;
            }}
        """)
        left_layout.addWidget(title)

        # Trennlinie unter Header
        header_line = QFrame()
        header_line.setFrameShape(QFrame.HLine)
        header_line.setStyleSheet(f"""
            background: {Theme.rgba('border', 150)}; 
            max-height: 1px; 
            margin: 0 0 10px 0;
        """)
        left_layout.addWidget(header_line)

        # === BUTTON BEREICH (Load + Export) ===
        # Load-Button
        self.btn_load = QPushButton("📂 Recording laden")
        self.btn_load.setCursor(Qt.PointingHandCursor)
        self.btn_load.clicked.connect(self.load_recording)
        self.btn_load.setMinimumHeight(36)
        self.btn_load.setMaximumWidth(210)
        self.btn_load.setStyleSheet(f"""
            QPushButton {{
                background-color: {Theme.rgba('accent_blue')};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 8px 15px;
                font-weight: bold;
                font-size: 11pt;
                text-align: center;
                margin-bottom: 10px;
            }}
            QPushButton:hover {{
                background-color: {Theme.rgba('accent_blue', 200)};
            }}
        """)
        left_layout.addWidget(self.btn_load)

        # NEU: Export-Button
        self.btn_export = QPushButton("💾 Recording Speichern")
        self.btn_export.setCursor(Qt.PointingHandCursor)
        self.btn_export.clicked.connect(self.export_recording)
        self.btn_export.setMinimumHeight(36)
        self.btn_export.setMaximumWidth(210)
        self.btn_export.setStyleSheet(f"""
            QPushButton {{
                background-color: {Theme.rgba('accent_green', 200)};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 8px 15px;
                font-weight: bold;
                font-size: 11pt;
                text-align: center;
                margin-bottom: 10px;
            }}
            QPushButton:hover {{
                background-color: {Theme.rgba('accent_green')};
            }}
        """)
        left_layout.addWidget(self.btn_export)

        # === PLATZHALTER FÜR WEITERE OPTIONEN ===
        options_label = QLabel("Weitere Optionen\nfolgen in Kürze")
        options_label.setAlignment(Qt.AlignCenter)
        options_label.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgba('text_secondary', 150)};
                font-size: 10pt;
                padding: 20px 10px;
                background: {Theme.rgba('bg_primary', 50)};
                border-radius: {Theme.RADIUS_MEDIUM}px;
                margin-top: 15px;
            }}
        """)
        options_label.setWordWrap(True)
        left_layout.addWidget(options_label)

        left_layout.addStretch()
        top_layout.addWidget(self.left_frame)  # Links - dehnt sich aus
        
        # === SPALTE 2: Kamera-Rig Frame (feste Breite) ===
        # Horizontaler Container für Rig-Frame + Toggle-Button
        rig_container = QHBoxLayout()
        rig_container.setContentsMargins(0, 0, 0, 0)
        rig_container.setSpacing(0)

        # Der eigentliche Rig-Frame (wird ein-/ausgeklappt)
        self.rig_frame = QFrame()
        self.rig_frame.setObjectName("rigFrame")
        self.rig_frame.setFixedWidth(self.rig_frame_width)
        self.rig_frame.setFixedHeight(350)
        self.rig_frame.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)  # Fixed = feste Breite
        self.rig_frame.setStyleSheet(f"""
            #rigFrame {{
                background: {Theme.rgba('bg_secondary', 100)};
                border: 1px solid {Theme.rgba('accent_blue')};
                border-radius: {Theme.RADIUS_LARGE}px;
            }}
        """)

        # Einfaches VBoxLayout für den Inhalt
        rig_layout = QVBoxLayout(self.rig_frame)
        rig_layout.setContentsMargins(5, 5, 5, 5)
        rig_layout.setSpacing(0)

        # Container für den Inhalt (immer sichtbar)
        self.rig_content = QFrame()
        self.rig_content.setVisible(True)
        self.rig_content.setStyleSheet("background: transparent;")

        content_layout = QVBoxLayout(self.rig_content)
        content_layout.setContentsMargins(5, 5, 5, 5)
        content_layout.setSpacing(5)

        # === PREVIEW BUTTON ===
        self.preview_btn = QPushButton("🎬 Preview starten")
        self.preview_btn.setCursor(Qt.PointingHandCursor)
        self.preview_btn.clicked.connect(self._toggle_preview_mode)
        self.preview_btn.setCheckable(True)
        self.preview_btn.setMinimumHeight(30)
        self.preview_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {Theme.rgba('accent_green', 200)};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 4px;
                font-weight: bold;
                font-size: 10pt;
                margin: 1px 3px;
            }}
            QPushButton:hover {{
                background-color: {Theme.rgba('accent_green')};
            }}
            QPushButton:checked {{
                background-color: {Theme.rgba('accent_red', 200)};
                color: white;
            }}
            QPushButton:checked:hover {{
                background-color: {Theme.rgba('accent_red')};
            }}
        """)
        content_layout.addWidget(self.preview_btn)

        # Platzhalter (wird später durch echtes Overlay ersetzt)
        self.rig_placeholder = QLabel("Rig Controls\nwerden geladen...")
        self.rig_placeholder.setAlignment(Qt.AlignCenter)
        self.rig_placeholder.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgba('text_secondary', 150)};
                font-size: 10pt;
                padding: 20px;
                background: {Theme.rgba('bg_primary', 30)};
                border-radius: {Theme.RADIUS_SMALL}px;
            }}
        """)
        content_layout.addWidget(self.rig_placeholder)

        content_layout.addStretch()
        rig_layout.addWidget(self.rig_content)

        # === Einklapp-Button (rechts vom Frame) ===
        self.collapse_btn = QPushButton("◀")
        self.collapse_btn.setFixedSize(20, 350)
        self.collapse_btn.setCursor(Qt.PointingHandCursor)
        self.collapse_btn.setCheckable(True)
        self.collapse_btn.setChecked(False)  # Startet ausgeklappt
        self.collapse_btn.clicked.connect(self._toggle_rig_panel)
        self.collapse_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.collapse_btn.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('bg_secondary', 150)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('accent_blue')};
                border-radius: {Theme.RADIUS_SMALL}px;
                font-size: 12pt;
                font-weight: bold;
                padding: 0px;
                margin: 0px;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_blue', 100)};
            }}
            QPushButton:checked {{
                background: {Theme.rgba('accent_blue', 150)};
            }}
        """)

        # Frame und Button zum Container hinzufügen
        rig_container.addWidget(self.rig_frame)
        rig_container.addWidget(self.collapse_btn)
        top_layout.addLayout(rig_container)  # Zweite Spalte - feste Breite
        
        # === SPALTE 3: VTK View (feste Breite 630px) ===
        self.vtk_view = VTK3DView()
        self.vtk_view.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)  # Fixed = feste Breite
        
        # VTK Overlay Signale verbinden
        self.vtk_view.overlay.track_selected.connect(self._on_vtk_track_selected)
        self.vtk_view.overlay.group_selected.connect(self._on_vtk_group_selected)
        self.vtk_view.overlay.view_mode_changed.connect(self._on_vtk_view_mode_changed)
        # Auch die direkten Signale der VTK-View verbinden!
        self.vtk_view.track_selected.connect(self._on_vtk_track_selected)
        self.vtk_view.group_selected.connect(self._on_vtk_group_selected)
        
        # WICHTIG: VTK Modus-Änderung an Kamera-Rig weiterleiten
        self.vtk_view.view_mode_changed.connect(self._on_vtk_mode_for_rig)
        
        top_layout.addWidget(self.vtk_view)  # Dritte Spalte - feste Breite
        
        # === SPALTE 4: Modulations-Tools (feste Breite 300px) ===
        self.modulation_frame = QFrame()
        self.modulation_frame.setObjectName("modulationFrame")
        self.modulation_frame.setFixedWidth(300)
        self.modulation_frame.setFixedHeight(350)
        self.modulation_frame.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)  # Fixed = feste Breite
        self.modulation_frame.setStyleSheet(f"""
            #modulationFrame {{
                background: {Theme.rgba('bg_secondary', 100)};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_LARGE}px;
            }}
        """)
        
        # Platzhalter für spätere Modulations-Tools
        mod_layout = QVBoxLayout(self.modulation_frame)
        mod_layout.setContentsMargins(15, 15, 15, 15)
        mod_layout.setAlignment(Qt.AlignTop)
        
        mod_title = QLabel("🔧 Modulations-Tools")
        mod_title.setAlignment(Qt.AlignCenter)
        mod_title.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgb('text_secondary')};
                font-size: 16pt;
                font-weight: bold;
                padding: 10px;
            }}
        """)
        mod_layout.addWidget(mod_title)
        
        # Trennlinie
        mod_line = QFrame()
        mod_line.setFrameShape(QFrame.HLine)
        mod_line.setStyleSheet(f"background: {Theme.rgba('border')}; max-height: 1px; margin: 5px 0;")
        mod_layout.addWidget(mod_line)
        
        mod_placeholder = QLabel("Hier kommen später\nModulations-Tools hin")
        mod_placeholder.setAlignment(Qt.AlignCenter)
        mod_placeholder.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgba('text_secondary', 180)};
                font-size: 11pt;
                padding: 20px;
            }}
        """)
        mod_layout.addWidget(mod_placeholder)
        
        mod_layout.addStretch()
        top_layout.addWidget(self.modulation_frame)  # Vierte Spalte - feste Breite
        
        layout.addLayout(top_layout)
        
        # === Timeline ===
        self.timeline = TimelineWidget()
        self.timeline.duration_changed.connect(self._on_timeline_duration_changed)
        layout.addWidget(self.timeline)
        
        # === Track Container mit ScrollArea ===
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area.setStyleSheet(f"""
            QScrollArea {{
                border: none;
                background: transparent;
            }}
            QScrollBar:vertical {{
                background: {Theme.rgba('bg_secondary')};
                width: 10px;
                border-radius: 5px;
            }}
            QScrollBar::handle:vertical {{
                background: {Theme.rgba('accent_blue', 150)};
                border-radius: 5px;
                min-height: 30px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: {Theme.rgba('accent_blue')};
            }}
        """)
        
        # TracksContainer in die ScrollArea legen
        self.tracks_container = TracksContainer()
        self.scroll_area.setWidget(self.tracks_container)
        
        # ScrollArea zum Hauptlayout hinzufügen (mit Stretch-Faktor)
        layout.addWidget(self.scroll_area, 1)
        
        # === Signale verbinden ===
        self.timeline.position_changed.connect(self._on_position_changed)
        self.timeline.zoom_changed.connect(self._on_zoom_changed)
        self.timeline.view.installEventFilter(self)
    
    def _update_content_width(self):
        """Berechnet die Breite für die Tracks"""
        if not self.scroll_area.isVisible() or self.timeline.width() < 200:
            return
        
        # Verfügbare Breite = Timeline-Breite minus Padding und Scrollbar
        sb_width = self.scroll_area.verticalScrollBar().width() if self.scroll_area.verticalScrollBar().isVisible() else self.SCROLLBAR_ESTIMATE
        tracks_width = self.timeline.width() - 2 * self.PADDING - sb_width - 30
        
        if tracks_width > 100:
            self.tracks_container.set_content_width(tracks_width)
    
    def _toggle_rig_panel(self, checked):
        """Klappt das Rig-Panel ein/aus"""
        if checked:
            # Einklappen - Breite auf 0 setzen
            self.rig_frame.setFixedWidth(0)
            self.rig_content.setVisible(False)
            self.collapse_btn.setText("▶")  # Pfeil zeigt nach rechts (zum Ausklappen)
            self.rig_collapsed = True
        else:
            # Ausklappen - volle Breite wiederherstellen
            self.rig_frame.setFixedWidth(self.rig_frame_width)
            self.rig_content.setVisible(True)
            self.collapse_btn.setText("◀")  # Pfeil zeigt nach links (zum Einklappen)
            self.rig_collapsed = False
        
        # Kurze Verzögerung für Neu-Layout
        QTimer.singleShot(10, self._update_layout_after_toggle)
    
    def _update_layout_after_toggle(self):
        """Aktualisiert das Layout nach dem Ein-/Ausklappen"""
        self.update()
        if hasattr(self, 'vtk_view') and self.vtk_view:
            self.vtk_view.update()
        # Auch die Tracks-Breite neu berechnen
        self._update_content_width()
    
    def export_recording(self):
        """Exportiert aktuelle Session als Recording-JSON"""
        if not self.session:
            QMessageBox.warning(self, "Export nicht möglich", "Keine Session geladen!")
            return
        
        # Dateiauswahl
        filepath, _ = QFileDialog.getSaveFileName(
            self, 
            "Recording exportieren", 
            "", 
            "JSON (*.json)"
        )
        if not filepath:
            return
        
        # Session-Daten vorbereiten
        session_data = {
            "name": self.session.name,
            "duration": self.duration
        }
        
        print(f"\n📤 Exportiere Session mit {len(self.tracks_data)} Tracks...")
        
        # Export durchführen - OHNE track_lanes
        success = ExportManager.export_session(
            session_data=session_data,
            tracks_data=self.tracks_data,
            curves_data=self.curves_data,
            filepath=filepath
        )
        
        if success:
            QMessageBox.information(self, "Export erfolgreich", 
                                f"Session exportiert nach:\n{filepath}")
        else:
            QMessageBox.critical(self, "Export fehlgeschlagen", 
                            "Fehler beim Export - siehe Konsole")
    
    def _toggle_preview_mode(self):
        """Schaltet zwischen Editor und Preview-Modus um"""
        if not self.preview_mode:
            # PREVIEW AKTIVIEREN
            if not self.vtk_view.camera_rig or not self.vtk_view.camera_rig.active:
                QMessageBox.warning(self, "Preview nicht möglich", 
                                "Bitte zuerst Kamera-Rig aktivieren!")
                self.preview_btn.setChecked(False)
                return
            
            if not self.current_vtk_group:
                QMessageBox.warning(self, "Preview nicht möglich", 
                                "Bitte zuerst eine Gruppe auswählen!")
                self.preview_btn.setChecked(False)
                return
            
            self.preview_mode = True
            
            # Timeline komplett deaktivieren
            self.timeline.setEnabled(False)
            if self.is_playing:
                self.pause_playback()
            
            # Rig-Preview vorbereiten und starten
            self.vtk_view.prepare_rig_preview()
            self.vtk_view.start_rig_preview()
            self.preview_btn.setText("⏹ Preview beenden")
            print("🎬 PREVIEW-MODUS AKTIVIERT")
            
        else:
            # PREVIEW BEENDEN
            self.preview_mode = False
            
            # Timeline reaktivieren
            self.timeline.setEnabled(True)
            self.vtk_view.stop_rig_preview()
            self.preview_btn.setText("🎬 Preview starten")
            
            # WICHTIG: Kamera-Rig deaktivieren!
            if hasattr(self, 'rig_content') and self.rig_content:
                for i in range(self.rig_content.layout().count()):
                    item = self.rig_content.layout().itemAt(i)
                    if item.widget() and hasattr(item.widget(), 'set_active'):
                        item.widget().set_active(False)  # Rig-Toggle-Button zurücksetzen
                        break
            
            # Auch im VTK das Rig deaktivieren
            if self.vtk_view.camera_rig:
                self.vtk_view.camera_rig.toggle(False)
                
            print("🔄 ZURÜCK ZUM EDITOR-MODUS")
    
    def _integrate_camera_rig(self):
        """Holt das Kamera-Rig Overlay aus dem VTK und bettet es im Rig-Frame ein"""
        if hasattr(self.vtk_view, 'camera_rig_overlay') and self.vtk_view.camera_rig_overlay:
            rig_overlay = self.vtk_view.camera_rig_overlay
            
            # Im VTK die Referenz entfernen
            self.vtk_view.camera_rig_overlay = None
            
            # Im Rig-Content einbetten
            rig_overlay.setParent(self.rig_content)
            
            # Platzhalter entfernen
            for i in reversed(range(self.rig_content.layout().count())):
                item = self.rig_content.layout().itemAt(i)
                if item.widget() == self.rig_placeholder:
                    self.rig_placeholder.deleteLater()
                    break
            
            # Overlay einfügen (nach dem Preview-Button)
            # Index 2 = nach Titel (0) und Preview-Button (1)
            self.rig_content.layout().insertWidget(2, rig_overlay)
            
            # Größe anpassen
            rig_overlay.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            rig_overlay.setMinimumWidth(280)
            
            # GANZ WICHTIG: show() aufrufen!
            rig_overlay.show()
            
            # ALLE Signale verbinden
            rig_overlay.tracks_changed.connect(self.vtk_view._on_camera_rig_tracks_changed)
            rig_overlay.toggled.connect(self.vtk_view._on_camera_rig_toggled)
            rig_overlay.distance_changed.connect(lambda d: self.vtk_view.camera_rig.set_params(distance=d) if self.vtk_view.camera_rig else None)
            rig_overlay.height_changed.connect(lambda h: self.vtk_view.camera_rig.set_params(height=h) if self.vtk_view.camera_rig else None)
            rig_overlay.focal_length_changed.connect(lambda f: self.vtk_view.camera_rig.set_focal_length(f) if self.vtk_view.camera_rig else None)
            rig_overlay.sensor_width_changed.connect(lambda s: self.vtk_view.camera_rig.set_sensor_width(s) if self.vtk_view.camera_rig else None)
            
            # Initialen Modus vom VTK holen und setzen
            is_group_mode = not self.vtk_view._is_track_mode
            rig_overlay.set_mode(is_group_mode)
            print(f"🎥 Kamera-Rig initialer Modus: {'Group' if is_group_mode else 'Track'}")
            
            # Wenn Gruppen existieren, Track-Liste übergeben
            if hasattr(self, 'group_names') and self.group_names:
                rig_overlay.update_tracks(self.group_names)
                print(f"✅ Kamera-Rig Gruppen-Liste initial: {self.group_names}")
            
            print("✅ Kamera-Rig in eigenen Frame integriert")

    def _on_vtk_mode_for_rig(self, mode):
        """Wird aufgerufen wenn VTK Modus ändert - leitet an Kamera-Rig weiter"""
        is_group = (mode == "group")
        print(f"🎥 VTK Modus für Rig: {mode} -> group={is_group}")
        
        if hasattr(self, 'rig_content') and self.rig_content:
            for i in range(self.rig_content.layout().count()):
                item = self.rig_content.layout().itemAt(i)
                if item.widget() and hasattr(item.widget(), 'set_mode'):
                    item.widget().set_mode(is_group)
                    
                    # Wenn wir in den Track-Modus wechseln, zusätzlich Rig deaktivieren
                    if not is_group:
                        if hasattr(item.widget(), 'set_active'):
                            item.widget().set_active(False)
                    break
    
    def _on_timeline_play_state_changed(self, playing):
        """Wird von der Timeline aufgerufen wenn sich der Play-State ändert"""
        print(f"\n📋 EDITOR: _on_timeline_play_state_changed({playing}) WURDE AUFGERUFEN!")
        print(f"   self.is_playing vorher = {self.is_playing}")
        
        # Im Preview-Modus nichts tun
        if self.preview_mode:
            return
        
        # Verhindere Endlosschleife
        if self._updating_play_state:
            print("   ⚠️ Wird ignoriert wegen updating_play_state")
            return
        
        self._updating_play_state = True
        
        # Nur wenn sich der State wirklich ändert
        if playing != self.is_playing:
            self.is_playing = playing
            
            # VTK synchronisieren (aber nur wenn nicht im Rig-Modus)
            if not self.vtk_view.camera_rig or not self.vtk_view.camera_rig.active:
                self.vtk_view.set_playing_from_timeline(playing)
        
        self._updating_play_state = False
        print(f"   self.is_playing nachher = {self.is_playing}")
        print(f"   ✅ _on_timeline_play_state_changed() abgeschlossen\n")

    def _setup_playback_connections(self):
        """Richtet die Playback-Verbindungen zwischen Timeline, VTK und Vollbild ein"""
        print("\n🔧 EDITOR: Richte Playback-Verbindungen ein...")
        
        # Timeline -> EditorPanel
        self.timeline.play_pause_clicked.connect(self._on_timeline_play_clicked)
        print("   - timeline.play_pause_clicked verbunden")
        self.timeline.stop_clicked.connect(self.stop_playback)
        
        # 🔥 NEU: Timeline Play-State Changes
        self.timeline.play_state_changed.connect(self._on_timeline_play_state_changed)
        print("   - timeline.play_state_changed verbunden")
        
        # VTK -> EditorPanel (vom Vollbild)
        self.vtk_view.play_state_changed.connect(self._on_vtk_play_state_changed)
        print("   - vtk_view.play_state_changed verbunden")
        self.vtk_view.playback_position_changed.connect(self._on_vtk_position_changed)
        
        # VTK-Play-Button (Vollbild) direkt mit Toggle verbinden
        self.vtk_view.play_toggled.connect(self.toggle_playback)
        print("   - vtk_view.play_toggled verbunden")

    
    def load_setup(self):
        """Lädt das aktuelle Setup für die Gruppenstruktur"""
        setup_path = r"E:\TSDE\tsde_engine\setup\json\setup.json"
        try:
            with open(setup_path, 'r') as f:
                self.current_setup = json.load(f)
            print(f"\n📁 SETUP GELADEN:")
            print(f"   Pfad: {setup_path}")
            print(f"   Gruppen: {len(self.current_setup['groups'])}")
            for group in self.current_setup["groups"]:
                print(f"      • {group['name']}: {len(group['tracks'])} Tracks")
                for track in group["tracks"]:
                    print(f"         - {track['name']}")
            return True
        except Exception as e:
            print(f"⚠️ Kein Setup gefunden: {e}")
            self.current_setup = None
            return False


    # ===== EVENT HANDLER =====
    
    def eventFilter(self, obj, event):
        """Filtert Resize-Events der Timeline"""
        if obj is self.timeline.view and event.type() == event.Type.Resize:
            self._resize_timer.start()
        return super().eventFilter(obj, event)
    
    def resizeEvent(self, event):
        """Passt die Content-Breite an wenn das Fenster größer wird"""
        super().resizeEvent(event)
        self._resize_timer.start()
    
    # ===== TIMELINE SIGNALS =====
    
    def _on_position_changed(self, pos):
        #print(f"📡 Editor _on_position_changed({pos:.4f})")
        """Marker-Position von Timeline an alle Tracks weiterleiten"""
        # PREVIEW-MODUS IGNORIERT TIMELINE!
        if self._updating_position or self.preview_mode:
            return
        
        self._updating_position = True
        self.current_pos = pos
        
        # Graphen immer updaten (billig)
        self.tracks_container.set_marker(pos)
        
        # WENN RIG AKTIV: Position an FrameAnimator!
        if self.vtk_view.camera_rig and self.vtk_view.camera_rig.active:
            self.vtk_view.set_position_from_timeline(pos)
        else:
            # IMMER die Timeline-Position an VTK übergeben!
            # Die VTK View entscheidet selbst, wie sie damit umgeht
            self.vtk_view.set_marker(pos)
        
        self._updating_position = False
    
    def _on_zoom_changed(self, start, end):
        """Zoom von Timeline an alle Tracks weiterleiten"""
        self.zoom_start = start
        self.zoom_end = end
        self.tracks_container.set_zoom(start, end)
    
    def _on_timeline_duration_changed(self, new_duration):
        """Wird aufgerufen wenn die Duration in der Timeline geändert wird"""
        self.duration = new_duration
        print(f"⏱️ Neue Duration: {new_duration}s")
    
    # ===== PLAYBACK =====
    
    def _on_timeline_play_clicked(self):
        """Play/Pause in der Timeline geklickt"""
        # Im Preview-Modus nichts tun
        if self.preview_mode:
            return
            
        # Verhindere doppelte Aufrufe
        if self._updating_play_state:
            return
            
        self.toggle_playback()
    
    def _on_vtk_play_state_changed(self, playing):
        """VTK hat Play-Status geändert (durch Vollbild-Klick)"""
        print(f"\n📋 EDITOR: _on_vtk_play_state_changed({playing}) WURDE AUFGERUFEN!")
        print(f"   _updating_play_state = {self._updating_play_state}")
        print(f"   self.is_playing vorher = {self.is_playing}")
        
        # Im Preview-Modus nichts tun
        if self.preview_mode:
            return
        
        # Verhindere Endlosschleife
        if self._updating_play_state:
            print("   ⚠️ Wird ignoriert wegen updating_play_state")
            return
        
        self._updating_play_state = True
        
        # 🔥 FIX: Nur wenn sich der State wirklich ändert!
        if playing != self.is_playing:
            self.is_playing = playing
            
            if playing:
                print("   → Starte Playback")
                self.timeline.set_playing_from_external(True)
            else:
                print("   → Pausiere Playback")
                self.timeline.set_playing_from_external(False)
        else:
            print(f"   ⚠️ State already correct - ignoring")
        
        self._updating_play_state = False
        print(f"   self.is_playing nachher = {self.is_playing}")
        print(f"   ✅ _on_vtk_play_state_changed() abgeschlossen\n")

    
    def _on_vtk_position_changed(self, pos):
        """Wird aufgerufen wenn VTK die Position ändert"""
        # Im Preview-Modus nichts tun
        if self.preview_mode:
            return
            
        # Wenn Kamera-Rig aktiv ist: Timeline IGNORIEREN!
        if self.vtk_view.camera_rig and self.vtk_view.camera_rig.active:
            return
            
        if not self._updating_position and abs(pos - self.current_pos) > 0.001:
            self._updating_position = True
            self.current_pos = pos  # <-- WICHTIG: Position speichern!
            self.timeline.set_position(pos)  # Nur wenn Rig NICHT aktiv!
            self._updating_position = False
    
    def toggle_playback(self):
        """Play/Pause umschalten"""
        if not self.session:
            return
        
        # Im Preview-Modus nichts tun
        if self.preview_mode:
            return
        
        # Verhindere doppelte Aufrufe
        if self._updating_play_state:
            return
        
        if self.is_playing:
            self.pause_playback()
        else:
            self.start_playback()
    
    def start_playback(self):
        """Playback starten - synchronisiert Timeline und VTK"""
        print(f"▶️ EDITOR: start_playback() aufgerufen")
        
        if not self.session or self.is_playing:
            return
        
        self._updating_play_state = True
        self.is_playing = True
        
        # Timeline-Controller starten (der macht den Timer!)
        self.timeline.set_playing(True)
        
        # KEIN playback_timer mehr - komplett raus!
        
        # VTK-Animation starten
        self.vtk_view.set_playing_from_timeline(True)
        
        self._updating_play_state = False
        print(f"   ✅ start_playback() abgeschlossen\n")
    
    def pause_playback(self):
        """Playback pausieren"""
        print(f"⏸️ EDITOR: pause_playback() aufgerufen")
        
        if not self.is_playing:
            return
        
        self._updating_play_state = True
        self.is_playing = False
        
        # Timeline-Controller pausieren
        self.timeline.set_playing(False)
        
        # KEIN playback_timer mehr - komplett raus!
        
        # VTK-Animation pausieren
        self.vtk_view.set_playing_from_timeline(False)
        
        self._updating_play_state = False
        print(f"   ✅ pause_playback() abgeschlossen\n")
    
    def stop_playback(self):
        """Playback stoppen"""
        was_playing = self.is_playing
        self.pause_playback()
        
        if was_playing or self.current_pos > 0:
            self._updating_position = True
            self.current_pos = 0.0
            self.timeline.set_position(0.0)
            self.tracks_container.set_marker(0.0)
            self.vtk_view.set_marker(0.0)
            self._updating_position = False
    
    
    # ===== VTK VIEW MANAGEMENT =====
    
    def _on_vtk_track_selected(self, track_name):
        """Wird aufgerufen wenn im VTK-Overlay ein Track ausgewählt wird"""
        if self.preview_mode:
            return
            
        if track_name in self.tracks_data:
            track = self.tracks_data[track_name]
            curve = self.curves_data.get(track_name)
            if curve:
                self.vtk_view.set_curve(curve, track, initial_fit=True)
                self.current_vtk_track = track
                self.current_vtk_group = None
                self.last_track_name = track_name  # Letzten Track speichern
                
                # Marker auf aktuelle Position setzen
                if hasattr(track, 'current_times') and len(track.current_times) > 0:
                    pos = self.current_pos
                    times = track.current_times
                    idx = int(pos * len(times))
                    idx = min(idx, len(times) - 1)
                    t_value = times[idx]
                    self.vtk_view.set_marker(t_value)
                
                print(f"🔄 VTK Track gewechselt zu: {track_name}")
    
    def _on_vtk_group_selected(self, group_name):
        """Wird aufgerufen wenn im VTK-Overlay eine Gruppe ausgewählt wird"""
        if self.preview_mode:
            return
            
        print(f"👥 VTK Gruppe ausgewählt: {group_name}")
        
        # Verhindere doppelte Auswahl derselben Gruppe
        if self.current_vtk_group == group_name and self.vtk_view.group_mode:
            print(f"   Gruppe {group_name} bereits aktiv")
            return
        
        # Tracks der Gruppe finden
        group_tracks_with_curves = []
        found_group = None
        
        for group in self.tracks_container.groups:
            if group.name == group_name:
                found_group = group
                for track_lane in group.tracks:
                    track = track_lane.track
                    curve = self.curves_data.get(track.name)
                    if curve is not None:
                        # Stelle sicher, dass der Track current_times hat
                        if not hasattr(track, 'current_times') or track.current_times is None:
                            # Fallback: Dummy-Zeiten erstellen
                            track.current_times = np.linspace(0, 1, 100)
                        group_tracks_with_curves.append((track, curve))
                break
        
        if group_tracks_with_curves:
            print(f"   Lade {len(group_tracks_with_curves)} Tracks aus Gruppe {group_name}")
            self.vtk_view.set_group_curves(group_tracks_with_curves, initial_fit=True, group_name=group_name)
            self.current_vtk_group = group_name
            self.last_group_name = group_name  # Letzte Gruppe speichern
            self.current_vtk_track = None
            
            # Marker auf aktuelle Position setzen
            self.vtk_view.set_marker(self.current_pos)
            
            # Auch das Overlay im Vollbild-Modus aktualisieren
            if hasattr(self.vtk_view, 'fullscreen_window') and self.vtk_view.fullscreen_window:
                self.vtk_view.fullscreen_window.group_combo.setCurrentText(group_name)
        else:
            print(f"⚠️ Keine Tracks mit Kurven in Gruppe {group_name} gefunden")
    
    def _on_vtk_view_mode_changed(self, mode):
        """Wird aufgerufen wenn der VTK-View Modus umgeschaltet wird"""
        if self.preview_mode:
            return
            
        print(f"🔄 VTK Modus gewechselt zu: {mode}")
        
        # Merken ob gerade gespielt wird
        was_playing = self.is_playing
        current_pos = self.current_pos  # <-- Aktuelle Position merken
        
        if mode == "track":
            # Track-Modus: letzten Track wiederherstellen
            if self.last_track_name and self.last_track_name in self.tracks_data:
                track = self.tracks_data[self.last_track_name]
                curve = self.curves_data.get(self.last_track_name)
                if track and curve:
                    self.vtk_view.set_curve(curve, track)
                    self.current_vtk_track = track
                    self.current_vtk_group = None
                    print(f"   → Letzten Track geladen: {self.last_track_name}")
            elif self.current_vtk_track:
                track_name = self.current_vtk_track.name
                track = self.tracks_data.get(track_name)
                curve = self.curves_data.get(track_name)
                if track and curve:
                    self.vtk_view.set_curve(curve, track)
        
        elif mode == "group":
            # Gruppen-Modus: erste Gruppe laden oder letzte Gruppe wiederherstellen
            if self.last_group_name:
                # 🔥 WICHTIG: Group auswählen OHNE Play-Status zu verlieren
                self._on_vtk_group_selected(self.last_group_name)
                print(f"   → Letzte Gruppe geladen: {self.last_group_name}")
            elif self.group_names and len(self.group_names) > 0:
                first_group = self.group_names[0]
                self._on_vtk_group_selected(first_group)
                self.last_group_name = first_group
                print(f"   → Erste Gruppe geladen: {first_group}")
            elif self.current_vtk_group:
                self._on_vtk_group_selected(self.current_vtk_group)
        
        # 🔥 WICHTIG: Position wiederherstellen (nach dem Laden)
        self.vtk_view.set_marker(current_pos)
        
        # Play-Status wiederherstellen - aber NUR über den Editor!
        if was_playing:
            print(f"   → Stelle Playback wieder her (war {was_playing})")
            self.is_playing = True
            self.timeline.set_playing_from_external(True)
            self.vtk_view.set_playing_from_timeline(True)
            
            # 🔥 EXTRA: Vollbild explizit benachrichtigen
            if self.vtk_view.fullscreen_window:
                self.vtk_view.fullscreen_window.set_playing_from_timeline(True)
                
    # ===== SPLINE & MOVEMENT FUNCTIONS =====
    
    def _on_generate_movement(self, track_lane=None):
        """Berechnet neue Bewegung mit Duration aus Timeline"""
        if self.preview_mode:
            return
            
        if not track_lane and self.current_vtk_track:
            track_lane = self.tracks_container.get_track_by_name(self.current_vtk_track.name)
        
        if not track_lane:
            QMessageBox.warning(self, "Fehler", "Kein Track ausgewählt")
            return
        
        track = track_lane.track
        curve_graph = track_lane.graph_group.curve_graph
        pedal_graph = track_lane.graph_group.pedal_graph
        curve = curve_graph.curve
        
        if not curve:
            QMessageBox.warning(self, "Fehler", "Track hat keine Kurve")
            return
        
        # === PARAMETER ===
        pedals = pedal_graph.pedal_data
        v_max = pedal_graph.vmax_spin.value()      # mm/s
        duration = self.duration                   # AUS DER TIMELINE
        length = curve.length_total                # mm
        
        # === START BESTIMMEN ===
        use_record_start = pedal_graph.use_record_start.isChecked() if hasattr(pedal_graph, 'use_record_start') else False

        if use_record_start:
            # ORIGINAL-Record-Start verwenden (beim Laden gesetzt)
            if hasattr(track, 'start_t') and track.start_t is not None:
                start_pos = float(track.start_t)
                start_info = f"Start: Record (t={start_pos:.3f})"
                print(f"📀 Record-Start (ORIGINAL) bei t={start_pos:.3f}")
            else:
                start_pos = 0.0
                start_info = "Start: Record (0.0) - Fallback"
                print(f"⚠️ Kein start_t im Track - Start bei 0.0")
        else:
            # Grüner Marker
            marker = curve_graph.get_start_position()
            if marker is None:
                start_pos = 0.0
                start_info = "Start: 0.0 (kein Marker)"
                print(f"⚪ Kein Marker - Start bei 0.0")
            else:
                start_pos = float(marker)
                start_info = f"Start: Marker ({start_pos:.3f})"
                print(f"🟢 Marker bei t={start_pos:.3f}")
        
        # === DISTANZ AUS STARTPOS ===
        start_distance = start_pos * length
        
        print("\n" + "="*60)
        print("🔍 BEWEGUNGSBERECHNUNG")
        print("="*60)
        print(f"Track: {track.name}")
        print(f"v-max: {v_max:.1f} mm/s")
        print(f"Duration (Timeline): {duration:.1f}s")
        print(f"Kurvenlänge: {length:.1f} mm")
        print(f"Samples: {len(pedals)}")
        print(f"{start_info}")
        
        # === BERECHNUNG ===
        dt = duration / len(pedals)
        distance = start_distance
        new_t_values = []
        
        print(f"dt = {dt*1000:.2f} ms")
        print("-"*40)
        
        for pedal in pedals:
            v_eff = pedal * v_max
            distance += v_eff * dt
            
            if length > 0:
                t_new = (distance % length) / length
            else:
                t_new = 0.0
            
            new_t_values.append(t_new)
        
        end_pos = new_t_values[-1]
        gefahrene_strecke = 0.0
        letzter_t = start_pos
        
        for t in new_t_values:
            delta = t - letzter_t
            if delta < -0.5:
                delta += 1.0
            gefahrene_strecke += abs(delta) * length
            letzter_t = t
        
        print("-"*40)
        print(f"Ende: t={end_pos:.4f}")
        print(f"Strecke: {gefahrene_strecke:.1f} mm")
        print(f"Mittlere Geschw: {gefahrene_strecke/duration:.1f} mm/s")
        print("="*60)
        
        # === NEUE BEWEGUNG SPEICHERN ===
        track.current_times = np.array(new_t_values)
        track.t_min = float(min(new_t_values))
        track.t_max = float(max(new_t_values))
        
        track.uses_custom_movement = True
        track.pedals = pedals
        track.custom_v_max = v_max
        track.custom_duration = duration
        
        # Graph aktualisieren
        curve_graph.update()
        
        # === WICHTIG: VTK aktualisieren OHNE Auto-Fit! ===
        if self.current_vtk_track and self.current_vtk_track.name == track.name:
            # HIER: initial_fit=False hinzufügen!
            self.vtk_view.set_curve(curve, track, initial_fit=False)
            self.vtk_view.set_marker(self.current_pos)
        
        # === Gruppenmodus aktualisieren ===
        if self.vtk_view.group_mode and self.current_vtk_group:
            # Auch hier: initial_fit=False für Gruppenmodus
            tracks_with_curves = []
            for track_name in self.current_vtk_group:
                if track_name in self.vtk_view.tracks_data:
                    track, curve = self.vtk_view.tracks_data[track_name]
                    if curve:
                        tracks_with_curves.append((track, curve))
            
            if tracks_with_curves:
                self.vtk_view.set_group_curves(tracks_with_curves, initial_fit=False)
        
        QMessageBox.information(
            self, 
            "Bewegung generiert", 
            f"{start_info}\n"
            f"Duration: {duration:.1f}s\n"
            f"v-max: {v_max:.1f} mm/s\n"
            f"Ende: {end_pos:.3f}\n"
            f"Strecke: {gefahrene_strecke:.1f} mm"
        )

    
    # ===== RECORDING LOADING =====

    def load_recording(self):
        """Lädt eine Recording-JSON-Datei (unterstützt normale und spline-only Formate)"""
        filepath, _ = QFileDialog.getOpenFileName(self, "Recording laden", "", "JSON (*.json)")
        if not filepath:
            return
        
        try:
            with open(filepath, encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            QMessageBox.critical(self, "Fehler", f"Datei konnte nicht geladen werden:\n{e}")
            return
        
        # 🔥 PRÜFEN OB SPLINE-ONLY FORMAT
        is_spline_only = data.get("format") == "spline_only"
        
        if is_spline_only:
            print("📦 Spline-Only Format erkannt")
            self._load_spline_only(data)
        else:
            print("📦 Normales Recording-Format erkannt")
            self._load_normal_recording(data)
        
        # === GEMEINSAME INITIALISIERUNG NACH LADEN ===
        self._finalize_recording_load()

    # !!! WICHTIG: Diese Methoden müssen AUSSERHALB von load_recording sein !!!
    # Also auf der gleichen Einrückungsebene wie load_recording

    def _load_normal_recording(self, data):
        """Lädt ein normales Recording mit Samples - VERWENDET SETUP FÜR GRUPPEN!"""
        tracks = []
        curves = {}
        self.tracks_data = {}
        self.curves_data = {}
        session_duration = data.get("duration", 0.0)
        
        # 🔥 WICHTIG: Track->Gruppe Mapping aus dem Setup erstellen
        track_to_group = {}
        if hasattr(self, 'current_setup') and self.current_setup:
            for group in self.current_setup["groups"]:
                for track in group["tracks"]:
                    track_to_group[track["name"]] = group["name"]
            print(f"📁 Track->Gruppe Mapping aus Setup:")
            for track, group in track_to_group.items():
                print(f"   {track} -> {group}")
        
        for name, track_data in data.get("tracks", {}).items():
            samples = track_data.get("samples", [])
            if not samples:
                continue
            
            times = np.array([s["t"] for s in samples], dtype=float)
            pedals = np.array([s["pedal"] for s in samples], dtype=float)
            
            # NEUE PARAMETER
            track_type = track_data.get("track_type", "motion")
            max_speed = track_data.get("max_speed", 100.0)
            curve_path = track_data.get("curve_path", "")
            curve_length = track_data.get("curve_length", 0.0)
            
            track = EditableTrack(name, times, pedals)
            track.t_min = float(times.min()) if len(times) > 0 else 0.0
            track.t_max = float(times.max()) if len(times) > 0 else 1.0
            track.pedals = pedals.tolist()
            track.duration = session_duration
            track.max_speed = max_speed
            track.curve_length = curve_length
            track.curve_path = curve_path
            track.track_type = track_type
            
            # 🔥 WICHTIG: Gruppe aus Setup-Mapping speichern
            track.group_name = track_to_group.get(name, "Andere")
            print(f"📌 Track {name} -> Gruppe {track.group_name}")
            
            # PARAM-TRACK SPEZIFISCHE PARAMETER
            if track_type in ["empty", "param"]:
                track.param_name = track_data.get("param_name", "")
                track.param_unit = track_data.get("param_unit", "")
                track.param_min = track_data.get("param_min", 0.0)
                track.param_max = track_data.get("param_max", 1.0)
                print(f"   📊 Param Track: {track.param_name} ({track.param_min}-{track.param_max} {track.param_unit})")
            
            # start_t aus dem ERSTEN Sample
            if len(times) > 0:
                track.start_t = times[0]
                print(f"   start_t = {track.start_t:.4f}")
            else:
                track.start_t = 0.0
            
            track.current_times = times
            tracks.append(track)
            self.tracks_data[name] = track
            
            # SPLINE-PUNKTE VORLÄUFIG SPEICHERN
            if "spline_points" in track_data:
                track.saved_spline_points = [
                    (p["t"], p["pedal"]) for p in track_data["spline_points"]
                ]
                print(f"   📍 {len(track.saved_spline_points)} Spline-Punkte")
            
            # EDITOR-MODE SPEICHERN
            if "editor_mode" in track_data:
                track.saved_editor_mode = track_data["editor_mode"]
            
            # Kurve laden (nur für Motion Tracks)
            if track_type == "motion" and curve_path and os.path.exists(curve_path):
                try:
                    from tsde_engine.curves.curve_loader import load_csv_curve
                    curve = load_csv_curve(curve_path, 0.01)
                    curve.source_path = curve_path
                    curves[name] = curve
                    self.curves_data[name] = curve
                    print(f"📊 Kurve geladen: {name}")
                except Exception as e:
                    print(f"⚠️ Fehler beim Laden der Kurve: {e}")
                    curves[name] = None
                    self.curves_data[name] = None
            else:
                curves[name] = None
                self.curves_data[name] = None
        
        self.session = EditableSession(data.get("name", "Unbenannt"), tracks)
        self.duration = session_duration
        self.timeline.set_duration(session_duration)
        self.vtk_view.set_duration(session_duration)  # <-- 🔥 WICHTIG
        self.tracks = tracks
        
        # Tracks bauen - JETZT mit den echten Gruppen!
        self._build_tracks_from_setup(tracks, curves)
        
        # Spline-Punkte wiederherstellen
        for name, track in self.tracks_data.items():
            if hasattr(track, 'pedal_graph') and track.pedal_graph is not None:
                pg = track.pedal_graph
                if hasattr(track, 'saved_spline_points') and track.saved_spline_points:
                    pg.spline_points = track.saved_spline_points.copy()
                    pg.apply_spline()
                    if hasattr(track, 'saved_editor_mode'):
                        if track.saved_editor_mode == "SPLINE":
                            pg.set_mode(PedalMode.SPLINE)
                        else:
                            pg.set_mode(PedalMode.SAMPLES)
                    else:
                        pg.set_mode(PedalMode.SPLINE)
                    delattr(track, 'saved_spline_points')
                    if hasattr(track, 'saved_editor_mode'):
                        delattr(track, 'saved_editor_mode')

    def _load_spline_only(self, data):
        """Lädt ein spline-only Format"""
        tracks = []
        curves = {}
        self.tracks_data = {}
        self.curves_data = {}
        session_duration = data.get("duration", 0.0)
        
        for name, track_data in data.get("tracks", {}).items():
            # Für spline-only: Erstelle leere Pedal-Daten
            times = np.linspace(0, 1, 100)  # Dummy
            pedals = np.zeros(100)  # Dummy
            
            # 🔥 NEUE PARAMETER: track_type, max_speed, etc.
            track_type = track_data.get("track_type", "motion")
            max_speed = track_data.get("max_speed", 100.0)
            curve_path = track_data.get("curve_path", "")
            curve_length = track_data.get("curve_length", 0.0)
            
            track = EditableTrack(name, times, pedals)
            track.duration = session_duration
            track.max_speed = max_speed
            track.curve_path = curve_path
            track.curve_length = curve_length
            track.start_t = 0.0
            track.track_type = track_type  # 🔥 NEU
            
            # 🔥 PARAM-TRACK SPEZIFISCHE PARAMETER
            if track_type in ["empty", "param"]:
                track.param_name = track_data.get("param_name", "")
                track.param_unit = track_data.get("param_unit", "")
                track.param_min = track_data.get("param_min", 0.0)
                track.param_max = track_data.get("param_max", 1.0)
                print(f"   📊 Param Track: {track.param_name} ({track.param_min}-{track.param_max} {track.param_unit})")
            
            # WICHTIG: vmax_value für PedalGraph
            if "vmax_value" in track_data:
                track.saved_vmax = track_data["vmax_value"]
            
            # Spline-Punkte speichern
            if "spline_points" in track_data:
                track.saved_spline_points = [
                    (p["t"], p["pedal"]) for p in track_data["spline_points"]
                ]
                print(f"   📍 {name}: {len(track.saved_spline_points)} Spline-Punkte")
            
            # Modus speichern
            if "mode" in track_data:
                track.saved_mode = track_data["mode"]
            
            track.current_times = times
            tracks.append(track)
            self.tracks_data[name] = track
            
            # Kurve laden (nur für Motion Tracks)
            if track_type == "motion" and curve_path and os.path.exists(curve_path):
                try:
                    from tsde_engine.curves.curve_loader import load_csv_curve
                    curve = load_csv_curve(curve_path, 0.01)
                    curve.source_path = curve_path
                    curves[name] = curve
                    self.curves_data[name] = curve
                    print(f"📊 Kurve geladen: {name} -> {curve_path}")
                except Exception as e:
                    print(f"⚠️ Fehler beim Laden der Kurve {curve_path}: {e}")
                    curves[name] = None
                    self.curves_data[name] = None
            else:
                curves[name] = None
                self.curves_data[name] = None
        
        self.session = EditableSession(data.get("name", "Unbenannt"), tracks)
        self.duration = session_duration
        self.timeline.set_duration(session_duration)
        self.vtk_view.set_duration(session_duration) 
        self.tracks = tracks
        
        # Tracks bauen (hier werden die PedalGraphs erstellt)
        self._build_tracks(tracks, curves)
        
        # 🔥 NACH DEM BAUEN: Spline-Punkte in PedalGraph setzen
        for name, track in self.tracks_data.items():
            if hasattr(track, 'pedal_graph') and track.pedal_graph is not None:
                pg = track.pedal_graph
                
                # v-max setzen
                if hasattr(track, 'saved_vmax'):
                    pg.vmax_value = track.saved_vmax
                    pg.vmax_spin.setValue(track.saved_vmax)
                
                # Spline-Punkte setzen
                if hasattr(track, 'saved_spline_points') and track.saved_spline_points:
                    pg.spline_points = track.saved_spline_points.copy()
                    pg.apply_spline()
                    
                    # Modus setzen
                    mode = getattr(track, 'saved_mode', 'SPLINE')
                    if mode == "SPLINE":
                        pg.set_mode(PedalMode.SPLINE)
                    else:
                        pg.set_mode(PedalMode.SAMPLES)
                    
                    print(f"🔄 Spline für {name} wiederhergestellt: {len(pg.spline_points)} Punkte")
                    
                    # Aufräumen
                    if hasattr(track, 'saved_spline_points'):
                        delattr(track, 'saved_spline_points')
                    if hasattr(track, 'saved_mode'):
                        delattr(track, 'saved_mode')
                    if hasattr(track, 'saved_vmax'):
                        delattr(track, 'saved_vmax')

    def _finalize_recording_load(self):
        """Gemeinsame Initialisierung nach dem Laden"""
        track_names = list(self.tracks_data.keys())
        
        # 🔥 Track->Gruppe Mapping aus den Track-Objekten
        track_to_group = {}
        for track_name, track in self.tracks_data.items():
            if hasattr(track, 'group_name'):
                track_to_group[track_name] = track.group_name
                print(f"   Mapping: {track_name} -> {track.group_name}")
        
        # 🔥 WICHTIG: Echte Gruppennamen aus dem Setup!
        if hasattr(self, 'current_setup') and self.current_setup:
            group_names = [g["name"] for g in self.current_setup["groups"]]
            print(f"📁 Echte Gruppen aus Setup: {group_names}")
        else:
            # Fallback: aus Track-Namen (wenn kein Setup)
            group_names = list(set(track_to_group.values()))
        
        self.group_names = group_names
        
        # VTK View mit Daten und Mapping füttern
        tracks_data_for_vtk = {}
        for track in self.tracks:
            tracks_data_for_vtk[track.name] = (track, self.curves_data.get(track.name))
        
        # 🔥 WICHTIG: track_to_group übergeben!
        self.vtk_view.set_tracks_data(tracks_data_for_vtk, track_to_group)
        self.vtk_view.update_track_names(track_names, track_to_group)
        self.vtk_view.update_group_names(group_names)  # Hier die echten Gruppennamen!
        
        # Kamera-Rig Overlay aktualisieren
        if hasattr(self, 'rig_content') and self.rig_content:
            for i in range(self.rig_content.layout().count()):
                item = self.rig_content.layout().itemAt(i)
                if item.widget() and hasattr(item.widget(), 'update_tracks'):
                    item.widget().update_tracks(track_names)
                    break
        
        # Ersten Track als Standard setzen
        if track_names:
            first_track = track_names[0]
            self.last_track_name = first_track
            self.current_vtk_track = self.tracks_data.get(first_track)
            self.vtk_view.set_curve(self.curves_data.get(first_track), self.current_vtk_track)

            # 🔥 WICHTIG: Duration nochmal sicherheitshalber setzen
            self.vtk_view.set_duration(self.duration)
            
            # 🔥 WICHTIG: Erste echte Gruppe als Standard!
            if group_names and len(group_names) > 0:
                self.last_group_name = group_names[0]
                print(f"📌 Erste Gruppe als Standard: {self.last_group_name}")
        
        print(f"✅ Recording geladen: {len(self.tracks)} Tracks")
        
        # In editor_panel.py - beim Erstellen der TrackLanes

    def _build_tracks_from_setup(self, tracks, curves):
        """Baut die Tracks genau nach der Setup-Gruppenstruktur"""
        self.tracks_container.clear()
        
        if not hasattr(self, 'current_setup') or not self.current_setup:
            print("⚠️ Kein Setup geladen - kann Gruppen nicht korrekt aufbauen!")
            return
        
        print(f"\n📁 Baue Tracks nach Setup-Struktur:")
        
        # Gehe die Gruppen in der richtigen Reihenfolge durch
        for group_data in self.current_setup["groups"]:
            group_name = group_data["name"]
            print(f"\n   Gruppe: {group_name}")
            
            group_widget = self.tracks_container.add_group(group_name)
            
            # Finde alle Tracks die zu dieser Gruppe gehören
            for track_data in group_data["tracks"]:
                track_name = track_data["name"]
                
                # Suche den passenden Track in der geladenen Liste
                track = next((t for t in tracks if t.name == track_name), None)
                if track:
                    curve = curves.get(track_name)
                    lane = TrackLane(track, curve)
                    
                    # 🔥 WICHTIG: Für Motion UND Empty Tracks pedal_graph setzen
                    if hasattr(track, 'track_type') and track.track_type in ["motion", "empty"]:
                        if hasattr(lane, 'graph_group') and lane.graph_group is not None:
                            track.pedal_graph = lane.graph_group.pedal_graph
                            
                            # Für Motion UND Empty Tracks: Spline-Modus und Signale
                            pedal_graph = lane.graph_group.pedal_graph
                            pedal_graph.set_mode(PedalMode.SPLINE)
                            pedal_graph.generate_spline_clicked.connect(pedal_graph.generate_spline)
                            pedal_graph.generate_movement_clicked.connect(
                                lambda checked=False, t=track: self._on_generate_movement(
                                    self.tracks_container.get_track_by_name(t.name)
                                )
                            )
                    else:
                        # Für Param Tracks: Kein pedal_graph
                        print(f"      ⚙️ Param Track {track_name} - keine Bearbeitung")
                    
                    group_widget.add_track(lane)
                    print(f"      ✅ {track_name} in Gruppe {group_name}")
                else:
                    print(f"      ⚠️ Track {track_name} aus Setup nicht im Recording gefunden")
        
        QTimer.singleShot(80, self._update_content_width)



    def _build_tracks(self, tracks, curves):
        """Baut die Track-Hierarchie aus den geladenen Tracks auf"""
        self.tracks_container.clear()
        
        print(f"📊 Lade {len(tracks)} Tracks:")
        for track in tracks:
            print(f"   - {track.name}")
        
        # Gruppiere Tracks nach dem ersten Teil des Namens
        grouped = {}
        for track in tracks:
            match = re.match(r"([A-Za-z]+)", track.name)
            if match:
                g_name = match.group(1)
            else:
                g_name = "Andere"
            grouped.setdefault(g_name, []).append(track)
        
        print(f"📁 Gruppiert in {len(grouped)} Gruppen:")
        for g_name, g_tracks in grouped.items():
            print(f"   - {g_name}: {len(g_tracks)} Tracks")
        
        for group_name, group_tracks in grouped.items():
            group_widget = self.tracks_container.add_group(group_name)
            
            for track in group_tracks:
                curve = curves.get(track.name)
                if curve is None:
                    print(f"⚠️ Keine Kurve für {track.name}")
                
                lane = TrackLane(track, curve)
                
                # 🔥 WICHTIG: PedalGraph im Track speichern!
                track.pedal_graph = lane.graph_group.pedal_graph
                
                # Spline-Modus setzen
                pedal_graph = lane.graph_group.pedal_graph
                pedal_graph.set_mode(PedalMode.SPLINE)
                pedal_graph.generate_spline_clicked.connect(pedal_graph.generate_spline)
                pedal_graph.generate_movement_clicked.connect(
                    lambda checked=False, t=track: self._on_generate_movement(
                        self.tracks_container.get_track_by_name(t.name)
                    )
                )
                
                group_widget.add_track(lane)
                print(f"   ✅ Track {track.name} hinzugefügt zu Gruppe {group_name}")
        
        QTimer.singleShot(80, self._update_content_width)