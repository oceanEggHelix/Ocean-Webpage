# tests/test_frame_animator_only.py

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QHBoxLayout
from PySide6.QtCore import QTimer
import sys
import numpy as np

from tsde_engine.editor_gui.widgets.vtk.vtk_view import VTK3DView
from tsde_engine.editor_gui.widgets.vtk.fullscreen_window import FullscreenVTKWindow
from tsde_engine.editor_gui.theme import Theme

class SimpleTestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("FrameAnimator Test")
        self.setGeometry(100, 100, 1200, 900)
        
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        
        # VTK View
        self.vtk_view = VTK3DView()
        layout.addWidget(self.vtk_view)
        
        # Control Panel
        control_layout = QHBoxLayout()
        
        self.test_btn = QPushButton("🎬 FrameAnimator Start")
        self.test_btn.clicked.connect(self.start_test)
        control_layout.addWidget(self.test_btn)
        
        self.stop_btn = QPushButton("⏹️ Stop")
        self.stop_btn.clicked.connect(self.stop_test)
        control_layout.addWidget(self.stop_btn)
        
        # ECHTER Vollbild-Button (nicht simuliert!)
        self.fullscreen_btn = QPushButton("🖥️ Vollbild öffnen")
        self.fullscreen_btn.clicked.connect(self.vtk_view.toggle_fullscreen)
        self.fullscreen_btn.setStyleSheet("background-color: purple; color: white;")
        control_layout.addWidget(self.fullscreen_btn)
        
        layout.addLayout(control_layout)
        
        # Dummy-Daten
        self.setup_test_data()
    
    def setup_test_data(self):
        class DummyTrack:
            def __init__(self, name):
                self.name = name
                self.pedals = [0.5] * 2000
                self.duration = 31.0
                self.max_speed = 100.0
                self.start_t = 0.0
        
        class DummyCurve:
            @property
            def length_total(self):
                return 100.0
            def evaluate(self, t):
                return type('Point', (), {'x': t * 100, 'y': 0, 'z': 0})()
        
        self.track1 = DummyTrack("Track1")
        self.track2 = DummyTrack("Track2")
        self.curve = DummyCurve()
        
        self.vtk_view.tracks_data = {
            "Track1": (self.track1, self.curve),
            "Track2": (self.track2, self.curve)
        }
        
        self.vtk_view.update_track_names(["Track1", "Track2"])
        self.vtk_view.update_group_names(["Test"])
        
        tracks_with_curves = [
            (self.track1, self.curve),
            (self.track2, self.curve)
        ]
        self.vtk_view.set_group_curves(tracks_with_curves)
        print("✅ Test-Daten geladen, Gruppenmodus aktiv")
    
    def start_test(self):
        self.vtk_view.frame_animator.start()
    
    def stop_test(self):
        self.vtk_view.frame_animator.stop()

def test():
    app = QApplication(sys.argv)
    window = SimpleTestWindow()
    window.show()
    print("\n" + "="*50)
    print("FrameAnimator Test mit ECHTEM Vollbild")
    print("="*50)
    print("1. 'FrameAnimator Start' - Animation starten")
    print("2. 'Vollbild öffnen' - Echtes Vollbild öffnen")
    print("3. Im Vollbild: Play/Pause/Stop testen")
    print("4. Beobachte ob die Animation reagiert!")
    print("="*50 + "\n")
    sys.exit(app.exec())

if __name__ == "__main__":
    test()