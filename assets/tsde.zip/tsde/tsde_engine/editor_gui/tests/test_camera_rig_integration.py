"""
Erweiterter Test für Kamera-Rig Integration
Lädt das Overlay extern wie im Editor und testet die Verbindungen
"""

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QHBoxLayout, QPushButton, QFrame, QLabel
from PySide6.QtCore import Qt, QTimer
import sys
import numpy as np

from tsde_engine.editor_gui.widgets.vtk.vtk_view import VTK3DView
from tsde_engine.editor_gui.widgets.vtk.overlays.camera_rig_overlay import CameraRigOverlay
from tsde_engine.editor_gui.theme import Theme

class DummyCurveA:
    """Track_A: Exzentrischer Kreis"""
    def __init__(self):
        self.length_total = 439.82  # Ungefähre Länge der Ellipse
    
    def evaluate(self, t):
        import math
        radius_x = 70
        radius_y = 30
        angle = t * 2 * math.pi
        x = radius_x * math.cos(angle)
        y = radius_y * math.sin(angle)
        z = 0
        return type('Point', (), {'x': x, 'y': y, 'z': z})()

class DummyCurveB:
    """Track_B: Vertikale Linie"""
    def __init__(self):
        self.length_total = 100.0  # Länge der Linie
    
    def evaluate(self, t):
        x = 0
        y = 0
        z = t * 100
        return type('Point', (), {'x': x, 'y': y, 'z': z})()

class DummyTrack:
    def __init__(self, name):
        self.name = name
        self.current_times = np.linspace(0, 1, 100)
        
        # WICHTIG: Diese Attribute für FrameAnimator!
        self.duration = 32.0  # 32 Sekunden
        self.max_speed = 100.0  # mm/s
        self.start_t = 0.0
        self.pedals = [0.5] * 100  # Dummy-Pedale
        self.uses_custom_movement = False

class TestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Kamera-Rig Externer Test")
        self.setGeometry(100, 100, 1400, 800)
        
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        
        # === LINKS: VTK View ===
        vtk_container = QFrame()
        vtk_container.setFrameStyle(QFrame.Box)
        vtk_container.setMinimumWidth(800)
        vtk_layout = QVBoxLayout(vtk_container)
        
        self.vtk_view = VTK3DView()
        vtk_layout.addWidget(self.vtk_view)
        main_layout.addWidget(vtk_container)
        
        # === RECHTS: Kamera-Rig Overlay (extern) ===
        rig_container = QFrame()
        rig_container.setFrameStyle(QFrame.Box)
        rig_container.setMaximumWidth(350)
        rig_container.setMinimumWidth(320)
        rig_container.setStyleSheet(f"""
            QFrame {{
                background: {Theme.rgba('bg_secondary', 50)};
                border: 2px solid {Theme.rgba('accent_blue')};
                border-radius: 10px;
                margin: 5px;
            }}
        """)
        
        rig_layout = QVBoxLayout(rig_container)
        rig_layout.setContentsMargins(10, 10, 10, 10)
        rig_layout.setSpacing(10)
        
        # Titel
        title = QLabel("🎥 Kamera-Rig (extern)")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgb('accent_blue')};
                font-size: 14pt;
                font-weight: bold;
                padding: 10px;
                background: {Theme.rgba('bg_primary', 100)};
                border-radius: 5px;
            }}
        """)
        rig_layout.addWidget(title)
        
        # Kamera-Rig Overlay - WICHTIG: show() aufrufen!
        self.rig_overlay = CameraRigOverlay()
        self.rig_overlay.show()  # <-- Overlay sichtbar machen
        rig_layout.addWidget(self.rig_overlay)
        
        # Debug-Info
        self.debug_label = QLabel("Debug: Warte auf Aktionen...")
        self.debug_label.setWordWrap(True)
        self.debug_label.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgb('text_primary')};
                font-size: 9pt;
                padding: 10px;
                background: {Theme.rgba('bg_primary', 80)};
                border: 1px solid {Theme.rgba('accent_blue')};
                border-radius: 3px;
                margin-top: 10px;
            }}
        """)
        rig_layout.addWidget(self.debug_label)
        
        # Test-Buttons
        btn_layout = QHBoxLayout()
        
        test_btn1 = QPushButton("🔄 Mode umschalten")
        test_btn1.clicked.connect(self.toggle_mode)
        test_btn1.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_blue')};
                color: white;
                border: none;
                border-radius: 3px;
                padding: 8px;
                font-size: 9pt;
            }}
        """)
        btn_layout.addWidget(test_btn1)
        
        test_btn2 = QPushButton("🎯 Reset")
        test_btn2.clicked.connect(self.reset_camera)
        test_btn2.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_red')};
                color: white;
                border: none;
                border-radius: 3px;
                padding: 8px;
                font-size: 9pt;
            }}
        """)
        btn_layout.addWidget(test_btn2)
        
        rig_layout.addLayout(btn_layout)
        rig_layout.addStretch()
        
        main_layout.addWidget(rig_container)
        
        # Animation Timer
        from PySide6.QtCore import QTimer
        self.anim_timer = QTimer()
        self.anim_timer.setInterval(50)
        self.anim_timer.timeout.connect(self.animate)
        self.anim_pos = 0.0
        self.anim_running = False
        
        # Dummy-Daten
        self.setup_test_data()
        
        # Verbindungen herstellen
        self.connect_rig_to_vtk()
        
        # Automatisch Gruppenmodus laden
        self.load_test_group()
    
    def setup_test_data(self):
        """Erstellt Test-Tracks und Kurven"""
        self.track1 = DummyTrack("Track_A (Kreis)")
        self.track2 = DummyTrack("Track_B (Linie)")
        self.curve1 = DummyCurveA()
        self.curve2 = DummyCurveB()
        
        # Tracks für VTK registrieren
        self.vtk_view.tracks_data = {
            "Track_A (Kreis)": (self.track1, self.curve1),
            "Track_B (Linie)": (self.track2, self.curve2)
        }
        
        # Track-Namen für Overlay
        track_names = ["Track_A (Kreis)", "Track_B (Linie)"]
        group_names = ["Test"]
        
        self.vtk_view.update_track_names(track_names)
        self.vtk_view.update_group_names(group_names)
        
        # Overlay mit Track-Namen füttern
        self.rig_overlay.update_tracks(track_names)
        
        print("✅ Test-Daten geladen")
    
    def connect_rig_to_vtk(self):
        """Verbindet das externe Overlay mit dem VTK"""
        # Tracks-Changed
        self.rig_overlay.tracks_changed.connect(self.on_rig_tracks_changed)
        
        # Toggle
        self.rig_overlay.toggled.connect(self.on_rig_toggled)
        
        # Parameter
        self.rig_overlay.distance_changed.connect(
            lambda d: self.vtk_view.camera_rig.set_params(distance=d) if self.vtk_view.camera_rig else None
        )
        self.rig_overlay.height_changed.connect(
            lambda h: self.vtk_view.camera_rig.set_params(height=h) if self.vtk_view.camera_rig else None
        )
        self.rig_overlay.focal_length_changed.connect(
            lambda f: self.vtk_view.camera_rig.set_focal_length(f) if self.vtk_view.camera_rig else None
        )
        self.rig_overlay.sensor_width_changed.connect(
            lambda s: self.vtk_view.camera_rig.set_sensor_width(s) if self.vtk_view.camera_rig else None
        )
        
        print("🔗 Overlay mit VTK verbunden")
        self.update_debug("Bereit - Overlay verbunden")
    
    def on_rig_tracks_changed(self, cam_track, target_track):
        """Track-Auswahl geändert"""
        self.update_debug(f"Tracks: Kamera={cam_track}, Ziel={target_track}")
        
        if hasattr(self.vtk_view, '_on_camera_rig_tracks_changed'):
            self.vtk_view._on_camera_rig_tracks_changed(cam_track, target_track)
    
    def on_rig_toggled(self, enabled):
        """Rig ein/aus"""
        status = "AKTIV" if enabled else "INAKTIV"
        self.update_debug(f"Rig {status}")
        
        if hasattr(self.vtk_view, '_on_camera_rig_toggled'):
            self.vtk_view._on_camera_rig_toggled(enabled)
    
    def toggle_mode(self):
        """Schaltet zwischen Track/Group Mode um"""
        if hasattr(self.vtk_view, '_is_track_mode'):
            current = self.vtk_view._is_track_mode
            new_mode = not current
            mode_str = "Group" if new_mode else "Track"
            self.update_debug(f"Mode: {mode_str}")
            
            # Overlay Modus setzen
            self.rig_overlay.set_mode(not new_mode)  # Overlay will group_mode=True bei Group
    
    def reset_camera(self):
        """Setzt Kamera zurück"""
        self.vtk_view.auto_fit_view()
        self.update_debug("Kamera zurückgesetzt")
    
    def update_debug(self, message):
        """Debug-Label aktualisieren"""
        self.debug_label.setText(f"🔍 {message}")
        print(f"🔍 {message}")
    
    def load_test_group(self):
        """Lädt eine Gruppe mit 2 Tracks"""
        tracks_with_curves = [
            (self.track1, self.curve1),
            (self.track2, self.curve2)
        ]
        self.vtk_view.set_group_curves(tracks_with_curves)
        print("✅ Gruppenmodus aktiv")
        
        # Overlay in Gruppenmodus setzen
        self.rig_overlay.set_mode(True)
        
        self.update_debug("Gruppenmodus geladen - Overlay aktiv")
        
        # Animation starten
        self.anim_running = True
        self.anim_timer.start()
        self.update_debug("Animation gestartet")
    
    def animate(self):
        """Animiert die Marker"""
        if not self.anim_running:
            return
            
        self.anim_pos += 0.01
        if self.anim_pos > 1.0:
            self.anim_pos = 0.0
        
        self.vtk_view.set_marker(self.anim_pos)

def test():
    app = QApplication(sys.argv)
    
    window = TestWindow()
    window.show()
    
    print("\n" + "="*70)
    print("🎥 KAMERA-RIG EXTERNER TEST")
    print("="*70)
    print("✅ VTK View mit Gruppe geladen")
    print("✅ Kamera-Rig Overlay extern rechts")
    print("")
    print("Jetzt testen:")
    print("1. Wähle 'Kamera folgt: Track_A (Kreis)'")
    print("2. Wähle 'Blick auf: Track_B (Linie)'")
    print("3. Klicke '🔴 Aktivieren'")
    print("4. Ändere Abstand/Höhe")
    print("5. Beobachte Kamera-Bewegung")
    print("")
    print("Debug-Info wird im rechten Panel angezeigt")
    print("="*70 + "\n")
    
    sys.exit(app.exec())

if __name__ == "__main__":
    test()