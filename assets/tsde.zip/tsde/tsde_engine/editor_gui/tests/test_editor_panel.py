#!/usr/bin/env python3
# editor_gui/tests/test_editor_panel.py

import sys
import os

# Projektroot zum Pfad hinzufügen
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PySide6.QtCore import Qt

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.editor_panel import EditorPanel


class TestDummyCurve:
    """Dummy-Kurve für Testzwecke"""
    
    def __init__(self):
        self.length_total = 1000.0
    
    def evaluate(self, t):
        """Gibt eine 3D-Punkt zurück (Helix-ähnlich)"""
        import math
        x = 100 * math.cos(t * 4 * math.pi)
        y = 100 * math.sin(t * 4 * math.pi)
        z = 200 * t - 100
        return type('Point', (), {'x': x, 'y': y, 'z': z})()


class TestWindow(QMainWindow):
    """Testfenster für EditorPanel"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Editor Panel Test")
        self.setGeometry(100, 100, 1200, 800)
        
        # Zentrales Widget
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Editor Panel erstellen
        print("🚀 Erstelle Editor Panel...")
        self.editor = EditorPanel()
        layout.addWidget(self.editor)
        
        # Dummy-Kurve für VTK laden
        print("📊 Lade Testkurve in VTK...")
        self.editor.vtk_view.set_curve(TestDummyCurve())
        
        # Overlay mit Track-Namen füttern
        self.editor.vtk_view.overlay.update_tracks(["Balu1", "Balu2", "Jana1"])
        
        # Timeline mit Dummy-Daten
        self.editor.timeline.set_duration(124.5)  # 2 Minuten 4.5 Sekunden
        
        # Signals verbinden für Debug
        self.editor.timeline.position_changed.connect(self.on_position)
        self.editor.timeline.zoom_changed.connect(self.on_zoom)
        
        print("✅ Editor Panel bereit!")
        print("   - VTK View mit Testkurve")
        print("   - Timeline mit Dauer 124.5s")
        print("   - Overlay mit Track-Auswahl")
        print("   - Play/Stop sollten funktionieren")
    
    def on_position(self, pos):
        print(f"📌 Position: {pos:.3f}")
    
    def on_zoom(self, start, end):
        print(f"🔍 Zoom: {start:.2f} - {end:.2f} ({int((end-start)*100)}%)")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Dunkles Theme
    Theme.MODE = "dark"
    
    window = TestWindow()
    window.show()
    
    sys.exit(app.exec())