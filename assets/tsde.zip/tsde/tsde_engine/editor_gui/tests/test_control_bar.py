#!/usr/bin/env python3
# editor_gui/tests/test_control_bar.py

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PySide6.QtCore import Qt

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.widgets.controls.control_bar import ControlBar

class TestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Control Bar Test")
        self.setGeometry(100, 100, 800, 150)
        
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Control Bar erstellen
        print("🚀 Erstelle Control Bar...")
        self.control = ControlBar()
        layout.addWidget(self.control, alignment=Qt.AlignTop)
        
        # Test-Daten
        self.control.update_tracks(["Balu1", "Balu2", "Jana1", "Jana2"])
        
        # Signals verbinden
        self.control.track_changed.connect(self.on_track)
        self.control.generate_spline_clicked.connect(self.on_spline)
        self.control.generate_movement_clicked.connect(self.on_movement)
        
        print("✅ Control Bar bereit!")
    
    def on_track(self, track):
        print(f"🎯 Track: {track}")
    
    def on_spline(self, points):
        print(f"📐 Spline mit {points} Punkten")
    
    def on_movement(self):
        print("🏃 Bewegung generieren")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    Theme.MODE = "dark"
    window = TestWindow()
    window.show()
    sys.exit(app.exec())