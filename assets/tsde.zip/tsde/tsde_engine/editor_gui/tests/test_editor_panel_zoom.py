# editor_gui/tests/test_editor_panel_zoom.py

import sys
import os
import math
import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QHBoxLayout, QPushButton, QLabel
from PySide6.QtCore import Qt, QTimer

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.editor_panel import EditorPanel
from tsde_engine.editor_gui.widgets.tracks.tracks_container import TracksContainer  # WICHTIG!
from tsde_engine.editor_gui.widgets.tracks.track_lane import TrackLane  # WICHTIG!


class DummyTrack:
    def __init__(self, name):
        self.name = name
        self.pedals = [math.sin(i * 0.1) * 0.8 for i in range(200)]
        self.current_times = np.linspace(0, 1, 200)
        self.max_speed = 100.0


class DummyCurve:
    def __init__(self):
        self.length_total = 1000.0
    
    def evaluate(self, t):
        x = 100 * math.cos(t * 4 * math.pi)
        y = 100 * math.sin(t * 4 * math.pi)
        z = 200 * t - 100
        return type('Point', (), {'x': x, 'y': y, 'z': z})()


class TestZoomWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Editor Panel Zoom Test")
        self.setGeometry(100, 100, 1200, 800)
        
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Editor Panel
        print("🚀 Erstelle Editor Panel...")
        self.editor = EditorPanel()
        layout.addWidget(self.editor)
        
        # === TRACKS ÜBER DEN TRACKSCONTAINER EINFÜGEN (wie im echten Editor) ===
        # Statt direkt ins Layout, erstelle einen TracksContainer
        self.tracks_container = TracksContainer()
        
        # Gruppe und Track erstellen
        group = self.tracks_container.add_group("Test Gruppe")
        
        self.track_lane = TrackLane(DummyTrack("TestTrack"), DummyCurve())
        group.add_track(self.track_lane)
        
        # TracksContainer ins EditorPanel einfügen (nach Timeline)
        editor_layout = self.editor.layout()
        if editor_layout:
            editor_layout.addWidget(self.tracks_container)
        
        # === Zoom Test Buttons ===
        zoom_container = QWidget()
        zoom_layout = QHBoxLayout(zoom_container)
        
        self.btn_zoom_100 = QPushButton("100%")
        self.btn_zoom_100.clicked.connect(lambda: self.editor.timeline.set_zoom(0.0, 1.0))
        zoom_layout.addWidget(self.btn_zoom_100)
        
        self.btn_zoom_50 = QPushButton("50% (0.25-0.75)")
        self.btn_zoom_50.clicked.connect(lambda: self.editor.timeline.set_zoom(0.25, 0.75))
        zoom_layout.addWidget(self.btn_zoom_50)
        
        self.btn_zoom_25 = QPushButton("25% (0.4-0.65)")
        self.btn_zoom_25.clicked.connect(lambda: self.editor.timeline.set_zoom(0.4, 0.65))
        zoom_layout.addWidget(self.btn_zoom_25)
        
        self.btn_zoom_left = QPushButton("Links (0.0-0.3)")
        self.btn_zoom_left.clicked.connect(lambda: self.editor.timeline.set_zoom(0.0, 0.3))
        zoom_layout.addWidget(self.btn_zoom_left)
        
        self.btn_zoom_right = QPushButton("Rechts (0.7-1.0)")
        self.btn_zoom_right.clicked.connect(lambda: self.editor.timeline.set_zoom(0.7, 1.0))
        zoom_layout.addWidget(self.btn_zoom_right)
        
        self.zoom_label = QLabel("Zoom: 0.00 - 1.00 (100%)")
        self.zoom_label.setStyleSheet(f"color: {Theme.rgb('text_primary')}; padding: 5px;")
        zoom_layout.addWidget(self.zoom_label)
        
        zoom_layout.addStretch()
        if editor_layout:
            editor_layout.addWidget(zoom_container)
        
        # === Playback Control ===
        play_container = QWidget()
        play_layout = QHBoxLayout(play_container)
        
        self.btn_play = QPushButton("▶ Play")
        self.btn_play.clicked.connect(self.toggle_play)
        play_layout.addWidget(self.btn_play)
        
        self.btn_stop = QPushButton("■ Stop")
        self.btn_stop.clicked.connect(self.stop_play)
        play_layout.addWidget(self.btn_stop)
        
        self.pos_label = QLabel("Position: 0.00")
        self.pos_label.setStyleSheet(f"color: {Theme.rgb('text_primary')}; padding: 5px;")
        play_layout.addWidget(self.pos_label)
        
        play_layout.addStretch()
        if editor_layout:
            editor_layout.addWidget(play_container)
        
        # Timer für Playback
        self.timer = QTimer()
        self.timer.setInterval(50)
        self.timer.timeout.connect(self.update_marker)
        self.playing = False
        
        # Signale verbinden
        self.editor.timeline.position_changed.connect(self.on_position_changed)
        self.editor.timeline.zoom_changed.connect(self.on_zoom_changed)
        
        # Initiale Breite setzen
        self.update_content_width()
        
        print("✅ Editor Panel Zoom Test bereit!")
        print("   - Tracks jetzt über TracksContainer (wie im echten Editor)")
        print("   - Zoom-Buttons verändern Timeline-Zoom")
        print("   - Graphen sollten mitzoomen")
    
    def update_content_width(self):
        """Setzt die Breite basierend auf der Timeline"""
        if hasattr(self.editor, 'timeline') and self.editor.timeline:
            tracks_width = self.editor.timeline.width() - 40  # etwas Padding
            self.tracks_container.set_content_width(tracks_width)
    
    def resizeEvent(self, event):
        """Bei Größenänderung Breite aktualisieren"""
        super().resizeEvent(event)
        self.update_content_width()
    
    def on_position_changed(self, pos):
        self.pos_label.setText(f"Position: {pos:.2f}")
        self.track_lane.set_marker(pos)
    
    def on_zoom_changed(self, start, end):
        percent = int((end - start) * 100)
        self.zoom_label.setText(f"Zoom: {start:.2f} - {end:.2f} ({percent}%)")
        self.track_lane.set_zoom(start, end)
    
    def toggle_play(self):
        if self.playing:
            self.timer.stop()
            self.btn_play.setText("▶ Play")
        else:
            self.timer.start()
            self.btn_play.setText("⏸ Pause")
        self.playing = not self.playing
    
    def stop_play(self):
        self.timer.stop()
        self.playing = False
        self.btn_play.setText("▶ Play")
        self.editor.timeline.set_position(0.0)
    
    def update_marker(self):
        current = self.editor.timeline.playback.position
        new_pos = current + 0.01
        if new_pos > 1.0:
            new_pos = 0.0
        self.editor.timeline.set_position(new_pos)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    Theme.MODE = "dark"
    window = TestZoomWindow()
    window.show()
    sys.exit(app.exec())