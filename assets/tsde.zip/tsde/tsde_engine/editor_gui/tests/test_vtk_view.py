#!/usr/bin/env python3
# editor_gui/tests/test_vtk_view.py

import sys
import os
import math

# Projektroot zum Pfad hinzufügen
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PySide6.QtCore import Qt

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.widgets.vtk.vtk_view import VTK3DView


class TestDummyCurve:
    """Dummy-Kurve für Testzwecke mit verschiedenen Formen"""
    
    def __init__(self, shape="helix", offset=0):
        self.length_total = 1000.0
        self.shape = shape
        self.offset = offset
        self.name = f"Curve_{shape}_{offset}"
    
    def evaluate(self, t):
        """Gibt einen 3D-Punkt zurück (verschiedene Formen)"""
        if self.shape == "helix":
            x = 100 * math.cos(t * 4 * math.pi + self.offset)
            y = 100 * math.sin(t * 4 * math.pi + self.offset)
            z = 200 * t - 100
        elif self.shape == "circle":
            x = 150 * math.cos(t * 2 * math.pi + self.offset)
            y = 150 * math.sin(t * 2 * math.pi + self.offset)
            z = 0
        elif self.shape == "line":
            x = 300 * t - 150
            y = 50 * math.sin(t * 4 * math.pi + self.offset)
            z = 100 * t - 50
        else:  # spiral
            r = 50 + 100 * t
            x = r * math.cos(t * 6 * math.pi + self.offset)
            y = r * math.sin(t * 6 * math.pi + self.offset)
            z = 200 * t - 100
        
        return type('Point', (), {'x': x, 'y': y, 'z': z})()


class TestDummyTrack:
    """Dummy-Track für Testzwecke"""
    
    def __init__(self, name, curve):
        self.name = name
        self.curve = curve
        self.current_times = [i/100 for i in range(100)]


class TestWindow(QMainWindow):
    """Testfenster für VTK View mit Gruppen-Unterstützung"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("VTK View Test - Overlay Steuerung")
        self.setGeometry(100, 100, 900, 700)
        
        # Zentrales Widget
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)
        
        # === VTK View erstellen ===
        print("🚀 Erstelle VTK View...")
        self.vtk_view = VTK3DView()
        layout.addWidget(self.vtk_view, alignment=Qt.AlignCenter)
        
        # === Testdaten erstellen ===
        self.create_test_data()
        
        # === WICHTIG: Track-Daten an VTK View übergeben ===
        tracks_data = {}
        for group_name, tracks in self.group_tracks.items():
            for track in tracks:
                tracks_data[track.name] = (track, track.curve)
        self.vtk_view.set_tracks_data(tracks_data)
        
        # === Signale verbinden ===
        self.vtk_view.track_selected.connect(self.on_track_selected)
        self.vtk_view.group_selected.connect(self.on_group_selected)
        self.vtk_view.view_mode_changed.connect(self.on_mode_changed)
        
        # === Overlay mit Daten füttern ===
        self.vtk_view.update_track_names(self.all_track_names)
        self.vtk_view.update_group_names(self.all_group_names)
        
        print("✅ Test bereit!")
        print("   - 🎯 Radio 'Track' für Einzelkurven")
        print("   - 👥 Radio 'Gruppe' für Mehrfachkurven")
        print("   - Comboboxen im Overlay zum Auswählen")
    
    def create_test_data(self):
        """Erstellt Testdaten für Tracks und Gruppen"""
        
        # === Gruppe 1: Balu (Helix-Kurven) ===
        self.balu_tracks = []
        self.balu_tracks.append(TestDummyTrack("Balu1", TestDummyCurve("helix", 0)))
        self.balu_tracks.append(TestDummyTrack("Balu2", TestDummyCurve("helix", math.pi/2)))
        self.balu_tracks.append(TestDummyTrack("Balu3", TestDummyCurve("helix", math.pi)))
        
        # === Gruppe 2: Jana (Verschiedene Formen) ===
        self.jana_tracks = []
        self.jana_tracks.append(TestDummyTrack("Jana1", TestDummyCurve("circle", 0)))
        self.jana_tracks.append(TestDummyTrack("Jana2", TestDummyCurve("circle", math.pi)))
        self.jana_tracks.append(TestDummyTrack("Jana3", TestDummyCurve("spiral", 0)))
        
        # === Gruppe 3: Mix (Lineare Kurven) ===
        self.mix_tracks = []
        self.mix_tracks.append(TestDummyTrack("Mix1", TestDummyCurve("line", 0)))
        self.mix_tracks.append(TestDummyTrack("Mix2", TestDummyCurve("line", math.pi/2)))
        
        # Track-Namen für Overlay
        self.all_track_names = [
            "Balu1", "Balu2", "Balu3",
            "Jana1", "Jana2", "Jana3",
            "Mix1", "Mix2"
        ]
        
        # Gruppen-Namen für Overlay
        self.all_group_names = ["Balu", "Jana", "Mix"]
        
        # Mapping für Gruppen-Tracks
        self.group_tracks = {
            "Balu": self.balu_tracks,
            "Jana": self.jana_tracks,
            "Mix": self.mix_tracks
        }
    
    def on_track_selected(self, track_name):
        """Wird aufgerufen wenn Track im Overlay ausgewählt wird"""
        print(f"🎯 Track ausgewählt: {track_name}")
        # Die VTK View lädt den Track automatisch über tracks_data
        # Wir müssen nichts mehr tun!
    
    def on_group_selected(self, group_name):
        """Wird aufgerufen wenn Gruppe im Overlay ausgewählt wird"""
        print(f"👥 Gruppe ausgewählt: {group_name}")
        
        if group_name in self.group_tracks:
            tracks = self.group_tracks[group_name]
            tracks_with_curves = [(track, track.curve) for track in tracks]
            
            self.vtk_view.set_group_curves(tracks_with_curves)
            
            # Kurze Übersicht der geladenen Tracks
            track_names = [t.name for t in tracks]
            print(f"   Geladene Tracks: {', '.join(track_names)}")
    
    def on_mode_changed(self, mode):
        """Wird aufgerufen wenn Anzeigemodus umgeschaltet wird"""
        print(f"🔄 Modus gewechselt zu: {mode}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Dunkles Theme
    Theme.MODE = "dark"
    
    window = TestWindow()
    window.show()
    
    sys.exit(app.exec())