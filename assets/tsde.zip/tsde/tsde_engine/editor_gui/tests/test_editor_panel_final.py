#!/usr/bin/env python3
# editor_gui/tests/test_editor_final.py

import sys
import os
import math
import numpy as np

# Projektroot zum Pfad hinzufügen
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PySide6.QtCore import Qt

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.editor_panel import EditorPanel


class DummyCurve:
    """Dummy-Kurve für Tests"""
    def __init__(self):
        self.length_total = 1000.0
    
    def evaluate(self, t):
        x = 100 * math.cos(t * 4 * math.pi)
        y = 100 * math.sin(t * 4 * math.pi)
        z = 200 * t - 100
        return type('Point', (), {'x': x, 'y': y, 'z': z})()


class TestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("TSDE Editor - Final Test")
        self.setGeometry(100, 100, 1400, 900)
        
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Editor Panel
        print("🚀 Starte TSDE Editor...")
        self.editor = EditorPanel()
        layout.addWidget(self.editor)
        
        # Demo-Daten laden (für Test)
        self.load_demo_data()
        
        print("✅ Editor bereit!")
        print("   - VTK 3D View mit Dummy-Kurve")
        print("   - Timeline mit Play/Stop")
        print("   - Track-Hierarchie mit Gruppen")
        print("   - Spline-Editierung im PedalGraph")
        print("\n📝 Funktionen:")
        print("   • Play/Stop in Timeline")
        print("   • Zoom mit Mausrad oder Alt+Klick")
        print("   • Spline-Punkte verschieben (linksklick)")
        print("   • Spline-Punkte löschen (rechtsklick)")
        print("   • Doppelklick = neuer Punkt")
        print("   • Auge = Track ein-/ausblenden")
        print("   • Gruppen auf-/zuklappen")
    
    def load_demo_data(self):
        """Lädt Demo-Daten für den Test"""
        # Dummy-Kurve für VTK
        self.editor.vtk_view.set_curve(DummyCurve())
        
        # Dummy-Tracks für die Hierarchie
        # Hier müssten echte Tracks erstellt werden
        # Aber da wir keine DummyTrack Klasse im EditorPanel haben,
        # lassen wir das erstmal weg - die Funktionalität wird
        # später mit echten Recording-Daten getestet


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Dunkles Theme
    Theme.MODE = "dark"
    
    window = TestWindow()
    window.show()
    
    sys.exit(app.exec())