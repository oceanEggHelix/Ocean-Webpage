#!/usr/bin/env python3
# editor_gui/tests/test_timeline.py

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PySide6.QtCore import Qt

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.widgets.timeline.timeline_widget import TimelineWidget

class TestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Timeline Test")
        self.setGeometry(100, 100, 800, 200)
        
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Timeline erstellen
        print("🚀 Erstelle Timeline...")
        self.timeline = TimelineWidget()
        layout.addWidget(self.timeline)
        
        # Test-Daten
        self.timeline.set_duration(124.5)  # 2 Minuten 4.5 Sekunden
        
        # Signals verbinden
        self.timeline.position_changed.connect(self.on_position)
        self.timeline.zoom_changed.connect(self.on_zoom)
        
        print("✅ Timeline bereit!")
        print("   - Play/Stop sollten funktionieren")
        print("   - Klick in Timeline setzt Position")
        print("   - Alt + Klick zoomt Bereich")
        print("   - Mausrad zoomt")
    
    def on_position(self, pos):
        print(f"📌 Position: {pos:.3f}")
    
    def on_zoom(self, start, end):
        print(f"🔍 Zoom: {start:.2f} - {end:.2f} ({int((end-start)*100)}%)")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    Theme.MODE = "dark"
    window = TestWindow()
    window.show()
    sys.exit(app.exec())