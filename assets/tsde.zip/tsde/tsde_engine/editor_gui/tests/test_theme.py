#!/usr/bin/env python3
# editor_gui/tests/test_theme.py

import sys
import os

# Projektroot zum Pfad hinzufügen
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QWidget, QPushButton
from PySide6.QtCore import Qt

from tsde_engine.editor_gui.theme import Theme  # <- Voller Pfad!


class ThemeTestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Theme Test")
        self.setGeometry(100, 100, 400, 300)
        
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        
        # Label mit Theme-Farben
        self.label = QLabel("Das ist ein Test-Label")
        self.label.setStyleSheet(f"""
            QLabel {{
                background: {Theme.rgba('bg_secondary')};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 10px;
                font: {Theme.FONT_PRIMARY.pointSize()}pt "Segoe UI";
            }}
        """)
        layout.addWidget(self.label)
        
        # Button zum Umschalten
        self.btn = QPushButton("Theme umschalten")
        self.btn.clicked.connect(self.toggle_theme)
        self.btn.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_blue')};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 8px;
            }}
        """)
        layout.addWidget(self.btn)
        
        # Aktuelles Theme anzeigen
        self.theme_label = QLabel(f"Aktuelles Theme: {Theme.MODE}")
        self.theme_label.setStyleSheet(f"color: {Theme.rgb('text_secondary')};")
        layout.addWidget(self.theme_label)
    
    def toggle_theme(self):
        Theme.toggle_mode()
        self.theme_label.setText(f"Aktuelles Theme: {Theme.MODE}")
        
        # Styles neu setzen
        self.label.setStyleSheet(f"""
            QLabel {{
                background: {Theme.rgba('bg_secondary')};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 10px;
            }}
        """)
        
        self.btn.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_blue')};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 8px;
            }}
        """)
        
        self.theme_label.setStyleSheet(f"color: {Theme.rgb('text_secondary')};")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Dunkles Theme (default)
    Theme.MODE = "dark"
    
    window = ThemeTestWindow()
    window.show()
    
    sys.exit(app.exec())