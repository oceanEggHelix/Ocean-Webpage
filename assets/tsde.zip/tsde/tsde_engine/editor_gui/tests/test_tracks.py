#!/usr/bin/env python3
# editor_gui/tests/test_tracks.py

import sys
import os
import math
import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt, QTimer

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.widgets.tracks.tracks_container import TracksContainer
from tsde_engine.editor_gui.widgets.tracks.track_lane import TrackLane
from tsde_engine.editor_gui.widgets.graphs.pedal_mode import PedalMode


class DummyTrack:
    def __init__(self, name):
        self.name = name
        self.pedals = [math.sin(i * 0.1) * 0.8 for i in range(200)]
        self.current_times = np.linspace(0, 1, 200)
        self.t_min = 0.0
        self.t_max = 31.0


class DummyCurve:
    def __init__(self):
        self.length_total = 1000.0
    
    def evaluate(self, t):
        x = 100 * math.cos(t * 4 * math.pi)
        y = 100 * math.sin(t * 4 * math.pi)
        z = 200 * t - 100
        return type('Point', (), {'x': x, 'y': y, 'z': z})()


class TestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Track Hierarchy Test")
        self.setGeometry(100, 100, 800, 600)
        
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Controls
        controls = QHBoxLayout()
        btn_add = QPushButton("➕ Gruppe hinzufügen")
        btn_add.clicked.connect(self.add_group)
        controls.addWidget(btn_add)
        
        btn_clear = QPushButton("🗑 Alle löschen")
        btn_clear.clicked.connect(self.clear_all)
        controls.addWidget(btn_clear)
        
        # Play-Button für Marker-Test
        self.btn_play = QPushButton("▶ Play")
        self.btn_play.clicked.connect(self.toggle_play)
        self.btn_play.setFixedWidth(80)
        controls.addWidget(self.btn_play)
        
        layout.addLayout(controls)
        
        # Tracks Container
        print("🚀 Erstelle Tracks Container...")
        self.tracks = TracksContainer()
        layout.addWidget(self.tracks)
        
        # Timer für Playback
        self.timer = QTimer()
        self.timer.setInterval(50)
        self.timer.timeout.connect(self.update_marker)
        self.marker_pos = 0.0
        self.playing = False
        
        # Demo-Daten laden
        self.load_demo_data()
        
        print("✅ Track Hierarchy bereit!")
        print("   - Gruppen aufklappbar")
        print("   - Tracks mit Auge ein-/ausblendbar")
        print("   - PedalGraph im Spline-Modus")
        print("   - Spline-Buttons funktionieren jetzt!")
        print("   - Play-Timer bewegt Marker")
    
    def load_demo_data(self):
        """Lädt Demo-Tracks"""
        # Gruppe A
        group_a = self.tracks.add_group("Gruppe A")
        
        track1 = TrackLane(DummyTrack("Balu1"), DummyCurve())
        # Spline-Modus setzen
        track1.graph_group.pedal_graph.set_mode(PedalMode.SPLINE)
        # Signale verbinden - WICHTIG: lambda mit track parameter
        track1.graph_group.pedal_graph.generate_spline_clicked.connect(
            lambda points, t=track1: self.on_generate_spline(points, t)
        )
        track1.graph_group.pedal_graph.generate_movement_clicked.connect(
            lambda: self.on_generate_movement(track1)
        )
        group_a.add_track(track1)
        
        track2 = TrackLane(DummyTrack("Balu2"), DummyCurve())
        track2.graph_group.pedal_graph.set_mode(PedalMode.SPLINE)
        track2.graph_group.pedal_graph.generate_spline_clicked.connect(
            lambda points, t=track2: self.on_generate_spline(points, t)
        )
        track2.graph_group.pedal_graph.generate_movement_clicked.connect(
            lambda: self.on_generate_movement(track2)
        )
        group_a.add_track(track2)
        
        # Gruppe B
        group_b = self.tracks.add_group("Gruppe B")
        
        track3 = TrackLane(DummyTrack("Jana1"), DummyCurve())
        track3.graph_group.pedal_graph.set_mode(PedalMode.SPLINE)
        track3.graph_group.pedal_graph.generate_spline_clicked.connect(
            lambda points, t=track3: self.on_generate_spline(points, t)
        )
        track3.graph_group.pedal_graph.generate_movement_clicked.connect(
            lambda: self.on_generate_movement(track3)
        )
        group_b.add_track(track3)
        
        track4 = TrackLane(DummyTrack("Jana2"), DummyCurve())
        track4.graph_group.pedal_graph.set_mode(PedalMode.SPLINE)
        track4.graph_group.pedal_graph.generate_spline_clicked.connect(
            lambda points, t=track4: self.on_generate_spline(points, t)
        )
        track4.graph_group.pedal_graph.generate_movement_clicked.connect(
            lambda: self.on_generate_movement(track4)
        )
        group_b.add_track(track4)
        
        # Gruppe C (leer)
        self.tracks.add_group("Leere Gruppe")
    
    def on_generate_spline(self, num_points, track_lane):
        """Wird vom PedalGraph aufgerufen - mit Track-Referenz"""
        print(f"📐 Spline generieren mit {num_points} Punkten für {track_lane.track.name}")
        # Jetzt rufen wir die Methode des richtigen PedalGraph auf!
        track_lane.graph_group.pedal_graph.generate_spline(num_points)
    
    def on_generate_movement(self, track_lane):
        """Wird vom PedalGraph aufgerufen - mit Track-Referenz"""
        print(f"🏃 Bewegung generieren für {track_lane.track.name}")
        # Hier später die Bewegungsberechnung
    
    def add_group(self):
        """Fügt eine neue Gruppe hinzu"""
        name = f"Gruppe {len(self.tracks.groups) + 1}"
        self.tracks.add_group(name)
    
    def clear_all(self):
        """Löscht alle Gruppen"""
        self.tracks.clear()
    
    def toggle_play(self):
        """Startet/Stoppt Playback"""
        if self.playing:
            self.timer.stop()
            self.btn_play.setText("▶ Play")
        else:
            self.timer.start()
            self.btn_play.setText("⏸ Pause")
        self.playing = not self.playing
    
    def update_marker(self):
        """Bewegt den Marker"""
        self.marker_pos += 0.01
        if self.marker_pos > 1.0:
            self.marker_pos = 0.0
        
        # Marker an alle Tracks senden
        self.tracks.set_marker(self.marker_pos)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    Theme.MODE = "dark"
    window = TestWindow()
    window.show()
    sys.exit(app.exec())