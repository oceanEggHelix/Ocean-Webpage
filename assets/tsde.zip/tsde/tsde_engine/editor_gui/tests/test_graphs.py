#!/usr/bin/env python3
# editor_gui/tests/test_graphs.py

import sys
import os
import math
import numpy as np

# Projektroot zum Pfad hinzufügen
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt, QTimer

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.widgets.graphs.graph_group import GraphGroup
from tsde_engine.editor_gui.widgets.graphs.pedal_mode import PedalMode


class DummyTrack:
    """Dummy-Track für Tests"""
    def __init__(self, name):
        self.name = name
        # Simulierte Pedal-Daten (Sinus)
        self.pedals = [math.sin(i * 0.1) * 0.8 for i in range(200)]
        self.current_times = np.linspace(0, 1, 200)
        self.max_speed = 100.0


class DummyCurve:
    """Dummy-Kurve für Tests"""
    def __init__(self):
        self.length_total = 1000.0
    
    def evaluate(self, t):
        """Gibt Punkt auf Helix zurück"""
        x = 100 * math.cos(t * 4 * math.pi)
        y = 100 * math.sin(t * 4 * math.pi)
        z = 200 * t - 100
        return type('Point', (), {'x': x, 'y': y, 'z': z})()


class TestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Graph Group Test")
        self.setGeometry(100, 100, 800, 600)
        
        # Zentrales Widget
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)
        
        # === NUR Play-Button oben (Rest macht PedalGraph selbst) ===
        controls = QHBoxLayout()
        
        self.btn_play = QPushButton("Play")
        self.btn_play.clicked.connect(self.toggle_play)
        self.btn_play.setFixedWidth(80)
        controls.addWidget(self.btn_play)
        
        controls.addStretch()
        layout.addLayout(controls)
        
        # === Graph Group ===
        print("🚀 Erstelle Graph Group...")
        self.graph_group = GraphGroup()
        layout.addWidget(self.graph_group)
        
        # Dummy-Daten
        self.track = DummyTrack("TestTrack")
        self.curve = DummyCurve()
        
        # In Graphen setzen
        self.graph_group.set_track(self.track)
        self.graph_group.set_curve(self.curve, self.track)
        
        # PedalGraph auf Spline-Modus setzen (Control-Panel erscheint)
        self.graph_group.pedal_graph.set_mode(PedalMode.SPLINE)
        
        # Verbinde Signale vom PedalGraph
        self.graph_group.pedal_graph.generate_spline_clicked.connect(self.on_generate_spline)
        self.graph_group.pedal_graph.generate_movement_clicked.connect(self.on_generate_movement)
        
        # Timer für Playback
        self.timer = QTimer()
        self.timer.setInterval(50)  # 20 FPS
        self.timer.timeout.connect(self.update_marker)
        self.marker_pos = 0.0
        self.playing = False
        
        print("✅ Graph Group bereit!")
        print("   - CurveGraph oben, PedalGraph unten")
        print("   - PedalGraph hat eigenes Control-Panel:")
        print("     • Samples-Reset Button")
        print("     • Spline-Punkte SpinBox")
        print("     • Spline generieren Button")
        print("     • Bewegung generieren Button")
        print("   - Doppelklick im PedalGraph: neuer Punkt")
        print("   - Play-Timer bewegt Marker")
    
    def on_generate_spline(self, num_points):
        """Wird vom PedalGraph aufgerufen"""
        print(f"📐 Spline generieren mit {num_points} Punkten")
        self.graph_group.pedal_graph.generate_spline(num_points)
    
    def on_generate_movement(self):
        """Wird vom PedalGraph aufgerufen"""
        print("🏃 Bewegung generieren")
        # Hier später die Bewegungsberechnung
    
    def toggle_play(self):
        """Startet/Stoppt Playback"""
        if self.playing:
            self.timer.stop()
            self.btn_play.setText("Play")
        else:
            self.timer.start()
            self.btn_play.setText("Stop")
        self.playing = not self.playing
    
    def update_marker(self):
        """Bewegt den Marker"""
        self.marker_pos += 0.01
        if self.marker_pos > 1.0:
            self.marker_pos = 0.0
        
        # Marker an Graphen senden
        self.graph_group.set_marker(self.marker_pos)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Dunkles Theme
    Theme.MODE = "dark"
    
    window = TestWindow()
    window.show()
    
    sys.exit(app.exec())