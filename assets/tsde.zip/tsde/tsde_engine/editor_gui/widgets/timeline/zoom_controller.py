# editor_gui/widgets/timeline/zoom_controller.py

from PySide6.QtCore import QObject, Signal

class ZoomController(QObject):
    """Zentrale Zoom-Logik für Timeline und PedalGraph"""
    
    zoom_changed = Signal(float, float)  # start, end
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Zoom-Bereich (0-1)
        self._start = 0.0
        self._end = 1.0
        self._min_range = 0.05  # Minimal 5% Zoom
        
        # Puffer (5% links/rechts für Marker)
        self.padding = 0.05
    
    @property
    def start(self):
        return self._start
    
    @property
    def end(self):
        return self._end
    
    @property
    def range(self):
        return self._end - self._start
    
    def set_zoom(self, start, end):
        """Setzt Zoom-Bereich mit Begrenzungen"""
        start = max(0.0, min(1.0, start))
        end = max(0.0, min(1.0, end))
        
        if end - start < self._min_range:
            # Zu kleiner Zoom -> korrigieren
            center = (start + end) / 2
            start = max(0.0, center - self._min_range/2)
            end = min(1.0, center + self._min_range/2)
        
        self._start = start
        self._end = end
        self.zoom_changed.emit(start, end)
    
    def zoom_to(self, center, factor):
        """Zoomt auf bestimmten Punkt (für Mausrad)"""
        half_range = self.range * factor / 2
        start = max(0.0, center - half_range)
        end = min(1.0, center + half_range)
        
        # Korrigieren wenn an den Rändern
        if start == 0.0:
            end = min(1.0, self._min_range)
        elif end == 1.0:
            start = max(0.0, 1.0 - self._min_range)
        
        self.set_zoom(start, end)
    
    def reset(self):
        """Reset auf 100% Zoom"""
        self.set_zoom(0.0, 1.0)
    
    def get_visible_range(self, marker_pos):
        """
        Gibt den sichtbaren Bereich zurück, unter Berücksichtigung des Markers.
        Für das Oszilloskop-Verhalten im CurveGraph.
        """
        if marker_pos < self.start + self.padding:
            # Marker im linken Puffer
            return (self.start, self.end, "LEFT_EDGE")
        elif marker_pos > self.end - self.padding:
            # Marker im rechten Puffer
            return (self.start, self.end, "RIGHT_EDGE")
        else:
            # Marker in der Mitte
            return (self.start, self.end, "NORMAL")