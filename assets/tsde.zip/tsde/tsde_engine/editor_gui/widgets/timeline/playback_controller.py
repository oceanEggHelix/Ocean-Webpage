# editor_gui/widgets/timeline/playback_controller.py

from PySide6.QtCore import QObject, QTimer, Signal
import time  # <-- WICHTIG: time importieren!

class PlaybackController(QObject):
    """Steuert Play/Pause/Stop und Timer"""
    
    position_changed = Signal(float)  # 0-1
    state_changed = Signal(str)  # "playing", "paused", "stopped"
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.duration = 1.0  # in Sekunden
        self.position = 0.0
        self.is_playing = False
        self.direction = 1  # 1 = vorwärts, -1 = rückwärts
        self.loop_enabled = False  # NEU: Loop-Status
        
        # Timer für Playback (60 FPS ≈ 16ms)
        self.timer = QTimer()
        self.timer.setInterval(16)
        self.timer.timeout.connect(self._update)
        
        # FIX: Zeit des letzten Frames speichern
        self.last_time = 0
        
        # Liste der Graphen die Playback-Updates bekommen
        self.subscribed_graphs = []
    
    def set_duration(self, seconds):
        """Setzt die Gesamtdauer"""
        self.duration = max(0.001, seconds)
    
    def set_direction(self, direction):
        """Setzt Richtung: 1 = vorwärts, -1 = rückwärts"""
        self.direction = 1 if direction > 0 else -1
    
    # NEUE METHODE: Loop setzen
    def set_loop(self, enabled):
        """Aktiviert/deaktiviert Loop"""
        self.loop_enabled = enabled
    
    def play(self):
        """Startet Playback"""
        if not self.is_playing:
            self.is_playing = True
            self.last_time = time.time()  # <-- FIX: Zeit beim Start speichern
            self.timer.start()
            self.state_changed.emit("playing")
    
    def pause(self):
        """Pausiert Playback"""
        if self.is_playing:
            self.is_playing = False
            self.timer.stop()
            self.state_changed.emit("paused")
    
    def stop(self):
        """Stoppt und setzt zurück auf 0"""
        self.pause()
        self.position = 0.0
        self.position_changed.emit(self.position)
        self.state_changed.emit("stopped")
    
    def set_position(self, pos):
        """Setzt Position direkt (0-1)"""
        self.position = max(0.0, min(1.0, pos))
        self.position_changed.emit(self.position)
    
    def subscribe_graph(self, graph):
        """Fügt einen Graphen hinzu, der Playback-Updates bekommt"""
        if graph not in self.subscribed_graphs:
            self.subscribed_graphs.append(graph)
    
    def unsubscribe_graph(self, graph):
        """Entfernt einen Graphen"""
        if graph in self.subscribed_graphs:
            self.subscribed_graphs.remove(graph)
    
    def _update(self):
        """Wird vom Timer aufgerufen"""
        if not self.is_playing:
            return
        
        now = time.time()
        if self.last_time == 0:
            self.last_time = now
            return
        
        dt = now - self.last_time
        self.last_time = now
        
        step = dt / self.duration * self.direction
        new_pos = self.position + step
        
        # Prüfen ob am Ende/Anfang
        if new_pos >= 1.0:
            if self.loop_enabled:
                self.position = 0.0
                self.position_changed.emit(self.position)
            else:
                # Ende erreicht
                print(f"⏱️ Playback: Ende erreicht - setze Position auf 0.0")
                self.position = 0.0
                
                # 🔥 FIX: ZUERST is_playing auf False setzen!
                self.is_playing = False
                
                # DANN Signal senden (mit is_playing = False)
                self.position_changed.emit(self.position)
                print(f"   → position_changed(0.0) emitted")
                
                self.timer.stop()
                self.state_changed.emit("stopped")
                print(f"⏱️ Playback: Ende erreicht - is_playing = {self.is_playing}")
                
        elif new_pos <= 0.0:
            if self.loop_enabled and self.direction < 0:
                self.position = 1.0
                self.position_changed.emit(self.position)
            else:
                self.position = 0.0
                
                # 🔥 FIX: Auch hier zuerst is_playing auf False
                self.is_playing = False
                
                self.position_changed.emit(self.position)
                
                self.timer.stop()
                self.state_changed.emit("stopped")
                print(f"⏱️ Playback: Anfang erreicht - is_playing = {self.is_playing}")
        else:
            self.position = new_pos
            self.position_changed.emit(self.position)