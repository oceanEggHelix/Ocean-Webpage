# editor_gui/widgets/timeline/timeline_widget.py

from PySide6.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QDoubleSpinBox
from PySide6.QtCore import Qt, Signal

from ...theme import Theme
from .timeline_view import TimelineView
from .zoom_controller import ZoomController
from .playback_controller import PlaybackController

class TimelineWidget(QFrame):
    """Haupt-Timeline mit Play/Stop, Zoom und editierbarer Duration"""
    
    # Signale nach außen
    position_changed = Signal(float)
    zoom_changed = Signal(float, float)
    duration_changed = Signal(float)
    play_pause_clicked = Signal()
    stop_clicked = Signal()
    loop_toggled = Signal(bool)  # NEU: Signal für Loop-Status
    
    # NEU: Signal für extern gesteuerte Play-Status-Änderungen
    play_state_changed = Signal(bool)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setFixedHeight(Theme.TIMELINE_HEIGHT)
        self.setObjectName("timelineWidget")
        self.setStyleSheet(f"""
            #timelineWidget {{
                background: {Theme.rgba('bg_secondary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_LARGE}px;
            }}
        """)
        
        # Controller
        self.zoom = ZoomController()
        self.playback = PlaybackController()
        
        # NEU: Loop-Status
        self.loop_enabled = False
        
        # Verbindungen
        self.playback.position_changed.connect(self._on_playback_position)
        self.zoom.zoom_changed.connect(self._on_zoom_changed)
        
        # Layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(Theme.PADDING, Theme.PADDING_SMALL,
                                  Theme.PADDING, Theme.PADDING_SMALL)
        layout.setSpacing(Theme.SPACING_SMALL)
        
        # === Controls ===
        controls = QHBoxLayout()
        controls.setSpacing(Theme.SPACING)
        
        controls.addStretch(5)
        
        # NEU: Loop-Button
        self.loop_btn = QPushButton("⟲")
        self.loop_btn.setFixedSize(Theme.BUTTON_SIZE, Theme.BUTTON_SIZE)
        self.loop_btn.setCursor(Qt.PointingHandCursor)
        self.loop_btn.setCheckable(True)
        self.loop_btn.setChecked(False)
        self.loop_btn.clicked.connect(self._on_loop_toggled)
        self.loop_btn.setToolTip("Loop aktivieren/deaktivieren")
        self.loop_btn.setStyleSheet(self._button_style(Theme.color('accent_purple')))
        controls.addWidget(self.loop_btn)
        
        # Play/Pause
        self.play_btn = QPushButton("⏵")
        self.play_btn.setFixedSize(Theme.BUTTON_SIZE, Theme.BUTTON_SIZE)
        self.play_btn.setCursor(Qt.PointingHandCursor)
        self.play_btn.clicked.connect(self._on_play_clicked)
        self.play_btn.setStyleSheet(self._button_style(Theme.color('accent_blue')))
        controls.addWidget(self.play_btn)
        
        # Stop
        self.stop_btn = QPushButton("⏹")
        self.stop_btn.setFixedSize(Theme.BUTTON_SIZE, Theme.BUTTON_SIZE)
        self.stop_btn.setCursor(Qt.PointingHandCursor)
        self.stop_btn.clicked.connect(self._on_stop_clicked)
        self.stop_btn.setStyleSheet(self._button_style(Theme.color('accent_red')))
        controls.addWidget(self.stop_btn)
        
        # Duration
        duration_label = QLabel("Dauer:")
        duration_label.setStyleSheet(f"color: {Theme.rgb('text_primary')};")
        controls.addWidget(duration_label)
        
        self.duration_spin = QDoubleSpinBox()
        self.duration_spin.setRange(0.1, 999.9)
        self.duration_spin.setValue(31.0)
        self.duration_spin.setSingleStep(1.0)
        self.duration_spin.setSuffix(" s")
        self.duration_spin.setFixedWidth(90)
        self.duration_spin.setAlignment(Qt.AlignRight)
        self.duration_spin.setStyleSheet(f"""
            QDoubleSpinBox {{
                background: {Theme.rgba('bg_primary', 100)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 4px;
                font-family: monospace;
                font-size: 9pt;
            }}
            QDoubleSpinBox:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
            QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
                width: 16px;
                border: none;
                background: {Theme.rgba('bg_primary', 50)};
                border-radius: 2px;
            }}
        """)
        self.duration_spin.valueChanged.connect(self._on_duration_changed)
        controls.addWidget(self.duration_spin)
        
        # Zeitanzeige
        self.time_label = QLabel("00:00.00 / 00:00.00")
        self.time_label.setAlignment(Qt.AlignCenter)
        self.time_label.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgb('text_primary')};
                background: {Theme.rgba('bg_primary', 100)};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 4px 12px;
                font-family: monospace;
                font-size: 9pt;
            }}
        """)
        controls.addWidget(self.time_label)
        
        # Zoom-Anzeige
        self.zoom_label = QLabel("100%")
        self.zoom_label.setAlignment(Qt.AlignCenter)
        self.zoom_label.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgb('text_secondary')};
                background: {Theme.rgba('bg_primary', 80)};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 2px 8px;
                font-family: monospace;
                font-size: 8pt;
            }}
        """)
        controls.addWidget(self.zoom_label)
        
        controls.addStretch(6)
        
        layout.addLayout(controls)
        
        # === Timeline View ===
        self.view = TimelineView()
        self.view.position_changed.connect(self._on_view_position)
        self.view.zoom_changed.connect(self.zoom.set_zoom)
        layout.addWidget(self.view)
        
        # Initialzustand
        self.play_btn.setEnabled(False)
        self.stop_btn.setEnabled(False)
    
    def _button_style(self, color):
        """Erzeugt Style für Buttons"""
        return f"""
            QPushButton {{
                background: {Theme.rgba('bg_primary', 100)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                font-size: 14px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: {color.name() + '80'};
                border: 1px solid {color.name()};
            }}
            QPushButton:pressed {{
                background: {color.name()};
            }}
            QPushButton:disabled {{
                background: {Theme.rgba('bg_primary', 50)};
                color: {Theme.rgba('text_secondary', 100)};
                border: 1px solid {Theme.rgba('border')};
            }}
            QPushButton:checked {{
                background: {color.name()};
                border: 2px solid {Theme.rgb('text_primary')};
            }}
        """
    
    def _on_loop_toggled(self, checked):
        """Loop-Status umgeschaltet"""
        self.loop_enabled = checked
        self.playback.set_loop(checked)  # NEU: Loop an Controller weitergeben
        self.loop_toggled.emit(checked)
        
        # Visuelles Feedback (Tooltip)
        self.loop_btn.setToolTip("Loop deaktivieren" if checked else "Loop aktivieren")
    
    def _on_play_clicked(self):
        """Play/Pause umschalten (User-Klick)"""
        if self.playback.is_playing:
            self.playback.pause()
            self.play_btn.setText("⏵")
        else:
            self.playback.play()
            self.play_btn.setText("⏸")
        
        # Signale senden
        self.play_pause_clicked.emit()
        self.play_state_changed.emit(self.playback.is_playing)
    
    def _on_stop_clicked(self):
        """Stop drücken"""
        self.playback.stop()
        self.play_btn.setText("⏵")  # ← Hier auch!
        self.stop_clicked.emit()
        self.play_state_changed.emit(False)
    
    def _on_playback_position(self, pos):
        """Position vom Playback-Controller"""
        #print(f"⏱️ Timeline empfängt Position {pos:.4f}")  # <-- Wieder aktivieren!
        self.view.set_position(pos)
        self.position_changed.emit(pos)
        self._update_time_display()
        
        # FIX: Wenn wir am Ende sind (pos == 0.0 und Playback gestoppt)
        if pos == 0.0 and not self.playback.is_playing:
            self.play_btn.setText("⏵")
            self.play_state_changed.emit(False)
            print(f"⏱️ Timeline: Ende erreicht, Button zurückgesetzt")
    
    def _on_view_position(self, pos):
        """Position von der View (durch Klick)"""
        self.playback.set_position(pos)
        self.position_changed.emit(pos)
    
    def _on_zoom_changed(self, start, end):
        """Zoom geändert"""
        self.view.set_zoom(start, end)
        self.zoom_changed.emit(start, end)
        percent = int((end - start) * 100)
        self.zoom_label.setText(f"{percent}%")
    
    def _on_duration_changed(self, value):
        """Duration wurde geändert"""
        self.playback.set_duration(value)
        self.view.set_duration(value)
        self.duration_changed.emit(value)
        self._update_time_display()
    
    def _update_time_display(self):
        """Aktualisiert die Zeitanzeige"""
        if self.playback.duration <= 0:
            self.time_label.setText("00:00.00 / 00:00.00")
            return
        
        current = self.playback.position * self.playback.duration
        total = self.playback.duration
        
        def format_time(t):
            minutes = int(t // 60)
            seconds = int(t % 60)
            ms = int((t - int(t)) * 100)
            return f"{minutes:02d}:{seconds:02d}.{ms:02d}"
        
        self.time_label.setText(f"{format_time(current)} / {format_time(total)}")
    
    # === NEUE METHODE: Von extern gesteuert ===
    def set_playing_from_external(self, playing):
        """Wird vom EditorPanel aufgerufen wenn VTK/Vollbild Play/Pause ändert"""
        print(f"⏱️ TIMELINE: set_playing_from_external({playing}) aufgerufen")
        print(f"   playback.is_playing vorher = {self.playback.is_playing}")
        
        # Wenn der externe State mit dem internen übereinstimmt, nichts tun
        if playing == self.playback.is_playing:
            print(f"   ⚠️ Keine Änderung nötig")
            return
        
        # Sonst: Playback-Controller entsprechend starten/stoppen
        if playing:
            print(f"   → Starte Playback-Controller")
            self.playback.play()
            self.play_btn.setText("⏸")
        else:
            print(f"   → Pausiere Playback-Controller")
            self.playback.pause()
            self.play_btn.setText("⏵")
        
        print(f"   playback.is_playing nachher = {self.playback.is_playing}")
        print(f"   ⏱️ TIMELINE: set_playing_from_external() abgeschlossen\n")
    
    # === ÖFFENTLICHE API ===
    
    def set_duration(self, duration):
        """Setzt die Gesamtdauer"""
        self.duration_spin.blockSignals(True)
        self.duration_spin.setValue(duration)
        self.duration_spin.blockSignals(False)
        self.playback.set_duration(duration)
        self.view.set_duration(duration)
        self._update_time_display()
        self.play_btn.setEnabled(True)
        self.stop_btn.setEnabled(True)
        self.loop_btn.setEnabled(True)  # NEU: Loop-Button aktivieren
    
    def get_duration(self):
        """Gibt die aktuelle Dauer zurück"""
        return self.duration_spin.value()
    
    def set_position(self, pos):
        """Setzt Position direkt"""
        self.playback.set_position(pos)
    
    def set_zoom(self, start, end):
        """Setzt Zoom direkt"""
        self.zoom.set_zoom(start, end)
    
    def reset_zoom(self):
        """Reset auf 100%"""
        self.zoom.reset()
    
    def set_playing(self, is_playing):
        """Setzt Play-Status (wird von extern verwendet)"""
        print(f"⏱️ TIMELINE: set_playing({is_playing}) aufgerufen")
        print(f"   playback.is_playing vorher = {self.playback.is_playing}")
        
        # Wenn der State schon passt, nichts tun
        if is_playing == self.playback.is_playing:
            print(f"   ⚠️ State already correct - ignoring")
            return
        
        # Sonst an externen Setter weitergeben
        self.set_playing_from_external(is_playing)
    
    def set_playback_enabled(self, enabled):
        """Aktiviert/deaktiviert Playback-Steuerung"""
        self.play_btn.setEnabled(enabled)
        self.stop_btn.setEnabled(enabled)
        self.loop_btn.setEnabled(enabled)  # NEU: Loop-Button auch steuern
    
    # NEUE METHODE: Loop-Status setzen
    def set_loop(self, enabled):
        """Aktiviert/deaktiviert Loop von extern"""
        self.loop_btn.blockSignals(True)
        self.loop_btn.setChecked(enabled)
        self.loop_btn.blockSignals(False)
        self.loop_enabled = enabled
        self.playback.set_loop(enabled)
    
    # NEUE METHODE: Loop-Status abfragen
    def is_loop_enabled(self):
        """Gibt zurück ob Loop aktiv ist"""
        return self.loop_enabled