# editor_gui/widgets/timeline/timeline_view.py

from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, Signal, QRect, QPoint
from PySide6.QtGui import QPainter, QPen, QColor, QBrush

from ...theme import Theme

class TimelineView(QWidget):
    """Nur die Zeitleiste (ohne Buttons)"""
    
    position_changed = Signal(float)
    zoom_changed = Signal(float, float)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setFixedHeight(Theme.TIMELINE_VIEW_HEIGHT)
        
        # Daten
        self.duration = 0.0
        self.position = 0.0
        self.zoom_start = 0.0
        self.zoom_end = 1.0
        
        # Padding - GLEICHE WERTE WIE IM PEDALGRAPH!
        self.LEFT_PADDING = 65    # Gleicher Wert wie PedalGraph.LEFT_PADDING
        self.RIGHT_PADDING = 90   # Gleicher Wert wie PedalGraph.RIGHT_PADDING
        
        # Interaktion
        self.dragging = False
        self.zoom_dragging = False
        self.zoom_start_x = 0
        
        self.setMouseTracking(True)
    
    def set_duration(self, duration):
        self.duration = duration
        self.update()
    
    def set_position(self, pos):
        self.position = max(0.0, min(1.0, pos))
        self.update()
    
    def set_zoom(self, start, end):
        self.zoom_start = max(0.0, min(1.0, start))
        self.zoom_end = max(0.0, min(1.0, end))
        if self.zoom_end <= self.zoom_start:
            self.zoom_end = self.zoom_start + 0.01
        self.update()
    
    def get_content_rect(self):
        """Bereich für die Timeline (mit Padding) - EXAKT WIE IM PEDALGRAPH"""
        return self.rect().adjusted(self.LEFT_PADDING, 4, 
                                    -self.RIGHT_PADDING, -8)
    
    def map_t_to_x(self, t, rect):
        """Konvertiert Zeit zu x-Position (mit Zoom)"""
        if t < self.zoom_start:
            return rect.left()
        if t > self.zoom_end:
            return rect.right()
        
        visible_range = self.zoom_end - self.zoom_start
        t_visible = (t - self.zoom_start) / visible_range
        return rect.left() + t_visible * rect.width()
    
    def map_x_to_t(self, x, rect):
        """Konvertiert x-Position zu Zeit (mit Zoom)"""
        rel_x = (x - rect.left()) / rect.width()
        rel_x = max(0.0, min(1.0, rel_x))
        visible_range = self.zoom_end - self.zoom_start
        return self.zoom_start + rel_x * visible_range
    
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Hintergrund komplett transparent lassen
        # painter.fillRect(self.rect(), Theme.color('bg_graph'))  ← ENTFERNEN!
        
        content_rect = self.get_content_rect()
        
        # Alles NUR im content_rect zeichnen
        painter.fillRect(content_rect, Theme.color('bg_graph'))
        painter.fillRect(content_rect, Theme.color('bg_secondary'))
        
        # Rahmen
        painter.setPen(QPen(Theme.color('border'), 1))
        painter.drawRect(content_rect)
        
        # Ticks (Sekundenstriche)
        num_ticks = 11
        for i in range(num_ticks):
            t_visible = i / (num_ticks - 1)
            t = self.zoom_start + t_visible * (self.zoom_end - self.zoom_start)
            x = self.map_t_to_x(t, content_rect)
            
            # Haupt-Ticks länger
            if i % 2 == 0:
                painter.setPen(QPen(Theme.color('text_primary'), 2))
                painter.drawLine(int(x), content_rect.bottom() - 8, 
                                int(x), content_rect.bottom() - 2)
            else:
                painter.setPen(QPen(Theme.color('text_secondary'), 1))
                painter.drawLine(int(x), content_rect.bottom() - 6, 
                                int(x), content_rect.bottom() - 2)
            
            # Zeit-Label
            if self.duration > 0:
                time_sec = t * self.duration
                painter.setPen(Theme.color('text_secondary'))
                text_rect = QRect(int(x - 20), content_rect.top(), 40, 15)
                painter.drawText(text_rect, Qt.AlignCenter, f"{time_sec:.1f}s")
        
        # Zoom-Bereich hervorheben (wenn nicht 100%)
        if self.zoom_start > 0 or self.zoom_end < 1:
            painter.fillRect(content_rect, QBrush(QColor(100, 200, 255, 30)))
        
        # Marker
        marker_x = self.map_t_to_x(self.position, content_rect)
        painter.setPen(QPen(Theme.color('marker'), 2))
        painter.drawLine(marker_x, content_rect.top(), marker_x, content_rect.bottom())
        
        # Marker-Kopf
        painter.setBrush(QBrush(Theme.color('marker')))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(QPoint(int(marker_x), content_rect.top() + 5), 4, 4)
        
        painter.end()
        
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            if event.modifiers() & Qt.AltModifier:
                # Alt + Links = Zoom-Modus
                self.zoom_dragging = True
                self.zoom_start_x = int(event.position().x())
            else:
                # Normal = Position setzen
                self.dragging = True
                self._update_position(int(event.position().x()))
    
    def mouseMoveEvent(self, event):
        if self.zoom_dragging:
            x1 = min(self.zoom_start_x, int(event.position().x()))
            x2 = max(self.zoom_start_x, int(event.position().x()))
            rect = self.get_content_rect()
            t1 = self.map_x_to_t(x1, rect)
            t2 = self.map_x_to_t(x2, rect)
            self.zoom_changed.emit(t1, t2)
        elif self.dragging:
            self._update_position(int(event.position().x()))
    
    def mouseReleaseEvent(self, event):
        self.dragging = False
        self.zoom_dragging = False
    
    def wheelEvent(self, event):
        """Mausrad für Zoom"""
        rect = self.get_content_rect()
        mouse_x = int(event.position().x())
        t_center = self.map_x_to_t(mouse_x, rect)
        
        zoom_factor = 1.2
        if event.angleDelta().y() > 0:
            # Reinzoomen
            new_range = (self.zoom_end - self.zoom_start) / zoom_factor
        else:
            # Rauszoomen
            new_range = (self.zoom_end - self.zoom_start) * zoom_factor
            new_range = min(1.0, new_range)
        
        new_start = t_center - new_range / 2
        new_end = t_center + new_range / 2
        
        # Randkorrektur
        if new_start < 0:
            new_start = 0
            new_end = new_range
        if new_end > 1:
            new_end = 1
            new_start = 1 - new_range
        
        self.zoom_changed.emit(new_start, new_end)
    
    def _update_position(self, x):
        rect = self.get_content_rect()
        t = self.map_x_to_t(x, rect)
        self.position = max(0.0, min(1.0, t))
        self.position_changed.emit(self.position)
        self.update()