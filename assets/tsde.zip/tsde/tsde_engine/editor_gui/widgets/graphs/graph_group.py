# editor_gui/widgets/graphs/graph_group.py

from PySide6.QtWidgets import QWidget, QVBoxLayout, QSplitter, QSizePolicy
from PySide6.QtCore import Qt, Signal

from ...theme import Theme
from .curve_graph import CurveGraph
from .pedal_graph import PedalGraph

class GraphGroup(QWidget):
    """Container für CurveGraph und PedalGraph mit Splitter"""
    
    height_changed = Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # WICHTIG: KEINE feste Höhe - dynamisch!
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
        
        # MINDESTHÖHEN für Graphen
        self.MIN_CURVE_HEIGHT = 0
        self.MIN_PEDAL_HEIGHT = 0  # Inklusive Control-Panel
        self.DEFAULT_CURVE_HEIGHT = 80
        self.DEFAULT_PEDAL_HEIGHT = 100  # 80 Graph + 30 Panel
        
        # Aktuelle Höhen
        self.curve_height = self.DEFAULT_CURVE_HEIGHT
        self.pedal_height = self.DEFAULT_PEDAL_HEIGHT
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Splitter - dehnbar
        self.splitter = QSplitter(Qt.Vertical)
        self.splitter.setHandleWidth(4)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setStyleSheet(f"""
            QSplitter::handle {{
                background: {Theme.rgba('border')};
                height: 4px;
            }}
            QSplitter::handle:hover {{
                background: {Theme.rgba('accent_blue')};
            }}
        """)
        
        # Graphen
        self.curve_graph = CurveGraph()
        self.pedal_graph = PedalGraph()
        
        # Mindesthöhen setzen
        self.curve_graph.setMinimumHeight(self.MIN_CURVE_HEIGHT)
        self.curve_graph.setMaximumHeight(1000)
        self.pedal_graph.setMinimumHeight(self.MIN_PEDAL_HEIGHT)
        self.pedal_graph.setMaximumHeight(1000)
        
        self.splitter.addWidget(self.curve_graph)
        self.splitter.addWidget(self.pedal_graph)
        
        # Splitter-Positionen setzen
        self.splitter.setSizes([self.curve_height, self.pedal_height])
        
        layout.addWidget(self.splitter)
        
        # Signals
        self.splitter.splitterMoved.connect(self._on_splitter_moved)
    
    def _on_splitter_moved(self):
        """Wird aufgerufen wenn der Splitter bewegt wird"""
        sizes = self.splitter.sizes()
        if len(sizes) == 2:
            # Mindesthöhen durchsetzen
            self.curve_height = max(sizes[0], self.MIN_CURVE_HEIGHT)
            self.pedal_height = max(sizes[1], self.MIN_PEDAL_HEIGHT)
            
            if sizes[0] != self.curve_height or sizes[1] != self.pedal_height:
                self.splitter.setSizes([self.curve_height, self.pedal_height])
            
            # Signal emittieren
            self.height_changed.emit()
    
    def height(self):
        """Gibt die aktuelle Höhe zurück"""
        if self.isVisible():
            return self.curve_height + self.pedal_height + self.splitter.handleWidth()
        return super().height()
    
    def sizeHint(self):
        """Qt-spezifische Größenempfehlung"""
        width = super().sizeHint().width()
        height = self.curve_height + self.pedal_height + self.splitter.handleWidth()
        return self.size().__class__(width, height)
    
    def minimumSizeHint(self):
        """Qt-spezifische Mindestgröße"""
        width = super().minimumSizeHint().width()
        height = self.MIN_CURVE_HEIGHT + self.MIN_PEDAL_HEIGHT + self.splitter.handleWidth()
        return self.size().__class__(width, height)
    
    def set_track(self, track):
        """Setzt Track für beide Graphen"""
        self.curve_graph.track = track
        self.pedal_graph.set_track(track)
    
    def set_curve(self, curve, track=None):
        """Setzt Kurve für CurveGraph"""
        self.curve_graph.set_curve(curve, track)
    
    def set_marker(self, t_pos):
        """Setzt Marker-Position für beide Graphen"""
        self.curve_graph.set_marker(t_pos)
        self.pedal_graph.set_marker(t_pos)
    
    def set_zoom(self, start, end):
        """Setzt Zoom für beide Graphen"""
        self.curve_graph.set_zoom(start, end)
        self.pedal_graph.set_zoom(start, end)
    
    def set_content_width(self, width):
        """Setzt Breite für beide Graphen"""
        self.curve_graph.set_content_width(width)
        self.pedal_graph.set_content_width(width)
    
    def set_sizes(self, sizes):
        """Setzt die Höhen der beiden Graphen"""
        if len(sizes) == 2:
            # Mindesthöhen beachten
            self.curve_height = max(sizes[0], self.MIN_CURVE_HEIGHT)
            self.pedal_height = max(sizes[1], self.MIN_PEDAL_HEIGHT)
            
            self.splitter.setSizes([self.curve_height, self.pedal_height])
            self.height_changed.emit()
    
    def get_sizes(self):
        """Gibt die aktuellen Höhen zurück"""
        return [self.curve_height, self.pedal_height]
    
    def reset_to_default(self):
        """Setzt die Höhen auf Standard zurück"""
        self.set_sizes([self.DEFAULT_CURVE_HEIGHT, self.DEFAULT_PEDAL_HEIGHT])