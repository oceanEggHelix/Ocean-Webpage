# editor_gui/widgets/graphs/base_graph.py

from PySide6.QtWidgets import QWidget, QSizePolicy
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QPainter, QPen, QBrush

from ...theme import Theme

class BaseGraph(QWidget):
    """Gemeinsame Basis für alle Graphen - reine Zeichenfläche ohne Header"""
    
    def __init__(self, parent=None):
        super().__init__(parent)

        # Padding für Achsen
        self.PADDING = Theme.PADDING
        
        # Zoom-Bereich (normalisiert 0-1)
        self.zoom_start = 0.0
        self.zoom_end = 1.0
        
        # Wichtig: Dynamische Höhe
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        
        self.content_width = 0

    def set_content_width(self, width):
        """Setzt die Breite des Inhaltsbereichs"""
        self.content_width = width
        self.setFixedWidth(width + 2 * self.PADDING)
        
    def set_zoom(self, start, end):
        """Setzt den sichtbaren Zoom-Bereich (normalisiert 0-1)"""
        self.zoom_start = max(0.0, min(1.0, start))
        self.zoom_end = max(0.0, min(1.0, end))
        if self.zoom_end <= self.zoom_start:
            self.zoom_end = self.zoom_start + 0.01
        self.update()

    def get_content_rect(self):
        """Gibt den inneren Bereich ohne Padding zurück"""
        return self.rect().adjusted(self.PADDING, self.PADDING, 
                                   -self.PADDING + 1, -self.PADDING)

    def map_x_to_t(self, x, content_rect):
        """Konvertiert x-Position zu normalisierter Zeit (0-1)"""
        if x < content_rect.left():
            return 0.0
        if x > content_rect.right():
            return 1.0
        
        t_visible = (x - content_rect.left()) / content_rect.width()
        return self.zoom_start + t_visible * (self.zoom_end - self.zoom_start)

    def map_t_to_x(self, t, content_rect):
        """Konvertiert Zeit t zu x-Position (mit Zoom)"""
        if t < self.zoom_start:
            return content_rect.left()
        if t > self.zoom_end:
            return content_rect.right()
            
        visible_range = self.zoom_end - self.zoom_start
        t_visible = (t - self.zoom_start) / visible_range
        
        return content_rect.left() + t_visible * content_rect.width()

    def draw_background(self, painter):
        """Zeichnet Hintergrund mit Rahmen"""
        painter.fillRect(self.rect(), Theme.color('bg_graph'))
        painter.setPen(QPen(Theme.color('border'), 1))
        painter.drawRect(self.rect().adjusted(0, 0, -1, -1))

    def draw_grid(self, painter, content_rect):
        """Zeichnet horizontale Gitterlinien"""
        painter.setPen(QPen(Theme.color('grid'), 1, Qt.DotLine))
        
        for i in range(1, 4):
            y = content_rect.top() + i * content_rect.height() / 4
            painter.drawLine(content_rect.left(), int(y), 
                           content_rect.right(), int(y))