# editor_gui/widgets/graphs/pedal_graph.py

from PySide6.QtWidgets import QWidget, QPushButton, QHBoxLayout, QVBoxLayout, QSpinBox, QDoubleSpinBox, QLabel, QFrame, QCheckBox
from PySide6.QtCore import Qt, Signal, QPoint, QTimer
from PySide6.QtGui import QPainter, QPen, QBrush, QMouseEvent
import numpy as np
from scipy import interpolate

from ...theme import Theme
from .base_graph import BaseGraph
from .pedal_mode import PedalMode

class PedalGraph(BaseGraph):
    """Pedal-Kurve über Zeit - mit Spline-Overlay und Live-Vorschau"""
    
    mode_changed = Signal(PedalMode)
    spline_points_updated = Signal()
    generate_spline_clicked = Signal(int)  # Anzahl Punkte
    generate_movement_clicked = Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)

        self.track = None
        self.marker_pos = 0.0  # Zeit-Position (0-1) von Timeline
        self.vmax_value = 100.0  # Standard v-max
        
        # Daten
        self.time_data = None
        self.pedal_data = None
        self.original_pedals = None  # Für Reset
        
        # Spline
        self.mode = PedalMode.SAMPLES
        self.spline_points = []
        self.spline_resolution = 500
        
        # Live-Vorschau
        self.preview_spline = None
        self.preview_points = []
        
        # Interaktion
        self.dragging = False
        self.drag_index = -1
        self.point_radius = 5
        self.hover_index = -1
        self.editing_spline = True
        self.x_movable = True

        self.setMouseTracking(True)
        self.setMinimumHeight(120)
        
        # Padding für Achsen (wie in CurveGraph)
        self.LEFT_PADDING = 35     # Platz für Pedal-Beschriftung
        self.RIGHT_PADDING = 40    # Platz rechts
        self.TOP_PADDING = 10      # Platz oben
        self.BOTTOM_PADDING = 20   # Platz für Controls-Info
        
        # ===== CONTROLS (unterer Bereich) =====
        self.control_panel = QFrame(self)
        self.control_panel.setObjectName("pedalControls")
        self.control_panel.setStyleSheet(f"""
            #pedalControls {{
                background: {Theme.rgba('bg_secondary', 200)};
                border-top: 1px solid {Theme.rgba('border')};
                border-bottom-left-radius: {Theme.RADIUS_MEDIUM}px;
                border-bottom-right-radius: {Theme.RADIUS_MEDIUM}px;
            }}
        """)
        
        control_layout = QHBoxLayout(self.control_panel)
        control_layout.setContentsMargins(8, 4, 8, 4)
        control_layout.setSpacing(8)
        
        # === Samples-Reset Button ===
        self.reset_btn = QPushButton("↺ Samples")
        self.reset_btn.setCursor(Qt.PointingHandCursor)
        self.reset_btn.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('bg_primary', 150)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 4px 8px;
                font-size: 8pt;
                min-width: 60px;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_blue', 150)};
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
        """)
        self.reset_btn.clicked.connect(self.reset_to_samples)
        control_layout.addWidget(self.reset_btn)
        
        # Trennlinie
        sep1 = QFrame()
        sep1.setFrameShape(QFrame.VLine)
        sep1.setStyleSheet(f"background: {Theme.rgba('border')}; width: 1px;")
        control_layout.addWidget(sep1)
        
        # === Spline Punkte ===
        points_label = QLabel("Punkte:")
        points_label.setStyleSheet(f"color: {Theme.rgb('text_primary')}; font-size: 8pt;")
        control_layout.addWidget(points_label)

        self.points_spin = QSpinBox()
        self.points_spin.setRange(3, 100)
        self.points_spin.setValue(10)
        self.points_spin.setFixedWidth(60)  # VON 50 AUF 60 ERHÖHT
        self.points_spin.setStyleSheet(f"""
            QSpinBox {{
                background: {Theme.rgba('bg_primary', 150)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 3px;
                font-size: 8pt;
            }}
            QSpinBox:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
        """)
        control_layout.addWidget(self.points_spin)

        # === Spline generieren und Glätten in einer Zeile ===
        spline_row = QHBoxLayout()
        spline_row.setSpacing(6)  # MEHR SPACING (von 4 auf 6)

        self.gen_spline_btn = QPushButton("Spline")
        self.gen_spline_btn.setCursor(Qt.PointingHandCursor)
        self.gen_spline_btn.setFixedWidth(75)  # VON 60 AUF 70 ERHÖHT
        self.gen_spline_btn.clicked.connect(self._on_generate_spline)
        self.gen_spline_btn.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_purple', 150)};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 4px 8px;
                font-size: 8pt;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_purple')};
            }}
            QPushButton:pressed {{
                background: {Theme.rgba('accent_purple', 200)};
            }}
        """)
        spline_row.addWidget(self.gen_spline_btn)

        # Glättungsstärke
        self.smooth_spin = QDoubleSpinBox()
        self.smooth_spin.setRange(0.1, 0.9)
        self.smooth_spin.setValue(0.3)
        self.smooth_spin.setSingleStep(0.1)
        self.smooth_spin.setFixedWidth(75)  # VON 45 AUF 55 ERHÖHT
        self.smooth_spin.setToolTip("Glättungsstärke (0.1 = wenig, 0.9 = stark)")
        self.smooth_spin.setStyleSheet(f"""
            QDoubleSpinBox {{
                background: {Theme.rgba('bg_primary', 150)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 3px;
                font-size: 8pt;
            }}
            QDoubleSpinBox:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
        """)
        spline_row.addWidget(self.smooth_spin)

        # Glätten Button - BREITER!
        self.smooth_btn = QPushButton("Glätten")
        self.smooth_btn.setCursor(Qt.PointingHandCursor)
        self.smooth_btn.setFixedWidth(65)  # VON 50 AUF 65 ERHÖHT
        self.smooth_btn.clicked.connect(self.smooth_spline)
        self.smooth_btn.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_green', 150)};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 4px 8px;
                font-size: 8pt;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_green')};
            }}
            QPushButton:pressed {{
                background: {Theme.rgba('accent_green', 200)};
            }}
        """)
        spline_row.addWidget(self.smooth_btn)

        control_layout.addLayout(spline_row)
        
        # Trennlinie
        sep2 = QFrame()
        sep2.setFrameShape(QFrame.VLine)
        sep2.setStyleSheet(f"background: {Theme.rgba('border')}; width: 1px;")
        control_layout.addWidget(sep2)
        
        # === v_max Eingabe ===
        vmax_label = QLabel("v-max:")
        vmax_label.setStyleSheet(f"color: {Theme.rgb('text_primary')}; font-size: 8pt;")
        control_layout.addWidget(vmax_label)
        
        self.vmax_spin = QDoubleSpinBox()
        self.vmax_spin.setRange(1.0, 500.0)
        self.vmax_spin.setValue(self.vmax_value)
        self.vmax_spin.setSingleStep(5.0)
        self.vmax_spin.setSuffix(" mm/s")
        self.vmax_spin.setFixedWidth(120)
        self.vmax_spin.setStyleSheet(f"""
            QDoubleSpinBox {{
                background: {Theme.rgba('bg_primary', 150)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 3px;
                font-size: 8pt;
            }}
            QDoubleSpinBox:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
        """)
        self.vmax_spin.valueChanged.connect(self._on_vmax_changed)
        control_layout.addWidget(self.vmax_spin)
        
        # === NEU: Record-Start Checkbox ===
        self.use_record_start = QCheckBox("Record-Start")
        self.use_record_start.setChecked(False)
        self.use_record_start.setToolTip("Startposition aus dem Original-Record verwenden")
        self.use_record_start.setStyleSheet(f"""
            QCheckBox {{
                color: {Theme.rgb('text_primary')};
                font-size: 8pt;
                spacing: 4px;
                margin-left: 5px;
            }}
            QCheckBox::indicator {{
                width: 14px;
                height: 14px;
                background: {Theme.rgba('bg_primary', 150)};
                border: 1px solid {Theme.rgba('border')};
                border-radius: 3px;
            }}
            QCheckBox::indicator:checked {{
                background: {Theme.rgba('accent_blue')};
            }}
            QCheckBox::indicator:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
        """)
        control_layout.addWidget(self.use_record_start)
        
        # Trennlinie
        sep3 = QFrame()
        sep3.setFrameShape(QFrame.VLine)
        sep3.setStyleSheet(f"background: {Theme.rgba('border')}; width: 1px;")
        control_layout.addWidget(sep3)
        
        # === Bewegung generieren Button ===
        self.gen_movement_btn = QPushButton("Bewegung")
        self.gen_movement_btn.setCursor(Qt.PointingHandCursor)
        self.gen_movement_btn.setFixedWidth(70)
        self.gen_movement_btn.clicked.connect(self._on_movement_clicked)
        self.gen_movement_btn.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_red', 150)};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 4px 8px;
                font-size: 8pt;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_red')};
            }}
            QPushButton:pressed {{
                background: {Theme.rgba('accent_red', 200)};
            }}
        """)
        control_layout.addWidget(self.gen_movement_btn)
        
        # === Hinweis für Rechtsklick ===
        hint_label = QLabel("Rechtsklick: Punkt löschen")
        hint_label.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgba('text_secondary', 180)};
                font-size: 7pt;
                font-style: italic;
                padding-left: 10px;
            }}
        """)
        control_layout.addWidget(hint_label)
        
        control_layout.addStretch()
        
        self.update_timer = QTimer()
        self.update_timer.setSingleShot(True)
        self.update_timer.setInterval(50)
        self.update_timer.timeout.connect(self._apply_preview)
        
        self.control_panel.hide()

    def _on_vmax_changed(self, value):
        """Wird aufgerufen wenn v-max geändert wird"""
        self.vmax_value = value
        if self.track and hasattr(self.track, 'max_speed'):
            self.track.max_speed = value

    def _on_movement_clicked(self):
        """Wird aufgerufen wenn Bewegung generieren geklickt wird"""
        print(f"🏃 Bewegung generieren geklickt für Track: {self.track.name if self.track else 'None'}")
        self.generate_movement_clicked.emit()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, 'control_panel'):
            panel_height = 30
            self.control_panel.setGeometry(
                0, self.height() - panel_height,
                self.width(), panel_height
            )

    def set_track(self, track):
        self.track = track
        self.dragging = False
        self.drag_index = -1
        self.hover_index = -1
        self.spline_points = []
        self.preview_points = []
        self.preview_spline = None

        if track and hasattr(track, 'pedals') and track.pedals is not None:

            num_samples = len(track.pedals)

            # 🔥 ECHTE ZEITACHSE VERWENDEN – niemals 0..1 erzeugen!
            if hasattr(track, "record_times") and track.record_times is not None:
                self.time_data = np.array(track.record_times, dtype=float)
            else:
                # Fallback nur wenn wirklich kein Recording geladen wurde
                self.time_data = np.linspace(0, 1, num_samples)

            # 🔥 Pedalwerte IMMER als Kopie laden
            if isinstance(track.pedals, np.ndarray):
                self.pedal_data = track.pedals.copy()
            else:
                self.pedal_data = np.array(track.pedals, dtype=float)

            # 🔥 Originalwerte sichern (für Reset)
            self.original_pedals = self.pedal_data.copy()

            # v-max übernehmen
            if hasattr(track, 'max_speed'):
                self.vmax_value = track.max_speed
                self.vmax_spin.setValue(track.max_speed)

        else:
            self.time_data = None
            self.pedal_data = None
            self.original_pedals = None

        self.update()

    def set_marker(self, t_global):
        self.marker_pos = max(0.0, min(1.0, t_global))
        self.update()
    
    def set_mode(self, mode: PedalMode):
        self.mode = mode
        if mode == PedalMode.SPLINE:
            self.control_panel.show()
        else:
            self.control_panel.hide()
        self.update()
        self.mode_changed.emit(mode)
    
    def reset_to_samples(self):
        if self.original_pedals is not None:
            for i in range(len(self.pedal_data)):
                self.pedal_data[i] = self.original_pedals[i]
            self.spline_points = []
            self.update()
    
    def _on_generate_spline(self):
        self.generate_spline_clicked.emit(self.points_spin.value())
    
    def generate_spline(self, num_points=10):
        if self.time_data is None or self.pedal_data is None:
            return
        
        indices = np.linspace(0, len(self.time_data)-1, num_points, dtype=int)
        self.spline_points = [
            (float(self.time_data[i]), float(self.pedal_data[i])) for i in indices
        ]
        self.spline_points_updated.emit()
        self.update()
    
    def smooth_spline(self):
        """Glättet den Spline durch Reduzierung der Punkte"""
        if len(self.spline_points) < 4:
            return
        
        factor = self.smooth_spin.value()
        num_points = max(4, int(len(self.spline_points) * (1 - factor)))
        
        if len(self.spline_points) >= 4:
            points = sorted(self.spline_points, key=lambda p: p[0])
            times = [p[0] for p in points]
            values = [p[1] for p in points]
            
            try:
                spline = interpolate.CubicSpline(times, values, bc_type='natural')
                t_min, t_max = min(times), max(times)
                new_times = np.linspace(t_min, t_max, num_points)
                new_values = spline(new_times)
                new_values = np.clip(new_values, -1.0, 1.0)
                
                self.spline_points = [(float(t), float(v)) for t, v in zip(new_times, new_values)]
                self.apply_spline()
                self.spline_points_updated.emit()
                self.update()
                
            except Exception as e:
                print(f"Glättungsfehler: {e}")
    
    def apply_spline(self):
        if self.time_data is None or len(self.spline_points) < 2:
            return

        points = sorted(self.spline_points, key=lambda p: p[0])
        times = np.array([p[0] for p in points], dtype=float)
        values = np.array([p[1] for p in points], dtype=float)

        try:
            if len(points) >= 4:
                spline = interpolate.CubicSpline(times, values, bc_type='natural')
            else:
                spline = interpolate.interp1d(
                    times, values, kind='linear', fill_value='extrapolate'
                )

            new_pedals = spline(self.time_data)
            new_pedals = np.clip(new_pedals, -1.0, 1.0)

            # 🔥 KEINE Filter mehr - nur noch die Spline-Werte!
            self.pedal_data = new_pedals.astype(float)
            self.update()

        except Exception as e:
            print(f"Spline-Fehler: {e}")
    
    def remove_spline_point(self, index):
        if 0 <= index < len(self.spline_points):
            del self.spline_points[index]
            if len(self.spline_points) >= 2:
                self.apply_spline()
            self.spline_points_updated.emit()
            self.update()
    
    def _create_preview_spline(self, points):
        if len(points) < 2:
            return None
        
        p_sorted = sorted(points, key=lambda p: p[0])
        times = [p[0] for p in p_sorted]
        values = [p[1] for p in p_sorted]
        
        try:
            if len(points) >= 4:
                return interpolate.CubicSpline(times, values, bc_type='natural')
            else:
                return interpolate.interp1d(times, values, kind='linear', 
                                          fill_value='extrapolate')
        except:
            return None
    
    def _apply_preview(self):
        if self.preview_spline is not None and self.preview_points:
            self.spline_points = self.preview_points.copy()
            self.apply_spline()
            self.preview_spline = None
            self.preview_points = []
    
    # === Interaktion ===
    
    def _find_spline_point(self, pos, content_rect):
        points = self.preview_points if self.preview_points else self.spline_points
        if not points:
            return -1
        
        t_min = self.time_data[0]
        t_max = self.time_data[-1]
        span = max(1e-6, t_max - t_min)
        h = content_rect.height()
        y_zero = content_rect.top() + h / 2
        
        for i, (t, v) in enumerate(points):
            t_norm = (t - t_min) / span
            x = self.map_t_to_x(t_norm, content_rect)
            y = y_zero - (v * h / 2)
            
            dx = abs(pos.x() - int(x))
            dy = abs(pos.y() - int(y))
            
            if dx < 15 and dy < 25:
                return i
        return -1

    def mousePressEvent(self, event: QMouseEvent):
        if self.time_data is None:
            return
            
        content = self.get_content_rect()
        if not content.contains(event.pos()):
            return

        if event.button() == Qt.RightButton and self.mode == PedalMode.SPLINE:
            idx = self._find_spline_point(event.pos(), content)
            if idx >= 0:
                self.remove_spline_point(idx)
                event.accept()
                return

        if event.button() == Qt.LeftButton and self.mode == PedalMode.SPLINE:
            idx = self._find_spline_point(event.pos(), content)
            if idx >= 0:
                self.dragging = True
                self.drag_index = idx
                self.preview_points = self.spline_points.copy()
                self.setCursor(Qt.ClosedHandCursor)
                event.accept()

    def mouseMoveEvent(self, event: QMouseEvent):
        if self.time_data is None:
            return
            
        content = self.get_content_rect()
        
        if self.dragging and self.drag_index >= 0 and self.preview_points:
            y_zero = content.top() + content.height() / 2
            y = event.pos().y()
            
            new_pedal = -(y - y_zero) / (content.height() / 2)
            new_pedal = max(-1.0, min(1.0, new_pedal))
            
            if self.drag_index < len(self.preview_points):
                t, _ = self.preview_points[self.drag_index]
                
                if self.x_movable:
                    t_norm = self.map_x_to_t(event.pos().x(), content)
                    t_min = self.time_data[0]
                    t_max = self.time_data[-1]
                    new_t = t_min + t_norm * (t_max - t_min)
                    new_t = max(t_min, min(t_max, new_t))
                    
                    if self.drag_index > 0:
                        prev_t = self.preview_points[self.drag_index - 1][0]
                        new_t = max(new_t, prev_t + 0.001)
                    if self.drag_index < len(self.preview_points) - 1:
                        next_t = self.preview_points[self.drag_index + 1][0]
                        new_t = min(new_t, next_t - 0.001)
                    
                    self.preview_points[self.drag_index] = (new_t, new_pedal)
                else:
                    self.preview_points[self.drag_index] = (t, new_pedal)
                
                self.preview_spline = self._create_preview_spline(self.preview_points)
                self.update()
            
            event.accept()
        else:
            old_hover = self.hover_index
            self.hover_index = self._find_spline_point(event.pos(), content)
            
            if self.hover_index >= 0:
                self.setCursor(Qt.PointingHandCursor)
            else:
                self.setCursor(Qt.ArrowCursor)
            
            if old_hover != self.hover_index:
                self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if self.dragging:
            self.dragging = False
            self.drag_index = -1
            self.setCursor(Qt.ArrowCursor)
            
            if self.mode == PedalMode.SPLINE and self.preview_points:
                self.spline_points = self.preview_points.copy()
                self.spline_points = sorted(self.spline_points, key=lambda p: p[0])
                self.apply_spline()
                self.preview_points = []
                self.preview_spline = None
            
            event.accept()

    def mouseDoubleClickEvent(self, event: QMouseEvent):
        if self.time_data is None or self.mode != PedalMode.SPLINE:
            return
        
        content = self.get_content_rect()
        if not content.contains(event.pos()):
            return
        
        t_norm = self.map_x_to_t(event.pos().x(), content)
        t = self.time_data[0] + t_norm * (self.time_data[-1] - self.time_data[0])
        
        h = content.height()
        y_zero = content.top() + h / 2
        value = (y_zero - event.pos().y()) / (h / 2)
        value = max(-1.0, min(1.0, value))
        
        self.spline_points.append((t, value))
        self.spline_points = sorted(self.spline_points, key=lambda p: p[0])
        self.apply_spline()
        self.spline_points_updated.emit()
        self.update()
        event.accept()

    def leaveEvent(self, event):
        self.hover_index = -1
        self.setCursor(Qt.ArrowCursor)
        self.update()
        super().leaveEvent(event)

    # === Zeichnen ===
    
    def paintEvent(self, event):
        if self.time_data is None or self.pedal_data is None:
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)
            self.draw_background(painter)
            painter.setPen(Theme.color('text_secondary'))
            painter.drawText(self.rect(), Qt.AlignCenter, "Keine Pedaldaten")
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        self.draw_background(painter)

        # Zeichenbereich für den Graphen (mit Padding)
        if self.mode == PedalMode.SPLINE:
            graph_rect = self.rect().adjusted(
                self.LEFT_PADDING, self.TOP_PADDING,
                -self.RIGHT_PADDING, -self.BOTTOM_PADDING - 30  # Platz für Controls
            )
        else:
            graph_rect = self.rect().adjusted(
                self.LEFT_PADDING, self.TOP_PADDING,
                -self.RIGHT_PADDING, -self.BOTTOM_PADDING
            )
        
        w = graph_rect.width()
        h = graph_rect.height()
        x_offset = graph_rect.left()
        y_offset = graph_rect.top()
        y_zero = y_offset + h / 2

        # Gitter
        self.draw_grid(painter, graph_rect)
        
        # Null-Linie
        painter.setPen(QPen(Theme.color('border'), 1, Qt.DashLine))
        painter.drawLine(graph_rect.left(), int(y_zero), graph_rect.right(), int(y_zero))

        # Pedal-Beschriftung (links)
        painter.setPen(Theme.color('text_secondary'))
        painter.setFont(Theme.FONT_TINY)
        painter.drawText(2, y_offset + 10, "+100%")
        painter.drawText(2, int(y_zero) - 5, "0%")
        painter.drawText(2, y_offset + h - 5, "-100%")

        # Kurve zeichnen
        points_to_draw = self.time_data
        values_to_draw = self.pedal_data
        
        if self.preview_spline is not None and self.preview_points:
            try:
                preview_values = self.preview_spline(self.time_data)
                values_to_draw = np.clip(preview_values, -1.0, 1.0)
            except:
                pass
        
        if len(points_to_draw) > 1:
            pts = []
            for t, v in zip(points_to_draw, values_to_draw):
                x = self.map_t_to_x(t, graph_rect)
                y = y_zero - (v * h / 2)
                pts.append((int(x), int(y)))
            
            if self.preview_spline:
                painter.setPen(QPen(Theme.color('accent'), 3, Qt.DashLine))
            else:
                painter.setPen(QPen(Theme.color('pedal'), 2))
            
            for i in range(len(pts) - 1):
                painter.drawLine(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])
            
            if self.mode == PedalMode.SPLINE:
                points_to_show = self.preview_points if self.preview_points else self.spline_points
                for i, (t, v) in enumerate(points_to_show):
                    x = self.map_t_to_x(t, graph_rect)
                    y = y_zero - (v * h / 2)
                    
                    if self.preview_points and i == self.drag_index:
                        painter.setBrush(QBrush(Theme.color('accent_red')))
                        radius = self.point_radius + 4
                    elif i == self.drag_index:
                        painter.setBrush(QBrush(Theme.color('accent_red')))
                        radius = self.point_radius + 3
                    elif i == self.hover_index:
                        painter.setBrush(QBrush(Theme.color('accent')))
                        radius = self.point_radius + 2
                    else:
                        painter.setBrush(QBrush(Theme.color('accent_purple')))
                        radius = self.point_radius
                    
                    painter.setPen(QPen(Theme.color('text_primary'), 1))
                    painter.drawEllipse(QPoint(x, y), radius, radius)

        # Marker
        marker_x = self.map_t_to_x(self.marker_pos, graph_rect)
        painter.setPen(QPen(Theme.color('marker'), 2))
        painter.drawLine(int(marker_x), graph_rect.top(), int(marker_x), graph_rect.bottom())
        
        painter.end()