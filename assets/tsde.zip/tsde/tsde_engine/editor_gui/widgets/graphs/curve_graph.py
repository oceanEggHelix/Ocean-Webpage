# editor_gui/widgets/graphs/curve_graph.py

from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QPainter, QPen, QBrush, QMouseEvent
import numpy as np

from ...theme import Theme
from .base_graph import BaseGraph

class CurveGraph(BaseGraph):
    """Zeigt die geografische Kurve (Position auf Kurve)"""
    
    def __init__(self, parent=None):
        super().__init__(parent)

        self.curve = None
        self.track = None
        self.t_current = 0.0  # Aktuelle Position (0-1)
        
        # Startpunkt für Bewegungsberechnung (grün)
        self.start_pos = None  # None = original t_start aus Record
        
        # Skalierung
        self.min_y = -1
        self.max_y = 1
        
        # Padding für die Kurve
        self.LEFT_PADDING = 35    # Platz für Y-Beschriftung LINKS
        self.RIGHT_PADDING = 40   # Platz rechts
        self.TOP_PADDING = 15      # Platz oben
        self.BOTTOM_PADDING = 20   # Platz für X-Achsen-Beschriftung UNTEN
        
        self.setMinimumHeight(150)

    def set_curve(self, curve, track=None):
        """Setzt Kurve und Track"""
        self.curve = curve
        self.track = track
        self._update_y_range()
        self.update()

    def set_marker(self, t_pos):
        """Setzt Marker-Position (0-1)"""
        self.t_current = max(0.0, min(1.0, t_pos))
        self.update()
    
    def set_start_marker(self, t_pos):
        """Setzt einen grünen Start-Marker (für Bewegungsberechnung)"""
        if t_pos is None:
            self.start_pos = None
        else:
            self.start_pos = max(0.0, min(1.0, t_pos))
        self.update()
    
    def get_start_position(self):
        """Gibt den Startpunkt zurück (None = original Record)"""
        return self.start_pos
    
    def _update_y_range(self):
        """Berechnet Y-Bereich der Kurve"""
        if not self.curve:
            return
        
        y_vals = []
        for i in range(200):
            t = i / 199
            try:
                p = self.curve.evaluate(t)
                y_vals.append(p.x)
            except:
                pass

        if y_vals:
            self.min_y = min(y_vals)
            self.max_y = max(y_vals)
            pad = (self.max_y - self.min_y) * 0.1
            self.min_y -= pad
            self.max_y += pad

    def mousePressEvent(self, event: QMouseEvent):
        """Rechtsklick setzt Start-Marker"""
        if event.button() == Qt.RightButton and self.curve:
            # Position in t umrechnen
            graph_rect = self.rect().adjusted(
                self.LEFT_PADDING, self.TOP_PADDING,
                -self.RIGHT_PADDING, -self.BOTTOM_PADDING
            )
            t = self._map_x_to_t(event.pos().x(), graph_rect)
            self.set_start_marker(t)
            event.accept()
        else:
            super().mousePressEvent(event)
    
    def _map_x_to_t(self, x, graph_rect):
        """Hilfsfunktion: x-Position zu t-Wert"""
        rel_x = (x - graph_rect.left()) / graph_rect.width()
        rel_x = max(0.0, min(1.0, rel_x))
        return rel_x

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Hintergrund
        painter.fillRect(self.rect(), Theme.color('bg_graph'))

        if not self.curve:
            painter.setPen(Theme.color('text_secondary'))
            painter.drawText(self.rect(), Qt.AlignCenter, "Keine Kurve geladen")
            return

        # Zeichenbereich für den Graphen (mit Padding für Achsen)
        graph_rect = self.rect().adjusted(
            self.LEFT_PADDING, self.TOP_PADDING,
            -self.RIGHT_PADDING, -self.BOTTOM_PADDING
        )
        
        w = graph_rect.width()
        h = graph_rect.height()
        x_offset = graph_rect.left()
        y_offset = graph_rect.top()

        # Gitter (im graph_rect)
        self._draw_grid(painter, graph_rect)
        
        # Y-Achsen-Beschriftung (LINKS im Padding-Bereich)
        painter.setPen(Theme.color('text_secondary'))
        painter.setFont(Theme.FONT_TINY)
        
        for i in range(0, 11, 2):
            y = y_offset + int((1 - i/10) * h)
            value = self.min_y + (self.max_y - self.min_y) * i/10
            
            # Text links vom Graphen (bei x=5)
            painter.drawText(5, y + 3, f"{value:.1f}")

        # X-Achsen-Beschriftung (UNTEN im Padding-Bereich)
        for i in range(0, 11, 2):
            x = x_offset + int(i * w / 10)
            value = i/10
            painter.drawText(x - 10, self.height() - 5, f"{value:.1f}")

        # Start-Marker (grün) zeichnen
        if self.start_pos is not None:
            start_x = x_offset + int(self.start_pos * w)
            painter.setPen(QPen(Theme.color('accent_green'), 2))
            painter.drawLine(start_x, y_offset, start_x, y_offset + h)

        # Kurve
        self._draw_curve(painter, graph_rect)

        # Marker
        self._draw_marker(painter, graph_rect)

    def _draw_grid(self, painter, rect):
        """Zeichnet Gitter im angegebenen Rechteck"""
        painter.setPen(QPen(Theme.color('grid'), 1, Qt.DotLine))
        
        w = rect.width()
        h = rect.height()
        left = rect.left()
        top = rect.top()
        
        # Vertikale Gitterlinien
        for i in range(1, 10):
            x = left + i * w / 10
            painter.drawLine(int(x), top, int(x), top + h)
        
        # Horizontale Gitterlinien
        for i in range(1, 10):
            y = top + i * h / 10
            painter.drawLine(left, int(y), left + w, int(y))

    def _draw_curve(self, painter, graph_rect):
        """Zeichnet die Kurve"""
        painter.setPen(QPen(Theme.color('curve'), 2))
        
        w = graph_rect.width()
        h = graph_rect.height()
        x_offset = graph_rect.left()
        y_offset = graph_rect.top()
        
        pts = []
        for i in range(200):
            t = i / 199
            try:
                p = self.curve.evaluate(t)
                x = x_offset + int(t * w)
                y_norm = (p.x - self.min_y) / (self.max_y - self.min_y)
                y = y_offset + int(h - y_norm * h)
                pts.append((x, y))
            except:
                pass

        for i in range(len(pts) - 1):
            painter.drawLine(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])

    def _draw_marker(self, painter, graph_rect):
        """Zeichnet den Marker"""
        w = graph_rect.width()
        h = graph_rect.height()
        x_offset = graph_rect.left()
        y_offset = graph_rect.top()
        
        marker_x = x_offset + int(self.t_current * w)
        
        # Marker-Linie (nur im Graphen)
        painter.setPen(QPen(Theme.color('marker'), 2))
        painter.drawLine(marker_x, y_offset, marker_x, y_offset + h)

        try:
            p = self.curve.evaluate(self.t_current)
            y_norm = (p.x - self.min_y) / (self.max_y - self.min_y)
            point_y = y_offset + int(h - y_norm * h)
            
            # Punkt auf Kurve
            painter.setBrush(QBrush(Theme.color('marker')))
            painter.drawEllipse(marker_x - 5, point_y - 5, 10, 10)
            
        except:
            pass