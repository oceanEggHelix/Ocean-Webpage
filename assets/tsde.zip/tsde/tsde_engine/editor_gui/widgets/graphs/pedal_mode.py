# editor_gui/widgets/graphs/pedal_mode.py

from enum import Enum

class PedalMode(Enum):
    SAMPLES = "Samples"      # Original-Samples
    SPLINE = "Spline"        # Editierbarer Spline