# E:\TSDE\tsde_engine\editor_gui\widgets\vtk\overlays\camera_rig_overlay.py

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QComboBox, QDoubleSpinBox, QLabel, QPushButton, QGridLayout, QMessageBox
from PySide6.QtCore import Signal, Qt,QTimer

from tsde_engine.editor_gui.theme import Theme


class CameraRigOverlay(QWidget):
    """Overlay für Kamera-Rig Steuerung - nur im Gruppenmodus sichtbar"""
   
    # Signale
    toggled = Signal(bool)                    # Rig ein/aus
    tracks_changed = Signal(str, str)          # (kamera_track, ziel_track)
    distance_changed = Signal(float)           # Abstand hinter Kamera-Track
    height_changed = Signal(float)             # Höhenversatz
    focal_length_changed = Signal(float)       # Brennweite in mm
    sensor_width_changed = Signal(float)       # Sensor-Größe in mm
   
    def __init__(self, parent=None):
        super().__init__(parent)
       
        # Fenster-Flags für Overlay
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
       
        self._group_mode = False  # Track-Modus/Group-Modus Status
        self._track_names = []    # Für Prüfungen
       
        self._setup_ui()
        self._connect_signals()
       
        # Initial versteckt
        self.hide()
   
    def _setup_ui(self):
        """Baut die UI auf - JETZT mit FESTER HÖHE und automatischer Anpassung!"""
        
        # === 1. FESTE HÖHE für das Haupt-Widget ===
        self.setFixedHeight(300)  # 285<-- Perfekt für deinen Frame!
        
        # Hauptcontainer mit semi-transparentem Hintergrund
        container = QWidget()
        container.setStyleSheet(f"""
            QWidget {{
                background: {Theme.rgba('bg_primary', 200)};
                border: 1px solid {Theme.rgba('accent_blue')};
                border-radius: {Theme.RADIUS_MEDIUM}px;
            }}
            QGroupBox {{
                color: {Theme.rgb('text_primary')};
                font-weight: bold;
                font-size: 8pt;
                border: 1px solid {Theme.rgba('border', 100)};
                border-radius: {Theme.RADIUS_SMALL}px;
                margin-top: 6px;
                padding-top: 8px;
                padding-bottom: 3px;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 8px;
                padding: 0 3px 0 3px;
            }}
            QLabel {{
                color: {Theme.rgb('text_secondary')};
                font-size: 8pt;
                padding: 2px 0;
            }}
            QComboBox, QDoubleSpinBox {{
                background: {Theme.rgba('bg_secondary', 200)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 2px;
                min-width: 85px;
                max-width: 100px;
                font-size: 8pt;
                max-height: 18px;
            }}
            QComboBox:hover, QDoubleSpinBox:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
            QComboBox:disabled, QDoubleSpinBox:disabled {{
                background: {Theme.rgba('bg_secondary', 50)};
                color: {Theme.rgba('text_secondary', 100)};
                border: 1px solid {Theme.rgba('border', 50)};
            }}
            QPushButton {{
                background: {Theme.rgba('bg_secondary', 200)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 4px 6px;
                font-weight: bold;
                font-size: 10pt;
                min-width: 100px;
                max-height: 20px;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_blue', 150)};
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
            QPushButton:checked {{
                background: {Theme.rgba('accent_green', 180)};
                border: 1px solid {Theme.rgba('accent_green')};
            }}
            QPushButton:disabled {{
                background: {Theme.rgba('bg_secondary', 50)};
                color: {Theme.rgba('text_secondary', 100)};
                border: 1px solid {Theme.rgba('border', 50)};
            }}
        """)
       
        # === 2. Hauptlayout für DAS WIDGET SELF ===
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(2)
       
        # === 3. Layout für den Container ===
        main_layout = QVBoxLayout(container)
        main_layout.setSpacing(3)
        main_layout.setContentsMargins(4, 4, 4, 4)
       
        # === 4. TRACK-AUSWAHL ===
        track_group = QGroupBox("Tracks")
        track_layout = QGridLayout()
        track_layout.setHorizontalSpacing(6)
        track_layout.setVerticalSpacing(6)
        track_layout.setContentsMargins(4, 2, 4, 2)
       
        track_layout.addWidget(QLabel("Kamera:"), 0, 0)
        self.cam_track_combo = QComboBox()
        self.cam_track_combo.setPlaceholderText("...")
        track_layout.addWidget(self.cam_track_combo, 0, 1)
       
        track_layout.addWidget(QLabel("Ziel:"), 1, 0)
        self.target_track_combo = QComboBox()
        self.target_track_combo.setPlaceholderText("...")
        track_layout.addWidget(self.target_track_combo, 1, 1)
       
        track_group.setLayout(track_layout)
        main_layout.addWidget(track_group)
       
        # === 5. POSITIONS-PARAMETER ===
        pos_group = QGroupBox("Position")
        pos_layout = QGridLayout()
        pos_layout.setHorizontalSpacing(6)
        pos_layout.setVerticalSpacing(6)
        pos_layout.setContentsMargins(4, 2, 4, 2)
       
        pos_layout.addWidget(QLabel("Abstand:"), 0, 0)
        self.distance_spin = QDoubleSpinBox()
        self.distance_spin.setRange(-10, 500)
        self.distance_spin.setValue(0)
        self.distance_spin.setSuffix(" mm")
        self.distance_spin.setSingleStep(5)
        self.distance_spin.setButtonSymbols(QDoubleSpinBox.NoButtons)
        pos_layout.addWidget(self.distance_spin, 0, 1)
       
        pos_layout.addWidget(QLabel("Höhe:"), 1, 0)
        self.height_spin = QDoubleSpinBox()
        self.height_spin.setRange(-50, 50)
        self.height_spin.setValue(0)
        self.height_spin.setSuffix(" mm")
        self.height_spin.setSingleStep(2)
        self.height_spin.setButtonSymbols(QDoubleSpinBox.NoButtons)
        pos_layout.addWidget(self.height_spin, 1, 1)
       
        pos_group.setLayout(pos_layout)
        main_layout.addWidget(pos_group)
       
        # === 6. KAMERA-PARAMETER ===
        cam_group = QGroupBox("Kamera")
        cam_layout = QGridLayout()
        cam_layout.setHorizontalSpacing(6)
        cam_layout.setVerticalSpacing(6)
        cam_layout.setContentsMargins(4, 2, 4, 2)
       
        cam_layout.addWidget(QLabel("Brennw.:"), 0, 0)
        self.focal_spin = QDoubleSpinBox()
        self.focal_spin.setRange(8, 400)
        self.focal_spin.setValue(50)
        self.focal_spin.setSuffix(" mm")
        self.focal_spin.setSingleStep(5)
        self.focal_spin.setButtonSymbols(QDoubleSpinBox.NoButtons)
        cam_layout.addWidget(self.focal_spin, 0, 1)
       
        cam_layout.addWidget(QLabel("Sensor:"), 1, 0)
        self.sensor_spin = QDoubleSpinBox()
        self.sensor_spin.setRange(1, 100)
        self.sensor_spin.setValue(36)
        self.sensor_spin.setSuffix(" mm")
        self.sensor_spin.setSingleStep(1)
        self.sensor_spin.setButtonSymbols(QDoubleSpinBox.NoButtons)
        cam_layout.addWidget(self.sensor_spin, 1, 1)
       
        cam_group.setLayout(cam_layout)
        main_layout.addWidget(cam_group)
       
        # === 7. Info-Label für View Angle ===
        self.angle_label = QLabel("➤ 39.6°")
        self.angle_label.setAlignment(Qt.AlignCenter)
        self.angle_label.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgb('accent_blue')};
                font-size: 8pt;
                font-weight: bold;
                background: {Theme.rgba('bg_secondary', 100)};
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 3px;
                margin: 5px 0;
                max-height: 16px;
            }}
        """)
        main_layout.addWidget(self.angle_label)
       
        # === 8. Aktivierungs-Button ===
        self.toggle_btn = QPushButton("● Aktivieren")
        self.toggle_btn.setCheckable(True)
        self.toggle_btn.setChecked(False)
        self.toggle_btn.setMinimumWidth(80)
        self.toggle_btn.clicked.connect(self._on_toggle_clicked)
        main_layout.addWidget(self.toggle_btn)
       
        # === 9. Container zum Hauptlayout hinzufügen ===
        layout.addWidget(container)
        main_layout.addStretch(0)
   
    def _connect_signals(self):
        """Verbindet interne Signale"""
        self.cam_track_combo.currentTextChanged.connect(self._on_tracks_changed)
        self.target_track_combo.currentTextChanged.connect(self._on_tracks_changed)
       
        self.distance_spin.valueChanged.connect(self.distance_changed.emit)
        self.height_spin.valueChanged.connect(self.height_changed.emit)
        self.focal_spin.valueChanged.connect(self._on_focal_changed)
        self.sensor_spin.valueChanged.connect(self._on_sensor_changed)
       
        self._update_angle_label()
   
    def set_mode(self, is_group_mode, timeline_playing=False):
        """
        Setzt den Modus (Track/Group) und aktualisiert UI
        timeline_playing: True wenn Timeline gerade läuft
        """
        self._group_mode = is_group_mode
        
        # 🔥 BUTTON NUR FREI wenn: Group Mode + Timeline NICHT läuft
        controls_enabled = is_group_mode and not timeline_playing
        
        self.cam_track_combo.setEnabled(controls_enabled)
        self.target_track_combo.setEnabled(controls_enabled)
        self.distance_spin.setEnabled(controls_enabled)
        self.height_spin.setEnabled(controls_enabled)
        self.focal_spin.setEnabled(controls_enabled)
        self.sensor_spin.setEnabled(controls_enabled)
        self.toggle_btn.setEnabled(controls_enabled)
        
        # Tooltip für den Fall dass Timeline läuft
        if timeline_playing and is_group_mode:
            tooltip = "⛔ Timeline läuft - Bitte Playback stoppen"
            self.cam_track_combo.setToolTip(tooltip)
            self.target_track_combo.setToolTip(tooltip)
            self.toggle_btn.setToolTip(tooltip)
        else:
            self.cam_track_combo.setToolTip("")
            self.target_track_combo.setToolTip("")
            self.toggle_btn.setToolTip("")
        
        if not is_group_mode:
            # Beim Wechsel in Track-Modus:
            if self.toggle_btn.isChecked():
                self.toggle_btn.setChecked(False)
                self.toggled.emit(False)
            
            self.toggle_btn.setText("⬤ Kamera-Rig (nur Gruppe)")
            self.cam_track_combo.setStyleSheet("")
            self.target_track_combo.setStyleSheet("")
            self.cam_track_combo.setPlaceholderText("...")
            self.target_track_combo.setPlaceholderText("...")
            
        else:
            self.toggle_btn.setText("⬤ Kamera-Rig aktivieren")
            self.cam_track_combo.setStyleSheet("")
            self.target_track_combo.setStyleSheet("")
   
    def _update_ui_for_active_state(self, active):
        """EINZIGE Methode für Rahmen-Update"""
        if active:
            self.toggle_btn.setText("⬤ Kamera-Rig aktiv")
            # NUR GRÜN wenn aktiv
            self.cam_track_combo.setStyleSheet(f"""
                QComboBox {{
                    background: {Theme.rgba('bg_secondary', 200)};
                    color: {Theme.rgb('text_primary')};
                    border: 2px solid {Theme.rgba('accent_green')};
                    border-radius: {Theme.RADIUS_SMALL}px;
                    padding: 2px;
                    min-width: 85px;
                    max-width: 100px;
                    font-size: 8pt;
                    max-height: 18px;
                }}
            """)
            self.target_track_combo.setStyleSheet(f"""
                QComboBox {{
                    background: {Theme.rgba('bg_secondary', 200)};
                    color: {Theme.rgb('text_primary')};
                    border: 2px solid {Theme.rgba('accent_green')};
                    border-radius: {Theme.RADIUS_SMALL}px;
                    padding: 2px;
                    min-width: 85px;
                    max-width: 100px;
                    font-size: 8pt;
                    max-height: 18px;
                }}
            """)
        else:
            self.toggle_btn.setText("⬤ Kamera-Rig aktivieren")
            # GAR KEIN Rahmen - komplett leer!
            self.cam_track_combo.setStyleSheet("")
            self.target_track_combo.setStyleSheet("")
   
    def _on_toggle_clicked(self, checked):
        """Spezieller Handler für Toggle-Button mit Prüfung"""
        if not self._group_mode:
            self.toggle_btn.setChecked(False)
            QMessageBox.warning(
                self,
                "Gruppenmodus erforderlich",
                "Bitte zuerst in den Gruppenmodus wechseln!\n\n"
                "1. Oben im VTK-Overlay auf 'Group' umschalten\n"
                "2. Eine Gruppe aus den Tracks auswählen"
            )
            return
    
        # Prüfen ob Tracks vorhanden sind
        if len(self._track_names) < 2:
            self.toggle_btn.setChecked(False)
            QMessageBox.warning(
                self,
                "Keine Tracks verfügbar",
                "Es sind nicht genügend Tracks für das Kamera-Rig vorhanden.\n\n"
                "Bitte zuerst Tracks laden oder generieren."
            )
            return
    
        # Prüfen ob beide Combos gültige Werte haben
        cam = self.cam_track_combo.currentText()
        target = self.target_track_combo.currentText()
    
        if not cam or not target:
            self.toggle_btn.setChecked(False)
            QMessageBox.warning(
                self,
                "Tracks nicht ausgewählt",
                "Bitte wählen Sie zuerst Kamera- und Ziel-Tracks aus!"
            )
            return
    
        if cam == target:
            self.toggle_btn.setChecked(False)
            QMessageBox.warning(
                self,
                "Ungültige Track-Auswahl",
                "Kamera- und Ziel-Track müssen unterschiedlich sein!"
            )
            return
    
        # Alles okay - normal togglen
        self._update_ui_for_active_state(checked)
        self.toggled.emit(checked)
   
    def _on_tracks_changed(self):
        """Track-Auswahl wurde geändert"""
        cam_track = self.cam_track_combo.currentText()
        target_track = self.target_track_combo.currentText()
       
        if cam_track and target_track and cam_track != target_track:
            self.tracks_changed.emit(cam_track, target_track)
   
    def _on_focal_changed(self, value):
        self.focal_length_changed.emit(value)
        self._update_angle_label()
   
    def _on_sensor_changed(self, value):
        self.sensor_width_changed.emit(value)
        self._update_angle_label()
   
    def _update_angle_label(self):
        """Berechnet und zeigt den View Angle an"""
        import math
        focal = self.focal_spin.value()
        sensor = self.sensor_spin.value()
       
        if focal > 0:
            angle = 2 * math.degrees(math.atan(sensor / (2 * focal)))
            self.angle_label.setText(f"➤ {angle:.1f}°")
   
    def update_tracks(self, track_names):
        """Aktualisiert die Track-Listen"""
        self._track_names = track_names
        current_cam = self.cam_track_combo.currentText()
        current_target = self.target_track_combo.currentText()
       
        self.cam_track_combo.clear()
        self.target_track_combo.clear()
       
        if track_names:
            self.cam_track_combo.addItems(track_names)
            self.target_track_combo.addItems(track_names)
            self.cam_track_combo.setPlaceholderText("...")
            self.target_track_combo.setPlaceholderText("...")
        else:
            self.cam_track_combo.setPlaceholderText("Keine Tracks")
            self.target_track_combo.setPlaceholderText("Keine Tracks")
       
        if current_cam in track_names:
            self.cam_track_combo.setCurrentText(current_cam)
        if current_target in track_names:
            self.target_track_combo.setCurrentText(current_target)
   
    def set_active(self, active):
        """Setzt den aktiven Status von extern (z.B. vom Editor)"""
        print(f"🎯 set_active({active}) aufgerufen")
        self.toggle_btn.setChecked(active)
        
        if active:
            self.toggle_btn.setText("⬤ Kamera-Rig aktiv")
            # NUR GRÜN wenn aktiv
            self.cam_track_combo.setStyleSheet(f"""
                QComboBox {{
                    background: {Theme.rgba('bg_secondary', 200)};
                    color: {Theme.rgb('text_primary')};
                    border: 2px solid {Theme.rgba('accent_green')} !important;
                    border-radius: {Theme.RADIUS_SMALL}px;
                    padding: 2px;
                    min-width: 85px;
                    max-width: 100px;
                    font-size: 8pt;
                    max-height: 18px;
                }}
            """)
            self.target_track_combo.setStyleSheet(f"""
                QComboBox {{
                    background: {Theme.rgba('bg_secondary', 200)};
                    color: {Theme.rgb('text_primary')};
                    border: 2px solid {Theme.rgba('accent_green')} !important;
                    border-radius: {Theme.RADIUS_SMALL}px;
                    padding: 2px;
                    min-width: 85px;
                    max-width: 100px;
                    font-size: 8pt;
                    max-height: 18px;
                }}
            """)
        else:
            self.toggle_btn.setText("⬤ Kamera-Rig aktivieren")
            # RADIKAL: Alles zurücksetzen!
            self.cam_track_combo.setStyleSheet("")  # Erst leer
            self.target_track_combo.setStyleSheet("")  # Erst leer
            
            # Dann explizit auf Standard setzen (falls irgendwo ein Style vererbt wird)
            self.cam_track_combo.style().unpolish(self.cam_track_combo)
            self.cam_track_combo.style().polish(self.cam_track_combo)
            self.target_track_combo.style().unpolish(self.target_track_combo)
            self.target_track_combo.style().polish(self.target_track_combo)
            
            # Und zusätzlich die Stylesheets nochmal explizit leeren
            self.cam_track_combo.setStyleSheet("")
            self.target_track_combo.setStyleSheet("")
            
            print("🔴 Rahmen radikal entfernt!")
            
            # Prüfen ob wirklich weg
            QTimer.singleShot(500, self._check_style)

            
    
    def is_active(self):
        return self.toggle_btn.isChecked()
   
    def get_params(self):
        return {
            'distance': self.distance_spin.value(),
            'height': self.height_spin.value(),
            'focal_length': self.focal_spin.value(),
            'sensor_width': self.sensor_spin.value(),
            'cam_track': self.cam_track_combo.currentText(),
            'target_track': self.target_track_combo.currentText()
        }
    
    def _check_style(self):
        print(f"Cam style: {self.cam_track_combo.styleSheet()}")
        print(f"Target style: {self.target_track_combo.styleSheet()}")
    