# widgets/vtk/overlays/mini_timeline.py

from PySide6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QPushButton, QLabel, QSlider, QWidget
from PySide6.QtCore import Qt, Signal, QTimer
from ....theme import Theme

class MiniTimeline(QFrame):
    """
    Kompakte Timeline für Vollbild und Rig Mode
    Funktioniert mit normalem Timer ODER FrameAnimator
    Layout: Controls oben zentriert, Slider darunter
    """
    
    # Signale
    play_toggled = Signal(bool)      # True = Play, False = Pause
    stop_clicked = Signal()
    position_changed = Signal(float)  # 0-1
    position_dragged = Signal(float)  # während des Ziehens
    
    def __init__(self, parent=None, use_frame_animator=False):
        super().__init__(parent)
        
        self.use_frame_animator = use_frame_animator  # True für Rig Mode
        self.duration = 0.0
        self.position = 0.0
        self.is_playing = False
        self._external_control = False
        self._was_playing = False
        
        self.setup_ui()
        self.setup_style()
        
    def setup_ui(self):
        """UI aufbauen - Controls oben zentriert, Slider darunter"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 5, 10, 5)
        layout.setSpacing(8)
        
        # === Controls (oben, zentriert) ===
        controls = QHBoxLayout()
        controls.setSpacing(10)
        
        # Linker Stretch
        controls.addStretch(1)
        
        # Play Button (links)
        self.play_btn = QPushButton("▶")
        self.play_btn.setFixedSize(45, 32)
        self.play_btn.clicked.connect(self._on_play_clicked)
        controls.addWidget(self.play_btn)
        
        # Stop Button (rechts von Play)
        self.stop_btn = QPushButton("⏹")
        self.stop_btn.setFixedSize(45, 32)
        self.stop_btn.clicked.connect(self._on_stop_clicked)
        controls.addWidget(self.stop_btn)
        
        # Duration Label (zentriert)
        self.duration_label = QLabel("00:00.00")
        self.duration_label.setAlignment(Qt.AlignCenter)
        self.duration_label.setFixedSize(90, 32)  # Gleiche Höhe wie Buttons
        self.duration_label.setStyleSheet("""
            QLabel {
                color: #88ff88;
                font-family: monospace;
                font-size: 13px;
                font-weight: bold;
                background: rgba(30, 30, 30, 150);
                border: 1px solid #333;
                border-radius: 4px;
                padding: 0px 5px;
            }
        """)
        controls.addWidget(self.duration_label)
        
        # Position Label (rechts)
        self.position_label = QLabel("00:00.00")
        self.position_label.setAlignment(Qt.AlignCenter)
        self.position_label.setFixedSize(90, 32)  # Gleiche Höhe wie Buttons
        self.position_label.setStyleSheet("""
            QLabel {
                color: #88aaff;
                font-family: monospace;
                font-size: 13px;
                font-weight: bold;
                background: rgba(30, 30, 30, 150);
                border: 1px solid #333;
                border-radius: 4px;
                padding: 0px 5px;
            }
        """)
        controls.addWidget(self.position_label)
        
        # Rechter Stretch
        controls.addStretch(1)
        
        layout.addLayout(controls)
        
        # === Slider (unten, volle Breite) ===
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 1000)
        self.slider.setValue(0)
        
        # Slider Events
        self.slider.sliderPressed.connect(self._on_slider_pressed)
        self.slider.sliderReleased.connect(self._on_slider_released)
        self.slider.valueChanged.connect(self._on_slider_changed)
        
        layout.addWidget(self.slider)

    def setup_style(self):
        """Styling für dunkles Theme"""
        self.setStyleSheet(f"""
            QFrame {{
                background: {Theme.rgba('bg_primary', 200)};
                border: 1px solid {Theme.rgba('border')};
                border-radius: 5px;
            }}
            QPushButton {{
                background: {Theme.rgba('bg_secondary', 150)};
                color: white;
                border: 1px solid {Theme.rgba('border')};
                border-radius: 4px;
                font-size: 15px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_blue', 100)};
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
            QPushButton:pressed {{
                background: {Theme.rgba('accent_blue', 180)};
            }}
            QLabel {{
                color: white;
                font-family: monospace;
                font-size: 12px;
            }}
            QSlider::groove:horizontal {{
                height: 6px;
                background: {Theme.rgba('bg_secondary')};
                border-radius: 3px;
            }}
            QSlider::handle:horizontal {{
                background: {Theme.rgb('accent_blue')};
                width: 16px;
                height: 16px;
                margin: -5px 0;
                border-radius: 8px;
            }}
            QSlider::handle:horizontal:hover {{
                background: {Theme.rgb('accent_green')};
                width: 18px;
                height: 18px;
                margin: -6px 0;
            }}
            QSlider::sub-page:horizontal {{
                background: {Theme.rgb('accent_blue')};
                border-radius: 3px;
            }}
        """)
    
    # ===== PUBLIC API =====
    
    def set_duration(self, duration):
        """Setzt Gesamtdauer in Sekunden"""
        self.duration = duration
        self._update_time_display()
    
    def set_position(self, pos):
        """Setzt Position (0-1)"""
        if self._external_control:
            return
        
        self._external_control = True
        self.position = max(0.0, min(1.0, pos))
        self.slider.setValue(int(self.position * 1000))
        self._update_time_display()
        self._external_control = False
    
    def set_playing(self, playing):
        """Setzt Play-Status von extern"""
        if self._external_control or playing == self.is_playing:
            return
        
        self._external_control = True
        self.is_playing = playing
        self.play_btn.setText("⏸" if playing else "▶")
        self._external_control = False
    
    # ===== SLIDER HANDLING =====
    
    def _on_slider_pressed(self):
        """Slider wird gedrückt - Playback pausieren"""
        if self.is_playing:
            self._was_playing = True
            self._on_play_clicked()  # Pausiert
        else:
            self._was_playing = False
    
    def _on_slider_released(self):
        """Slider losgelassen"""
        pos = self.slider.value() / 1000.0
        self.position = pos
        self.position_changed.emit(pos)
        self._update_time_display()
        
        # Wenn vorher gespielt wurde, weitermachen
        if self._was_playing:
            self._on_play_clicked()
    
    def _on_slider_changed(self, value):
        """Slider wird gezogen - Live-Update"""
        if self.slider.isSliderDown():
            pos = value / 1000.0
            self.position_dragged.emit(pos)
            self._update_time_display()
    
    # ===== PLAYBACK CONTROLS =====
    
    def _on_play_clicked(self):
        """Play/Pause umschalten"""
        if self._external_control:
            return
        
        self.is_playing = not self.is_playing
        self.play_btn.setText("⏸" if self.is_playing else "▶")
        self.play_toggled.emit(self.is_playing)
    
    def _on_stop_clicked(self):
        """Stop drücken"""
        if self._external_control:
            return
            
        self._external_control = True
        
        # State zurücksetzen
        self.is_playing = False
        self.play_btn.setText("▶")
        self.position = 0.0
        self.slider.setValue(0)
        self._update_time_display()
        
        # Signale senden
        self.stop_clicked.emit()        # Für externen Handler
        self.play_toggled.emit(False)   # Play-State auf False setzen!
        self.position_changed.emit(0.0)
        
        self._external_control = False
    
    def _update_time_display(self):
        """Zeit in Sekunden anzeigen - getrennte Labels für Position und Duration"""
        if self.duration <= 0:
            self.duration_label.setText("00:00.00")
            self.position_label.setText("00:00.00")
            return
        
        def format_time(t):
            minutes = int(t // 60)
            seconds = int(t % 60)
            ms = int((t - int(t)) * 100)
            return f"{minutes:02d}:{seconds:02d}.{ms:02d}"
        
        current_sec = self.position * self.duration
        self.duration_label.setText(format_time(self.duration))
        self.position_label.setText(format_time(current_sec))

    
        