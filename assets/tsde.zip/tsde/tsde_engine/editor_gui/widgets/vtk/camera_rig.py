# editor_gui/widgets/vtk/camera_rig.py

import numpy as np
import math


class CameraRig:
    """
    Kamera-Rig für Gruppenmodus:
    - Kamera folgt Track1 (Position)
    - Kamera blickt auf Track2 (Ziel)
    - Abstand und Höhe konfigurierbar
    - Volle Blender-Kamera Kontrolle: Brennweite & Sensor-Größe
    """
    
    def __init__(self, renderer):
        """
        Args:
            renderer: VTKRenderer Instanz
        """
        self.renderer = renderer  # Das ist direkt der VTK-Renderer!
        self.active = False
        
        # Tracks
        self.camera_track = None    # Track für Kameraposition
        self.target_track = None    # Track für Blickziel
        
        # Parameter
        self.distance = 0.0        # Abstand hinter Kamera-Track (mm)
        self.height = 0.0           # Höhenversatz (mm)
        
        # Blender Kamera-Parameter
        self.sensor_width = 36.0    # mm (Vollformat - wie Blender Standard)
        self.focal_length = 50.0    # mm (Standard-Objektiv)
        
        # Referenz auf die Marker-Actors (wird später gesetzt)
        self.marker_actors = []      # Direkte Referenz auf die Liste der Marker
        
        # Initial View Angle berechnen
        self._update_view_angle()
    
    def _update_view_angle(self):
        """
        Berechnet View Angle aus Sensor-Größe und Brennweite.
        Exakt die gleiche Formel wie in Blender!
        
        View Angle = 2 * arctan( Sensor-Größe / (2 * Brennweite) )
        """
        if self.focal_length <= 0:
            return 30.0  # Fallback
        
        angle = 2 * math.degrees(math.atan(self.sensor_width / (2 * self.focal_length)))
        return angle
    
    def set_focal_length(self, focal_length):
        """Setzt Brennweite in mm (wie in Blender)"""
        self.focal_length = max(5.0, min(500.0, focal_length))
        if self.active:
            self.update()
    
    def set_sensor_width(self, sensor_width):
        """
        Setzt Sensor-Breite in mm.
        Standard Vollformat: 36mm
        APS-C: ~24mm
        Micro Four Thirds: ~17mm
        """
        self.sensor_width = max(1.0, min(100.0, sensor_width))
        if self.active:
            self.update()
    
    def set_marker_actors(self, marker_actors):
        """Setzt direkte Referenz auf die Marker-Actors Liste"""
        self.marker_actors = marker_actors
    
    def set_tracks(self, camera_track, target_track):
        """Setzt die beiden Tracks für den Rig"""
        self.camera_track = camera_track
        self.target_track = target_track
    
    def set_params(self, distance=None, height=None):
        """Aktualisiert Parameter"""
        if distance is not None:
            self.distance = distance
        if height is not None:
            self.height = height
    
    def toggle(self, enabled=None):
        """Schaltet Rig ein/aus"""
        if enabled is not None:
            self.active = enabled
        else:
            self.active = not self.active
        
        if self.active:
            self.update()
        
        return self.active
    
    def update(self):
        """
        Aktualisiert Kameraposition basierend auf den beiden Markern.
        Verwendet direkt die vorhandenen marker_actors.
        """
        if not self.active or not self.marker_actors:
            return
        
        # Positionen der beiden Marker finden
        cam_pos = None
        target_pos = None
        
        for actor, track, _ in self.marker_actors:
            if track is self.camera_track:
                cam_pos = actor.GetPosition()
            if track is self.target_track:
                target_pos = actor.GetPosition()
        
        # Prüfen ob beide Positionen gefunden
        if cam_pos is None or target_pos is None:
            return
        
        # In numpy arrays umwandeln
        p_cam = np.array(cam_pos)
        p_target = np.array(target_pos)
        
        # Richtung von Kamera-Track zu Ziel-Track
        direction = p_target - p_cam
        length = np.linalg.norm(direction)
        
        if length < 1e-6:  # Verhindere Division durch Null
            return
        
        direction = direction / length
        
        # Kameraposition: hinter dem Kamera-Track (entgegen der Richtung)
        # plus Höhenversatz in Z
        cam_position = p_cam - direction * self.distance
        cam_position[2] += self.height
        
        # Kamera setzen
        cam = self.renderer.GetActiveCamera()
        cam.SetPosition(cam_position)
        cam.SetFocalPoint(p_target)  # Auf Ziel-Track schauen
        cam.SetViewUp(0, 0, 1)       # Z-Achse nach oben
        
        # View Angle aus Sensor und Brennweite berechnen (Blender-kompatibel!)
        view_angle = self._update_view_angle()
        cam.SetViewAngle(view_angle)
        
        self.renderer.GetRenderWindow().Render()
    
    def reset(self):
        """Setzt Rig zurück und deaktiviert"""
        self.active = False
        self.camera_track = None
        self.target_track = None
    
    def is_available(self):
        """
        Prüft ob Rig verfügbar ist:
        - Mindestens 2 Marker vorhanden
        - Beide Tracks sind gesetzt
        """
        return (len(self.marker_actors) >= 2 and
                self.camera_track is not None and
                self.target_track is not None and
                self.camera_track != self.target_track)  # verschiedene Tracks
    
    def get_blender_params(self):
        """Gibt aktuelle Parameter im Blender-Format zurück"""
        return {
            'focal_length': self.focal_length,
            'sensor_width': self.sensor_width,
            'distance': self.distance,
            'height': self.height
        }