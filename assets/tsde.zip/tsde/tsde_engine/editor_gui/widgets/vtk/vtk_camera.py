# editor_gui/widgets/vtk/vtk_camera.py - Kamera-Positionen

import vtk

class VTKCamera:
    """Verwaltet verschiedene Kamerapositionen"""
    
    def __init__(self, renderer):
        self.renderer = renderer
        self.camera = renderer.GetActiveCamera()
    
    def set_top(self):
        """Top-Ansicht (von oben)"""
        self.camera.SetPosition(0, 0, 500)
        self.camera.SetFocalPoint(0, 0, 0)
        self.camera.SetViewUp(0, 1, 0)
        self._update()
    
    def set_front(self):
        """Front-Ansicht (von vorne)"""
        self.camera.SetPosition(0, 500, 0)
        self.camera.SetFocalPoint(0, 0, 0)
        self.camera.SetViewUp(0, 0, 1)
        self._update()
    
    def set_side(self):
        """Seiten-Ansicht (von rechts)"""
        self.camera.SetPosition(500, 0, 0)
        self.camera.SetFocalPoint(0, 0, 0)
        self.camera.SetViewUp(0, 0, 1)
        self._update()
    
    def set_back(self):
        """Rück-Ansicht (von hinten)"""
        self.camera.SetPosition(-500, 0, 0)
        self.camera.SetFocalPoint(0, 0, 0)
        self.camera.SetViewUp(0, 0, 1)
        self._update()
    
    def set_iso(self):
        """Isometrische Ansicht"""
        self.camera.SetPosition(500, 500, 500)
        self.camera.SetFocalPoint(0, 0, 0)
        self.camera.SetViewUp(0, 0, 1)
        self._update()
    
    def zoom(self, factor):
        """Zoom-Faktor anpassen"""
        self.camera.Zoom(factor)
    
    def _update(self):
        """Aktualisiert die Kamera-Clipping Range"""
        self.renderer.ResetCameraClippingRange()