# editor_gui/widgets/vtk/vtk_lights.py

import vtk

def setup_lights(renderer):
    """Richtet eine ausgewogene, moderne 3-Light-Setup-Beleuchtung ein"""
    
    # 1. Key Light – Hauptlicht, hell, leicht warm, von vorne-oben
    key = vtk.vtkLight()
    key.SetLightTypeToSceneLight()
    key.SetPosition(8, 10, 12)
    key.SetFocalPoint(0, 0, 0)
    key.SetIntensity(1.1)                  # etwas stärker als Standard
    key.SetColor(1.0, 0.98, 0.92)         # leicht warm (fast weiß)
    key.SetConeAngle(60)                   # etwas fokussierter
    key.SetExponent(20)                    # weicher Übergang
    renderer.AddLight(key)

    # 2. Fill Light – weiches Fülllicht von der Seite, kühler
    fill = vtk.vtkLight()
    fill.SetLightTypeToSceneLight()
    fill.SetPosition(-6, -4, 8)
    fill.SetFocalPoint(0, 0, 0)
    fill.SetIntensity(0.45)                # deutlich schwächer als Key
    fill.SetColor(0.85, 0.92, 1.0)        # leicht bläulich/kühl
    fill.SetConeAngle(80)
    fill.SetExponent(5)                    # sehr weich
    renderer.AddLight(fill)

    # 3. Rim / Back Light – Kontrastlicht von hinten/unten, für Silhouette & Glow
    rim = vtk.vtkLight()
    rim.SetLightTypeToSceneLight()
    rim.SetPosition(0, 3, -10)
    rim.SetFocalPoint(0, 0, 0)
    rim.SetIntensity(0.7)
    rim.SetColor(0.95, 0.95, 1.0)         # fast weiß, leicht kühl
    rim.SetConeAngle(70)
    rim.SetExponent(15)
    renderer.AddLight(rim)

    # Optional: sehr schwaches Ambient-Licht (verhindert totale schwarze Schatten)
    renderer.SetAmbient(0.08, 0.09, 0.12)  # ganz leicht blau-grau

    # Wichtig: Lichter bewegen sich mit der Kamera mit (meist gewünscht)
    renderer.LightFollowCameraOn()