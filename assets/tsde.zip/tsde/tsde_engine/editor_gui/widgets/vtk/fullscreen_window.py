"""Vollbild-Fenster für VTK - ausgelagert aus vtk_view.py"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFrame, QPushButton, 
    QLabel, QComboBox, QRadioButton, QStackedWidget, QButtonGroup
)
from PySide6.QtCore import Qt, Signal
from ...theme import Theme
from .overlays.mini_timeline import MiniTimeline  # 🔥 NEU


class FullscreenVTKWindow(QDialog):
    """Vollbild-Fenster – synchron mit zentralem Modus-State"""

    # Signale
    closed = Signal()
    track_selected = Signal(str)
    group_selected = Signal(str)
    play_toggled = Signal(bool)
    camera_requested = Signal(str)
    radius_changed = Signal(float)
    marker_size_changed = Signal(float)
    request_mode_change = Signal(str)  # "track" oder "group"
    
    # Signale für Mini-Timeline
    position_changed = Signal(float)  # Zum Scrubben (final)
    position_dragged = Signal(float)  # Während des Ziehens (Live-Update)
    stop_clicked = Signal()  # Stop-Signal

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("VTK Motion Full-Screen")
        self.setWindowFlags(Qt.Window | Qt.FramelessWindowHint)
        self.showFullScreen()

        self._internal_change = False
        self._external_control = False

        self.track_names = []
        self.group_names = []
        self.duration = 0.0

        self._setup_ui()
        self._connect_signals()

        self.rig_mode = False  # 🔥 NEU: Rig-Mode Flag

    def _setup_ui(self):
        """Baut die komplette UI auf"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Obere Leiste
        self._create_top_bar(layout)
        
        # VTK Container
        self._create_vtk_container(layout)
        
        # Untere Kontrollleiste
        self._create_bottom_bar(layout)

    def _create_top_bar(self, parent_layout):
        """Erstellt die obere Leiste mit Modus-Auswahl"""
        control_bar = QFrame()
        control_bar.setFixedHeight(50)
        control_bar.setStyleSheet(f"""
            QFrame {{
                background: {Theme.rgba('bg_primary', 230)};
                border-bottom: 2px solid {Theme.rgba('accent_blue')};
            }}
        """)

        control_layout = QHBoxLayout(control_bar)
        control_layout.setContentsMargins(15, 5, 15, 5)

        # Titel
        title_label = QLabel("🎞️ TSDE Motion Full-Screen")
        title_label.setStyleSheet(f"color: {Theme.rgb('accent_blue')}; font-size: 12pt; font-weight: bold;")
        control_layout.addWidget(title_label)
        control_layout.addStretch()

        # Modus-Umschalter
        self._create_mode_selector(control_layout)

        # Auswahl-Stack
        self._create_selection_stack(control_layout)

        # Schließen-Button
        close_btn = self._create_close_button()
        control_layout.addWidget(close_btn)

        parent_layout.addWidget(control_bar)

    def _create_mode_selector(self, parent_layout):
        """Erstellt die Radio-Buttons für Track/Group Mode"""
        mode_layout = QHBoxLayout()
        mode_layout.setSpacing(16)

        self.trk_radio = QRadioButton("🎯 Track Mode")
        self.grp_radio = QRadioButton("👥 Group Mode")

        style = f"""
            QRadioButton {{ color: white; font-size: 11pt; spacing: 8px; }}
            QRadioButton::indicator {{ width: 16px; height: 16px; }}
        """
        self.trk_radio.setStyleSheet(style)
        self.grp_radio.setStyleSheet(style)

        self.mode_group = QButtonGroup(self)
        self.mode_group.addButton(self.trk_radio)
        self.mode_group.addButton(self.grp_radio)
        self.mode_group.setExclusive(True)

        mode_layout.addWidget(self.trk_radio)
        mode_layout.addWidget(self.grp_radio)
        parent_layout.addLayout(mode_layout)

    def _create_selection_stack(self, parent_layout):
        """Erstellt den Stack für Track/Group Comboboxen"""
        self.selection_stack = QStackedWidget()
        self.selection_stack.setFixedWidth(220)

        # Track Combo
        self.track_combo = QComboBox()
        self.track_combo.setStyleSheet(self._get_combo_style())
        self.track_combo.currentTextChanged.connect(self._on_track_combo_changed)

        # Group Combo
        self.group_combo = QComboBox()
        self.group_combo.setStyleSheet(self._get_combo_style())
        self.group_combo.currentTextChanged.connect(self._on_group_combo_changed)

        self.selection_stack.addWidget(self.track_combo)
        self.selection_stack.addWidget(self.group_combo)
        parent_layout.addWidget(self.selection_stack)

    def _get_combo_style(self):
        """Gibt den Style für Comboboxen zurück"""
        return f"""
            QComboBox {{
                background: {Theme.rgba('bg_secondary', 220)};
                color: white;
                border: 1px solid {Theme.rgba('border')};
                border-radius: 5px;
                padding: 6px 10px;
                font-size: 11pt;
                min-width: 180px;
            }}
            QComboBox::drop-down {{ width: 24px; border: none; }}
            QComboBox:hover {{ border: 1px solid {Theme.rgba('accent_blue')}; }}
        """

    def _create_close_button(self):
        """Erstellt den Schließen-Button"""
        btn = QPushButton("✕ Beenden")
        btn.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_red', 180)};
                color: white;
                border: none;
                border-radius: 5px;
                padding: 6px 18px;
                font-weight: bold;
                font-size: 11pt;
                margin-left: 12px;
            }}
            QPushButton:hover {{ background: {Theme.rgba('accent_red', 240)}; }}
        """)
        btn.clicked.connect(self.close)
        return btn

    def _create_vtk_container(self, parent_layout):
        """Erstellt den Container für das VTK-Widget"""
        self.vtk_container = QFrame()
        self.vtk_container.setStyleSheet(f"background: {Theme.rgba('bg_secondary')};")
        vtk_layout = QVBoxLayout(self.vtk_container)
        vtk_layout.setContentsMargins(0, 0, 0, 0)
        parent_layout.addWidget(self.vtk_container, 1)

    def _create_bottom_bar(self, parent_layout):
        """Erstellt die untere Leiste mit Mini-Timeline"""
        bottom_bar = QFrame()
        bottom_bar.setFixedHeight(150)
        bottom_bar.setStyleSheet(f"""
            QFrame {{
                background: {Theme.rgba('bg_primary', 230)};
                border-top: 1px solid {Theme.rgba('border')};
            }}
        """)

        bottom_layout = QVBoxLayout(bottom_bar)
        bottom_layout.setContentsMargins(20, 10, 20, 10)
        bottom_layout.setSpacing(10)

        # === 🔥 Mini-Timeline ===
        self.timeline = MiniTimeline(parent=self, use_frame_animator=False)
        bottom_layout.addWidget(self.timeline)
        
        # === Kamera-Buttons und Größen-Einstellungen ===
        controls_layout = QHBoxLayout()
        controls_layout.setSpacing(20)

        # Kamera-Buttons (links)
        self._create_camera_buttons(controls_layout)
        
        controls_layout.addStretch()
        
        # Größen-Einstellungen (rechts)
        self._create_size_controls(controls_layout)
        
        bottom_layout.addLayout(controls_layout)

        parent_layout.addWidget(bottom_bar)

    def _create_camera_buttons(self, parent_layout):
        """Erstellt die Kamera-Buttons (Fit, Top, Iso, etc.)"""
        camera_layout = QHBoxLayout()
        camera_layout.setSpacing(8)

        cam_buttons = [
            ("Fit", "fit"), ("Top", "top"), ("Iso", "iso"),
            ("Front", "front"), ("Side", "side")
        ]

        btn_style = f"""
            QPushButton {{
                background: {Theme.rgba('bg_secondary', 150)};
                color: white;
                border: 1px solid {Theme.rgba('border')};
                border-radius: 4px;
                padding: 6px 14px;
                font-size: 10pt;
                min-width: 55px;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_blue', 180)};
            }}
        """

        for text, cmd in cam_buttons:
            btn = QPushButton(text)
            btn.setStyleSheet(btn_style)
            btn.clicked.connect(lambda _, c=cmd: self.camera_requested.emit(c))
            camera_layout.addWidget(btn)

        parent_layout.addLayout(camera_layout)

    def _create_size_controls(self, parent_layout):
        """Erstellt die Größen-Einstellungen für Tube und Marker"""
        size_layout = QHBoxLayout()
        size_layout.setSpacing(20)

        # Tube-Größe
        tube_layout = QVBoxLayout()
        tube_layout.setSpacing(3)
        tube_label = QLabel("📏 Tube Ø")
        tube_label.setStyleSheet(f"color: {Theme.rgb('text_secondary')}; font-size: 9pt;")
        tube_layout.addWidget(tube_label)

        self.tube_combo = QComboBox()
        self.tube_combo.addItems(["0.5", "1.0", "2.0", "2.5", "3.0", "5.0", "8.0", "10.0", "12.0", "15.0", "20.0", "25.0", "30.0", "35.0", "40.0", "50.0"])
        self.tube_combo.setCurrentText("2.5")
        self.tube_combo.setStyleSheet(self._get_size_combo_style())
        self.tube_combo.currentTextChanged.connect(
            lambda v: self.radius_changed.emit(float(v))
        )
        tube_layout.addWidget(self.tube_combo)
        size_layout.addLayout(tube_layout)

        # Marker-Größe (im size_layout)
        marker_layout = QVBoxLayout()
        marker_layout.setSpacing(3)
        marker_label = QLabel("🔴 Marker Ø")
        marker_label.setStyleSheet(f"color: {Theme.rgb('text_secondary')}; font-size: 9pt;")
        marker_layout.addWidget(marker_label)

        self.marker_combo = QComboBox()

        # Gleiche dynamische Werte!
        values = []
        for i in range(1, 101):
            if i <= 10:
                values.append(str(float(i)))
            elif i <= 20:
                if i % 2 == 0:
                    values.append(str(float(i)))
            elif i <= 35:
                if i % 5 == 0:
                    values.append(str(float(i)))
            else:
                if i % 10 == 0:
                    values.append(str(float(i)))

        self.marker_combo.addItems(values)
        self.marker_combo.setCurrentText("5.0")
        self.marker_combo.setStyleSheet(self._get_size_combo_style())
        self.marker_combo.currentTextChanged.connect(
            lambda v: self.marker_size_changed.emit(float(v))
        )
        marker_layout.addWidget(self.marker_combo)
        size_layout.addLayout(marker_layout)

        parent_layout.addLayout(size_layout)

    def _get_size_combo_style(self):
        """Style für Größen-Comboboxen"""
        return f"""
            QComboBox {{
                background: {Theme.rgba('bg_secondary', 160)};
                color: white;
                border: 1px solid {Theme.rgba('border')};
                border-radius: 4px;
                padding: 5px;
                min-width: 80px;
                font-size: 10pt;
            }}
        """

    def _connect_signals(self):
        """Verbindet interne Signale"""
        print("🔌 Fullscreen: Verbinde Signale...")
        
        # Mode-Umschalter
        self.trk_radio.toggled.connect(self._on_mode_toggled)
        self.grp_radio.toggled.connect(self._on_mode_toggled)
        
        # 🔥 Timeline Signale
        self.timeline.play_toggled.connect(self._on_timeline_play_toggled)
        self.timeline.stop_clicked.connect(self._on_timeline_stop_clicked)
        self.timeline.position_changed.connect(self._on_timeline_position_changed)
        self.timeline.position_dragged.connect(self._on_timeline_position_dragged)
        
        print("   - timeline Signale verbunden")
        print("   - play_btn.clicked verbunden")
        print("   - stop_btn.clicked verbunden")

    # ===== TIMELINE CALLBACKS =====

    def _on_timeline_play_toggled(self, playing):
        """Wird aufgerufen wenn in der Mini-Timeline Play/Pause geklickt wird"""
        print(f"\n🎬 FULLSCREEN: _on_timeline_play_toggled({playing})")
        self.play_toggled.emit(playing)

    def _on_timeline_stop_clicked(self):
        """Wird aufgerufen wenn Stop geklickt wird"""
        print("\n⏹️ FULLSCREEN: _on_timeline_stop_clicked")
        
        # Stop-Signal an VTK/Editor
        self.stop_clicked.emit()
        
        # Zusätzlich Play-State auf False setzen
        self.play_toggled.emit(False)

    def _on_timeline_position_changed(self, pos):
        """Wird aufgerufen wenn Position final geändert (nach Loslassen)"""
        print(f"🎚️ FULLSCREEN: Position changed to {pos:.3f}")
        self.position_changed.emit(pos)

    def _on_timeline_position_dragged(self, pos):
        """Wird aufgerufen während des Ziehens (Live-Update)"""
        self.position_dragged.emit(pos)

    # ===== EXTERNE SYNC METHODEN =====

    def set_playing_from_timeline(self, playing):
        """
        Wird von VTK3DView aufgerufen wenn Timeline Play/Pause ändert
        """
        print(f"🎬 FULLSCREEN: set_playing_from_timeline({playing}) aufgerufen")
        self.timeline.set_playing(playing)

    def set_position_from_timeline(self, pos):
        """
        Wird von VTK3DView aufgerufen wenn Timeline Position ändert
        """
        # Falls Duration noch nicht gesetzt, aber bekannt
        if self.duration > 0:
            self.timeline.set_duration(self.duration)
        self.timeline.set_position(pos)

    def set_duration_from_timeline(self, duration):
        """Wird von VTK3DView aufgerufen wenn sich die Dauer ändert"""
        #print(f"⏱️ FULLSCREEN: Duration update: {duration}s")
        self.duration = duration
        if hasattr(self, 'timeline'):
            self.timeline.set_duration(duration)
            #print(f"   → Timeline Duration gesetzt auf {duration}s")

    def sync_with_timeline(self, is_playing, position):
        """Synchronisiert mit Haupt-Timeline"""
        self.timeline.set_playing(is_playing)
        self.timeline.set_position(position)

    def set_playing_state(self, playing):
        """Setzt den Play-Status (von extern)"""
        print(f"🎬 FULLSCREEN: set_playing_state({playing}) aufgerufen")
        self.set_playing_from_timeline(playing)

    # ===== ÖFFENTLICHE METHODEN =====

    def set_vtk_widget(self, vtk_widget):
        """Fügt das VTK-Widget in den Container ein"""
        vtk_widget.setParent(self.vtk_container)
        self.vtk_container.layout().addWidget(vtk_widget)
        vtk_widget.show()

    def set_track_names(self, names):
        """Setzt die Track-Namen für die Combo"""
        self.track_names = names or []
        if self.trk_radio.isChecked():
            self._update_combo(self.track_combo, names)

    def set_group_names(self, names):
        """Setzt die Group-Namen für die Combo"""
        self.group_names = names or []
        if self.grp_radio.isChecked():
            self._update_combo(self.group_combo, names)

    def sync_mode(self, is_track_mode):
        """Synchronisiert UI mit Modus-Änderung"""
        self._internal_change = True

        self.trk_radio.setChecked(is_track_mode)
        self.grp_radio.setChecked(not is_track_mode)
        self.selection_stack.setCurrentIndex(0 if is_track_mode else 1)

        if is_track_mode:
            self._update_combo(self.track_combo, self.track_names)
        else:
            self._update_combo(self.group_combo, self.group_names)

        self._internal_change = False

    def set_rig_mode(self, enabled):
        """Aktiviert Rig-Modus im Vollbild"""
        print(f"🎬 FULLSCREEN: set_rig_mode({enabled}) aufgerufen")
        self.rig_mode = enabled
        
        if hasattr(self, 'timeline'):
            if enabled:
                # 🔥 Rig-Mode: Slider + Stop grau, Play bleibt
                self.timeline.slider.setEnabled(False)
                self.timeline.stop_btn.setEnabled(False)
                self.timeline.play_btn.setEnabled(True)  # Play bleibt aktiv!
                
                # Optional: Visuelles Feedback
                self.timeline.slider.setToolTip("Rig-Mode aktiv - Slider gesperrt")
                self.timeline.stop_btn.setToolTip("Rig-Mode aktiv - Stop gesperrt")
                self.timeline.play_btn.setToolTip("Play startet Rig-Preview")
                
                print("   → Rig-Mode: Slider+Stop grau, Play aktiv")
            else:
                # 🔥 Normal-Mode: Alles wieder aktiv
                self.timeline.slider.setEnabled(True)
                self.timeline.stop_btn.setEnabled(True)
                self.timeline.play_btn.setEnabled(True)
                
                self.timeline.slider.setToolTip("")
                self.timeline.stop_btn.setToolTip("")
                self.timeline.play_btn.setToolTip("")
                
                print("   → Normal-Mode: Alle Controls aktiv")

    # ===== PRIVATE METHODEN =====

    def _update_combo(self, combo, items):
        """Aktualisiert eine Combo ohne Signale"""
        combo.blockSignals(True)
        combo.clear()
        combo.addItems(items)
        if items:
            combo.setCurrentIndex(0)
        combo.blockSignals(False)

    def _on_mode_toggled(self, checked):
        """Modus wurde umgeschaltet"""
        if not checked or self._internal_change:
            return

        is_track = self.trk_radio.isChecked()
        mode = "track" if is_track else "group"
        self.request_mode_change.emit(mode)

    def _on_track_combo_changed(self, text):
        """Track-Auswahl geändert"""
        if text and not self._internal_change:
            self.track_selected.emit(text)

    def _on_group_combo_changed(self, text):
        """Group-Auswahl geändert"""
        if text and not self._internal_change:
            self.group_selected.emit(text)

    # ===== EVENT HANDLER =====

    def keyPressEvent(self, event):
        """Escape schließt das Vollbild"""
        if event.key() == Qt.Key_Escape:
            self.close()
        super().keyPressEvent(event)

    def closeEvent(self, event):
        """Signalisiert das Schließen"""
        self.closed.emit()
        super().closeEvent(event)