# editor_gui/widgets/vtk/vtk_view.py

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt, Signal, QTimer
from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
import vtk
import numpy as np

from tsde_engine.editor_gui.theme import Theme
from tsde_engine.editor_gui.widgets.vtk.vtk_overlay import VTKOverlay
from tsde_engine.editor_gui.widgets.vtk.vtk_lights import setup_lights
from tsde_engine.editor_gui.widgets.vtk.vtk_camera import VTKCamera
from tsde_engine.editor_gui.widgets.vtk.fullscreen_window import FullscreenVTKWindow

from tsde_engine.editor_gui.widgets.vtk.camera_rig import CameraRig
from tsde_engine.editor_gui.widgets.vtk.overlays.camera_rig_overlay import CameraRigOverlay

import math  # 🔥 WICHTIG für Radiant-Umrechnung

import time
from collections import deque


class FrameBasedAnimator:
    """Frame-basierter Animator NUR für Rig-Modus - JETZT MIT SIMPLEM ROLL-SYSTEM"""
    
    def __init__(self, vtk_view):
        self.vtk_view = vtk_view
        self.fps = 60
        self.current_frame = 0
        self.total_frames = 0
        self.is_playing = False
        self.preview_mode = False
        self.timer = QTimer()
        self.timer.timeout.connect(self.next_frame)
        
        self.start_time = 0
        self.animation_progress = 0.0
        self.frame_cache = {}          # Positionen {track_name: [pos_frame0, pos_frame1, ...]}
        self.roll_cache = {}           # 🔥 NEU: Roll-Werte pro Rig {rig_name: [roll_rad_frame0, ...]}
        self.distance_map = {}
        self.tracks_with_curves = []
        self.v_max = 0.0
        self.duration = 0.0
        self.length = 0.0
    
    def prepare_animation(self, duration, all_tracks, v_max):
        """Berechnet alle Frames vor - inklusive Roll-Tracks!"""
        self.stop()
        self.duration = duration
        self.all_tracks = all_tracks  # Speichern für später
        self.v_max = v_max
        self.total_frames = int(duration * self.fps)
        
        # Position-Cache für Tracks mit Kurven
        self.frame_cache = {}
        self.tracks_with_curves = []
        
        for track, curve in all_tracks:
            if curve is not None:  # Nur Tracks mit Kurven
                self.tracks_with_curves.append((track, curve))
                self.frame_cache[track.name] = []
        
        if self.tracks_with_curves:
            self.length = self.tracks_with_curves[0][1].length_total
        
        # 🔥 Roll-Cache für ALLE Roll-Tracks
        self.roll_cache = {}
        for track, curve in all_tracks:
            if track.name.endswith("_Roll"):
                rig_name = track.name.replace("_Roll", "")
                self.roll_cache[rig_name] = []
                print(f"🔄 Roll-Track erkannt: {track.name} -> Rig {rig_name}")
        
        # Distance-Map für Positionstracks
        self.distance_map = {}
        for track, curve in self.tracks_with_curves:
            start_t = getattr(track, 'start_t', 0.0)
            self.distance_map[track.name] = start_t * self.length
        
        dt = 1.0 / self.fps
        
        print(f"🔄 Berechne {self.total_frames} Frames für {len(self.tracks_with_curves)} Tracks + {len(self.roll_cache)} Roll-Tracks")
        
        for frame in range(self.total_frames):
            t = frame * dt
            progress = t / duration
            
            # 1. Positionstracks (nur mit Kurven)
            for track, curve in self.tracks_with_curves:
                if hasattr(track, 'current_times') and len(track.current_times) > 0:
                    idx = int(progress * len(track.current_times))
                    idx = min(idx, len(track.current_times) - 1)
                    pos_t = track.current_times[idx]
                    
                    try:
                        pos = curve.evaluate(pos_t)
                        self.frame_cache[track.name].append(pos)
                    except:
                        self.frame_cache[track.name].append(None)
                else:
                    pedal = self._get_pedal_at_time(track, t)
                    v_eff = pedal * v_max
                    
                    self.distance_map[track.name] += v_eff * dt
                    distance = self.distance_map[track.name]
                    new_t = (distance % self.length) / self.length
                    
                    try:
                        pos = curve.evaluate(new_t)
                        self.frame_cache[track.name].append(pos)
                    except:
                        self.frame_cache[track.name].append(None)
            
            # 2. 🔥 Roll-Tracks (aus allen Tracks)
            for track, curve in all_tracks:
                if track.name.endswith("_Roll"):
                    rig_name = track.name.replace("_Roll", "")
                    
                    if hasattr(track, 'pedals') and len(track.pedals) > 0:
                        idx = int(progress * len(track.pedals))
                        idx = min(idx, len(track.pedals) - 1)
                        pedal = track.pedals[idx]
                        
                        roll_deg = pedal * 450
                        roll_rad = roll_deg * math.pi / 180.0
                        self.roll_cache[rig_name].append(roll_rad)
        
        print(f"✅ Frame-Animator vorbereitet: {self.total_frames} Frames")
        
    def _get_pedal_at_time(self, track, t):
        if hasattr(track, 'pedals') and len(track.pedals) > 0:
            sample_t = t + getattr(track, 'start_t', 0.0)
            idx = int(sample_t / track.duration * len(track.pedals))
            idx = min(idx, len(track.pedals) - 1)
            return track.pedals[idx]
        return 0.0
    
    def start_preview(self):
        """Startet Preview-Modus"""
        if self.total_frames == 0:
            return
        self.preview_mode = True
        self.is_playing = True
        self.current_frame = 0
        self.start_time = time.time()
        self.timer.start(16)
        print(f"▶️ Preview gestartet: {self.fps}fps, {self.total_frames} Frames")
    
    def stop_preview(self):
        """Stoppt Preview-Modus"""
        self.preview_mode = False
        self.is_playing = False
        self.timer.stop()
        print("⏹️ Preview gestoppt")
    
    def start(self):
        """Startet normale Animation"""
        if self.total_frames == 0:
            return
        self.current_frame = 0
        self.is_playing = True
        self.start_time = time.time()
        self.timer.start(16)
        print(f"▶️ FrameAnimator gestartet: {self.fps}fps, {self.total_frames} Frames")
    
    def stop(self):
        """Stoppt Animation"""
        self.is_playing = False
        self.timer.stop()
        print("⏹️ FrameAnimator gestoppt")
    
    def pause(self):
        """Pausiert Animation"""
        self.is_playing = False
        self.timer.stop()
    
    def show_frame(self, frame):
        """Zeigt einen bestimmten Frame - inklusive Roll!"""
        if self.total_frames == 0:
            return
        
        frame = max(0, min(frame, self.total_frames - 1))
        
        # 1. Positionen der Marker
        for item in self.vtk_view.marker_actors:
            if len(item) == 4:
                marker_actor, track, _, _ = item
            else:
                marker_actor, track, _ = item
                
            if track.name in self.frame_cache:
                pos = self.frame_cache[track.name][frame]
                if pos:
                    marker_actor.SetPosition(pos.x, pos.y, pos.z)
        
        # 2. 🔥 Roll-Werte anwenden - auf PIVOT Marker!
        for rig_name, roll_values in self.roll_cache.items():
            if frame < len(roll_values):
                roll_rad = roll_values[frame]
                
                # Finde den PIVOT Marker für dieses Rig
                pivot_marker = self.vtk_view.get_pivot_for_rig(rig_name)
                if pivot_marker:
                    # 🔥 VTK: Rotation über Transform setzen
                    transform = vtk.vtkTransform()
                    transform.Identity()
                    transform.RotateY(roll_rad * 180.0 / math.pi)  # VTK will Grad!
                    pivot_marker.SetUserTransform(transform)
        
        # 3. Kamera-Rig updaten
        if self.vtk_view.camera_rig and self.vtk_view.camera_rig.active:
            self.vtk_view.camera_rig.update()
        
        self.vtk_view.vtk_widget.GetRenderWindow().Render()
        
    def next_frame(self):
        """Nächsten Frame anzeigen"""
        if not self.is_playing:
            return
        
        elapsed_total = time.time() - self.start_time
        progress = elapsed_total / self.duration
        
        if progress >= 1.0:
            self.stop()
            return
        
        frame = int(progress * self.total_frames)
        frame = min(frame, self.total_frames - 1)
        
        self.show_frame(frame)


class VTK3DView(QWidget):
    """Zentrale View – besitzt den EINZIGEN Modus-State"""

    # Signale
    track_selected = Signal(str)
    group_selected = Signal(str)
    marker_changed = Signal(float)
    view_mode_changed = Signal(str)
    play_toggled = Signal(bool)
    
    # Playback-Signale
    playback_play = Signal()
    playback_pause = Signal()
    playback_stop = Signal()
    playback_position_changed = Signal(float)

    # Signal für Play/Pause-Änderungen
    play_state_changed = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setFixedSize(Theme.VTK_WIDTH, Theme.VTK_HEIGHT)

        self._updating_play_state = False
        self._updating_position = False

        # === Daten ===
        self.curve = None
        self.current_track = None
        self.current_vtk_group = None
        self.current_pos = 0.0
        self.duration = 0.0
        self.curve_actors = []
        self.marker_actors = []  # Enthält (marker, track, curve, v_eff)
        self.marker_actor = None
        self.current_group_tracks = []

        self.fullscreen_window = None
        self.is_fullscreen = False

        self.track_names = []
        self.group_names = []
        self.tracks_data = {}

        # Track->Gruppe Mapping
        self.track_to_group = {}
        self.group_to_tracks = {}

        # Kamera-Rig
        self.camera_rig = None
        self.camera_rig_overlay = None

        # Frame-basierter Animator (NUR für Rig-Modus)
        self.frame_animator = FrameBasedAnimator(self)

        # 🔥 NEU: Dictionary für Rig-Kameras
        self.rig_cameras = {}  # {rig_name: camera_actor}

        # === Timer ===
        self.redraw_timer = QTimer()
        self.redraw_timer.setSingleShot(True)
        self.redraw_timer.setInterval(50)
        self.redraw_timer.timeout.connect(self._force_redraw)
        
        self.animation_timer = QTimer()
        self.animation_timer.setInterval(33)
        self.animation_timer.timeout.connect(self._on_animation_timer)
        self.is_animating = False

        # Für schwebende Geschwindigkeitsanzeigen
        self.speed_text_actors = []  # Liste der Text-Actors

        # 🔥 EINFACHE LÖSUNG: Schriftgröße an Marker-Größe koppeln
        self.text_scale_factor = 1.5  # Schrift ist halb so groß wie Marker

        # Farben für Gruppen-Modus → Tubes / Kurven
        self.group_colors = [
            (1.0, 0.7, 0.2),   # Orange
            (0.2, 0.8, 1.0),   # Cyan
            (0.6, 1.0, 0.2),   # Hellgrün
            (1.0, 0.4, 0.7),   # Pink
            (0.9, 0.9, 0.2),   # Gelb
            (0.5, 0.3, 1.0),   # Lila
        ]

        self._is_track_mode = True
        self.group_mode = False

        self._setup_ui()
        self._setup_vtk()

    def _setup_ui(self):
        """Baut die UI auf"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.wrapper = QFrame()
        self.wrapper.setObjectName("vtkWrapper")
        self.wrapper.setStyleSheet(f"""
            #vtkWrapper {{
                background: {Theme.rgba('bg_secondary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_LARGE}px;
            }}
        """)

        wrapper_layout = QVBoxLayout(self.wrapper)
        wrapper_layout.setContentsMargins(1, 1, 1, 1)

        self.vtk_widget = QVTKRenderWindowInteractor()
        self.vtk_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        wrapper_layout.addWidget(self.vtk_widget)
        layout.addWidget(self.wrapper)

        self.overlay = VTKOverlay(self.vtk_widget)
        self._connect_overlay_signals()
        self.camera_rig_overlay = CameraRigOverlay(self.vtk_widget)

    def _setup_vtk(self):
        """Initialisiert VTK-Komponenten"""
        self.renderer = vtk.vtkRenderer()
        self.vtk_widget.GetRenderWindow().AddRenderer(self.renderer)
        
        render_window = self.vtk_widget.GetRenderWindow()
        render_window.SetMultiSamples(4)

        self.renderer.SetBackground(0.15, 0.15, 0.2)
        self.renderer.SetBackground2(0.05, 0.05, 0.1)
        self.renderer.SetGradientBackground(True)
        setup_lights(self.renderer)

        self.camera_manager = VTKCamera(self.renderer)
        self.camera_manager.set_iso()

        self.interactor = self.vtk_widget.GetRenderWindow().GetInteractor()
        style = vtk.vtkInteractorStyleTrackballCamera()
        self.interactor.SetInteractorStyle(style)
        self.interactor.Initialize()

        self.distance_widget = None
        self.camera_rig = CameraRig(self.renderer)

    # ===== METHODEN FÜR SCHWEBENDE TEXTANZEIGEN =====

    def _create_speed_text(self, position, v_eff, max_speed, track_name=""):
        """Erstellt einen 3D-Text der immer zur Kamera zeigt"""
        
        speed_mms = v_eff * max_speed
        
        # Text mit Track-Name und Geschwindigkeit
        text_source = vtk.vtkVectorText()
        if track_name:
            text_source.SetText(f"{track_name}: {speed_mms:.0f} mm/s")
        else:
            text_source.SetText(f"{speed_mms:.0f} mm/s")
        
        # Mapper
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(text_source.GetOutputPort())
        
        # Follower statt normalem Actor - dreht sich immer zur Kamera
        follower = vtk.vtkFollower()
        follower.SetMapper(mapper)
        
        # 🔥 EINFACHE LÖSUNG: Schriftgröße = Marker-Größe * Faktor
        marker_size = self.overlay.get_marker_size()
        text_scale = marker_size * self.text_scale_factor
        
        follower.SetPosition(position.x, position.y, position.z + marker_size * 2)
        follower.SetScale(text_scale, text_scale, text_scale)
        
        # Farbe basierend auf Geschwindigkeit
        if v_eff < 0.5:
            r = v_eff * 2.0
            g = 1.0
            b = 0.0
        else:
            r = 1.0
            g = 1.0 - (v_eff - 0.5) * 2.0
            b = 0.0
        
        follower.GetProperty().SetColor(r, g, b)
        follower.GetProperty().SetSpecular(0.3)
        follower.GetProperty().SetSpecularPower(10)
        
        # Kamera setzen (wichtig für Follower!)
        follower.SetCamera(self.renderer.GetActiveCamera())
        
        return follower
    
    def _update_speed_texts(self):
        """Aktualisiert alle Geschwindigkeitstexte"""
        
        # 🔥 Wenn Rig-Mode aktiv, gar nichts anzeigen
        if self.camera_rig and self.camera_rig.active:
            # Alte Texte entfernen und keine neuen erstellen
            for text_actor in self.speed_text_actors:
                self.renderer.RemoveActor(text_actor)
            self.speed_text_actors.clear()
            return
        
        # Alte Texte entfernen
        for text_actor in self.speed_text_actors:
            self.renderer.RemoveActor(text_actor)
        self.speed_text_actors.clear()
        
        # Neue Texte für alle Marker erstellen
        if not self._is_track_mode and self.marker_actors:
            for marker, track, curve, v_eff in self.marker_actors:
                pos = marker.GetPosition()
                if pos != (0, 0, 0):
                    # Konvertiere Tupel zu Point-Objekt
                    class Point:
                        def __init__(self, x, y, z):
                            self.x = x
                            self.y = y
                            self.z = z
                    point = Point(pos[0], pos[1], pos[2])
                    
                    max_speed = getattr(track, 'max_speed', 100.0)
                    text_actor = self._create_speed_text(point, v_eff, max_speed, track.name)
                    self.renderer.AddActor(text_actor)
                    self.speed_text_actors.append(text_actor)
        
        elif self.marker_actor and self.curve and self.current_track:
            pos = self.marker_actor.GetPosition()
            if pos != (0, 0, 0):
                # Konvertiere Tupel zu Point-Objekt
                class Point:
                    def __init__(self, x, y, z):
                        self.x = x
                        self.y = y
                        self.z = z
                point = Point(pos[0], pos[1], pos[2])
                
                # Für Einzeltrack: v_eff aus current_track holen
                if hasattr(self.current_track, 'current_times') and len(self.current_track.current_times) > 0:
                    times = self.current_track.current_times
                    idx = int(self.current_pos * len(times))
                    idx = min(idx, len(times) - 1)
                    if hasattr(self.current_track, 'pedals') and self.current_track.pedals is not None:
                        v_eff = abs(self.current_track.pedals[idx])
                    else:
                        v_eff = 0.5
                    
                    max_speed = getattr(self.current_track, 'max_speed', 100.0)
                    text_actor = self._create_speed_text(point, v_eff, max_speed, self.current_track.name)
                    self.renderer.AddActor(text_actor)
                    self.speed_text_actors.append(text_actor)

    # ===== KAMERA-RIG METHODEN =====

    def _on_camera_rig_toggled(self, enabled):
        """Kamera-Rig ein/aus schalten"""
        if not self.camera_rig:
            return
            
        if not self._is_track_mode and len(self.marker_actors) >= 2:
            self.camera_rig.toggle(enabled)
            
            if enabled:
                print("🔴 RIG-MODUS AKTIVIERT")
                self.camera_rig.update()
                
                # 🔥 Speed-Marker sofort ausblenden
                self._update_speed_texts()
                
                # Wenn Vollbild offen, Timeline anpassen
                if self.fullscreen_window:
                    self.fullscreen_window.set_rig_mode(True)
                    
            else:
                print("🟢 RIG-MODUS DEAKTIVIERT")
                if self.frame_animator.preview_mode:
                    self.frame_animator.stop_preview()
                
                # 🔥 Speed-Marker wieder einblenden
                self._update_speed_texts()
                
                # Wenn Vollbild offen, Timeline zurücksetzen
                if self.fullscreen_window:
                    self.fullscreen_window.set_rig_mode(False)

    def _on_camera_rig_tracks_changed(self, cam_track_name, target_track_name):
        """Track-Auswahl für Kamera-Rig ändern"""
        if not self.camera_rig:
            return
        
        print(f"🎥 CameraRig: Tracks ausgewählt - Kamera: {cam_track_name}, Ziel: {target_track_name}")
        
        cam_track = self.tracks_data.get(cam_track_name, (None, None))[0]
        target_track = self.tracks_data.get(target_track_name, (None, None))[0]
        
        if cam_track and target_track:
            self.camera_rig.set_tracks(cam_track, target_track)
            
            if self.camera_rig.active:
                self.camera_rig.update()
        else:
            print(f"⚠️ Konnte Tracks nicht finden: {cam_track_name} -> {target_track_name}")

    def _connect_overlay_signals(self):
        """Verbindet die Signale des Haupt-Overlays"""
        self.overlay.camera_requested.connect(self._on_camera_request)
        self.overlay.track_selected.connect(self._on_track_selected)
        self.overlay.group_selected.connect(self._on_group_selected)
        self.overlay.radius_changed.connect(self._on_radius_changed)
        self.overlay.marker_size_changed.connect(self._on_marker_size_changed)
        self.overlay.view_mode_changed.connect(self._on_view_mode_changed)
        self.overlay.measure_toggled.connect(self.toggle_measure_mode)

        self.overlay.trk_radio.setChecked(True)
        self.overlay.grp_radio.setChecked(False)

    # ===== PREVIEW METHODEN =====
        
    def prepare_rig_preview(self):
        """Bereitet Rig-Preview vor"""
        if self.camera_rig and self.camera_rig.active and self.current_group_tracks:
            first_track = self.current_group_tracks[0][0]
            if hasattr(first_track, 'duration') and hasattr(first_track, 'max_speed'):
                duration = first_track.duration
                v_max = first_track.max_speed
                
                # 🔥 ALLE Tracks für den Animator sammeln (wie in set_group_curves!)
                all_tracks_for_animator = []
                
                # Positionstracks
                for track, curve in self.current_group_tracks:
                    all_tracks_for_animator.append((track, curve))
                
                # Roll-Tracks aus der Gruppe
                if hasattr(self, 'group_to_tracks') and self.current_vtk_group:
                    for track_name in self.group_to_tracks.get(self.current_vtk_group, []):
                        if track_name.endswith("_Roll") and track_name in self.tracks_data:
                            track_tuple = self.tracks_data[track_name]
                            track = track_tuple[0]
                            all_tracks_for_animator.append((track, None))
                            print(f"   🎯 Roll-Track für Preview: {track_name}")
                
                self.frame_animator.prepare_animation(
                    duration,
                    all_tracks_for_animator,  # 🔥 Jetzt mit Roll-Tracks!
                    v_max
                )
                print(f"✅ Preview vorbereitet mit {len([t for t,_ in all_tracks_for_animator if t.name.endswith('_Roll')])} Roll-Tracks")
    
    def start_rig_preview(self):
        """Startet Preview-Playback"""
        if self.camera_rig and self.camera_rig.active:
            self.frame_animator.start_preview()
    
    def stop_rig_preview(self):
        """Stoppt Preview"""
        self.frame_animator.stop_preview()
        if self.camera_rig:
            self.camera_rig.toggle(False)

    # 🔥 NEUE METHODE: Kamera registrieren
    def register_rig_camera(self, rig_name, camera_actor):
        """Registriert eine Kamera für ein Rig"""
        self.rig_cameras[rig_name] = camera_actor
        print(f"📷 Kamera für Rig {rig_name} registriert")
    
    # 🔥 NEUE METHODE: Kamera für Rig holen
    def get_camera_for_rig(self, rig_name):
        """Gibt die Kamera für ein Rig zurück"""
        return self.rig_cameras.get(rig_name)
    
    # 🔥 NEUE METHODE: Pivot Marker für Rig holen
    def get_pivot_for_rig(self, rig_name):
        """Findet den PIVOT Marker für ein Rig"""
        pivot_name = f"{rig_name}_Pivot"
        for item in self.marker_actors:
            if len(item) == 4:
                marker, track, _, _ = item
            else:
                marker, track, _ = item
            
            if track.name == pivot_name:
                return marker
        return None


    # ===== PLAYBACK METHODEN =====

    def play(self):
        """Startet Animation"""
        if self._updating_play_state:
            return
            
        self._updating_play_state = True
        
        if not self.is_animating and self.duration > 0:
            self.is_animating = True
            self.animation_timer.start()
            self.playback_play.emit()
            self._update_fullscreen_play_state()
            
        self._updating_play_state = False

    def pause(self):
        """Pausiert Animation"""
        if self._updating_play_state:
            return
            
        self._updating_play_state = True
        
        if self.is_animating:
            self.is_animating = False
            self.animation_timer.stop()
            self.playback_pause.emit()
            self._update_fullscreen_play_state()
            
        self._updating_play_state = False

    def stop(self):
        """Stoppt Animation und setzt zurück"""
        if self._updating_play_state:
            return
            
        self._updating_play_state = True
        
        was_animating = self.is_animating
        self.pause()
        if was_animating or self.current_pos > 0:
            self.set_marker(0.0)
            self.playback_stop.emit()
            self._update_fullscreen_play_state()
            
        self._updating_play_state = False

    def _on_animation_timer(self):
        """Wird bei jedem Timer-Intervall aufgerufen"""
        if self.duration <= 0:
            return
        
        step = 0.016 / self.duration
        new_pos = self.current_pos + step
        
        if new_pos >= 1.0:
            self.stop()
        else:
            self.set_marker(new_pos)
            self.playback_position_changed.emit(new_pos)

    def _update_fullscreen_play_state(self):
        """Aktualisiert Play-Status im Vollbild"""
        if self.fullscreen_window and not self._updating_play_state:
            self.fullscreen_window.set_playing_from_timeline(self.is_animating)

    def set_playing_from_timeline(self, playing):
        """Wird vom EditorPanel aufgerufen wenn Timeline Play/Pause ändert"""
        if self._updating_play_state:
            return
            
        self._updating_play_state = True
        
        rig_active = self.camera_rig and self.camera_rig.active
        
        if playing:
            if not self.is_animating:
                self.is_animating = True
                
                if rig_active:
                    self.animation_timer.stop()
                    print("🎬 FrameAnimator start (Rig-Modus)")
                    self.frame_animator.start()
                else:
                    self.frame_animator.stop()
                    self.animation_timer.start()
                    print("🎬 Normaler Timer start")
                
                self.playback_play.emit()
        else:
            if self.is_animating:
                self.is_animating = False
                self.animation_timer.stop()
                self.frame_animator.pause()
                self.playback_pause.emit()
        
        self._update_fullscreen_play_state()
        self._updating_play_state = False

    def set_position_from_timeline(self, pos):
        """Setzt Position von extern"""
        if self._updating_position:
            return
            
        self._updating_position = True
        
        if self.group_mode and self.frame_animator.total_frames > 0 and not self.frame_animator.preview_mode:
            # Hier fehlte die set_position Methode - für jetzt einfach set_marker
            self.set_marker(pos)
        else:
            self.set_marker(pos)
        
        self._updating_position = False

    # ===== PUBLIC METHODEN FÜR DATEN =====

    def set_tracks_data(self, tracks_data, track_to_group=None):
        """
        Setzt Track-Daten und speichert Gruppenzuordnung
        
        Args:
            tracks_data: Dict {track_name: (track, curve)}
            track_to_group: Dict {track_name: group_name}
        """
        self.tracks_data = tracks_data
        self.track_to_group = track_to_group or {}
        
        # Für schnellen Zugriff auch reverse mapping
        self.group_to_tracks = {}
        for track_name, group_name in self.track_to_group.items():
            if group_name not in self.group_to_tracks:
                self.group_to_tracks[group_name] = []
            self.group_to_tracks[group_name].append(track_name)

    def update_track_names(self, names, track_to_group=None):
        """
        Aktualisiert Track-Liste im Overlay - mit Gruppenzuordnung
        
        Args:
            names: Liste aller Track-Namen
            track_to_group: Dict {track_name: group_name}
        """
        self.track_names = names
        if track_to_group:
            self.track_to_group = track_to_group
            
            # Reverse mapping aktualisieren
            self.group_to_tracks = {}
            for track_name, group_name in track_to_group.items():
                if group_name not in self.group_to_tracks:
                    self.group_to_tracks[group_name] = []
                self.group_to_tracks[group_name].append(track_name)
        
        if not self.is_fullscreen:
            if hasattr(self, 'track_to_group') and self.track_to_group:
                self.overlay.update_tracks_with_groups(names, self.track_to_group)
            else:
                self.overlay.update_tracks_with_groups(names, {})
        
        if self.fullscreen_window:
            self.fullscreen_window.set_track_names(names)
            
    def update_group_names(self, names):
        self.group_names = names
        if not self.is_fullscreen:
            self.overlay.update_groups(names)
        if self.fullscreen_window:
            self.fullscreen_window.set_group_names(names)

    def set_duration(self, duration):
        """Setzt die Duration und aktualisiert Vollbild"""
        self.duration = duration
        if self.fullscreen_window:
            self.fullscreen_window.set_duration_from_timeline(duration)

    def set_playing(self, playing: bool):
        self.is_animating = playing
        self._update_fullscreen_play_state()

    # ===== VIEW MODE MANAGEMENT =====

    def _on_view_mode_changed(self, mode):
        is_track = (mode == "track")
        if is_track == self._is_track_mode:
            return

        self._is_track_mode = is_track
        self.group_mode = not is_track

        self.overlay.trk_radio.setChecked(is_track)
        self.overlay.grp_radio.setChecked(not is_track)

        if self.fullscreen_window:
            self.fullscreen_window.sync_mode(is_track)

        self.view_mode_changed.emit(mode)

    def _on_request_mode_change(self, mode):
        is_track = (mode == "track")
        if is_track == self._is_track_mode:
            return

        self._is_track_mode = is_track
        self.group_mode = not is_track

        self.overlay.trk_radio.setChecked(is_track)
        self.overlay.grp_radio.setChecked(not is_track)

        if self.fullscreen_window:
            self.fullscreen_window.sync_mode(is_track)

        self.view_mode_changed.emit(mode)

    # ===== TRACK/GROUP SELECTION =====

    def _on_track_selected(self, track_name):
        """Track ausgewählt - mit Gruppenzuordnung"""
        print(f"🎯 Track ausgewählt: {track_name}")
        
        if hasattr(self, 'track_to_group'):
            group = self.track_to_group.get(track_name, "Unbekannt")
            print(f"   → Gruppe: {group}")
        
        if track_name in self.tracks_data:
            track, curve = self.tracks_data[track_name]
            self.set_curve(curve, track)
            self.track_selected.emit(track_name)

            if self.fullscreen_window and not getattr(self.fullscreen_window, '_internal_change', False):
                self.fullscreen_window.track_combo.setCurrentText(track_name)
            
            if not self.is_fullscreen:
                for i in range(self.overlay.track_combo.count()):
                    if self.overlay.track_combo.itemText(i).strip() == track_name:
                        self.overlay.track_combo.setCurrentIndex(i)
                        break

    def _on_group_selected(self, group_name):
        print(f"👥 VTK Gruppe ausgewählt: {group_name}")
        
        # Verhindere doppelte Auswahl derselben Gruppe
        if self.group_mode and self.current_vtk_group == group_name:
            print(f"   Gruppe {group_name} bereits aktiv")
            return
        
        # Tracks der Gruppe finden
        group_tracks_with_curves = []
        found_group = None
        
        for group in self.tracks_container.groups:
            if group.name == group_name:
                found_group = group
                for track_lane in group.tracks:
                    track = track_lane.track
                    curve = self.curves_data.get(track.name)
                    if curve is not None:
                        if not hasattr(track, 'current_times') or track.current_times is None:
                            track.current_times = np.linspace(0, 1, 100)
                        group_tracks_with_curves.append((track, curve))
                break
        
        if group_tracks_with_curves:
            print(f"   Lade {len(group_tracks_with_curves)} Tracks aus Gruppe {group_name}")
            
            # 🔥 NICHT MEHR HIER SETZEN - das macht jetzt set_group_curves!
            self.set_group_curves(group_tracks_with_curves, initial_fit=True, group_name=group_name)
            
            self.last_group_name = group_name
            self.current_vtk_track = None
            self.vtk_view.set_marker(self.current_pos)
            
            if hasattr(self.vtk_view, 'fullscreen_window') and self.vtk_view.fullscreen_window:
                self.vtk_view.fullscreen_window.group_combo.setCurrentText(group_name)
        else:
            print(f"⚠️ Keine Tracks mit Kurven in Gruppe {group_name} gefunden")

    # ===== CAMERA MANAGEMENT =====

    def _on_camera_request(self, view_name):
        print(f"🎥 Kamera-Anfrage: {view_name}")
        
        if view_name == "top":
            self.camera_manager.set_top()
        elif view_name == "front":
            self.camera_manager.set_front()
        elif view_name == "side":
            self.camera_manager.set_side()
        elif view_name == "back":
            self.camera_manager.set_back()
        elif view_name == "iso":
            self.camera_manager.set_iso()
        elif view_name == "fit":
            self.auto_fit_view()
            return
        elif view_name == "fullscreen":
            self.toggle_fullscreen()
            return
        
        self.auto_fit_view() 

    def auto_fit_view(self):
        self.renderer.ResetCamera()
        self.renderer.ResetCameraClippingRange()
        cam = self.renderer.GetActiveCamera()
        near, far = cam.GetClippingRange()
        cam.SetClippingRange(near * 0.5, far * 1.8)
        self.vtk_widget.GetRenderWindow().Render()

    # ===== RADIUS & MARKER SIZE =====

    def _on_radius_changed(self, radius):
        print(f"📏 Tube Radius Update: {radius}")
        
        if self.is_fullscreen and self.fullscreen_window:
            self.overlay.tube_combo.setCurrentText(str(radius))
        elif not self.is_fullscreen and self.fullscreen_window:
            self.fullscreen_window.tube_combo.setCurrentText(str(radius))

        # 🔥 ALLE Kurven neu rendern (egal welcher Mode)
        for actor, _ in self.curve_actors:
            self.renderer.RemoveActor(actor)
        self.curve_actors.clear()
        
        if not self._is_track_mode and self.current_group_tracks:
            # Group Mode
            for i, (track, curve) in enumerate(self.current_group_tracks):
                if curve and track:
                    color = self.group_colors[i % len(self.group_colors)]
                    self.add_curve(curve, track, color, track.name)
        elif self.curve and self.current_track:
            # Track Mode
            self.add_curve(self.curve, self.current_track)
        
        self.vtk_widget.GetRenderWindow().Render()

    def _on_marker_size_changed(self, size):
        """Marker-Größe wurde geändert"""
        print(f"🔴 Marker Size Update: {size}")
        
        if self.is_fullscreen and self.fullscreen_window:
            self.overlay.marker_combo.setCurrentText(str(size))
        elif not self.is_fullscreen and self.fullscreen_window:
            self.fullscreen_window.marker_combo.setCurrentText(str(size))

        if not self._is_track_mode:
            for marker_actor, _, _, _ in self.marker_actors:
                self._update_marker_actor_size(marker_actor, size)
        elif self.marker_actor:
            self._update_marker_actor_size(self.marker_actor, size)
        
        # 🔥 Texte neu erstellen mit neuer Größe
        self._update_speed_texts()

        self.vtk_widget.GetRenderWindow().Render()    

    def _refresh_markers_with_new_size(self, new_size):
        """Aktualisiert alle Marker mit neuer Größe"""
        if not self.current_group_tracks:
            return
        
        for marker_actor, _, _, _ in self.marker_actors:
            self._update_marker_actor_size(marker_actor, new_size)
        
        # 🔥 Texte neu erstellen
        self._update_speed_texts()

    # ===== VOLLBILD =====

    def toggle_fullscreen(self):
        if not self.fullscreen_window:
            self._open_fullscreen()
        else:
            self.close_fullscreen()

    def _open_fullscreen(self):
        was_playing = self.is_animating
        print(f"🎬 Vollbild öffnen - is_animating = {was_playing}")
        # 🔥 HIER muss die Variable definiert werden!
        is_rig_active = self.camera_rig and self.camera_rig.active
        
        if was_playing:
            self.pause()
        
        self.overlay.hide()
        self.is_fullscreen = True

        self.fullscreen_window = FullscreenVTKWindow(self.window())

        # 🔥 WICHTIG: Rig-Mode Status an Vollbild übergeben!
        self.fullscreen_window.set_rig_mode(is_rig_active)
                
        # 🔥 WICHTIG: Erst das VTK widget hinzufügen
        self.vtk_widget.setParent(self.fullscreen_window.vtk_container)
        self.fullscreen_window.vtk_container.layout().addWidget(self.vtk_widget)
        self.vtk_widget.show()
        
        # DANN alle Daten setzen (nachdem das Fenster vollständig ist)
        self.fullscreen_window.set_track_names(self.track_names)
        self.fullscreen_window.set_group_names(self.group_names)
        self.fullscreen_window.sync_mode(self._is_track_mode)

        self.fullscreen_window.tube_combo.setCurrentText(
            self.overlay.tube_combo.currentText()
        )
        self.fullscreen_window.marker_combo.setCurrentText(
            self.overlay.marker_combo.currentText()
        )
        
        # 🔥 Duration und Position setzen (mit den echten Werten!)
        print(f"   → Setze Duration: {self.duration}s")
        self.fullscreen_window.set_duration_from_timeline(self.duration)
        self.fullscreen_window.set_position_from_timeline(self.current_pos)
        self.fullscreen_window.set_playing_state(was_playing)

        self._connect_fullscreen_signals()

        print("🎬 Vollbild-Fenster geöffnet")

    def _connect_fullscreen_signals(self):
        fs = self.fullscreen_window
        
        print("\n🔗 VTK: Verbinde Vollbild-Signale...")
        
        fs.closed.connect(self._on_fullscreen_closed)
        fs.play_toggled.connect(self._on_fullscreen_play_toggled)
        fs.position_changed.connect(self._on_fullscreen_position_changed)
        fs.position_dragged.connect(self._on_fullscreen_position_dragged)
        fs.stop_clicked.connect(self._on_fullscreen_stop_clicked)
        
        fs.track_selected.connect(self._on_track_selected)
        fs.group_selected.connect(self._on_group_selected)
        fs.camera_requested.connect(self._on_camera_request)
        fs.radius_changed.connect(self._on_radius_changed)
        fs.marker_size_changed.connect(self._on_marker_size_changed)
        fs.request_mode_change.connect(self._on_request_mode_change)
        print("   - alle Signale verbunden")

    def _on_fullscreen_play_toggled(self, playing):
        print(f"\n🎥 VTK: _on_fullscreen_play_toggled({playing})")
        
        if self._updating_play_state:
            return
            
        self._updating_play_state = True
        
        rig_active = self.camera_rig and self.camera_rig.active
        
        if playing:
            if not self.is_animating:
                self.is_animating = True
                
                if rig_active:
                    print("🎬 FrameAnimator start (vom Vollbild, Rig aktiv)")
                    self.frame_animator.start()
                else:
                    print("🎬 Normaler Timer start (vom Vollbild)")
                    self.animation_timer.start()
        else:
            if self.is_animating:
                self.is_animating = False
                self.animation_timer.stop()
                self.frame_animator.pause()
        
        self.play_state_changed.emit(playing)
        self._updating_play_state = False

    def _on_fullscreen_position_changed(self, pos):
        self.set_marker(pos)
        self.playback_position_changed.emit(pos)

    def _on_fullscreen_position_dragged(self, pos):
        self.set_marker(pos)

    def _on_fullscreen_stop_clicked(self):
        self.stop()
        self.play_state_changed.emit(False)

    def close_fullscreen(self):
        if not self.fullscreen_window:
            return

        tube_val = self.fullscreen_window.tube_combo.currentText()
        marker_val = self.fullscreen_window.marker_combo.currentText()
        
        current_track = (self.fullscreen_window.track_combo.currentText() 
                       if self.fullscreen_window.track_names else "")
        current_group = (self.fullscreen_window.group_combo.currentText() 
                       if self.fullscreen_window.group_names else "")

        self.vtk_widget.setParent(self.wrapper)
        self.wrapper.layout().addWidget(self.vtk_widget)
        self.vtk_widget.show()

        self.overlay.show()
        self.overlay._update_position()
        self.overlay.raise_()

        self.overlay.tube_combo.setCurrentText(tube_val)
        self.overlay.marker_combo.setCurrentText(marker_val)
        
        if current_track and self._is_track_mode:
            self.overlay.track_combo.setCurrentText(current_track)
        if current_group and not self._is_track_mode:
            self.overlay.group_combo.setCurrentText(current_group)

        self.is_fullscreen = False
        self.fullscreen_window.close()
        self.fullscreen_window = None

        self.redraw_timer.start()
        self._force_redraw()

        print("🎬 Vollbild-Fenster geschlossen")

    def _on_fullscreen_closed(self):
        if self.fullscreen_window:
            tube_val = self.fullscreen_window.tube_combo.currentText()
            marker_val = self.fullscreen_window.marker_combo.currentText()
            
            current_track = (self.fullscreen_window.track_combo.currentText() 
                           if self.fullscreen_window.track_names else "")
            current_group = (self.fullscreen_window.group_combo.currentText() 
                           if self.fullscreen_window.group_names else "")

            if self.vtk_widget.parent() != self.wrapper:
                self.vtk_widget.setParent(self.wrapper)
                self.wrapper.layout().addWidget(self.vtk_widget)

            self.overlay.show()
            self.overlay._update_position()
            self.overlay.raise_()

            self.overlay.tube_combo.setCurrentText(tube_val)
            self.overlay.marker_combo.setCurrentText(marker_val)
            
            if current_track and self._is_track_mode:
                self.overlay.track_combo.setCurrentText(current_track)
            if current_group and not self._is_track_mode:
                self.overlay.group_combo.setCurrentText(current_group)

            self.fullscreen_window = None
            self.is_fullscreen = False

            self.redraw_timer.start()
            self._force_redraw()

    # ===== KURVEN =====

    def _get_speed_color(self, v_eff):
        """
        Perfekt linearer Verlauf über den HSV-Farbraum
        """
        hue = 120 * (1 - v_eff)
        
        h = hue / 60.0
        i = int(h)
        f = h - i
        p = 0.0
        q = 1.0 * (1 - f)
        t = 1.0 * f
        
        if i == 0:
            r, g, b = 1.0, t, p
        elif i == 1:
            r, g, b = q, 1.0, p
        elif i == 2:
            r, g, b = p, 1.0, t
        elif i == 3:
            r, g, b = p, q, 1.0
        elif i == 4:
            r, g, b = t, p, 1.0
        else:
            r, g, b = 1.0, p, q
        
        return (r, g, b)
    
    def set_group_curves(self, tracks_with_curves, initial_fit=True, group_name=None):
        """Zeigt eine Gruppe von Kurven an - JETZT MIT ROLL-TRACKS!"""
        
        # 🔥 GANZ AM ANFANG: current_vtk_group setzen!
        if group_name:
            self.current_vtk_group = group_name
            print(f"🎯 set_group_curves: current_vtk_group jetzt = {self.current_vtk_group}")
        
        if self.frame_animator.is_playing:
            self.frame_animator.stop()
        
        self.group_mode = True
        self._is_track_mode = False
        self.current_group_tracks = tracks_with_curves
        
        self.animation_timer.stop()
        self.is_animating = False
        
        # Alte Texte entfernen
        for text_actor in self.speed_text_actors:
            self.renderer.RemoveActor(text_actor)
        self.speed_text_actors.clear()
        
        self.remove_all_curves()
        self.remove_all_markers()
        
        # 🔥 Rig-Kameras zurücksetzen
        self.rig_cameras.clear()
        
        # Normale Tubes (einfarbig)
        for i, (track, curve) in enumerate(tracks_with_curves):
            if curve and track:
                color = self.group_colors[i % len(self.group_colors)]
                self.add_curve(curve, track, color, track.name)
        
        # Marker mit dynamischer Farbe + Text erstellen
        for i, (track, curve) in enumerate(tracks_with_curves):
            if not curve:
                continue
            
            sphere = vtk.vtkSphereSource()
            sphere.SetRadius(self.overlay.get_marker_size())
            sphere.SetThetaResolution(12)
            sphere.SetPhiResolution(12)
            
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(sphere.GetOutputPort())
            
            marker = vtk.vtkActor()
            marker.SetMapper(mapper)
            
            if hasattr(track, 'current_times') and len(track.current_times) > 0:
                times = track.current_times
                idx = int(self.current_pos * len(times))
                idx = min(idx, len(times) - 1)
                t_val = times[idx]
                
                if hasattr(track, 'pedals') and track.pedals is not None:
                    v_eff = abs(track.pedals[idx])
                else:
                    v_eff = 0.5
                
                r, g, b = self._get_speed_color(v_eff)
                marker.GetProperty().SetColor(r, g, b)
                marker.GetProperty().SetSpecular(0.8)
                marker.GetProperty().SetSpecularPower(30)
                
                try:
                    p = curve.evaluate(t_val)
                    marker.SetPosition(p.x, p.y, p.z)
                    
                    self.marker_actors.append((marker, track, curve, v_eff))
                    
                    # 🔥 FIX: Nur PIVOT Marker als Kamera registrieren (für Kompatibilität)
                    if track.name.endswith("_Pivot"):
                        rig_name = track.name.replace("_Pivot", "")
                        self.register_rig_camera(rig_name, marker)
                        print(f"   ✅ Kamera für Rig {rig_name} registriert (Pivot)")
                    
                    # Lens Marker NICHT als Kamera registrieren!
                    
                    if hasattr(track, 'max_speed'):
                        max_speed = track.max_speed
                    else:
                        max_speed = 100.0
                    
                    text_actor = self._create_speed_text(p, v_eff, max_speed, track.name)
                    self.renderer.AddActor(text_actor)
                    self.speed_text_actors.append(text_actor)
                        
                except Exception as e:
                    print(f"Fehler bei Marker-Erstellung: {e}")
                    marker.SetPosition(0, 0, 0)
                    self.marker_actors.append((marker, track, curve, 0.5))
            else:
                marker.SetPosition(0, 0, 0)
                self.marker_actors.append((marker, track, curve, 0.5))
            
            self.renderer.AddActor(marker)
        
        if self.camera_rig:
            self.camera_rig.set_marker_actors([(a,t,c) for a,t,c,v in self.marker_actors])
        
        print(f"🔍 DEBUG IN set_group_curves: group_to_tracks = {self.group_to_tracks}")
        print(f"🔍 DEBUG IN set_group_curves: current_vtk_group = {self.current_vtk_group}")
        
        # Jetzt sollte current_vtk_group NICHT mehr None sein!
        tracks_in_group = self.group_to_tracks.get(self.current_vtk_group, []) if self.current_vtk_group else []
        print(f"🔍 DEBUG IN set_group_curves: tracks in group: {tracks_in_group}")

        # ============================================================
        # 🔥 ALLE TRACKS FÜR ANIMATOR SAMMELN (INKL. ROLL-TRACKS!)
        # ============================================================
        if (len(tracks_with_curves) > 0 and 
            hasattr(tracks_with_curves[0][0], 'pedals') and 
            tracks_with_curves[0][0].pedals is not None and 
            len(tracks_with_curves[0][0].pedals) > 0):
            
            duration = tracks_with_curves[0][0].duration
            v_max = tracks_with_curves[0][0].max_speed
            
            # 🔥 ALLE Tracks für den Animator sammeln
            all_tracks_for_animator = []
            
            # Zuerst die normalen Tracks mit Kurven
            for track, curve in tracks_with_curves:
                all_tracks_for_animator.append((track, curve))
                print(f"   📌 Positions-Track: {track.name}")
            
            # 🔥 Dann alle Roll-Tracks aus der Gruppe hinzufügen
            if hasattr(self, 'group_to_tracks') and self.current_vtk_group:
                for track_name in self.group_to_tracks.get(self.current_vtk_group, []):
                    if track_name.endswith("_Roll") and track_name in self.tracks_data:
                        track_tuple = self.tracks_data[track_name]
                        track = track_tuple[0]  # Der Track ist das erste Element
                        all_tracks_for_animator.append((track, None))
                        print(f"   🎯 Roll-Track hinzugefügt: {track_name}")
            
            if duration > 0:
                self.frame_animator.prepare_animation(
                    duration,
                    all_tracks_for_animator,  # 🔥 Jetzt mit Roll-Tracks!
                    v_max
                )
                roll_count = len([t for t,_ in all_tracks_for_animator if t.name.endswith('_Roll')])
                print(f"✅ Frame-Animator vorbereitet: {self.frame_animator.total_frames} Frames mit {roll_count} Roll-Tracks")
        
        if initial_fit:
            self.auto_fit_view()
        
        self.vtk_widget.GetRenderWindow().Render()

    def set_curve(self, curve, track=None, initial_fit=True):
        """Zeigt einen einzelnen Track an"""
        self.group_mode = False
        self._is_track_mode = True
        self.current_group_tracks = []
        
        # Alte Texte entfernen
        for text_actor in self.speed_text_actors:
            self.renderer.RemoveActor(text_actor)
        self.speed_text_actors.clear()
        
        self.remove_all_curves()
        self.remove_all_markers()
        
        self.curve = curve
        self.current_track = track
        
        if curve is None:
            return
        
        self.add_curve(curve, track)
        
        self._create_marker()
        
        if self.camera_rig:
            self.camera_rig.reset()
        
        if initial_fit:
            self.auto_fit_view()
        
        self.vtk_widget.GetRenderWindow().Render()

    def add_curve(self, curve, track=None, color=None, track_name=""):
        """Fügt eine einfarbige Kurve als Tube hinzu"""
        if curve is None:
            return None
        
        points = vtk.vtkPoints()
        num_points = 3000
        
        for i in range(num_points):
            t = i / (num_points - 1)
            try:
                p = curve.evaluate(t)
                points.InsertNextPoint(p.x, p.y, p.z)
            except:
                pass
        
        polyline = vtk.vtkPolyLine()
        polyline.GetPointIds().SetNumberOfIds(points.GetNumberOfPoints())
        for i in range(points.GetNumberOfPoints()):
            polyline.GetPointIds().SetId(i, i)
        
        cells = vtk.vtkCellArray()
        cells.InsertNextCell(polyline)
        
        polyData = vtk.vtkPolyData()
        polyData.SetPoints(points)
        polyData.SetLines(cells)
        
        if self.is_fullscreen and self.fullscreen_window:
            radius = float(self.fullscreen_window.tube_combo.currentText())
        else:
            radius = self.overlay.get_tube_radius()
        
        tubeFilter = vtk.vtkTubeFilter()
        tubeFilter.SetInputData(polyData)
        tubeFilter.SetRadius(radius)
        tubeFilter.SetNumberOfSides(16)
        tubeFilter.CappingOn()
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(tubeFilter.GetOutputPort())
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        
        if color:
            actor.GetProperty().SetColor(color[0], color[1], color[2])
        else:
            actor.GetProperty().SetColor(1, 0.7, 0.2)
        
        actor.GetProperty().SetSpecular(0.4)
        actor.GetProperty().SetSpecularPower(15)
        actor.GetProperty().SetAmbient(0.2)
        
        self.renderer.AddActor(actor)
        self.curve_actors.append((actor, track_name))
        
        return actor

    def remove_all_curves(self):
        """Entfernt alle Kurven"""
        for actor, _ in self.curve_actors:
            self.renderer.RemoveActor(actor)
        self.curve_actors = []
        self.curve = None

    # ===== MARKER =====

    def _create_marker(self):
        """Erstellt einen Marker für Single-Track-Modus"""
        if self.marker_actor:
            self.renderer.RemoveActor(self.marker_actor)
        
        if self.is_fullscreen and self.fullscreen_window:
            size = float(self.fullscreen_window.marker_combo.currentText())
        else:
            size = self.overlay.get_marker_size()
        
        sphere = vtk.vtkSphereSource()
        sphere.SetRadius(size)
        sphere.SetThetaResolution(16)
        sphere.SetPhiResolution(16)
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(sphere.GetOutputPort())
        
        self.marker_actor = vtk.vtkActor()
        self.marker_actor.SetMapper(mapper)
        
        self.marker_actor.GetProperty().SetColor(1, 0.2, 0.2)
        self.marker_actor.GetProperty().SetSpecular(0.8)
        self.marker_actor.GetProperty().SetSpecularPower(30)
        
        self.renderer.AddActor(self.marker_actor)
        self.set_marker(self.current_pos)

    def set_marker(self, pos):
        #print(f"🎯 VTK set_marker({pos:.4f}) - is_playing: {self.is_animating}")
        """Setzt die Marker-Position - mit farbigen Markern und Text"""
        self.current_pos = pos
        
        # GROUP MODE - funktioniert perfekt
        if not self._is_track_mode and self.marker_actors:
            # Marker-Positionen aktualisieren
            new_marker_actors = []
            for marker, track, curve, old_v in self.marker_actors:
                if hasattr(track, 'current_times') and len(track.current_times) > 0:
                    times = track.current_times
                    idx = int(pos * len(times))
                    idx = min(idx, len(times) - 1)
                    t_val = times[idx]
                    
                    try:
                        p = curve.evaluate(t_val)
                        if p is not None:
                            marker.SetPosition(p.x, p.y, p.z)
                            
                            if hasattr(track, 'pedals') and track.pedals is not None:
                                v_eff = abs(track.pedals[idx])
                            else:
                                v_eff = old_v
                            
                            r, g, b = self._get_speed_color(v_eff)
                            marker.GetProperty().SetColor(r, g, b)
                            
                    except Exception as e:
                        print(f"Fehler bei Marker-Update: {e}")
                        v_eff = old_v
                else:
                    v_eff = old_v
                
                new_marker_actors.append((marker, track, curve, v_eff))
            
            self.marker_actors = new_marker_actors
            self._update_speed_texts()
            
            if self.camera_rig and self.camera_rig.active:
                self.camera_rig.update()
            
            # 🔥 FIX: Vollbild über neue Methoden aktualisieren
            if self.fullscreen_window:
                self.fullscreen_window.set_position_from_timeline(pos)
                self.fullscreen_window.set_duration_from_timeline(self.duration)
        
        # TRACK-MODE - JETZT MIT EXAKT GLEICHER LOGIK
        elif self.marker_actor and self.curve and self.current_track:
            try:
                if hasattr(self.current_track, 'current_times') and len(self.current_track.current_times) > 0:
                    times = self.current_track.current_times
                    idx = int(pos * len(times))
                    idx = min(idx, len(times) - 1)
                    t_val = times[idx]  # <-- WICHTIG: t_val aus current_times!
                    
                    # Position mit t_val berechnen (nicht mit pos!)
                    p = self.curve.evaluate(t_val)
                    if p is not None:
                        self.marker_actor.SetPosition(p.x, p.y, p.z)
                        
                        # Gleicher Index für Pedals
                        if hasattr(self.current_track, 'pedals') and self.current_track.pedals is not None:
                            v_eff = abs(self.current_track.pedals[idx])
                            
                            r, g, b = self._get_speed_color(v_eff)
                            self.marker_actor.GetProperty().SetColor(r, g, b)
                            
                            self._update_speed_texts()
                        else:
                            self.marker_actor.GetProperty().SetColor(1, 0.2, 0.2)
                
            except Exception as e:
                print(f"Fehler bei Einzeltrack-Update: {e}")
            
            # 🔥 FIX: Vollbild über neue Methoden aktualisieren
            if self.fullscreen_window:
                self.fullscreen_window.set_position_from_timeline(pos)
                self.fullscreen_window.set_duration_from_timeline(self.duration)
        
        self.vtk_widget.GetRenderWindow().Render()
        self.marker_changed.emit(pos)

    def _update_marker_actor_size(self, marker_actor, size):
        sphere = vtk.vtkSphereSource()
        sphere.SetRadius(size)
        sphere.SetThetaResolution(16)
        sphere.SetPhiResolution(16)
        marker_actor.GetMapper().SetInputConnection(sphere.GetOutputPort())

    def remove_all_markers(self):
        if self.marker_actor:
            self.renderer.RemoveActor(self.marker_actor)
            self.marker_actor = None
        
        for actor, _, _, _ in self.marker_actors:
            self.renderer.RemoveActor(actor)
        self.marker_actors = []

    # ===== HILFSMETHODEN =====

    def _force_redraw(self):
        self.vtk_widget.GetRenderWindow().Render()
        if self.overlay and self.overlay.isVisible():
            self.overlay.update()
            self.overlay._update_position()

    def toggle_measure_mode(self, enabled):
        if enabled:
            self.distance_widget = vtk.vtkDistanceWidget()
            self.distance_widget.SetInteractor(self.interactor)
            rep = vtk.vtkDistanceRepresentation2D()
            rep.GetAxis().GetTitleTextProperty().SetFontSize(14)
            rep.GetAxis().GetTitleTextProperty().SetColor(1, 0, 0)
            self.distance_widget.SetRepresentation(rep)
            self.distance_widget.CreateDefaultRepresentation()
            self.distance_widget.On()
            self.interactor.SetInteractorStyle(vtk.vtkInteractorStyleUser())
        else:
            if self.distance_widget:
                self.distance_widget.Off()
                self.distance_widget = None
            style = vtk.vtkInteractorStyleTrackballCamera()
            self.interactor.SetInteractorStyle(style)