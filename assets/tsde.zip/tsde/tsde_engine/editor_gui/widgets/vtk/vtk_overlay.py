# editor_gui/widgets/vtk/vtk_overlay.py
from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QPushButton, QLabel,
    QComboBox, QGridLayout, QRadioButton, QStackedWidget
)
from PySide6.QtCore import Qt, Signal
from tsde_engine.editor_gui.theme import Theme

class VTKOverlay(QFrame):
    """
    Maximal kompaktes Overlay-Panel für VTK-View.
    Mit QStackedWidget gegen Flackern bei Modus-Wechsel.
    """
    
    # Signale
    camera_requested = Signal(str)
    track_selected = Signal(str)
    group_selected = Signal(str)
    radius_changed = Signal(float)
    marker_size_changed = Signal(float)
    view_mode_changed = Signal(str)
    measure_toggled = Signal(bool)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("vtkOverlay")
        
        # Stabilisiert halbtransparenten Hintergrund
        self.setAttribute(Qt.WA_TranslucentBackground, False)
        self.setAutoFillBackground(True)
        
        self.setFixedSize(115, 360)  # Etwas höher für Vollbild-Button
        
        self.setStyleSheet(f"""
            #vtkOverlay {{
                background: {Theme.rgba('bg_overlay', 220)};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_MEDIUM}px;
            }}
            QLabel {{ 
                color: {Theme.rgb('text_secondary')}; 
                font-size: 7pt; 
                font-weight: bold;
                margin-top: 2px;
            }}
            QLabel#titleLabel {{
                color: {Theme.rgb('accent_blue')};
                font-size: 9pt;
                font-weight: bold;
                padding: 2px;
                background: {Theme.rgba('bg_primary', 100)};
                border-radius: 3px;
                margin-bottom: 4px;
            }}
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)
        
        # --- Styles ---
        self.btn_style = f"""
            QPushButton {{
                background: {Theme.rgba('bg_secondary', 150)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: 2px;
                font-size: 7.5pt;
                min-height: 18px;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_blue', 100)};
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
            QPushButton:checked {{
                background: {Theme.rgba('accent_blue', 180)};
                border: 1px solid white;
            }}
        """
        
        self.combo_style = f"""
            QComboBox {{
                background: {Theme.rgba('bg_secondary', 120)};
                color: white;
                border: 1px solid {Theme.rgba('border')};
                border-radius: 2px;
                font-size: 8pt;
                min-height: 20px;
                padding-left: 4px;
            }}
            QComboBox::drop-down {{ border: none; width: 14px; }}
            QComboBox::down-arrow {{ 
                image: none; 
                border-top: 4px solid {Theme.rgb('text_primary')}; 
                border-left: 3px solid transparent; 
                border-right: 3px solid transparent; 
            }}
        """

        # TITLE
        title_label = QLabel("TSDE PANEL")
        title_label.setObjectName("titleLabel")
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)

        # Modus-Umschalter (kompakt)
        mode_layout = QVBoxLayout()
        mode_layout.setSpacing(2)
        mode_layout.setContentsMargins(0, 2, 0, 4)
        
        radio_css = f"""
            QRadioButton {{ 
                color: white; 
                font-size: 7.5pt; 
                spacing: 5px;
                padding: 1px 2px;
                min-height: 16px;
            }} 
            QRadioButton::indicator {{ 
                width: 11px; 
                height: 11px; 
            }}
        """
        
        self.trk_radio = QRadioButton("🎯 Track Mode")
        self.trk_radio.setStyleSheet(radio_css)
        self.trk_radio.setChecked(True)
        self.trk_radio.toggled.connect(lambda checked: self._on_mode_changed("track") if checked else None)
        mode_layout.addWidget(self.trk_radio)
        
        self.grp_radio = QRadioButton("👥 Group Mode")
        self.grp_radio.setStyleSheet(radio_css)
        self.grp_radio.toggled.connect(lambda checked: self._on_mode_changed("group") if checked else None)
        mode_layout.addWidget(self.grp_radio)
        
        layout.addLayout(mode_layout)

        self._add_separator(layout)

        # Kamera-Grid mit Vollbild-Button
        cam_grid = QGridLayout()
        cam_grid.setSpacing(2)
        views = [("Fit", "fit"), ("Top", "top"), ("Frt", "front"), 
                 ("Sid", "side"), ("Bak", "back"), ("Iso", "iso"),
                 ("⬜", "fullscreen")]  # Vollbild-Button
        
        for i, (txt, cmd) in enumerate(views):
            btn = QPushButton(txt)
            btn.setStyleSheet(self.btn_style)
            btn.clicked.connect(lambda _, c=cmd: self.camera_requested.emit(c))
            cam_grid.addWidget(btn, i // 2, i % 2)
        layout.addLayout(cam_grid)

        # Mess-Button
        self.measure_btn = QPushButton("📏 Messen")
        self.measure_btn.setCheckable(True)
        self.measure_btn.setStyleSheet(self.btn_style)
        self.measure_btn.setFixedHeight(22)
        self.measure_btn.toggled.connect(self.measure_toggled.emit)
        layout.addWidget(self.measure_btn)

        self._add_separator(layout)

        # === AUSWAHL MIT STACKED WIDGET ===
        self.selection_stack = QStackedWidget()
        
        # 🔥 Track-Combo MIT GRUPPEN-STRUKTUR!
        self.track_combo = QComboBox()
        self.track_combo.setStyleSheet(self.combo_style)
        self.track_combo.currentTextChanged.connect(self._on_track_selected)
        self.selection_stack.addWidget(self.track_combo)
        
        # 🔥 Group-Combo (bleibt gleich)
        self.group_combo = QComboBox()
        self.group_combo.setStyleSheet(self.combo_style)
        self.group_combo.currentTextChanged.connect(self._on_group_selected)
        self.selection_stack.addWidget(self.group_combo)
        
        layout.addWidget(self.selection_stack)
        self.selection_stack.setCurrentIndex(0)  # Track-Modus

        self._add_separator(layout)

        # === GEOMETRIE-EINSTELLUNGEN (für beide Modi gleich) ===
        layout.addWidget(QLabel("📏 TUBE Ø"))
        self.tube_combo = QComboBox()
        self.tube_combo.addItems(["0.5", "1.0", "2.0", "2.5", "3.0", "5.0", "8.0", "10.0", "12.0", "15.0", "20.0", "25.0", "30.0", "35.0", "40.0", "50.0"])
        self.tube_combo.setCurrentText("2.5")
        self.tube_combo.setStyleSheet(self.combo_style)
        self.tube_combo.currentTextChanged.connect(lambda v: self.radius_changed.emit(float(v)))
        layout.addWidget(self.tube_combo)

        layout.addWidget(QLabel("🔴 MARKER Ø"))
        self.marker_combo = QComboBox()

        # Dynamische Werte von 1-50 mit sinnvollen Schritten
        values = []
        for i in range(1, 101):  # 1-50
            if i <= 10:
                values.append(str(float(i)))  # 1,2,3...10
            elif i <= 20:
                if i % 2 == 0:
                    values.append(str(float(i)))  # 12,14,16,18,20
            elif i <= 35:
                if i % 5 == 0:
                    values.append(str(float(i)))  # 25,30,35
            else:
                if i % 10 == 0:
                    values.append(str(float(i)))  # 40,50

        self.marker_combo.addItems(values)
        self.marker_combo.setCurrentText("5.0")
        self.marker_combo.setStyleSheet(self.combo_style)
        self.marker_combo.currentTextChanged.connect(lambda v: self.marker_size_changed.emit(float(v)))
        layout.addWidget(self.marker_combo)

        layout.addStretch()
        
        self._update_position()
        
        # 🔥 NEU: Speichert die Track->Gruppe Zuordnung
        self.track_to_group = {}
        self.group_to_tracks = {}

    def _add_separator(self, layout):
        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet(f"background: {Theme.rgba('border')};")
        layout.addWidget(line)

    def _on_mode_changed(self, mode):
        """Wechselt per Stack – kein Flackern mehr"""
        index = 0 if mode == "track" else 1
        self.selection_stack.setCurrentIndex(index)
        self.view_mode_changed.emit(mode)

    def _update_position(self):
        if self.parent():
            parent_width = self.parent().width()
            self.move(parent_width - self.width() - 10, 10)

    # 🔥 NEU: Track mit Gruppen-Kontext auswählen
    def _on_track_selected(self, track_name):
        """Track ausgewählt - mit Gruppenzuordnung"""
        if track_name:
            # Entferne führende Leerzeichen und die Einrückung
            clean_name = track_name.strip()
            # Finde die Gruppe dieses Tracks mit dem bereinigten Namen
            group = self.track_to_group.get(clean_name, "")
            print(f"🎯 Track ausgewählt: '{track_name}' -> bereinigt: '{clean_name}' (Gruppe: {group})")
            # Sende den bereinigten Namen weiter
            self.track_selected.emit(clean_name)

    def _on_group_selected(self, group_name):
        """Gruppe ausgewählt"""
        if group_name:
            print(f"👥 Gruppe ausgewählt: {group_name}")
            self.group_selected.emit(group_name)

    # 🔥 NEU: Update mit voller Gruppenstruktur
    def update_tracks_with_groups(self, track_names, track_to_group):
        """
        Aktualisiert Track-Combo mit hierarchischer Anzeige
        
        Args:
            track_names: Liste aller Track-Namen
            track_to_group: Dict {track_name: group_name}
        """
        self.track_to_group = track_to_group
        
        # Gruppiere Tracks nach Gruppen für bessere Übersicht
        grouped_tracks = {}
        for track in sorted(track_names):
            group = track_to_group.get(track, "Andere")
            if group not in grouped_tracks:
                grouped_tracks[group] = []
            grouped_tracks[group].append(track)
        
        # Track-Combo befüllen
        curr = self.track_combo.currentText().strip()  # Auch hier strip()!
        self.track_combo.blockSignals(True)
        self.track_combo.clear()
        
        if grouped_tracks:
            for group, tracks in sorted(grouped_tracks.items()):
                # Gruppentitel (nicht auswählbar)
                self.track_combo.addItem(f"─── {group} ───")
                idx = self.track_combo.count() - 1
                self.track_combo.model().item(idx).setEnabled(False)
                
                # Tracks dieser Gruppe
                for track in sorted(tracks):
                    self.track_combo.addItem(f"   {track}")
            
            # Alte Auswahl wiederherstellen wenn möglich
            if curr:
                found = False
                for i in range(self.track_combo.count()):
                    item_text = self.track_combo.itemText(i).strip()
                    if item_text and item_text == curr and self.track_combo.model().item(i).isEnabled():
                        self.track_combo.setCurrentIndex(i)
                        found = True
                        break
                
                if not found and self.track_combo.count() > 0:
                    # Ersten echten Track auswählen
                    for i in range(self.track_combo.count()):
                        if self.track_combo.model().item(i).isEnabled():
                            self.track_combo.setCurrentIndex(i)
                            break
            elif self.track_combo.count() > 0:
                # Ersten echten Track auswählen
                for i in range(self.track_combo.count()):
                    if self.track_combo.model().item(i).isEnabled():
                        self.track_combo.setCurrentIndex(i)
                        break
        
        self.track_combo.blockSignals(False)

    def update_groups(self, group_names):
        """Aktualisiert Group-Combo"""
        self._update_combo(self.group_combo, group_names)

    def _update_combo(self, combo, items):
        """Standard-Combo Update (für Gruppen)"""
        curr = combo.currentText()
        combo.blockSignals(True)
        combo.clear()
        if items:
            combo.addItems(sorted(items))
            if curr in items:
                combo.setCurrentText(curr)
            elif combo.count() > 0:
                combo.setCurrentIndex(0)
        combo.blockSignals(False)

    def get_current_mode(self):
        return "track" if self.trk_radio.isChecked() else "group"

    def get_tube_radius(self):
        return float(self.tube_combo.currentText())

    def get_marker_size(self):
        return float(self.marker_combo.currentText())