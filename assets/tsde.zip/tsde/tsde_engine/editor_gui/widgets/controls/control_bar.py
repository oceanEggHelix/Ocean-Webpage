# editor_gui/widgets/controls/control_bar.py

from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QComboBox, QPushButton, QSpinBox
from PySide6.QtCore import Qt, Signal

from ...theme import Theme

class ControlBar(QFrame):
    """Einzige Kontrollleiste - Track-Auswahl + Buttons"""
    
    track_changed = Signal(str)
    generate_spline_clicked = Signal(int)
    generate_movement_clicked = Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setFixedHeight(Theme.CONTROL_BAR_HEIGHT)
        self.setObjectName("controlBar")
        self.setStyleSheet(f"""
            #controlBar {{
                background: {Theme.rgba('bg_secondary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_LARGE}px;
            }}
        """)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(Theme.PADDING, Theme.PADDING_SMALL,
                                  Theme.PADDING_LARGE, Theme.PADDING_SMALL)
        layout.setSpacing(Theme.SPACING)
        
        # === Track Dropdown ===
        track_label = QLabel("Track:")
        track_label.setStyleSheet(f"color: {Theme.rgb('text_primary')};")
        layout.addWidget(track_label)
        
        self.track_combo = QComboBox()
        self.track_combo.setMinimumWidth(150)
        self.track_combo.currentTextChanged.connect(self.track_changed.emit)
        self.track_combo.setStyleSheet(f"""
            QComboBox {{
                background: {Theme.rgba('bg_primary', 100)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 5px 10px;
                font-size: 9pt;
            }}
            QComboBox:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
                background: {Theme.rgba('bg_primary', 150)};
            }}
            QComboBox::drop-down {{
                border: none;
                width: 20px;
            }}
            QComboBox::down-arrow {{
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid {Theme.rgb('text_primary')};
            }}
            QComboBox QAbstractItemView {{
                background: {Theme.rgba('bg_secondary')};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                selection-background-color: {Theme.rgba('accent_blue', 100)};
            }}
        """)
        layout.addWidget(self.track_combo)
        
        # === Spline Punkte ===
        spline_label = QLabel("Punkte:")
        spline_label.setStyleSheet(f"color: {Theme.rgb('text_primary')};")
        layout.addWidget(spline_label)
        
        self.spline_points = QSpinBox()
        self.spline_points.setRange(3, 100)
        self.spline_points.setValue(10)
        self.spline_points.setFixedWidth(70)
        self.spline_points.setStyleSheet(f"""
            QSpinBox {{
                background: {Theme.rgba('bg_primary', 100)};
                color: {Theme.rgb('text_primary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 5px;
                font-size: 9pt;
            }}
            QSpinBox:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
            QSpinBox::up-button, QSpinBox::down-button {{
                width: 16px;
                border: none;
                background: {Theme.rgba('bg_primary', 50)};
                border-radius: 2px;
            }}
        """)
        layout.addWidget(self.spline_points)
        
        # === Spline generieren Button ===
        self.btn_spline = QPushButton("Spline")
        self.btn_spline.setCursor(Qt.PointingHandCursor)
        self.btn_spline.setFixedWidth(80)
        self.btn_spline.clicked.connect(self._on_spline_clicked)
        self.btn_spline.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_purple', 150)};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 6px 12px;
                font-size: 9pt;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_purple')};
            }}
            QPushButton:pressed {{
                background: {Theme.rgba('accent_purple', 200)};
            }}
        """)
        layout.addWidget(self.btn_spline)
        
        # === Bewegung generieren Button ===
        self.btn_movement = QPushButton("Bewegung")
        self.btn_movement.setCursor(Qt.PointingHandCursor)
        self.btn_movement.setFixedWidth(90)
        self.btn_movement.clicked.connect(self.generate_movement_clicked.emit)
        self.btn_movement.setStyleSheet(f"""
            QPushButton {{
                background: {Theme.rgba('accent_red', 150)};
                color: {Theme.rgb('text_primary')};
                border: none;
                border-radius: {Theme.RADIUS_MEDIUM}px;
                padding: 6px 12px;
                font-size: 9pt;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_red')};
            }}
            QPushButton:pressed {{
                background: {Theme.rgba('accent_red', 200)};
            }}
        """)
        layout.addWidget(self.btn_movement)
        
        layout.addStretch()
    
    def _on_spline_clicked(self):
        """Spline generieren Button geklickt"""
        self.generate_spline_clicked.emit(self.spline_points.value())
    
    def update_tracks(self, track_names):
        """Aktualisiert die Track-Liste"""
        current = self.track_combo.currentText()
        self.track_combo.clear()
        if track_names:
            self.track_combo.addItems(track_names)
            if current in track_names:
                self.track_combo.setCurrentText(current)
            else:
                self.track_combo.setCurrentIndex(0)
    
    def get_current_track(self):
        """Gibt aktuellen Track zurück"""
        return self.track_combo.currentText()