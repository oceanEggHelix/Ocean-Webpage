# editor_gui/widgets/tracks/track_lane.py

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

from ...theme import Theme
from ..graphs.graph_group import GraphGroup
from ..graphs.pedal_mode import PedalMode


class TrackLane(QFrame):
    """Ein Track in der Explorer-Hierarchie - mit GraphGroup und Drag-Handle"""
    
    # Signale
    toggled = Signal(bool)  # True = sichtbar, False = ausgeblendet
    heights_changed = Signal(list)  # [curve_height, pedal_height]
    drag_started = Signal()  # Für Drag & Drop
    
    def __init__(self, track, curve=None, parent=None):
        super().__init__(parent)

        self.track = track
        self.PADDING = Theme.PADDING
        self.is_visible = True
        self.track_type = getattr(track, 'track_type', 'motion')  # 🔥 Track-Typ

        print(f"🛤️ TrackLane erstellt für: {track.name} (Typ: {self.track_type})")

        # Style mit Theme
        self.setObjectName("trackLane")
        self.setStyleSheet(f"""
            #trackLane {{
                background: {Theme.rgba('bg_secondary')};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_MEDIUM}px;
                margin: 2px 0px;
            }}
            #trackLane:hover {{
                border: 1px solid {Theme.rgba('accent_blue')};
                background: {Theme.rgba('bg_secondary', 220)};
            }}
        """)

        # Hauptlayout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(self.PADDING, self.PADDING, 
                                self.PADDING, self.PADDING)
        layout.setSpacing(Theme.SPACING_SMALL)

        # Header mit Drag-Handle, Name und Toggle-Button
        self._build_header(layout)
        
        # 🔥 Unterschiedliche Graph-Gruppe je nach Track-Typ
        self._build_graph_group(layout, curve)

    def _build_header(self, parent_layout):
        """Erstellt den Header mit Drag-Handle, Track-Name und Toggle - SCHLANKER"""
        header = QFrame()
        header.setObjectName("trackHeader")
        header.setFixedHeight(22)
        header.setStyleSheet(f"""
            #trackHeader {{
                background: {Theme.rgba('bg_primary', 50)};
                border-bottom: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_SMALL}px;
            }}
        """)
        
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(6, 2, 6, 2)
        header_layout.setSpacing(4)
        
        # === Toggle-Button (Auge) ===
        self.toggle_btn = QPushButton()
        self.toggle_btn.setFixedSize(12, 12)
        self.toggle_btn.setCursor(Qt.PointingHandCursor)
        self.toggle_btn.setStyleSheet("QPushButton { background: transparent; border: none; color: gray; } QPushButton:hover { color: white; }")
        self.update_toggle_button()
        self.toggle_btn.clicked.connect(self.toggle_visibility)
        header_layout.addWidget(self.toggle_btn)
        
        # === Track-Name mit Typ-Icon ===
        if self.track_type == "motion":
            icon = "🎬"
            name_color = "#2E7D32"  # Grün
        elif self.track_type == "empty":
            icon = "📦"
            name_color = "#757575"  # Grau
        else:  # param
            icon = "⚙️"
            name_color = "#7B1FA2"  # Lila
        
        self.name_label = QLabel(f"{icon} {self.track.name}")
        font = QFont()
        font.setBold(False)
        font.setPointSize(8)
        self.name_label.setFont(font)
        self.name_label.setStyleSheet(f"QLabel {{ color: {name_color}; }}")
        header_layout.addWidget(self.name_label)
        
        header_layout.addStretch()
        
        # === Info (optional) ===
        info_text = ""

        # Nur für Motion Tracks: Kurvenlänge anzeigen
        if self.track_type == "motion" and hasattr(self.track, 'curve_length') and self.track.curve_length:
            info_text += f"📏 {self.track.curve_length:.0f} mm"

        # Anzahl Punkte anzeigen (für Motion und Empty)
        if self.track_type in ["motion", "empty"] and hasattr(self.track, 'current_times') and self.track.current_times is not None:
            if info_text:
                info_text += " | "
            info_text += f"📊 {len(self.track.current_times)} pts"

        # Max Speed anzeigen (für Motion)
        if self.track_type == "motion" and hasattr(self.track, 'max_speed') and self.track.max_speed:
            if info_text:
                info_text += " | "
            info_text += f"⚡ {self.track.max_speed:.0f} mm/s"
        
        # Für Param Tracks: Parameter anzeigen
        if self.track_type == "param":
            param_name = getattr(self.track, 'param_name', 'param')
            param_unit = getattr(self.track, 'param_unit', '')
            param_min = getattr(self.track, 'param_min', 0.0)
            param_max = getattr(self.track, 'param_max', 1.0)
            info_text = f"⚙️ {param_name} ({param_min}-{param_max} {param_unit})"

        if info_text:
            self.info_label = QLabel(info_text)
            self.info_label.setStyleSheet("""
                QLabel { 
                    color: #888888; 
                    font-size: 7pt; 
                    font-family: monospace;
                    padding: 2px 4px;
                    background: rgba(0,0,0,0.2);
                    border-radius: 3px;
                }
            """)
            header_layout.addWidget(self.info_label)

        parent_layout.addWidget(header)

    def update_toggle_button(self):
        """Aktualisiert das Toggle-Button-Symbol"""
        if self.is_visible:
            self.toggle_btn.setText("👁️")  # Auge = sichtbar
            self.toggle_btn.setToolTip("Track ausblenden")
        else:
            self.toggle_btn.setText("👁️‍🗨️")  # Auge mit Strich = unsichtbar
            self.toggle_btn.setToolTip("Track einblenden")

    def toggle_visibility(self):
        """Schaltet die Sichtbarkeit des Tracks um"""
        self.is_visible = not self.is_visible
        self.update_toggle_button()
        
        # Graph-Gruppe nur ein-/ausblenden wenn vorhanden
        if hasattr(self, 'graph_group') and self.graph_group:
            self.graph_group.setVisible(self.is_visible)
        
        # Header-Style anpassen wenn ausgeblendet
        if self.is_visible:
            self.setStyleSheet(f"""
                #trackLane {{
                    background: {Theme.rgba('bg_secondary')};
                    border: 1px solid {Theme.rgba('border')};
                    border-radius: {Theme.RADIUS_MEDIUM}px;
                    margin: 2px 0px;
                }}
                #trackLane:hover {{
                    border: 1px solid {Theme.rgba('accent_blue')};
                    background: {Theme.rgba('bg_secondary', 220)};
                }}
            """)
        else:
            self.setStyleSheet(f"""
                #trackLane {{
                    background: {Theme.rgba('bg_primary', 100)};
                    border: 1px dashed {Theme.rgba('border')};
                    border-radius: {Theme.RADIUS_MEDIUM}px;
                    margin: 2px 0px;
                }}
            """)
        
        self.toggled.emit(self.is_visible)

# editor_gui/widgets/tracks/track_lane.py - in _build_graph_group Methode

    def _build_graph_group(self, parent_layout, curve):
        """Erstellt die Graph-Gruppe je nach Track-Typ"""
        
        # 🔥 MOTION TRACK: Normal mit beiden Graphen
        if self.track_type == "motion":
            self.graph_group = GraphGroup()
            self.graph_group.set_track(self.track)
            self.track.graph_group = self.graph_group

            if curve:
                self.graph_group.set_curve(curve, self.track)
            
            # Spline-Modus setzen
            self.graph_group.pedal_graph.set_mode(PedalMode.SPLINE)
            
            # Signals
            self.graph_group.height_changed.connect(self._on_heights_changed)
            
            parent_layout.addWidget(self.graph_group)
        
        # 🔥 EMPTY TRACK: Nur Pedal-Graph, aber VOLL FUNKTIONSFÄHIG!
        elif self.track_type == "empty":
            self.graph_group = GraphGroup()
            self.graph_group.set_track(self.track)
            self.track.graph_group = self.graph_group
            
            # Curve-Graph komplett ausblenden (nicht nur verstecken)
            self.graph_group.curve_graph.setVisible(False)
            
            # Pedal-Graph normal aktivieren und konfigurieren
            self.graph_group.pedal_graph.set_mode(PedalMode.SPLINE)
            self.graph_group.pedal_graph.setEnabled(True)
            
            # Spline-Signale verbinden
            pedal_graph = self.graph_group.pedal_graph
            pedal_graph.generate_spline_clicked.connect(pedal_graph.generate_spline)
            pedal_graph.generate_movement_clicked.connect(
                lambda checked=False, t=self.track: self._on_generate_movement(
                    self.tracks_container.get_track_by_name(t.name)
                )
            )
            
            # Signals
            self.graph_group.height_changed.connect(self._on_heights_changed)
            
            # Grauen Hintergrund mit Stil setzen
            self.graph_group.setStyleSheet(f"""
                background-color: {Theme.rgba('bg_secondary', 30)};
                border-left: 3px solid #757575;
                border-radius: 3px;
            """)
            
            parent_layout.addWidget(self.graph_group)
        
        # 🔥 PARAM TRACK: GAR NICHTS anzeigen - nur Platzhalter
        else:  # param
            self.graph_group = None
            self.track.graph_group = None
            
            # Grauer Platzhalter in gleicher Höhe wie Graphen
            placeholder = QFrame()
            placeholder.setFixedHeight(60)
            placeholder.setStyleSheet(f"""
                background-color: {Theme.rgba('bg_secondary', 20)};
                border: 1px dashed #7B1FA2;
                border-radius: 3px;
            """)
            
            # Kleiner Text
            label = QLabel("⚙️ PARAM (keine Bearbeitung)", placeholder)
            label.setAlignment(Qt.AlignCenter)
            label.setStyleSheet("color: #7B1FA2; font-style: italic; font-size: 8pt;")
            
            parent_layout.addWidget(placeholder)

    def _on_heights_changed(self):
        """Wird aufgerufen wenn der Splitter bewegt wurde"""
        if hasattr(self, 'graph_group') and self.graph_group:
            heights = self.graph_group.splitter.sizes()
            self.heights_changed.emit(heights)

    def set_content_width(self, width):
        """Setzt die Content-Breite für die Graphen"""
        if width <= 0:
            return
            
        total_width = width + 2 * self.PADDING
        self.setFixedWidth(total_width)
        
        if hasattr(self, 'graph_group') and self.graph_group:
            self.graph_group.set_content_width(width)

    def set_marker(self, time_pos):
        """
        Setzt die Marker-Position.
        time_pos ist die normierte Zeit (0-1) von der Timeline.
        """
        # Nur für Motion und Empty Tracks
        if self.track_type in ["motion", "empty"] and hasattr(self, 'graph_group') and self.graph_group:
            # PedalGraph bekommt die Zeit
            self.graph_group.pedal_graph.set_marker(time_pos)
            
            # Nur für Motion Tracks: CurveGraph aktualisieren
            if self.track_type == "motion" and hasattr(self.track, 'current_times') and len(self.track.current_times) > 0:
                # Zeit in Sample-Index umrechnen
                num_samples = len(self.track.current_times)
                idx = int(time_pos * num_samples)
                idx = min(idx, num_samples - 1)
                
                # t-Wert an dieser Position
                t_value = self.track.current_times[idx]
                self.graph_group.curve_graph.set_marker(t_value)
            elif self.track_type == "motion":
                # Fallback: gleiche Zeit verwenden
                self.graph_group.curve_graph.set_marker(time_pos)
        
    def set_zoom(self, start, end):
        """Setzt den Zoom-Bereich für beide Graphen"""
        if hasattr(self, 'graph_group') and self.graph_group:
            self.graph_group.set_zoom(start, end)
    
    def get_graph_heights(self):
        """Gibt die aktuellen Höhen der Graphen zurück"""
        if hasattr(self, 'graph_group') and self.graph_group:
            return self.graph_group.splitter.sizes()
        return [140, 80]  # Default
    
    def set_graph_heights(self, curve_height, pedal_height):
        """Setzt die Höhen der Graphen"""
        if hasattr(self, 'graph_group') and self.graph_group:
            self.graph_group.splitter.setSizes([curve_height, pedal_height])
    
    def reset_graph_heights(self):
        """Setzt die Höhen auf Standard zurück"""
        if hasattr(self, 'graph_group') and self.graph_group:
            self.graph_group.splitter.setSizes([140, 80])
    
    def is_track_visible(self):
        """Gibt zurück ob der Track sichtbar ist"""
        return self.is_visible