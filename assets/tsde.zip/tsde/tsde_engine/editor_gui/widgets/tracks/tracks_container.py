# editor_gui/widgets/tracks/tracks_container.py

from PySide6.QtWidgets import QWidget, QVBoxLayout, QApplication, QScrollArea
from PySide6.QtCore import Qt, QPoint, QTimer
from PySide6.QtGui import QPainter, QPen, QColor, QDrag

from ...theme import Theme
from .collapsible_group import CollapsibleGroup
from .track_lane import TrackLane

class TracksContainer(QWidget):
    """Hauptcontainer für alle Track-Gruppen"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # WICHTIG: Drag & Drop aktivieren
        self.setAcceptDrops(True)
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(10, 0, 20, 0)
        self.layout.setSpacing(Theme.SPACING)
        self.layout.setAlignment(Qt.AlignTop)
        
        self.setObjectName("tracksContainer")
        self.setStyleSheet(f"""
            #tracksContainer {{
                background: transparent;
            }}
        """)
        
        self.groups = []
        
        # Drag & Drop Variablen
        self.drag_source = None
        self.drag_start_pos = None
        self.drag_type = None  # 'group' oder 'track'
        self.drag_source_group = None  # Für Track-Drag: Quellgruppe
        self.drop_target_group = None
        self.drop_indicator_pos = -1
        self.drop_indicator_visible = False
        self.drop_indicator_group = None  # Für Track-Drop: Zielgruppe
        
        # Timer für Auto-Scroll während Drag
        self.auto_scroll_timer = QTimer()
        self.auto_scroll_timer.setInterval(50)
        self.auto_scroll_timer.timeout.connect(self.auto_scroll)
        self.auto_scroll_direction = 0
    
    def add_group(self, name):
        """Fügt eine neue Gruppe hinzu"""
        group = CollapsibleGroup(name)
        
        # Drag-Handle Events für Gruppe verbinden
        group.header.drag_handle.mousePressEvent = lambda e: self.group_mouse_press(e, group)
        group.header.drag_handle.mouseMoveEvent = lambda e: self.group_mouse_move(e, group)
        group.header.drag_handle.mouseReleaseEvent = lambda e: self.group_mouse_release(e, group)
        
        self.groups.append(group)
        self.layout.addWidget(group)
        return group
    
    # ===== GROUP DRAG & DROP =====
    
    def group_mouse_press(self, event, group):
        """Mausdruck auf Gruppen-Drag-Handle"""
        if event.button() == Qt.LeftButton:
            self.drag_start_pos = event.pos()
            self.drag_source = group
            self.drag_type = 'group'
            event.accept()
    
    def group_mouse_move(self, event, group):
        """Mausbewegung auf Gruppen-Drag-Handle"""
        if not self.drag_start_pos or self.drag_source != group:
            return
        
        # Prüfen ob weit genug für Drag
        if (event.pos() - self.drag_start_pos).manhattanLength() < QApplication.startDragDistance():
            return
        
        # Drag starten
        self.start_group_drag(group)
        self.drag_start_pos = None
    
    def group_mouse_release(self, event, group):
        """Maus loslassen auf Gruppen-Drag-Handle"""
        self.drag_start_pos = None
        self.drag_source = None
        self.drag_type = None
    
    def _create_mime_data(self, text):
        """Erstellt Mime-Daten für Drag"""
        from PySide6.QtCore import QMimeData
        mime_data = QMimeData()
        mime_data.setText(text)
        return mime_data

    def _create_group_pixmap(self, group):
        """Erstellt Vorschaubild für Gruppe"""
        from PySide6.QtGui import QPixmap, QPainter, QBrush, QPen
        
        width = 200
        height = 40
        
        pixmap = QPixmap(width, height)
        pixmap.fill(Qt.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Hintergrund
        painter.setBrush(QBrush(Theme.color('bg_secondary')))
        painter.setPen(QPen(Theme.color('accent_blue'), 2))
        painter.drawRoundedRect(0, 0, width-1, height-1, 5, 5)
        
        # Text
        painter.setPen(Theme.color('text_primary'))
        painter.setFont(Theme.FONT_SMALL)
        painter.drawText(10, 25, f"📁 {group.name}")
        
        painter.end()
        return pixmap

    def start_group_drag(self, group):
        """Startet Drag für eine Gruppe"""
        drag = QDrag(self)
        mime_data = self._create_mime_data(f"group:{group.name}")
        drag.setMimeData(mime_data)
        
        pixmap = self._create_group_pixmap(group)
        drag.setPixmap(pixmap)
        drag.setHotSpot(QPoint(pixmap.width() // 2, 20))
        
        self.drag_source = group
        result = drag.exec_(Qt.MoveAction)
        
        # Aufräumen
        self.drag_source = None
        self.drag_type = None
        self.drop_indicator_visible = False
        self.update()
    
    # ===== TRACK DRAG & DROP =====
    
    def _create_track_pixmap(self, track_lane):
        """Erstellt Vorschaubild für Track"""
        from PySide6.QtGui import QPixmap, QPainter, QBrush, QPen
        
        width = 180
        height = 30
        
        pixmap = QPixmap(width, height)
        pixmap.fill(Qt.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Hintergrund
        painter.setBrush(QBrush(Theme.color('bg_primary')))
        painter.setPen(QPen(Theme.color('accent_green'), 1))
        painter.drawRoundedRect(0, 0, width-1, height-1, 3, 3)
        
        # Text
        painter.setPen(Theme.color('text_primary'))
        painter.setFont(Theme.FONT_TINY)
        painter.drawText(10, 20, f"🎵 {track_lane.track.name}")
        
        painter.end()
        return pixmap
    
    def start_track_drag(self, track_lane, source_group):
        """Startet Drag für einen Track (wird von TrackLane aufgerufen)"""
        drag = QDrag(self)
        mime_data = self._create_mime_data(f"track:{track_lane.track.name}:{source_group.name}")
        drag.setMimeData(mime_data)
        
        pixmap = self._create_track_pixmap(track_lane)
        drag.setPixmap(pixmap)
        drag.setHotSpot(QPoint(pixmap.width() // 2, 15))
        
        self.drag_source = track_lane
        self.drag_source_group = source_group
        self.drag_type = 'track'
        
        result = drag.exec_(Qt.MoveAction)
        
        # Aufräumen
        self.drag_source = None
        self.drag_source_group = None
        self.drag_type = None
        self.drop_indicator_visible = False
        self.drop_target_group = None
        self.update()
    
    # ===== NEUE METHODEN FÜR GRUPPENABFRAGEN =====
    
    def get_all_group_names(self):
        """Gibt alle Gruppennamen zurück"""
        return [group.name for group in self.groups]
    
    def get_group_tracks(self, group_name):
        """Gibt alle Tracks einer Gruppe zurück (TrackLane Objekte)"""
        for group in self.groups:
            if group.name == group_name:
                return group.tracks
        return []
    
    def get_group_tracks_with_curves(self, group_name, curves_data):
        """
        Gibt alle Tracks einer Gruppe mit ihren Kurven zurück.
        curves_data: Dictionary {track_name: curve}
        Returns: Liste von Tupeln (track, curve)
        """
        result = []
        for group in self.groups:
            if group.name == group_name:
                for track_lane in group.tracks:
                    track = track_lane.track
                    curve = curves_data.get(track.name)
                    if curve:
                        result.append((track, curve))
                break
        return result
    
    def get_group_by_name(self, group_name):
        """Gibt die Gruppe anhand des Namens zurück"""
        for group in self.groups:
            if group.name == group_name:
                return group
        return None
    
    # ===== DROP HANDLING =====
    
    def dragEnterEvent(self, event):
        """Wird beim Betreten des Containers mit Drag aufgerufen"""
        if event.mimeData().hasText():
            text = event.mimeData().text()
            if text.startswith('group:') or text.startswith('track:'):
                event.acceptProposedAction()
                self.drop_indicator_visible = True
    
    def dragMoveEvent(self, event):
        """Wird während des Drags über dem Container aufgerufen"""
        if not event.mimeData().hasText():
            return
        
        text = event.mimeData().text()
        
        if text.startswith('group:'):
            # Group Drop
            pos = event.pos()
            self.drop_indicator_pos = self._get_group_drop_position(pos)
            self.drop_indicator_visible = True
            self._check_auto_scroll(pos)
            event.acceptProposedAction()
            
        elif text.startswith('track:'):
            # Track Drop
            pos = event.pos()
            group, track_index = self._get_track_drop_position(pos)
            self.drop_target_group = group
            self.drop_indicator_pos = track_index
            self.drop_indicator_visible = True
            self._check_auto_scroll(pos)
            event.acceptProposedAction()
        
        self.update()
    
    def dragLeaveEvent(self, event):
        """Wird beim Verlassen des Containers aufgerufen"""
        self.drop_indicator_visible = False
        self.drop_indicator_pos = -1
        self.drop_target_group = None
        self.auto_scroll_timer.stop()
        self.update()
    
    def dropEvent(self, event):
        """Wird beim Fallenlassen aufgerufen"""
        if not event.mimeData().hasText():
            return
        
        text = event.mimeData().text()
        
        if text.startswith('group:'):
            # Gruppe droppen
            group_name = text.split(':')[1]
            self._handle_group_drop(group_name, event.pos())
            
        elif text.startswith('track:'):
            # Track droppen
            parts = text.split(':')
            track_name = parts[1]
            source_group_name = parts[2]
            self._handle_track_drop(track_name, source_group_name, event.pos())
        
        self.drop_indicator_visible = False
        self.drop_indicator_pos = -1
        self.drop_target_group = None
        self.auto_scroll_timer.stop()
        self.update()
        event.acceptProposedAction()
    
    def _get_track_drop_position(self, pos):
        """Berechnet die Drop-Position für einen Track"""
        # Finde die Gruppe unter der Maus
        for group in self.groups:
            group_rect = group.geometry()
            if group_rect.contains(pos):
                # Position innerhalb der Gruppe
                local_pos = group.mapFrom(self, pos)
                track_index = group.get_track_drop_position(local_pos)
                return group, track_index
        
        # Keine Gruppe gefunden -> an das Ende der letzten Gruppe
        if self.groups:
            return self.groups[-1], len(self.groups[-1].tracks)
        
        return None, -1
    
    def _handle_track_drop(self, track_name, source_group_name, pos):
        """Behandelt Drop eines Tracks"""
        # Quellgruppe und Track finden
        source_group = None
        track_lane = None
        
        for group in self.groups:
            if group.name == source_group_name:
                source_group = group
                for track in group.tracks:
                    if track.track.name == track_name:
                        track_lane = track
                        break
                break
        
        if not track_lane or not source_group:
            return
        
        # Zielgruppe und Position
        target_group, target_index = self._get_track_drop_position(pos)
        
        if not target_group:
            return
        
        # Track aus Quellgruppe entfernen
        source_group.remove_track(track_lane)
        
        # In Zielgruppe einfügen
        if target_index > len(target_group.tracks):
            target_index = len(target_group.tracks)
        
        target_group.tracks.insert(target_index, track_lane)
        target_group.tracks_layout.insertWidget(target_index, track_lane)
        target_group.header.set_track_count(len(target_group.tracks))
        
        # Layouts aktualisieren - OHNE _adjust_size()
        target_group.updateGeometry()
        source_group.updateGeometry()
        
        # Auch den Container und Parent aktualisieren
        self.updateGeometry()
        if self.parent():
            self.parent().updateGeometry()
    
    def _get_group_drop_position(self, pos):
        """Berechnet die Drop-Position für eine Gruppe"""
        y = pos.y()
        
        for i, group in enumerate(self.groups):
            group_y = group.y()
            group_height = group.height()
            
            if y < group_y + group_height // 2:
                return i
        
        return len(self.groups)
    
    def _handle_group_drop(self, group_name, pos):
        """Behandelt Drop einer Gruppe"""
        source_index = -1
        for i, group in enumerate(self.groups):
            if group.name == group_name:
                source_index = i
                break
        
        if source_index == -1:
            return
        
        target_index = self._get_group_drop_position(pos)
        
        if source_index < target_index:
            target_index -= 1
        
        group = self.groups.pop(source_index)
        self.groups.insert(target_index, group)
        
        self._rebuild_layout()
    
    def _rebuild_layout(self):
        """Baut das Layout mit der neuen Reihenfolge neu auf"""
        while self.layout.count():
            item = self.layout.takeAt(0)
            if item.widget():
                item.widget().setParent(None)
        
        for group in self.groups:
            self.layout.addWidget(group)
    
    # ===== AUTO-SCROLL =====
    
    def _check_auto_scroll(self, pos):
        """Prüft ob Auto-Scroll nötig ist"""
        scroll_area = self.parent()
        if not scroll_area or not isinstance(scroll_area, QScrollArea):
            return
        
        scrollbar = scroll_area.verticalScrollBar()
        if not scrollbar:
            return
        
        margin = 30
        viewport_rect = scroll_area.viewport().rect()
        
        if pos.y() < margin:
            scrollbar.setValue(scrollbar.value() - 20)
        elif pos.y() > viewport_rect.height() - margin:
            scrollbar.setValue(scrollbar.value() + 20)
    
    def auto_scroll(self):
        """Auto-Scroll während Drag"""
        pass
    
    # ===== DROP-INDICATOR =====
    
    def paintEvent(self, event):
        """Zeichnet den Container inkl. Drop-Indikator"""
        super().paintEvent(event)
        
        if self.drop_indicator_visible and self.drop_indicator_pos >= 0:
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)
            
            if self.drag_type == 'group':
                # Gruppen-Indikator
                if self.drop_indicator_pos < len(self.groups):
                    group = self.groups[self.drop_indicator_pos]
                    y = group.y()
                else:
                    if self.groups:
                        last_group = self.groups[-1]
                        y = last_group.y() + last_group.height() + Theme.SPACING // 2
                    else:
                        y = 10
                
                painter.setPen(QPen(Theme.color('accent_blue'), 2, Qt.DashLine))
                painter.drawLine(50, y, self.width() - 50, y)
                
            elif self.drag_type == 'track' and self.drop_target_group:
                # Track-Indikator innerhalb der Gruppe
                group = self.drop_target_group
                group_pos = group.mapTo(self, QPoint(0, 0))
                
                if self.drop_indicator_pos < len(group.tracks):
                    track = group.tracks[self.drop_indicator_pos]
                    track_pos = track.mapTo(self, QPoint(0, 0))
                    y = track_pos.y()
                else:
                    if group.tracks:
                        last_track = group.tracks[-1]
                        track_pos = last_track.mapTo(self, QPoint(0, 0))
                        y = track_pos.y() + last_track.height() + Theme.SPACING // 2
                    else:
                        y = group_pos.y() + group.header.height() + 10
                
                painter.setPen(QPen(Theme.color('accent_green'), 2, Qt.DashLine))
                painter.drawLine(70, y, self.width() - 70, y)
    
    # ===== BESTEHENDE METHODEN =====
    
    def clear(self):
        """Entfernt alle Gruppen"""
        self.groups.clear()
        while self.layout.count():
            item = self.layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
    
    def set_content_width(self, width):
        """Setzt Breite für alle Gruppen"""
        for group in self.groups:
            group.set_content_width(width)
    
    def set_marker(self, time_pos):
        """Setzt Marker für alle Tracks"""
        for group in self.groups:
            group.set_marker(time_pos)
    
    def set_zoom(self, start, end):
        """Setzt Zoom für alle Tracks"""
        for group in self.groups:
            group.set_zoom(start, end)
    
    def get_all_track_names(self):
        """Gibt alle Track-Namen zurück"""
        names = []
        for group in self.groups:
            for track in group.tracks:
                if hasattr(track, 'track') and hasattr(track.track, 'name'):
                    names.append(track.track.name)
        return names
    
    def get_track_by_name(self, name):
        """Findet Track anhand des Namens"""
        for group in self.groups:
            for track in group.tracks:
                if hasattr(track, 'track') and hasattr(track.track, 'name') and track.track.name == name:
                    return track
        return None