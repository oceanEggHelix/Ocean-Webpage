# editor_gui/widgets/tracks/group_header.py

from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QApplication
from PySide6.QtCore import Qt, Signal, QPoint
from PySide6.QtGui import QMouseEvent

from ...theme import Theme

class GroupHeader(QFrame):
    """Header für eine Track-Gruppe - aufklappbar mit Drag-Handle"""
    
    toggled = Signal(bool)  # True = expanded, False = collapsed
    drag_started = Signal()  # Für Drag & Drop der ganzen Gruppe
    
    def __init__(self, name, track_count=0, parent=None):
        super().__init__(parent)
        
        self.is_expanded = True
        self.name = name
        self.track_count = track_count
        self.drag_start_position = None
        
        self.setObjectName("groupHeader")
        self.setFixedHeight(28)
        self.setStyleSheet(f"""
            #groupHeader {{
                background: {Theme.rgba('bg_primary', 150)};
                border: 1px solid {Theme.rgba('border')};
                border-radius: {Theme.RADIUS_MEDIUM}px;
            }}
            #groupHeader:hover {{
                background: {Theme.rgba('bg_primary', 180)};
                border: 1px solid {Theme.rgba('accent_blue')};
            }}
        """)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(Theme.SPACING_SMALL)
        
        # === Drag-Handle für Gruppe ===
        self.drag_handle = QLabel("🖐️")
        self.drag_handle.setFixedSize(16, 16)  # Etwas größer für bessere Bedienung
        self.drag_handle.setCursor(Qt.OpenHandCursor)
        self.drag_handle.setAlignment(Qt.AlignCenter)
        self.drag_handle.setStyleSheet(f"""
            QLabel {{
                color: {Theme.rgb('text_secondary')};
                font-size: 12px;
                background: transparent;
                border-radius: {Theme.RADIUS_SMALL}px;
                padding: 2px;
            }}
            QLabel:hover {{
                background: {Theme.rgba('accent_blue', 150)};
                color: {Theme.rgb('text_primary')};
            }}
        """)
        
        # Maus-Events für Drag & Drop
        self.drag_handle.mousePressEvent = self.handle_mouse_press
        self.drag_handle.mouseMoveEvent = self.handle_mouse_move
        self.drag_handle.mouseReleaseEvent = self.handle_mouse_release
        
        layout.addWidget(self.drag_handle)
        
        # === Expand/Collapse Button ===
        self.expand_btn = QPushButton("▼")
        self.expand_btn.setFixedSize(16, 16)
        self.expand_btn.setCursor(Qt.PointingHandCursor)
        self.expand_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                border: none;
                border-radius: {Theme.RADIUS_SMALL}px;
                font-size: 10px;
                font-weight: bold;
                color: {Theme.rgb('text_primary')};
                padding: 2px;
            }}
            QPushButton:hover {{
                background: {Theme.rgba('accent_blue', 150)};
            }}
        """)
        self.expand_btn.clicked.connect(self.toggle)
        layout.addWidget(self.expand_btn)
        
        # === Gruppen-Name ===
        self.name_label = QLabel(f"📁 {name}")
        self.name_label.setStyleSheet(f"""
            color: {Theme.rgb('text_primary')};
            font-size: 9pt;
            font-weight: bold;
            padding: 0 4px;
        """)
        layout.addWidget(self.name_label)
        
        # === Track-Anzahl ===
        self.count_label = QLabel(f"{track_count}")
        self.count_label.setFixedWidth(30)
        self.count_label.setAlignment(Qt.AlignCenter)
        self.count_label.setStyleSheet(f"""
            color: {Theme.rgb('text_secondary')};
            font-size: 8pt;
            background: {Theme.rgba('bg_primary', 200)};
            border-radius: 10px;
            padding: 2px 0px;
        """)
        layout.addWidget(self.count_label)
        
        # Track-Anzahl Text (optional, für Tooltip)
        self.count_text = QLabel("tracks")
        self.count_text.setStyleSheet(f"""
            color: {Theme.rgb('text_secondary')};
            font-size: 8pt;
        """)
        layout.addWidget(self.count_text)
        
        layout.addStretch()
    
    def handle_mouse_press(self, event: QMouseEvent):
        """Behandelt Mausdrücken auf dem Drag-Handle"""
        if event.button() == Qt.LeftButton:
            self.drag_start_position = event.pos()
            self.drag_handle.setCursor(Qt.ClosedHandCursor)
            event.accept()
    
    def handle_mouse_move(self, event: QMouseEvent):
        """Behandelt Mausbewegungen für Drag & Drop"""
        if not self.drag_start_position:
            return
        
        # Prüfen ob weit genug für Drag
        if (event.pos() - self.drag_start_position).manhattanLength() < QApplication.startDragDistance():
            return
        
        # Drag starten
        self.drag_started.emit()
        
        # Drag-Event an Parent weiterleiten
        if self.parent():
            # QDrag-Event simulieren
            drag_event = QMouseEvent(
                QMouseEvent.MouseMove,
                self.mapToParent(event.pos()),
                Qt.LeftButton,
                Qt.LeftButton,
                Qt.NoModifier
            )
            self.parent().mouseMoveEvent(drag_event)
    
    def handle_mouse_release(self, event: QMouseEvent):
        """Behandelt Loslassen der Maus"""
        if event.button() == Qt.LeftButton:
            self.drag_start_position = None
            self.drag_handle.setCursor(Qt.OpenHandCursor)
            event.accept()
    
    def toggle(self):
        """Klappt die Gruppe auf/zu"""
        self.is_expanded = not self.is_expanded
        self.expand_btn.setText("▼" if self.is_expanded else "▶")
        self.toggled.emit(self.is_expanded)
    
    def set_track_count(self, count):
        """Aktualisiert die Track-Anzahl"""
        self.track_count = count
        self.count_label.setText(f"{count}")
    
    def enterEvent(self, event):
        """Wird aufgerufen wenn Maus in Widget eintritt"""
        self.drag_handle.setCursor(Qt.OpenHandCursor)
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        """Wird aufgerufen wenn Maus Widget verlässt"""
        self.drag_handle.setCursor(Qt.ArrowCursor)
        super().leaveEvent(event)