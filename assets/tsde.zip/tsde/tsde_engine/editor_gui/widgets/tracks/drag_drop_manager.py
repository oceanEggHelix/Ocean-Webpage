# editor_gui/widgets/tracks/drag_drop_manager.py

from PySide6.QtCore import QObject, QMimeData, QPoint, Signal
from PySide6.QtGui import QDrag, QPixmap, QPainter, QBrush, QPen,Qt
from PySide6.QtWidgets import QApplication, QWidget

from ...theme import Theme

class DragDropManager(QObject):
    """Verwaltet Drag & Drop für Gruppen und Tracks"""
    
    # Signale
    groups_reordered = Signal(list)  # Neue Gruppen-Reihenfolge
    tracks_moved = Signal(str, str, int)  # track_name, target_group, new_index
    
    def __init__(self, container):
        super().__init__(container)
        self.container = container
        self.drag_source = None
        self.drag_type = None  # 'group' oder 'track'
        self.drag_start_pos = None
    
    def start_drag(self, widget, event, drag_type='group'):
        """Startet einen Drag-Vorgang"""
        if event.button() != Qt.LeftButton:
            return False
        
        self.drag_start_pos = event.pos()
        self.drag_source = widget
        self.drag_type = drag_type
        
        # Drag mit Verzögerung starten (verhindert versehentliches Draggen)
        QApplication.processEvents()
        return True
    
    def handle_drag(self, event):
        """Behandelt Drag-Bewegungen"""
        if not self.drag_source or not self.drag_start_pos:
            return False
        
        # Prüfen ob weit genug gezogen wurde (Drag-Schwelle)
        if (event.pos() - self.drag_start_pos).manhattanLength() < QApplication.startDragDistance():
            return False
        
        # Drag-Objekt erstellen
        drag = QDrag(self.drag_source)
        mime_data = QMimeData()
        
        # Daten je nach Typ speichern
        if self.drag_type == 'group':
            mime_data.setText(f"group:{self.drag_source.name}")
            # Vorschaubild erstellen
            pixmap = self._create_group_pixmap(self.drag_source)
        else:  # track
            track = self.drag_source.track
            mime_data.setText(f"track:{track.name}:{self.drag_source.parent().name}")
            # Vorschaubild erstellen
            pixmap = self._create_track_pixmap(self.drag_source)
        
        drag.setMimeData(mime_data)
        
        if pixmap:
            drag.setPixmap(pixmap)
            drag.setHotSpot(QPoint(pixmap.width() // 2, pixmap.height() // 2))
        
        # Drag ausführen
        result = drag.exec_()
        
        # Aufräumen
        self.drag_source = None
        self.drag_type = None
        self.drag_start_pos = None
        
        return True
    
    def _create_group_pixmap(self, group):
        """Erstellt ein Vorschaubild für eine Gruppe"""
        width = 200
        height = 40
        
        pixmap = QPixmap(width, height)
        pixmap.fill(Qt.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Hintergrund
        painter.setBrush(QBrush(Theme.color('bg_secondary')))
        painter.setPen(QPen(Theme.color('accent_blue'), 2))
        painter.drawRoundedRect(0, 0, width-1, height-1, 5, 5)
        
        # Text
        painter.setPen(Theme.color('text_primary'))
        painter.setFont(Theme.FONT_SMALL)
        painter.drawText(10, 25, f"📁 {group.name}")
        
        painter.end()
        return pixmap
    
    def _create_track_pixmap(self, track_lane):
        """Erstellt ein Vorschaubild für einen Track"""
        width = 180
        height = 30
        
        pixmap = QPixmap(width, height)
        pixmap.fill(Qt.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Hintergrund
        painter.setBrush(QBrush(Theme.color('bg_primary')))
        painter.setPen(QPen(Theme.color('accent_green'), 1))
        painter.drawRoundedRect(0, 0, width-1, height-1, 3, 3)
        
        # Text
        painter.setPen(Theme.color('text_primary'))
        painter.setFont(Theme.FONT_TINY)
        painter.drawText(10, 20, f"🎵 {track_lane.track.name}")
        
        painter.end()
        return pixmap
    
    def handle_drop(self, target, event):
        """Behandelt Drop-Events"""
        mime_data = event.mimeData()
        if not mime_data.hasText():
            return False
        
        text = mime_data.text()
        
        if text.startswith('group:'):
            # Gruppe droppen
            group_name = text.split(':')[1]
            return self._handle_group_drop(group_name, target, event.pos())
        
        elif text.startswith('track:'):
            # Track droppen
            parts = text.split(':')
            track_name = parts[1]
            source_group = parts[2]
            return self._handle_track_drop(track_name, source_group, target, event.pos())
        
        return False
    
    def _handle_group_drop(self, group_name, target_group, pos):
        """Behandelt Drop einer Gruppe"""
        if not target_group or target_group.name == group_name:
            return False
        
        # Quelle und Ziel finden
        source_index = -1
        target_index = -1
        
        for i, group in enumerate(self.container.groups):
            if group.name == group_name:
                source_index = i
            if group == target_group:
                target_index = i
        
        if source_index >= 0 and target_index >= 0 and source_index != target_index:
            # Gruppe verschieben
            group = self.container.groups.pop(source_index)
            
            # Einfügeposition anpassen
            if source_index < target_index:
                target_index -= 1
            
            self.container.groups.insert(target_index, group)
            
            # Layout aktualisieren
            self.container._rebuild_layout()
            
            # Signal emittieren
            self.groups_reordered.emit([g.name for g in self.container.groups])
            
            return True
        
        return False
    
    def _handle_track_drop(self, track_name, source_group_name, target_group, pos):
        """Behandelt Drop eines Tracks"""
        if not target_group:
            return False
        
        # Quelle finden
        source_group = None
        track_lane = None
        
        for group in self.container.groups:
            for track in group.tracks:
                if track.track.name == track_name:
                    source_group = group
                    track_lane = track
                    break
            if source_group:
                break
        
        if not track_lane or source_group == target_group:
            return False
        
        # Relative Position im Ziel berechnen (für Einfüge-Reihenfolge)
        y_pos = pos.y()
        insert_index = 0
        
        for i, track in enumerate(target_group.tracks):
            if y_pos > track.y() + track.height() // 2:
                insert_index = i + 1
        
        # Track aus Quellgruppe entfernen
        source_group.remove_track(track_lane)
        
        # Track in Zielgruppe einfügen
        target_group.tracks.insert(insert_index, track_lane)
        target_group.tracks_layout.insertWidget(insert_index, track_lane)
        target_group.header.set_track_count(len(target_group.tracks))
        
        # Layout aktualisieren
        target_group._adjust_size()
        source_group._adjust_size()
        
        # Signal emittieren
        self.tracks_moved.emit(track_name, target_group.name, insert_index)
        
        return True