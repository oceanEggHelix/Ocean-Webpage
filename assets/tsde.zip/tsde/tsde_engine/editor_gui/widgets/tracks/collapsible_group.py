# editor_gui/widgets/tracks/collapsible_group.py

from PySide6.QtWidgets import QWidget, QVBoxLayout

from ...theme import Theme
from .group_header import GroupHeader
from .track_lane import TrackLane

class CollapsibleGroup(QWidget):
    """Eine aufklappbare Gruppe mit mehreren Tracks"""
    
    def __init__(self, name, parent=None):
        super().__init__(parent)
        
        self.name = name
        self.tracks = []
        
        # Hauptlayout
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(Theme.SPACING)  # Geändert
        
        
        # Header
        self.header = GroupHeader(name)
        self.header.toggled.connect(self.on_toggle)
        self.layout.addWidget(self.header)
        self.layout.setContentsMargins(0, 0, 50, 0)
        
        # Container für Tracks
        self.tracks_container = QWidget()
        self.tracks_container.setObjectName("tracksContainer")
        self.tracks_container.setStyleSheet(f"""
            #tracksContainer {{
                background: transparent;          
            }}
        """)
        
        self.tracks_layout = QVBoxLayout(self.tracks_container)
        self.tracks_layout.setContentsMargins(20, 5, 0, 5)
        self.tracks_layout.setSpacing(Theme.SPACING)  # Geändert
        
        self.layout.addWidget(self.tracks_container)
    
    def add_track(self, track_lane):
        """Fügt einen Track zur Gruppe hinzu"""
        self.tracks.append(track_lane)
        self.tracks_layout.addWidget(track_lane)
        self.header.set_track_count(len(self.tracks))
    
    def remove_track(self, track_lane):
        """Entfernt einen Track aus der Gruppe"""
        if track_lane in self.tracks:
            self.tracks.remove(track_lane)
            self.tracks_layout.removeWidget(track_lane)
            track_lane.setParent(None)
            self.header.set_track_count(len(self.tracks))
    
    def on_toggle(self, expanded):
        """Wird aufgerufen wenn Gruppe auf-/zugeklappt wird"""
        self.tracks_container.setVisible(expanded)
    
    def set_content_width(self, width):
        """Setzt Breite für alle Tracks in der Gruppe"""
        for track in self.tracks:
            track.set_content_width(width - 30)
    
    def set_marker(self, time_pos):
        """Setzt Marker für alle Tracks"""
        for track in self.tracks:
            if track.is_visible:
                track.set_marker(time_pos)
    
    def set_zoom(self, start, end):
        """Setzt Zoom für alle Tracks"""
        for track in self.tracks:
            track.set_zoom(start, end)