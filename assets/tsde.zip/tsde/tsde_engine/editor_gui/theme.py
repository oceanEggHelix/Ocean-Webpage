# editor_gui/theme.py - DAS EINE THEME FÜR ALLES

from PySide6.QtGui import QColor, QFont
from PySide6.QtCore import Qt

class Theme:
    # ===== MODUS (vorerst dark, später umschaltbar) =====
    MODE = "dark"
    
    # ===== FARBEN =====
    COLORS = {
        "dark": {
            # Hintergründe
            "bg_primary": QColor(20, 20, 25, 255),      # Haupt-Hintergrund
            "bg_secondary": QColor(30, 30, 35, 220),    # Panel-Hintergrund
            "bg_overlay": QColor(20, 20, 25, 200),      # Overlay-Panel
            "bg_graph": QColor(25, 25, 30, 255),        # Graphen-Hintergrund
            
            # Text
            "text_primary": QColor(255, 255, 255, 255), # Weiß
            "text_secondary": QColor(180, 180, 190, 255), # Hellgrau
            "text_muted": QColor(120, 120, 130, 255),   # Dunkelgrau
            
            # Rahmen und Linien
            "border": QColor(255, 255, 255, 40),        # 40/255 ≈ 0.15
            "border_light": QColor(255, 255, 255, 20),  # Noch transparenter
            "grid": QColor(100, 100, 110, 60),          # Gitterlinien
            
            # Akzente
            "accent": QColor(255, 123, 74, 255),        # Orange
            "accent_blue": QColor(80, 120, 200, 255),   # Blau für Play
            "accent_red": QColor(200, 80, 80, 255),     # Rot für Stop
            "accent_green": QColor(80, 200, 80, 255),   # Grün für Ext.
            "accent_purple": QColor(120, 80, 200, 255), # Lila für Spline
            
            # Marker
            "marker": QColor(255, 120, 120, 255),       # Roter Marker
            "marker_alt": QColor(120, 120, 255, 255),   # Blauer Marker (für Original)
            
            # Kurven
            "curve": QColor(255, 180, 80, 255),         # Gold für 3D
            "curve_alt": QColor(180, 180, 180, 255),    # Grau für Original
            "pedal": QColor(100, 200, 255, 255),        # Hellblau für Pedal
            "spline_point": QColor(255, 170, 0, 255),   # Orange für Spline-Punkte
        },
        "light": {
            # Hintergründe
            "bg_primary": QColor(240, 240, 245, 255),
            "bg_secondary": QColor(225, 225, 230, 220),
            "bg_overlay": QColor(240, 240, 245, 200),
            "bg_graph": QColor(250, 250, 255, 255),
            
            # Text
            "text_primary": QColor(20, 20, 25, 255),
            "text_secondary": QColor(80, 80, 90, 255),
            "text_muted": QColor(140, 140, 150, 255),
            
            # Rahmen und Linien
            "border": QColor(0, 0, 0, 40),
            "border_light": QColor(0, 0, 0, 20),
            "grid": QColor(150, 150, 160, 60),
            
            # Akzente
            "accent": QColor(230, 76, 46, 255),
            "accent_blue": QColor(50, 90, 170, 255),
            "accent_red": QColor(170, 50, 50, 255),
            "accent_green": QColor(50, 170, 50, 255),
            "accent_purple": QColor(90, 50, 170, 255),
            
            # Marker
            "marker": QColor(200, 50, 50, 255),
            "marker_alt": QColor(50, 50, 200, 255),
            
            # Kurven
            "curve": QColor(200, 120, 30, 255),
            "curve_alt": QColor(100, 100, 100, 255),
            "pedal": QColor(30, 120, 200, 255),
            "spline_point": QColor(200, 100, 0, 255),
        }
    }
    
    # ===== ABSTÄNDE =====
    PADDING = 8
    PADDING_SMALL = 4
    PADDING_LARGE = 12
    MARGIN = 20
    SPACING = 10
    SPACING_SMALL = 5
    SPACING_LARGE = 15
    
    # ===== ZOOM =====
    ZOOM_PADDING = 0.05  # 5% Puffer links/rechts für Marker
    
    # ===== GRÖSSEN =====
    TIMELINE_HEIGHT = 70
    TIMELINE_VIEW_HEIGHT = 35
    BUTTON_SIZE = 32
    BUTTON_SIZE_SMALL = 24
    TRACK_HEIGHT = 220  # Curve 140 + Pedal 80
    VTK_WIDTH = 650
    VTK_HEIGHT = 350
    CONTROL_BAR_HEIGHT = 50
    
    # ===== TIMELINE PADDING (neu) =====
    TIMELINE_LEFT_PADDING = 55    # Linker Abstand für Timeline
    TIMELINE_RIGHT_PADDING = 100  # Rechter Abstand für Timeline
    
    # ===== SCHRIFTEN =====
    FONT_PRIMARY = QFont("Segoe UI", 9)
    FONT_SMALL = QFont("Segoe UI", 8)
    FONT_TINY = QFont("Segoe UI", 7)
    FONT_MONO = QFont("Consolas", 9)
    FONT_MONO_SMALL = QFont("Consolas", 8)
    
    # ===== RUNDUNGEN =====
    RADIUS_SMALL = 4
    RADIUS_MEDIUM = 6
    RADIUS_LARGE = 8
    RADIUS_CIRCLE = 999  # Für runde Buttons
    
    @classmethod
    def color(cls, name):
        """Holt Farbe für aktuellen Modus"""
        return cls.COLORS[cls.MODE][name]
    
    @classmethod
    def rgb(cls, name):
        """Holt Farbe als RGB-String für Stylesheets"""
        c = cls.color(name)
        return f"rgb({c.red()}, {c.green()}, {c.blue()})"
    
    @classmethod
    def rgba(cls, name, alpha=None):
        """Holt Farbe als RGBA-String für Stylesheets"""
        c = cls.color(name)
        if alpha is not None:
            return f"rgba({c.red()}, {c.green()}, {c.blue()}, {alpha})"
        return f"rgba({c.red()}, {c.green()}, {c.blue()}, {c.alpha()})"
    
    @classmethod
    def toggle_mode(cls):
        """Hell/Dunkel umschalten"""
        cls.MODE = "light" if cls.MODE == "dark" else "dark"
        return cls.MODE