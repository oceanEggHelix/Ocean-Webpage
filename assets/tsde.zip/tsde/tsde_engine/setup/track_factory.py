# ------------------------------------------------------------------------
# TSDE Engine – Track Factory
# ------------------------------------------------------------------------
# Verantwortlichkeiten:
# - Einheitliche Erzeugung von Track-Objekten
# - Automatisches Anlegen des zugehörigen Channels
# - Minimiert Redundanz in allen Setups (Camera, Rig, Motion, FX)
#
# Hinweise:
# - Factory kennt KEINE Engine- oder GUI-Logik
# - Factory ist rein Core-orientiert
# - Liefert fertige Track-Instanzen für TrackGroups
# ------------------------------------------------------------------------

from ..core.track import Track
from ..core.channel import Channel


def make_track(curve, name: str, v_max_mm_s: float):
    t = Track(curve, name)
    t.channel = Channel(curve, v_max_mm_s=v_max_mm_s)
    return t