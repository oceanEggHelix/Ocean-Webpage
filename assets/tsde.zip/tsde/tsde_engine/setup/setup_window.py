from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QPushButton, QFileDialog,
    QListWidget, QListWidgetItem, QHBoxLayout, QInputDialog, QMenu,
    QComboBox, QLabel, QDialogButtonBox, QFormLayout  # NEU
)
from PySide6.QtCore import Qt
import os
import json
from typing import Literal

# NEU: TrackType Definition
TrackType = Literal["motion", "empty", "param"]

# NEU: Dialog für Param-Track Einstellungen
class ParamTrackDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Param Track Einstellungen")
        self.param_name = ""
        self.param_unit = ""
        self.param_min = 0.0
        self.param_max = 1.0
        
        layout = QVBoxLayout(self)
        
        form = QFormLayout()
        
        self.name_edit = QComboBox()
        self.name_edit.setEditable(True)
        self.name_edit.addItems(["brightness", "volume", "fog", "rain", "speed", "zoom", "focus"])
        form.addRow("Parameter Name:", self.name_edit)
        
        self.unit_edit = QComboBox()
        self.unit_edit.setEditable(True)
        self.unit_edit.addItems(["%", "mm", "Hz", "dB", "°C", "K"])
        form.addRow("Einheit (optional):", self.unit_edit)
        
        self.min_edit = QComboBox()
        self.min_edit.setEditable(True)
        self.min_edit.addItems(["0.0", "0", "-1.0", "-180"])
        form.addRow("Minimalwert:", self.min_edit)
        
        self.max_edit = QComboBox()
        self.max_edit.setEditable(True)
        self.max_edit.addItems(["1.0", "100", "255", "180"])
        form.addRow("Maximalwert:", self.max_edit)
        
        layout.addLayout(form)
        
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def get_values(self):
        try:
            min_val = float(self.min_edit.currentText())
            max_val = float(self.max_edit.currentText())
        except ValueError:
            min_val = 0.0
            max_val = 1.0
        
        return {
            "param_name": self.name_edit.currentText(),
            "param_unit": self.unit_edit.currentText(),
            "param_min": min_val,
            "param_max": max_val
        }


class SetupWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.groups = []
        self.setup_path = r"E:\TSDE\tsde_engine\setup\json\setup.json"

        self.build_ui()
        self.load_setup()
        self.refresh_group_list()

    # ------------------------------------------------------------
    # Setup laden
    # ------------------------------------------------------------
    def load_setup(self):
        """Lädt das letzte Setup, falls vorhanden."""
        if not os.path.exists(self.setup_path):
            return

        try:
            with open(self.setup_path, "r") as f:
                data = json.load(f)

            if "groups" in data:
                self.groups = data["groups"]
                
                # 🔥 Kompatibilität: Alten Tracks track_type hinzufügen falls nicht vorhanden
                for group in self.groups:
                    for track in group["tracks"]:
                        if "track_type" not in track:
                            track["track_type"] = "motion"

        except Exception as e:
            print("Fehler beim Laden des Setups:", e)

    # ------------------------------------------------------------
    # UI
    # ------------------------------------------------------------
    def build_ui(self):
        self.setWindowTitle("TDSE Setup")
        layout = QVBoxLayout()

        self.group_list = QListWidget()
        self.group_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.group_list.customContextMenuRequested.connect(self.open_context_menu)

        layout.addWidget(self.group_list)

        btn_row = QHBoxLayout()
        self.btn_add_group = QPushButton("Add Group")
        
        # 🔥 NEU: Dropdown für Track-Typen
        self.track_type_combo = QComboBox()
        self.track_type_combo.addItem("🎬 Motion Track", "motion")
        self.track_type_combo.addItem("📦 Empty Track", "empty")
        self.track_type_combo.addItem("⚙️ Param Track", "param")
        self.track_type_combo.setToolTip(
            "Motion: Bewegung entlang Geometrie\n"
            "Empty: Nur Pedal-Werte, keine Geometrie\n"
            "Param: Binäre Zustände (0/1) für Effekte"
        )
        
        self.btn_add_track = QPushButton("Add Track")
        self.btn_export = QPushButton("Export Setup")

        btn_row.addWidget(self.btn_add_group)
        btn_row.addWidget(QLabel("Typ:"))
        btn_row.addWidget(self.track_type_combo)
        btn_row.addWidget(self.btn_add_track)
        btn_row.addWidget(self.btn_export)

        layout.addLayout(btn_row)
        self.setLayout(layout)

        self.btn_add_group.clicked.connect(self.add_group)
        self.btn_add_track.clicked.connect(self.add_track)
        self.btn_export.clicked.connect(self.export_setup)

    # ------------------------------------------------------------
    # Hierarchie anzeigen
    # ------------------------------------------------------------
    def refresh_group_list(self):
        self.group_list.clear()

        for g in self.groups:
            group_item = QListWidgetItem(g["name"])
            group_item.setData(Qt.UserRole, ("group", g))
            
            # Gruppenfarbe je nach Inhalt
            if any(t.get("track_type") == "motion" for t in g["tracks"]):
                group_item.setForeground(Qt.darkBlue)
            self.group_list.addItem(group_item)

            for t in g["tracks"]:
                track_type = t.get("track_type", "motion")
                
                # Verschiedene Icons/Symbole für Track-Typen
                if track_type == "motion":
                    prefix = "🎬"
                elif track_type == "empty":
                    prefix = "📦"
                else:  # param
                    prefix = "⚙️"
                
                # Unterschiedliche Anzeige je nach Typ
                if track_type == "motion":
                    txt = f"{prefix} {t['name']}  (v={t['max_speed']} mm/s)"
                elif track_type == "empty":
                    txt = f"{prefix} {t['name']}  (Empty Track)"
                else:  # param
                    param_info = f"{t.get('param_name', 'param')}"
                    if t.get('param_unit'):
                        param_info += f" [{t['param_unit']}]"
                    txt = f"{prefix} {t['name']}  ({param_info}: {t.get('param_min',0)}-{t.get('param_max',1)})"
                
                track_item = QListWidgetItem(txt)
                track_item.setData(Qt.UserRole, ("track", t))
                
                # ToolTip je nach Typ
                if track_type == "motion":
                    track_item.setToolTip(f"Motion Track\nKurve: {t['curve']['path']}")
                elif track_type == "empty":
                    track_item.setToolTip(f"Empty Track\nKeine Geometrie")
                else:
                    track_item.setToolTip(f"Param Track\n{t.get('param_name','')} ({t.get('param_min',0)}-{t.get('param_max',1)} {t.get('param_unit','')})")
                
                # Farbliche Hervorhebung
                if track_type == "motion":
                    track_item.setForeground(Qt.darkGreen)
                elif track_type == "empty":
                    track_item.setForeground(Qt.darkGray)
                else:
                    track_item.setForeground(Qt.darkMagenta)
                    
                self.group_list.addItem(track_item)

    # ------------------------------------------------------------
    # Gruppen
    # ------------------------------------------------------------
    def add_group(self):
        name, ok = QInputDialog.getText(self, "Group Name", "Name:")
        if not ok or not name:
            return

        self.groups.append({"name": name, "tracks": []})
        self.refresh_group_list()

    # ------------------------------------------------------------
    # Tracks - Jetzt mit Typ-Unterstützung!
    # ------------------------------------------------------------
    def add_track(self):
        group_item = self.group_list.currentItem()
        if not group_item:
            return

        role, obj = group_item.data(Qt.UserRole)
        if role != "group":
            # Wenn ein Track selektiert ist, nimm die darüberliegende Gruppe
            for i in range(self.group_list.row(group_item) - 1, -1, -1):
                item = self.group_list.item(i)
                r, o = item.data(Qt.UserRole)
                if r == "group":
                    group = o
                    break
            else:
                return
        else:
            group = obj

        # 🔥 Track-Typ aus ComboBox holen
        track_type = self.track_type_combo.currentData()
        
        name, ok = QInputDialog.getText(self, "Track Name", f"Name für {track_type} Track:")
        if not ok or not name:
            return
        
        # Basisdaten für alle Track-Typen
        track = {
            "name": name,
            "track_type": track_type
        }
        
        # Typspezifische Daten
        if track_type == "motion":
            # Motion Track: braucht Curve, Speed, Focal
            path, _ = QFileDialog.getOpenFileName(self, "Load Curve", "", "CSV (*.csv)")
            if not path:
                return
                
            v_max, ok = QInputDialog.getDouble(self, "Max Speed", "mm/s:", 100.0)
            if not ok:
                return

            f_len, ok = QInputDialog.getDouble(self, "Focal Length", "mm:", 35.0)
            if not ok:
                return
                
            track.update({
                "max_speed": v_max,
                "focal_length": f_len,
                "curve": {
                    "source": "csv",
                    "path": path,
                    "segment_length": 0.01
                }
            })
            
        elif track_type == "empty":
            # Empty Track: keine Geometrie, nur Standardwerte
            track.update({
                "max_speed": 0.0,      # Nicht verwendet, aber für Kompatibilität
                "focal_length": 0.0,    # Nicht verwendet
                "curve": {
                    "source": "empty",
                    "path": "",
                    "segment_length": 0.0
                }
            })
            
        else:  # param track
            # Param Track: für binäre Zustände
            dialog = ParamTrackDialog(self)
            if dialog.exec():
                params = dialog.get_values()
            else:
                return
                
            track.update({
                "max_speed": 0.0,
                "focal_length": 0.0,
                "curve": {
                    "source": "param",
                    "path": "",
                    "segment_length": 0.0
                },
                "param_name": params["param_name"],
                "param_unit": params["param_unit"],
                "param_min": params["param_min"],
                "param_max": params["param_max"]
            })

        group["tracks"].append(track)
        self.refresh_group_list()

    # ------------------------------------------------------------
    # Kontextmenü - Erweitert für Track-Typen
    # ------------------------------------------------------------
    def open_context_menu(self, pos):
        item = self.group_list.itemAt(pos)
        if not item:
            return

        role, obj = item.data(Qt.UserRole)
        menu = QMenu(self)

        if role == "group":
            menu.addAction("Rename Group", lambda: self.rename_group(obj))
            menu.addAction("Delete Group", lambda: self.delete_group(obj))

        if role == "track":
            track_type = obj.get("track_type", "motion")
            
            menu.addAction("Rename Track", lambda: self.rename_track(obj))
            
            # Typspezifische Menüeinträge
            if track_type == "motion":
                menu.addAction("Change max_speed", lambda: self.change_speed(obj))
                menu.addAction("Change focal_length", lambda: self.change_focal(obj))
                menu.addAction("Change Curve", lambda: self.change_curve(obj))
            elif track_type == "param":
                menu.addAction("Edit Parameter Settings", lambda: self.edit_param_settings(obj))
            
            # Track-Typ ändern (eingeschränkt)
            type_menu = menu.addMenu("Change Type")
            
            motion_action = type_menu.addAction("🎬 Motion")
            motion_action.setEnabled(track_type != "motion")
            if track_type != "motion":
                motion_action.triggered.connect(lambda: self.change_track_type(obj, "motion"))
            
            empty_action = type_menu.addAction("📦 Empty")
            empty_action.setEnabled(track_type != "empty")
            if track_type != "empty":
                empty_action.triggered.connect(lambda: self.change_track_type(obj, "empty"))
            
            param_action = type_menu.addAction("⚙️ Param")
            param_action.setEnabled(track_type != "param")
            if track_type != "param":
                param_action.triggered.connect(lambda: self.change_track_type(obj, "param"))
            
            menu.addSeparator()
            menu.addAction("Delete Track", lambda: self.delete_track(obj))

        menu.exec(self.group_list.mapToGlobal(pos))

    # ------------------------------------------------------------
    # Edit-Funktionen - Erweitert
    # ------------------------------------------------------------
    def rename_group(self, group):
        name, ok = QInputDialog.getText(self, "Rename Group", "Name:", text=group["name"])
        if ok and name:
            group["name"] = name
            self.refresh_group_list()

    def delete_group(self, group):
        self.groups.remove(group)
        self.refresh_group_list()

    def rename_track(self, track):
        name, ok = QInputDialog.getText(self, "Rename Track", "Name:", text=track["name"])
        if ok and name:
            track["name"] = name
            self.refresh_group_list()

    def change_speed(self, track):
        v, ok = QInputDialog.getDouble(self, "Max Speed", "mm/s:", track["max_speed"])
        if ok:
            track["max_speed"] = v
            self.refresh_group_list()

    def change_focal(self, track):
        f, ok = QInputDialog.getDouble(self, "Focal Length", "mm:", track["focal_length"])
        if ok:
            track["focal_length"] = f
            self.refresh_group_list()
    
    def change_curve(self, track):
        """Ändert die CSV-Kurve eines Motion Tracks"""
        path, _ = QFileDialog.getOpenFileName(self, "Load Curve", "", "CSV (*.csv)")
        if path:
            track["curve"]["path"] = path
            self.refresh_group_list()
    
    def edit_param_settings(self, track):
        """Bearbeitet Param-Track Einstellungen"""
        dialog = ParamTrackDialog(self)
        
        # Vorausfüllen
        dialog.name_edit.setCurrentText(track.get("param_name", ""))
        dialog.unit_edit.setCurrentText(track.get("param_unit", ""))
        dialog.min_edit.setCurrentText(str(track.get("param_min", 0.0)))
        dialog.max_edit.setCurrentText(str(track.get("param_max", 1.0)))
        
        if dialog.exec():
            params = dialog.get_values()
            track.update(params)
            self.refresh_group_list()
    
    def change_track_type(self, track, new_type):
        """Ändert den Typ eines Tracks"""
        old_type = track.get("track_type", "motion")
        if old_type == new_type:
            return
            
        track["track_type"] = new_type
        
        # Typwechsel: Daten anpassen
        if new_type == "motion":
            # Von empty/param zu motion: Frage nach Curve
            path, _ = QFileDialog.getOpenFileName(self, "Load Curve für Motion Track", "", "CSV (*.csv)")
            if path:
                track["curve"] = {
                    "source": "csv",
                    "path": path,
                    "segment_length": 0.01
                }
                track["max_speed"] = track.get("max_speed", 100.0)
                track["focal_length"] = track.get("focal_length", 35.0)
            else:
                track["track_type"] = old_type  # Zurück ändern wenn abgebrochen
                
        elif new_type == "empty":
            # Von motion/param zu empty: Curve entfernen
            track["curve"] = {
                "source": "empty",
                "path": "",
                "segment_length": 0.0
            }
            track["max_speed"] = 0.0
            track["focal_length"] = 0.0
            # Param-spezifische Daten entfernen
            track.pop("param_name", None)
            track.pop("param_unit", None)
            track.pop("param_min", None)
            track.pop("param_max", None)
            
        else:  # param
            # Von motion/empty zu param: Frage nach Param-Einstellungen
            dialog = ParamTrackDialog(self)
            if dialog.exec():
                params = dialog.get_values()
                track.update(params)
                track["curve"] = {
                    "source": "param",
                    "path": "",
                    "segment_length": 0.0
                }
                track["max_speed"] = 0.0
                track["focal_length"] = 0.0
            else:
                track["track_type"] = old_type  # Zurück ändern wenn abgebrochen
        
        self.refresh_group_list()

    def delete_track(self, track):
        for g in self.groups:
            if track in g["tracks"]:
                g["tracks"].remove(track)
                break
        self.refresh_group_list()

    # ------------------------------------------------------------
    # Export - Jetzt mit Track-Typen!
    # ------------------------------------------------------------
    def export_setup(self):
        data = {"groups": self.groups}
        os.makedirs(os.path.dirname(self.setup_path), exist_ok=True)

        with open(self.setup_path, "w") as f:
            json.dump(data, f, indent=4)

        self.accept()