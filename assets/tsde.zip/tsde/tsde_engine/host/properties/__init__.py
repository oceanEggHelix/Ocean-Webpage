"""Property Groups für alle Sektionen"""
from .walkfly_props import WalkflyProperties
from .spline_setter_props import SplineSetterProperties
from .keyframe_retter_props import KeyframeRetterProperties
from .setup_props import SetupProperties
from .engine_props import EngineProperties
from .live_props import LiveProperties
from .recorder_props import RecorderProperties
from .render_props import RenderProperties

__all__ = [
    "WalkflyProperties",
    "SplineSetterProperties",
    "KeyframeRetterProperties",
    "SetupProperties",
    "EngineProperties",
    "LiveProperties",
    "RecorderProperties",
    "RenderProperties",
]