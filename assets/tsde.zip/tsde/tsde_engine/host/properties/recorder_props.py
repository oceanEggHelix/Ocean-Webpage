"""Property Groups für Section 5: Recorder"""
import bpy
from bpy.props import BoolProperty, StringProperty, FloatProperty, IntProperty
from bpy.types import PropertyGroup

class RecorderProperties(PropertyGroup):
    is_recording: BoolProperty(
        name="Recording",
        default=False
    )
    session_name: StringProperty(
        name="Session",
        default=""
    )
    duration: FloatProperty(
        name="Dauer",
        default=0.0
    )
    recording_start: FloatProperty(  # ← NEU
        name="Startzeit",
        default=0.0
    )
    decimate: IntProperty(
        name="Dezimierung",
        description="1 = alle Samples, 2 = jeden zweiten, usw.",
        default=1,
        min=1,
        max=240
    )
    normalize: BoolProperty(
        name="Normalisieren",
        description="t auf 0-1 normalisieren",
        default=True
    )