# properties/settings_props.py
import bpy

class SettingsProperties(bpy.types.PropertyGroup):
    """Technische Einstellungen für Sampling, Dezimation, Export-Standards"""
    
    # =================================================================
    # KURVEN-SAMPLING
    # =================================================================
    curve_sample_method: bpy.props.EnumProperty(
        name="Sampling Methode",
        description="Methode für Kurven-Sampling",
        items=[
            ('FIXED', "Feste Schrittweite", "Konstante Segmentlänge"),
            ('ADAPTIVE', "Adaptiv", "Angepasst an Krümmung"),
            ('UNIFORM', "Uniform", "Gleichmäßige t-Verteilung"),
        ],
        default='FIXED'
    )
    
    curve_segment_length: bpy.props.FloatProperty(
        name="Segment Länge",
        description="Länge der Kurven-Segmente in mm (kleiner = genauer)",
        default=0.01,
        min=0.001,
        max=1.0,
        precision=3,
        step=0.1
    )
    
    curve_max_points: bpy.props.IntProperty(
        name="Max Punkte",
        description="Maximale Anzahl Kurvenpunkte",
        default=3000,
        min=100,
        max=10000
    )
    
    curve_interpolation: bpy.props.EnumProperty(
        name="Interpolation",
        description="Interpolationsmethode für Kurven",
        items=[
            ('LINEAR', "Linear", "Lineare Interpolation - schneller"),
            ('CUBIC', "Kubisch", "Kubische Splines - genauer"),
        ],
        default='CUBIC'
    )
    
    # =================================================================
    # DEZIMATION
    # =================================================================
    decimate_enabled: bpy.props.BoolProperty(
        name="Dezimation aktivieren",
        description="Kurvenpunkte reduzieren für bessere Performance",
        default=False
    )
    
    decimate_ratio: bpy.props.FloatProperty(
        name="Reduktionsfaktor",
        description="Faktor für Punkt-Reduktion (0.1 = 90% weniger Punkte)",
        default=0.5,
        min=0.01,
        max=0.99,
        precision=2
    )
    
    decimate_error: bpy.props.FloatProperty(
        name="Max Fehler",
        description="Maximaler erlaubter Fehler in mm",
        default=0.1,
        min=0.001,
        max=1.0,
        precision=3
    )
    
    # =================================================================
    # CS-PUNKTE
    # =================================================================
    cs_point_density: bpy.props.FloatProperty(
        name="Punkt-Dichte",
        description="Dichte der CS-Punkte (Punkte pro mm)",
        default=0.1,
        min=0.01,
        max=1.0,
        precision=2
    )
    
    cs_point_scale: bpy.props.FloatProperty(
        name="Punkt-Skalierung",
        description="Größe der CS-Punkte",
        default=1.0,
        min=0.1,
        max=5.0,
        precision=1
    )
    
    cs_point_color: bpy.props.FloatVectorProperty(
        name="Punkt-Farbe",
        subtype='COLOR',
        default=(0.2, 0.8, 1.0),
        min=0.0,
        max=1.0,
        description="Farbe der CS-Punkte"
    )
    
    # =================================================================
    # EXPORT-STANDARDS
    # =================================================================
    export_path: bpy.props.StringProperty(
        name="Export Pfad",
        description="Standard-Pfad für Spline CSV & Setup Exports",
        default="//TSDE_Exports/",
        subtype='DIR_PATH'
    )
    
    export_auto_increment: bpy.props.BoolProperty(
        name="Auto-Inkrement",
        description="Automatisch Nummerierung bei Export",
        default=True
    )
    
    export_include_timestamps: bpy.props.BoolProperty(
        name="Timestamps",
        description="Zeitstempel in Dateinamen einfügen",
        default=True
    )
    
    # =================================================================
    # DEFAULTS & RESET
    # =================================================================
    def reset_to_defaults(self):
        """Setzt alle Werte auf Standard zurück"""
        self.curve_sample_method = 'FIXED'
        self.curve_segment_length = 0.01
        self.curve_max_points = 3000
        self.curve_interpolation = 'CUBIC'
        self.decimate_enabled = False
        self.decimate_ratio = 0.5
        self.decimate_error = 0.1
        self.cs_point_density = 0.1
        self.cs_point_scale = 1.0
        self.cs_point_color = (0.2, 0.8, 1.0)
        self.export_path = "//TSDE_Exports/"
        self.export_auto_increment = True
        self.export_include_timestamps = True
        print("⚙️ Einstellungen auf Standard zurückgesetzt")