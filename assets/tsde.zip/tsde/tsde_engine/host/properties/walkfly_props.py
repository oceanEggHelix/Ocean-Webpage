"""Property Groups für Section 1: Walk/Fly Recorder"""
from bpy.props import FloatProperty
from bpy.types import PropertyGroup

class WalkflyProperties(PropertyGroup):
    speed_multiplier: FloatProperty(
        name="Speed Multiplier",
        description="Globaler Geschwindigkeits-Multiplikator",
        default=1.0,
        min=0.1,
        max=5.0,
        step=0.1,
        precision=1
    )