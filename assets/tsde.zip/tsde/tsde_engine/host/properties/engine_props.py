"""Property Groups für Section 3: Engine Control"""
import bpy
from bpy.props import (
    StringProperty, 
    FloatProperty, 
    IntProperty, 
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    PointerProperty
)
from bpy.types import PropertyGroup

# NEU: PropertyGroup für einzelnes Rig in der Liste
class EngineRigItem(PropertyGroup):
    """Ein Rig-Eintrag für die Mehrfachauswahl"""
    name: StringProperty(
        name="Name",
        description="Name des Rigs"
    )
    
    rig_object: StringProperty(
        name="Rig Object",
        description="Name des Rig-Objekts in Blender"
    )
    
    selected: BoolProperty(
        name="Ausgewählt",
        description="Dieses Rig exportieren",
        default=True
    )
    
    export_filepath: StringProperty(
        name="Export Datei",
        description="Pfad für die JSON-Exportdatei",
        subtype='FILE_PATH',
        default=""
    )
    
    # Optional: Eigene Einstellungen pro Rig
    custom_segment_length: FloatProperty(
        name="Segment Länge",
        description="Individuelle Segment-Länge für dieses Rig (0 = Global)",
        default=0.0,
        min=0.0,
        max=5.0,
        precision=2
    )
    
    custom_max_speed: FloatProperty(
        name="Max Speed",
        description="Individuelle Maximalgeschwindigkeit (0 = Global)",
        default=0.0,
        min=0.0,
        max=1000.0,
        precision=1
    )


class EngineProperties(PropertyGroup):
    # =================================================================
    # LETZTES SETUP
    # =================================================================
    last_setup_path: StringProperty(
        name="Letztes Setup",
        description="Pfad zum zuletzt exportierten Setup",
        default=""
    )
    
    last_setup_name: StringProperty(
        name="Letzter Rig-Name",
        description="Name des zuletzt exportierten Rigs",
        default=""
    )
    
    # =================================================================
    # RIG AUSWAHL (ERWEITERT)
    # =================================================================
    # NEU: Collection für Mehrfachauswahl
    rig_selection: CollectionProperty(
        type=EngineRigItem,
        name="Rig Auswahl",
        description="Liste der verfügbaren Rigs"
    )
    
    # NEU: Aktiver Index für UI-Navigation
    active_rig_index: IntProperty(
        name="Aktiver Index",
        description="Index des aktiven Rigs in der Liste",
        default=0
    )
    
    # NEU: Auswahlmodus
    rig_selection_mode: EnumProperty(
        name="Auswahlmodus",
        description="Wie Rigs ausgewählt werden",
        items=[
            ('ALL', "Alle Rigs", "Alle verfügbaren Rigs exportieren"),
            ('SELECTED', "Nur ausgewählte", "Nur die manuell ausgewählten Rigs exportieren"),
            ('VISIBLE', "Sichtbare", "Nur sichtbare Rigs exportieren"),
        ],
        default='SELECTED'
    )
    
    # NEU: Mehrfach-Export Optionen
    multi_export_enabled: BoolProperty(
        name="Multi-Rig Export",
        description="Mehrere Rigs gleichzeitig exportieren",
        default=False
    )
    
    # Bestehend: Einzel-Rig Auswahl (behalten für Kompatibilität)
    selected_rig: StringProperty(
        name="Rig",
        description="Name des zu exportierenden Rigs",
        default=""
    )
    
    # NEU: Gemeinsamer Export-Ordner für mehrere Rigs
    use_common_export_folder: BoolProperty(
        name="Gemeinsamer Export-Ordner",
        description="Alle Rigs in denselben Ordner exportieren",
        default=True
    )
    
    common_export_path: StringProperty(
        name="Export Ordner",
        description="Gemeinsamer Ordner für alle Rig-Exports",
        subtype='DIR_PATH',
        default="//exports/"
    )
    
    # NEU: Batch-Verarbeitung
    batch_export_mode: EnumProperty(
        name="Batch Modus",
        description="Wie mehrere Rigs exportiert werden",
        items=[
            ('SEQUENTIAL', "Sequentiell", "Rigs nacheinander exportieren"),
            ('PARALLEL', "Parallel", "Rigs parallel exportieren (experimentell)"),
        ],
        default='SEQUENTIAL'
    )
    
    # =================================================================
    # CSV PFAD
    # =================================================================
    csv_path: StringProperty(
        name="CSV Pfad",
        description="Verzeichnis für CSV-Dateien (leer = Temp-Verzeichnis)",
        default="",
        subtype='DIR_PATH'
    )
    
    # =================================================================
    # SETUP PARAMETER
    # =================================================================
    max_speed: FloatProperty(
        name="Max Speed",
        description="Maximale Geschwindigkeit für Tracks (mm/s)",
        default=100.0,
        min=1.0,
        max=1000.0,
        soft_min=10.0,
        soft_max=500.0,
        step=5.0,
        precision=1
    )
    
    num_csv_points: IntProperty(
        name="CSV Punkte",
        description="Anzahl der Punkte in den CSV-Dateien",
        default=100,
        min=10,
        max=1000
    )
    
    global_segment_length: FloatProperty(
        name="Segment Länge",
        description="Globale Segment-Länge für CSV-Exporte (mm)",
        default=1.0,
        min=0.01,
        max=5.0,
        precision=2,
        step=0.1
    )
    
    # =================================================================
    # ENGINE DEBUG
    # =================================================================
    engine_debug_level: IntProperty(
        name="Debug Level",
        description="Debug-Level für Engine (0=Aus, 1=Basic, 2=Medium, 3=Full)",
        default=1,
        min=0,
        max=3
    )
    
    # =================================================================
    # STATUS
    # =================================================================
    engine_pid: IntProperty(
        name="Engine PID",
        description="Prozess-ID der laufenden Engine",
        default=0
    )
    
    engine_status: StringProperty(
        name="Engine Status",
        description="Aktueller Status der Engine",
        default="Gestoppt"
    )
    
    connection_status: StringProperty(
        name="Verbindung",
        description="IPC-Verbindungsstatus",
        default="Getrennt"
    )


# NEU: Registrierungsfunktion
def register():
    bpy.utils.register_class(EngineRigItem)
    bpy.utils.register_class(EngineProperties)


def unregister():
    bpy.utils.unregister_class(EngineProperties)
    bpy.utils.unregister_class(EngineRigItem)