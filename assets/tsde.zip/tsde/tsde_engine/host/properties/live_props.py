"""Property Groups für Section 4: Live Control"""
import bpy
from bpy.props import FloatProperty, StringProperty, CollectionProperty
from bpy.types import PropertyGroup

def update_pedal(self, context):
    """Wird aufgerufen wenn Slider bewegt wird"""
    try:
        bpy.ops.tsde.set_pedal(
            track_name=self.name, 
            pedal_value=self.pedal
        )
    except Exception as e:
        print(f"⚠️ Fehler beim Senden des Pedalwerts: {e}")

class TrackLiveProperties(PropertyGroup):
    """Ein Track für Live Control"""
    name: StringProperty(name="Track Name")
    pedal: FloatProperty(
        name="Pedal",
        description="Pedal-Wert -100..+100",
        default=0,
        min=-100,
        max=100,
        precision=0,
        step=1,
        subtype='PERCENTAGE',
        update=update_pedal  # Normale Funktion statt Lambda
    )

class LiveProperties(PropertyGroup):
    """Live Control Properties"""
    tracks: CollectionProperty(type=TrackLiveProperties)
    active_track: StringProperty(name="Active Track", default="")