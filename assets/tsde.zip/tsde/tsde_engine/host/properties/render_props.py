"""Property Groups für Section 6: Render Export"""
import bpy
from bpy.props import (
    StringProperty, 
    IntProperty, 
    FloatProperty,
    BoolProperty,
    EnumProperty
)
from bpy.types import PropertyGroup

class RenderProperties(PropertyGroup):
    """Properties für Render-Export"""
    
    # =================================================================
    # RECORDING AUSWAHL (NEU!)
    # =================================================================
    custom_recording_path: StringProperty(
        name="Recording Pfad",
        description="Benutzerdefinierter Pfad zur Recording-JSON",
        default="",
        subtype='FILE_PATH'
    )
    
    # =================================================================
    # RENDERING EINSTELLUNGEN
    # =================================================================
    render_fps: IntProperty(
        name="FPS",
        description="Frames pro Sekunde für den Render",
        default=24,
        min=1,
        max=120
    )
    
    output_path: StringProperty(
        name="Ausgabeordner",
        description="Zielordner für gerenderte Bilder",
        default="//renders/",
        subtype='DIR_PATH'
    )
    
    file_prefix: StringProperty(
        name="Dateiprefix",
        description="Prefix für Bilddateien (z.B. 'shot_')",
        default="frame_"
    )
    
    # =================================================================
    # ZEIT-STRETCHING
    # =================================================================
    use_time_stretch: BoolProperty(
        name="Time Stretch",
        description="Aufnahmezeit strecken/stauchen",
        default=False
    )
    
    time_factor: FloatProperty(
        name="Faktor",
        description="Zeitfaktor (0.5 = halbe Geschwindigkeit, 2.0 = doppelte)",
        default=1.0,
        min=0.1,
        max=10.0
    )
    
    # =================================================================
    # RENDER BEREICH
    # =================================================================
    render_range: EnumProperty(
        name="Bereich",
        description="Welcher Bereich gerendert werden soll",
        items=[
            ('ALL', "Gesamte Aufnahme", "Alle Frames der Aufnahme"),
            ('CUSTOM', "Benutzerdefiniert", "Nur bestimmten Bereich"),
        ],
        default='ALL'
    )
    
    frame_start: IntProperty(
        name="Start Frame",
        description="Erster Frame (0-100%)",
        default=0,
        min=0,
        max=100
    )
    
    frame_end: IntProperty(
        name="End Frame", 
        description="Letzter Frame (0-100%)",
        default=100,
        min=0,
        max=100
    )