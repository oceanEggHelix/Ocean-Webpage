"""Property Groups für Section 2: Setup Builder"""
from bpy.props import StringProperty, FloatProperty, BoolProperty, EnumProperty
from bpy.types import PropertyGroup

class SetupProperties(PropertyGroup):
    group_name: StringProperty(
        name="Group Name",
        description="Name für die Rig-Gruppe (z.B. TSDE_CAM1)",
        default="TSDE_Rig",
        maxlen=64
    )
    
    # =================================================================
    # PIVOT TRACK (Kamera)
    # =================================================================
    pivot_spline: StringProperty(
        name="Pivot Spline",
        description="Spline für die Kameraposition (orange)",
        default="",
        options={'HIDDEN'}
    )
    
    pivot_max_speed: FloatProperty(
        name="Pivot Max Speed",
        description="Maximale Geschwindigkeit für Pivot Track (mm/s)",
        default=100.0,
        min=1.0,
        max=1000.0,
        soft_min=10.0,
        soft_max=500.0,
        step=5.0,
        precision=1
    )
    
    # =================================================================
    # LENS TRACK (Blickpunkt)
    # =================================================================
    lens_spline: StringProperty(
        name="Lens Spline",
        description="Spline für den Blickpunkt (blau)",
        default="",
        options={'HIDDEN'}
    )
    
    lens_max_speed: FloatProperty(
        name="Lens Max Speed",
        description="Maximale Geschwindigkeit für Lens Track (mm/s)",
        default=100.0,
        min=1.0,
        max=1000.0,
        soft_min=10.0,
        soft_max=500.0,
        step=5.0,
        precision=1
    )
    
    # =================================================================
    # EMPTY SETTINGS
    # =================================================================
    empty_size: FloatProperty(
        name="Empty Size",
        description="Größe der Empties im 3D-View",
        default=0.1,
        min=0.01,
        max=1.0,
        soft_min=0.05,
        soft_max=0.5,
        step=0.01,
        precision=2
    )
    
    # =================================================================
    # KAMERA SETTINGS
    # =================================================================
    create_camera: BoolProperty(
        name="Kamera erstellen",
        description="Erstellt eine neue Kamera mit Tracking auf Lens Empty",
        default=True
    )
    
    camera_focal_length: FloatProperty(
        name="Brennweite",
        description="Brennweite der Kamera in mm",
        default=50.0,
        min=1.0,
        max=500.0,
        soft_min=18.0,
        soft_max=200.0,
        step=1.0,
        precision=1
    )
    
    # =================================================================
    # 🔥 NEU: ROLL SYSTEM AUSWAHL
    # =================================================================
    roll_system: EnumProperty(
        name="Roll System",
        description="Welches Roll-System soll verwendet werden?",
        items=[
            ('SIMPLE', "Einfach (Y-Roll)", "LookAt → Roll → Kamera - Nur Y-Roll als Effekt"),
            ('COMPLEX', "Komplex (X/Y/Z)", "Drei separate Roll-Gimbals für volle Kontrolle"),
        ],
        default='SIMPLE'
    )
    
    # =================================================================
    # DEPRECATED / ZUKUNFT
    # =================================================================
    track_speed: FloatProperty(
        name="Track Speed",
        description="[DEPRECATED] Bitte einzelne Geschwindigkeiten pro Track verwenden",
        default=100.0,
        min=1.0,
        max=1000.0,
        soft_min=10.0,
        soft_max=500.0,
        step=5.0,
        precision=1,
        options={'HIDDEN'}  # 🔥 Versteckt!
    )
    
    use_track_speed: BoolProperty(
        name="Speed verwenden",
        description="Track-Geschwindigkeit aktivieren",
        default=False,
        options={'HIDDEN'}
    )