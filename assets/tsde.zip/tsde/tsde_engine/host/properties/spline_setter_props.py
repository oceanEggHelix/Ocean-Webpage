"""Property Groups für TSDE Spline Setter"""
from bpy.props import StringProperty, IntProperty
from bpy.types import PropertyGroup

class SplineSetterProperties(PropertyGroup):
    keyframe_name: StringProperty(
        name="Name",
        default="Key"
    )
    steps_between: IntProperty(
        name="Feinheit",
        description="Je höher, desto weicher die Kurve",
        default=20,
        min=5,
        max=100
    )