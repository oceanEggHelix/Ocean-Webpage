"""Property Groups für Keyframe Retter"""
from bpy.props import FloatProperty, BoolProperty
from bpy.types import PropertyGroup

class KeyframeRetterProperties(PropertyGroup):
    target_segment_length: FloatProperty(
        name="Segmentlänge",
        default=0.005,
        min=0.001,
        max=0.1,
        precision=3
    )
    use_active_camera: BoolProperty(
        name="Aktive Kamera verwenden",
        default=True
    )