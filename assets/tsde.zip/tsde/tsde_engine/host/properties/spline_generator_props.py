"""Property Groups für TSDE Spline Generator"""
from bpy.props import FloatProperty, StringProperty, IntProperty, EnumProperty, BoolProperty
from bpy.types import PropertyGroup

class SplineSetterProperties(PropertyGroup):
    keyframe_name: StringProperty(
        name="Name",
        default="Key"
    )
    steps_between: IntProperty(
        name="Schritte",
        default=20,
        min=5,
        max=200
    )
    interpolation_method: EnumProperty(
        name="Methode",
        items=[
            ('LINEAR', "Linear", ""),
            ('EASE_IN_OUT', "Ease In/Out", ""),
            ('EASE_IN', "Ease In", ""),
            ('EASE_OUT', "Ease Out", ""),
            ('CATMULL_ROM', "Catmull-Rom", ""),
            ('BEZIER', "Bezier", ""),
            ('ELASTIC', "Elastic", ""),
            ('BOUNCE', "Bounce", "")
        ],
        default='CATMULL_ROM'
    )
    use_resample: BoolProperty(
        name="Resample",
        default=True
    )
    segment_length: FloatProperty(
        name="Segmentlänge",
        default=0.005,
        min=0.001,
        max=0.1,
        precision=3
    )

class KeyframeRetterProperties(PropertyGroup):
    target_segment_length: FloatProperty(
        name="Segmentlänge",
        default=0.005,
        min=0.001,
        max=0.1,
        precision=3
    )
    use_active_camera: BoolProperty(
        name="Aktive Kamera verwenden",
        default=True
    )