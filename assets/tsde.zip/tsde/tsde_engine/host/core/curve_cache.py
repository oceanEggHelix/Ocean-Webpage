# host/core/curve_cache.py
import bpy
import math
from mathutils import Vector
import json
import os

class CurveCache:
    """Cache für Kurvendaten mit ultraschneller O(log n) Interpolation"""

    def __init__(self):
        self.cache = {}      # track_name -> {points, seg_lengths, cumulative, total_length}
        self.initialized = False

    def load_from_setup(self, setup_path):
        """Lädt Kurvendaten aus Setup-JSON und bereitet cumulative lengths vor"""
        if not os.path.exists(setup_path):
            print(f"❌ Setup nicht gefunden: {setup_path}")
            return False

        try:
            with open(setup_path, 'r') as f:
                setup = json.load(f)
        except Exception as e:
            print(f"❌ Fehler beim Laden: {e}")
            return False

        self.cache.clear()

        for group in setup.get("groups", []):
            for track in group.get("tracks", []):
                if track.get("track_type") == "motion":
                    curve = track.get("curve", {})

                    if "points" in curve and "segment_lengths" in curve:
                        points = [Vector(p) for p in curve["points"]]
                        seg_lengths = curve["segment_lengths"]
                        total_length = curve.get("total_length", sum(seg_lengths))

                        # 🔥 cumulative lengths vorberechnen (O(n))
                        cumulative = [0.0]
                        for L in seg_lengths:
                            cumulative.append(cumulative[-1] + L)

                        self.cache[track["name"]] = {
                            "points": points,
                            "seg_lengths": seg_lengths,
                            "cumulative": cumulative,
                            "total_length": total_length
                        }

                        print(f"✅ Kurve geladen: {track['name']} ({len(points)} Punkte)")

        self.initialized = True
        print(f"📊 {len(self.cache)} Kurven im Cache")
        return True

    def get_position(self, track_name, t_local):
        """Berechnet Position für t_local (0–1) mit echter binärer Suche"""
        if track_name not in self.cache:
            return None

        cache = self.cache[track_name]
        points = cache["points"]
        seg_lengths = cache["seg_lengths"]
        cumulative = cache["cumulative"]
        total_length = cache["total_length"]

        # Clamp
        t_local = max(0.0, min(1.0, t_local))

        # Zielstrecke in mm
        s = t_local * total_length

        # 🔥 ECHTE BINÄRE SUCHE (O(log n))
        low, high = 0, len(cumulative) - 1
        while low < high:
            mid = (low + high) // 2
            if cumulative[mid] < s:
                low = mid + 1
            else:
                high = mid

        idx = max(0, low - 1)

        # Distanz im Segment
        dist_before = cumulative[idx]
        seg_len = seg_lengths[idx]

        # Fraction im Segment
        frac = (s - dist_before) / seg_len if seg_len > 0 else 0.0
        frac = max(0.0, min(1.0, frac))

        # Interpolation
        p0 = points[idx]
        p1 = points[idx + 1]

        x = p0.x + (p1.x - p0.x) * frac
        y = p0.y + (p1.y - p0.y) * frac
        z = p0.z + (p1.z - p0.z) * frac

        # Blender = Meter
        return Vector((x / 1000.0, y / 1000.0, z / 1000.0))

    def clear(self):
        self.cache.clear()
        self.initialized = False


# 🔥 Globale Instanz
curve_cache = CurveCache()