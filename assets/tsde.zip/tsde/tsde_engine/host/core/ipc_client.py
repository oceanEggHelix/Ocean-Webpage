# tsde_engine/host/core/ipc_client.py

import sys
import os

# TSDE-Pfad für ipc-Modul
TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

try:
    import tsde_engine.core.ipc as _ipc
    print("✅ ipc importiert")
except Exception as e:
    print(f"❌ ipc Import fehlgeschlagen: {e}")
    _ipc = None

# ============================================================
# BESTEHENDE FUNKTIONEN (delegieren an _ipc)
# ============================================================

def is_running():
    return _ipc.is_running() if _ipc else False

def start_engine(debug_level=1):
    if _ipc:
        _ipc.start_engine(debug_level)

def stop_engine():
    if _ipc:
        _ipc.stop_engine()

def send(cmd, **kwargs):
    if _ipc:
        _ipc.send(cmd, **kwargs)

def poll():
    return _ipc.poll() if _ipc else []

def poll_recorder():
    return _ipc.poll_recorder() if _ipc else {}

def get_engine_info():
    return _ipc.get_engine_info() if _ipc else {}

# ============================================================
# 🔥 NEU: RENDER-FUNKTIONEN
# ============================================================

def start_render(recording_path, fps=24, time_factor=1.0, t_start=0.0, t_end=1.0):
    """Startet Render-Modus"""
    if _ipc:
        return _ipc.start_render(recording_path, fps, time_factor, t_start, t_end)
    return False

def poll_render_frame():
    """Holt nächsten Frame für Render"""
    if _ipc:
        return _ipc.poll_render_frame()
    return None

def get_render_progress():
    """Gibt Render-Fortschritt zurück"""
    if _ipc:
        return _ipc.get_render_progress()
    return {"running": False, "current": 0, "total": 0, "progress": 0}

def stop_render():
    """Stoppt Render vorzeitig"""
    if _ipc:
        return _ipc.stop_render()
    return False