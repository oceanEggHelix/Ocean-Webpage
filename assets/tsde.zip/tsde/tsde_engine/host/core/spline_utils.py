"""Spline Hilfsfunktionen - Resampling und Grundlagen"""
from math import ceil
from mathutils import Vector

def resample_spline_points(points, segment_length):
    """
    EXAKT wie im Prototyp: Gleicht Spline-Punkte auf konstante Segmentlänge an
    """
    if len(points) < 2:
        return points.copy()

    new_points = []

    for i in range(len(points) - 1):
        start_pt = points[i]
        end_pt = points[i + 1]

        distance = (end_pt - start_pt).length
        if distance == 0:
            continue

        num_segments = max(1, int(ceil(distance / segment_length)))
        direction = (end_pt - start_pt).normalized()

        for j in range(num_segments):
            t = j / num_segments
            point = start_pt + direction * (distance * t)
            new_points.append(point)

    new_points.append(points[-1].copy())
    return new_points