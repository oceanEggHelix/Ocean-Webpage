"""Exakte Lens-Berechnung wie im Prototyp"""
import mathutils
from mathutils import Vector

def get_lens_position_exact(cam):
    """
    Berechnet die optische Linsenposition EXAKT wie im Prototyp:
    lens_center = cam.matrix_world.translation + forward * (lens_mm / sensor_mm)
    """
    cam_matrix = cam.matrix_world
    
    # Forward-Vektor (lokale -Z Achse)
    forward = cam_matrix.to_quaternion() @ Vector((0, 0, -1))
    
    # Aktuelle Brennweite
    lens_mm = cam.data.lens
    
    # Sensorgröße (horizontal oder vertikal)
    if cam.data.sensor_fit == 'VERTICAL':
        sensor_mm = cam.data.sensor_height
    else:
        sensor_mm = cam.data.sensor_width
    
    # Offset in Blender Units (physikalisch plausibel)
    lens_offset = lens_mm / sensor_mm
    
    # Optisches Zentrum = Kameraposition + Blickrichtung * Offset
    lens_center = cam_matrix.translation + forward * lens_offset
    
    return lens_center