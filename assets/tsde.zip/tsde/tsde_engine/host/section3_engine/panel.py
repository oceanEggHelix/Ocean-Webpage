"""N-Panel UI für Section 3: Engine Control"""
import bpy
import os
from bpy.types import Panel, UIList

# =================================================================
# EINFACHE LISTE FÜR RIGS
# =================================================================
class TSDE_UL_RigList(UIList):
    """Einfache Liste mit Checkboxen für Rigs"""
    bl_idname = "TSDE_UL_RigList"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Checkbox zum Auswählen
            layout.prop(item, "selected", text="", emboss=False)
            # Rig Name
            layout.label(text=item.name, icon='OUTLINER_COLLECTION')
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='OUTLINER_COLLECTION')


class TSDE_PT_Section3(Panel):
    bl_label = "3. Engine Control"
    bl_idname = "TSDE_PT_section3"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    @classmethod
    def poll(cls, context):
        return hasattr(context.scene, 'tsde_engine_props')
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_engine_props
        
        # =================================================================
        # RIG AUSWAHL - EINFACHE LISTE
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="🎯 RIG AUSWAHL", icon='OUTLINER_COLLECTION')
        col.separator()
        
        # Button zum Laden der Rigs
        row = col.row(align=True)
        row.operator("tsde.list_rigs", text="📋 Rigs laden", icon='FILE_REFRESH')
        
        col.separator()
        
        # Die einfache Liste mit Checkboxen
        if props and len(props.rig_selection) > 0:
            # Liste anzeigen
            col.template_list(
                "TSDE_UL_RigList",
                "rig_selection",
                props,
                "rig_selection",
                props,
                "active_rig_index",
                rows=5
            )
            
            # Zeige Anzahl ausgewählter Rigs
            selected = sum(1 for rig in props.rig_selection if rig.selected)
            col.label(text=f"Ausgewählt: {selected} von {len(props.rig_selection)}")
            
            # Schnell-Auswahl Buttons
            row = col.row(align=True)
            row.operator("tsde.select_all_rigs", text="Alle", icon='CHECKBOX_HLT')
            row.operator("tsde.select_none_rigs", text="Keine", icon='CHECKBOX_DEHLT')
        else:
            col.label(text="Keine Rigs geladen", icon='INFO')
        
        # =================================================================
        # ENGINE STARTEN - NUR EIN BUTTON
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="🚀 ENGINE STARTEN", icon='PLAY')
        col.separator()
        
        # GROSSER START BUTTON
        row = col.row(align=True)
        row.scale_y = 2.0
        
        # Dein existierender start_engine exportiert ALLE Rigs!
        row.operator("tsde.start_engine", text="⚡ ENGINE STARTEN", icon='EXPERIMENTAL')
        
        # Letztes Setup Info
        if props and props.last_setup_path:
            col.label(text=f"✅ {os.path.basename(props.last_setup_path)}")
        
        # =================================================================
        # REST (bleibt gleich)
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="🎮 ENGINE CONTROL", icon='PLAY')
        col.separator()
        
        if props:
            col.prop(props, "engine_debug_level")
        else:
            col.label(text="Debug-Level nicht verfügbar", icon='ERROR')
        
        col.separator()
        
        # Status-Anzeige
        status_box = col.box()
        status_col = status_box.column(align=True)
        
        if props:
            status_col.label(text=f"Status: {props.engine_status}")
            status_col.label(text=f"Verbindung: {props.connection_status}")
            if props.engine_pid > 0:
                status_col.label(text=f"PID: {props.engine_pid}")
        else:
            status_col.label(text="Status: Unbekannt", icon='QUESTION')
        
        col.separator()
        
        # Engine Buttons
        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("tsde.stop_engine", text="🛑 ENGINE STOPPEN", icon='CANCEL')
        
        row = col.row(align=True)
        row.operator("tsde.test_connection", text="🔌 Verbindung testen", icon='NETWORK_DRIVE')
        
        # =================================================================
        # INFO
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="ℹ️ WORKFLOW:", icon='INFO')
        col.label(text="1. Rigs laden")
        col.label(text="2. ENGINE STARTEN drücken")
        col.label(text="3. Fertig! (Exportiert ALLE Rigs)")
        col.label(text="   Die Checkboxen sind nur zur Info")


# =================================================================
# HILFS-OPERATOREN
# =================================================================
class TSDE_OT_SelectAllRigs(bpy.types.Operator):
    """Alle Rigs auswählen"""
    bl_idname = "tsde.select_all_rigs"
    bl_label = "Alle auswählen"
    
    def execute(self, context):
        props = context.scene.tsde_engine_props
        for rig in props.rig_selection:
            rig.selected = True
        return {'FINISHED'}


class TSDE_OT_SelectNoneRigs(bpy.types.Operator):
    """Alle Rigs abwählen"""
    bl_idname = "tsde.select_none_rigs"
    bl_label = "Keine auswählen"
    
    def execute(self, context):
        props = context.scene.tsde_engine_props
        for rig in props.rig_selection:
            rig.selected = False
        return {'FINISHED'}