"""Testet IPC-Verbindung zur Engine"""
import bpy
import sys
from bpy.types import Operator

TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

class TSDE_OT_TestConnection(Operator):
    bl_idname = "tsde.test_connection"
    bl_label = "Verbindung testen"
    bl_description = "Testet die IPC-Verbindung zur Engine"

    def execute(self, context):
        props = context.scene.tsde_engine_props

        if ipc.is_running():
            props.connection_status = "Verbunden"
            info = ipc.get_engine_info()
            props.engine_pid = info.get('pid', 0)
            self.report({'INFO'}, "✅ Verbindung zur Engine OK")
        else:
            props.connection_status = "Getrennt"
            self.report({'WARNING'}, "❌ Engine läuft nicht")

        return {'FINISHED'}