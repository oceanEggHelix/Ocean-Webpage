"""Exportiert Rigs als Setup für die TSDE Engine - JETZT MIT MEHREREN GRUPPEN!"""
import bpy
import os
import json
import tempfile
from mathutils import Vector
from bpy.types import Operator
from ..utils.file_utils import ensure_directory, save_json, save_csv
from ..utils.blender_utils import get_spline_points

BLENDER_TO_MM = 1000.0

def spline_to_csv_data(spline_obj, num_points=100):
    """Konvertiert Blender Spline in CSV (mm, 3 Nachkommastellen)"""
    if not spline_obj or spline_obj.type != 'CURVE':
        return []
    
    points = get_spline_points(spline_obj)
    if len(points) < 2:
        return []
    
    if len(points) >= num_points:
        step = len(points) / num_points
        csv_data = []
        for i in range(num_points):
            idx = min(int(i * step), len(points) - 1)
            p = points[idx]
            x_mm = p.x * BLENDER_TO_MM
            y_mm = p.y * BLENDER_TO_MM
            z_mm = p.z * BLENDER_TO_MM
            csv_data.append(f"{x_mm:.3f} {y_mm:.3f} {z_mm:.3f}")
        return csv_data
    else:
        csv_data = []
        for i in range(num_points):
            t = i / (num_points - 1)
            pos = len(points) - 1
            idx = t * pos
            i1 = int(idx)
            i2 = min(i1 + 1, len(points) - 1)
            frac = idx - i1
            if i1 == i2:
                p = points[i1]
            else:
                p = points[i1].lerp(points[i2], frac)
            x_mm = p.x * BLENDER_TO_MM
            y_mm = p.y * BLENDER_TO_MM
            z_mm = p.z * BLENDER_TO_MM
            csv_data.append(f"{x_mm:.3f} {y_mm:.3f} {z_mm:.3f}")
        return csv_data

def find_rig_objects(context, group_name):
    """Findet alle Objekte einer Rig-Gruppe"""
    group = bpy.data.collections.get(group_name)
    if not group:
        return None
    
    pivot_empty = None
    lens_empty = None
    camera = None
    
    for obj in group.objects:
        if obj.name.endswith("_Pivot"):
            pivot_empty = obj
        elif obj.name.endswith("_Lens"):
            lens_empty = obj
        elif obj.type == 'CAMERA':
            camera = obj
    
    pivot_spline = None
    lens_spline = None
    
    if pivot_empty and pivot_empty.constraints:
        for c in pivot_empty.constraints:
            if c.type == 'FOLLOW_PATH' and c.target:
                pivot_spline = c.target.name
    
    if lens_empty and lens_empty.constraints:
        for c in lens_empty.constraints:
            if c.type == 'FOLLOW_PATH' and c.target:
                lens_spline = c.target.name
    
    return {
        'group': group,
        'pivot_empty': pivot_empty,
        'lens_empty': lens_empty,
        'camera': camera,
        'pivot_spline': pivot_spline,
        'lens_spline': lens_spline
    }

def get_track_speed(context, group_name, track_name):
    """Holt die gespeicherte Speed für einen Track aus dem Rig"""
    track_speeds = context.scene.get('tsde_track_speeds', {})
    full_name = f"{group_name}_{track_name}"
    speed = track_speeds.get(full_name, 100.0)
    print(f"📊 Speed für {full_name}: {speed} mm/s")
    return speed

def detect_roll_system(group):
    """Erkennt welches Roll-System in der Gruppe verwendet wurde"""
    has_simple_roll = False
    has_complex_roll = False
    
    for obj in group.objects:
        if obj.name.endswith("_Roll"):
            has_simple_roll = True
        if obj.name.endswith("_Gimbal_Roll"):
            has_complex_roll = True
    
    if has_simple_roll:
        return 'SIMPLE'
    elif has_complex_roll:
        return 'COMPLEX'
    else:
        return 'NONE'

class TSDE_OT_ExportSetup(Operator):
    bl_idname = "tsde.export_setup"
    bl_label = "Setup exportieren"
    bl_description = "Exportiert Rigs als Setup für die TSDE Engine"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty(
        name="Group Name",
        description="Name der Rig-Gruppe (optional - wenn leer, werden ALLE ausgewählten exportiert)",
        default=""
    )
    
    filepath: bpy.props.StringProperty(
        name="File Path",
        description="Zielpfad für die JSON-Datei (optional)",
        default="",
        subtype='FILE_PATH'
    )

    def execute(self, context):
        props = context.scene.tsde_engine_props
        settings_props = context.scene.tsde_settings_props

        # ============================================================
        # SAMPLING AUS SECTION 7
        # ============================================================
        segment_length = round(settings_props.curve_segment_length, 2)
        num_points = settings_props.curve_max_points

        # ============================================================
        # CSV-VERZEICHNIS
        # ============================================================
        csv_dir = props.csv_path
        if not csv_dir:
            csv_dir = os.path.join(tempfile.gettempdir(), "tsde_csv")
        ensure_directory(csv_dir)

        # ============================================================
        # GRUPPEN SAMMELN (ALLE ODER NUR EINE)
        # ============================================================
        groups_to_export = []
        
        if self.group_name:
            # Nur EINE bestimmte Gruppe
            groups_to_export.append(self.group_name)
        else:
            # ALLE ausgewählten Gruppen aus der rig_selection
            for rig_item in props.rig_selection:
                if rig_item.selected:
                    groups_to_export.append(rig_item.name)
        
        if not groups_to_export:
            self.report({'ERROR'}, "Keine Gruppen zum Exportieren ausgewählt!")
            return {'CANCELLED'}
        
        print(f"\n📦 Exportiere {len(groups_to_export)} Gruppen: {', '.join(groups_to_export)}")
        
        # ============================================================
        # JSON-SETUP MIT ALLEN GRUPPEN
        # ============================================================
        setup_data = {"groups": []}
        
        for group_name in groups_to_export:
            rig = find_rig_objects(context, group_name)
            
            if not rig:
                print(f"⚠️ Rig '{group_name}' nicht gefunden, überspringe...")
                continue
            
            if not rig['pivot_spline'] or not rig['lens_spline']:
                print(f"⚠️ Keine gültigen Splines in '{group_name}', überspringe...")
                continue
            
            pivot_spline_obj = bpy.data.objects.get(rig['pivot_spline'])
            lens_spline_obj = bpy.data.objects.get(rig['lens_spline'])
            
            if not pivot_spline_obj or not lens_spline_obj:
                print(f"⚠️ Spline-Objekte in '{group_name}' nicht gefunden, überspringe...")
                continue
            
            # Speeds holen
            pivot_speed = get_track_speed(context, group_name, "Pivot")
            lens_speed = get_track_speed(context, group_name, "Lens")
            
            # CSV-Dateien für dieses Rig
            pivot_csv = os.path.join(csv_dir, f"{group_name}_pivot.csv")
            lens_csv = os.path.join(csv_dir, f"{group_name}_lens.csv")
            
            # CSV-Daten generieren
            pivot_data = spline_to_csv_data(pivot_spline_obj, num_points)
            lens_data = spline_to_csv_data(lens_spline_obj, num_points)
            
            if not pivot_data or not lens_data:
                print(f"⚠️ Konnte keine CSV-Daten für '{group_name}' generieren, überspringe...")
                continue
            
            save_csv(pivot_data, pivot_csv)
            save_csv(lens_data, lens_csv)
            
            # Pfade für JSON (mit / für JSON)
            pivot_csv_json = pivot_csv.replace('\\', '/')
            lens_csv_json = lens_csv.replace('\\', '/')
            
            # Kamera-Daten
            camera_lens = 50.0
            if rig['camera'] and hasattr(rig['camera'].data, 'lens'):
                camera_lens = rig['camera'].data.lens
            
            # ============================================================
            # 🔥 ROLL-SYSTEM ERKENNEN
            # ============================================================
            roll_system = detect_roll_system(rig['group'])
            print(f"   🔍 Erkanntes Roll-System für {group_name}: {roll_system}")
            
            # Basistracks (immer vorhanden)
            tracks = [
                # Pivot Track (motion)
                {
                    "name": f"{group_name}_Pivot",
                    "max_speed": pivot_speed,
                    "focal_length": 0.0,
                    "curve": {
                        "source": "csv",
                        "path": pivot_csv_json,
                        "segment_length": segment_length
                    },
                    "track_type": "motion"
                },
                # Lens Track (motion)
                {
                    "name": f"{group_name}_Lens",
                    "max_speed": lens_speed,
                    "focal_length": 0.0,
                    "curve": {
                        "source": "csv",
                        "path": lens_csv_json,
                        "segment_length": segment_length
                    },
                    "track_type": "motion"
                }
            ]
            
            # 🔥 ROLL-TRACKS JE NACH SYSTEM
            if roll_system == 'SIMPLE':
                # EINFACHES SYSTEM: Nur EINEN Roll-Track
                tracks.append({
                    "name": f"{group_name}_Roll",
                    "track_type": "empty",
                    "max_speed": 0.0,
                    "focal_length": 0.0,
                    "curve": {
                        "source": "empty",
                        "path": "",
                        "segment_length": 0.0
                    }
                })
                print(f"   ✅ Einfaches System: {group_name}_Roll")
                
            elif roll_system == 'COMPLEX':
                # KOMPLEXES SYSTEM: X/Y/Z Roll-Tracks
                tracks.append({
                    "name": f"{group_name}_Roll_X",
                    "track_type": "empty",
                    "max_speed": 0.0,
                    "focal_length": 0.0,
                    "curve": {
                        "source": "empty",
                        "path": "",
                        "segment_length": 0.0
                    }
                })
                tracks.append({
                    "name": f"{group_name}_Roll_Y",
                    "track_type": "empty",
                    "max_speed": 0.0,
                    "focal_length": 0.0,
                    "curve": {
                        "source": "empty",
                        "path": "",
                        "segment_length": 0.0
                    }
                })
                print(f"   ✅ Komplexes System: {group_name}_Roll_X, {group_name}_Roll_Y")
            
            # Kamera Track (immer für Kompatibilität)
            tracks.append({
                "name": f"{group_name}_Camera",
                "track_type": "empty",
                "max_speed": 0.0,
                "focal_length": camera_lens,
                "curve": {
                    "source": "empty",
                    "path": "",
                    "segment_length": 0.0
                }
            })
            
            # Gruppe hinzufügen
            group_data = {
                "name": group_name,
                "tracks": tracks
            }
            
            setup_data["groups"].append(group_data)
            print(f"   ✅ {group_name} hinzugefügt ({len(tracks)} Tracks)")
        
        if not setup_data["groups"]:
            self.report({'ERROR'}, "Keine gültigen Gruppen zum Exportieren gefunden!")
            return {'CANCELLED'}
        
        # ============================================================
        # JSON SPEICHERN
        # ============================================================
        # Zielpfad bestimmen
        if self.filepath:
            setup_json = self.filepath
        else:
            # 🔥 DYNAMISCHER PFAD NACH INSTALLATION
            addon_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
            engine_setup_dir = os.path.join(addon_root, "tsde_engine", "setup", "json")
            ensure_directory(engine_setup_dir)
            setup_json = os.path.join(engine_setup_dir, "setup.json")

        
        save_json(setup_data, setup_json)
        
        # Backup im CSV-Verzeichnis
        backup_json = os.path.join(csv_dir, "setup_all.json")
        save_json(setup_data, backup_json)
        
        # Letztes Setup speichern
        props.last_setup_path = setup_json
        props.last_setup_name = ", ".join(groups_to_export)
        
        self.report({'INFO'}, f"✅ {len(setup_data['groups'])} Gruppen exportiert nach: {setup_json}")
        print(f"\n📤 Setup Export abgeschlossen:")
        print(f"   Gruppen: {len(setup_data['groups'])}")
        print(f"   Datei: {setup_json}")
        print(f"   Segment Length: {segment_length} mm")
        print(f"   Num Points: {num_points}")
        
        return {'FINISHED'}