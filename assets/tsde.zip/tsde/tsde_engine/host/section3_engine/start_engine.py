"""Startet TSDE Engine mit IPC-Verbindung - JETZT MIT BEIDEN ROLL-SYSTEMEN!"""
import bpy
import os
import json
import time
import sys
import math
from bpy.types import Operator

# TSDE-Pfad für ipc-Modul
TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

try:
    import tsde_engine.core.ipc as ipc
    print("✅ ipc importiert")
except Exception as e:
    print(f"❌ ipc Import fehlgeschlagen: {e}")

# ============================================================
# GLOBALER POLLING TIMER - UNTERSTÜTZT BEIDE ROLL-SYSTEME!
# ============================================================
poll_timer = None

def poll_engine_data():
    """Pollt Engine-Daten - Unterstützt einfaches und komplexes Roll-System"""
    if not ipc.is_running():
        return None
    
    try:
        data = ipc.poll()
        if data:
            for track in data:
                track_name = track["name"]
                t_local = track["t_local"]
                pedal = track.get("pedal", 0.0)
                
                # 1. PIVOT TRACKS - wie gehabt
                if track_name.endswith("_Pivot"):
                    rig_name = track_name.replace("_Pivot", "")
                    set_constraint_offset(bpy.context, rig_name, "_Pivot", t_local)
                
                # 2. LENS TRACKS - wie gehabt
                elif track_name.endswith("_Lens"):
                    rig_name = track_name.replace("_Lens", "")
                    set_constraint_offset(bpy.context, rig_name, "_Lens", t_local)
                
                # 3. 🔥 EINFACHES SYSTEM - Y-ROLL TRACK
                elif track_name.endswith("_Roll"):
                    rig_name = track_name.replace("_Roll", "")
                    rig_collection = bpy.data.collections.get(rig_name)
                    
                    if rig_collection:
                        # Suche nach Roll Empty
                        roll = rig_collection.objects.get(f"{rig_name}_Roll")
                        
                        if roll:
                            roll_deg = pedal * 450
                            roll_rad = roll_deg * math.pi / 180.0
                            roll.rotation_euler.z = roll_rad
                            #print(f"🎥 {rig_name}: Y-Roll {roll_deg:.1f}°")
                        else:
                            # Fallback: Versuche LookAt
                            lookat = rig_collection.objects.get(f"{rig_name}_LookAt")
                            if lookat:
                                roll_deg = pedal * 450
                                roll_rad = roll_deg * math.pi / 180.0
                                lookat.rotation_euler.y = roll_rad
                                #print(f"🎥 {rig_name}: Y-Roll auf LookAt {roll_deg:.1f}°")
                
                # 4. 🔥 KOMPLEXES SYSTEM - X-ROLL TRACK
                elif track_name.endswith("_Roll_X"):
                    rig_name = track_name.replace("_Roll_X", "")
                    rig_collection = bpy.data.collections.get(rig_name)
                    
                    if rig_collection:
                        gimbal = rig_collection.objects.get(f"{rig_name}_Gimbal_Roll")
                        if gimbal:
                            roll_deg = pedal * 450
                            roll_rad = roll_deg * math.pi / 180.0
                            gimbal.rotation_euler.x = roll_rad
                            print(f"🎥 {rig_name}: X-Roll {roll_deg:.1f}°")
                
                # 5. 🔥 KOMPLEXES SYSTEM - Y-ROLL TRACK
                elif track_name.endswith("_Roll_Y"):
                    rig_name = track_name.replace("_Roll_Y", "")
                    rig_collection = bpy.data.collections.get(rig_name)
                    
                    if rig_collection:
                        gimbal = rig_collection.objects.get(f"{rig_name}_Gimbal_Roll")
                        if gimbal:
                            roll_deg = pedal * 450
                            roll_rad = roll_deg * math.pi / 180.0
                            gimbal.rotation_euler.y = roll_rad
                            print(f"🎥 {rig_name}: Y-Roll {roll_deg:.1f}°")
                
                # 6. 🔥 KOMPLEXES SYSTEM - Z-ROLL TRACK (für Zukunft)
                elif track_name.endswith("_Roll_Z"):
                    rig_name = track_name.replace("_Roll_Z", "")
                    rig_collection = bpy.data.collections.get(rig_name)
                    
                    if rig_collection:
                        gimbal = rig_collection.objects.get(f"{rig_name}_Gimbal_Roll")
                        if gimbal:
                            roll_deg = pedal * 450
                            roll_rad = roll_deg * math.pi / 180.0
                            gimbal.rotation_euler.z = roll_rad
                            print(f"🎥 {rig_name}: Z-Roll {roll_deg:.1f}°")
                
                    # 7. 🔥 FALLBACK für alte Camera Tracks - NUR wenn kein Roll Empty!
                    elif track_name.endswith("_Camera"):
                        rig_name = track_name.replace("_Camera", "")
                        rig_collection = bpy.data.collections.get(rig_name)
                        
                        if rig_collection:
                            # Prüfe OB ES ÜBERHAUPT EIN ROLL EMPTY GIBT
                            roll = rig_collection.objects.get(f"{rig_name}_Roll")
                            gimbal = rig_collection.objects.get(f"{rig_name}_Gimbal_Roll")
                            
                            # NUR wenn KEIN Roll-System existiert!
                            if not roll and not gimbal:
                                # Hier alten Kamera-Code
                                print(f"🎥 {rig_name}: Alter Kamera-Fallback")
                            else:
                                # Sonst ignorieren (wurde schon von anderem Zweig behandelt)
                                pass
                
    except Exception as e:
        print(f"⚠️ Polling Fehler: {e}")
    
    return 0.01


def set_constraint_offset(context, rig_name, empty_suffix, t_local):
    """Setzt den offset_factor der Follow Path Constraint"""
    rig_collection = bpy.data.collections.get(rig_name)
    if not rig_collection:
        return
    
    empty_name = f"{rig_name}{empty_suffix}"
    empty_obj = rig_collection.objects.get(empty_name)
    if not empty_obj:
        return
    
    for constraint in empty_obj.constraints:
        if constraint.type == 'FOLLOW_PATH':
            constraint.offset_factor = t_local
            break

# ============================================================
# TRACKS LADEN - JETZT MIT EMPTY TRACKS!
# ============================================================
def load_tracks_from_setup(context):
    """Lädt ALLE Tracks (Motion + Empty) aus Setup in Live Properties - OHNE Camera Fallback"""
    props = context.scene.tsde_live_props
    engine_props = context.scene.tsde_engine_props
    
    # Bestehende Tracks löschen
    props.tracks.clear()
    
    if engine_props.last_setup_path and os.path.exists(engine_props.last_setup_path):
        try:
            with open(engine_props.last_setup_path, 'r') as f:
                setup = json.load(f)
            
            track_count = 0
            group_count = 0
            empty_count = 0
            
            for group in setup.get("groups", []):
                group_count += 1
                print(f"   Gruppe {group_count}: {group.get('name')}")
                
                for track in group.get("tracks", []):
                    track_type = track.get("track_type", "motion")
                    track_name = track["name"]
                    
                    # 🔥 Camera Tracks überspringen!
                    if track_name.endswith("_Camera"):
                        print(f"      ⏭️ Camera übersprungen: {track_name}")
                        continue
                    
                    # 🔥 Alle anderen Tracks zur Live Section hinzufügen
                    new_track = props.tracks.add()
                    new_track.name = track_name
                    new_track.pedal = 0
                    track_count += 1
                    
                    if track_type == "motion":
                        print(f"      🎬 Motion {track_count}: {track_name}")
                    else:
                        empty_count += 1
                        print(f"      📦 Empty {track_count}: {track_name}")
            
            print(f"✅ {track_count} Tracks geladen ({track_count-empty_count} Motion, {empty_count} Empty) aus {group_count} Gruppen")
            
        except Exception as e:
            print(f"⚠️ Fehler beim Laden der Tracks: {e}")
            import traceback
            traceback.print_exc()
            
class TSDE_OT_StartEngine(Operator):
    bl_idname = "tsde.start_engine"
    bl_label = "Engine starten"
    bl_description = "Startet TSDE Engine"
    bl_options = {'REGISTER'}

    def execute(self, context):
        global poll_timer
        props = context.scene.tsde_engine_props

        # ============================================================
        # 1. ALLE AUSGEWÄHLTEN RIGS EXPORTIEREN (IN EINE JSON!)
        # ============================================================
        print("\n🚀 Starte Engine mit Multi-Rig Export...")
        
        # Export mit leerem group_name = ALLE ausgewählten Rigs
        result = bpy.ops.tsde.export_setup(group_name="")
        
        if 'CANCELLED' in result:
            self.report({'ERROR'}, "Export fehlgeschlagen!")
            return {'CANCELLED'}
        
        # ============================================================
        # 2. KURZE WARTEZEIT
        # ============================================================
        time.sleep(0.5)
        
        # ============================================================
        # 3. SETUP LADEN
        # ============================================================
        if not props.last_setup_path or not os.path.exists(props.last_setup_path):
            self.report({'ERROR'}, "Setup nicht gefunden!")
            return {'CANCELLED'}
        
        with open(props.last_setup_path, 'r') as f:
            setup_data = json.load(f)
        
        print(f"✅ Setup geladen: {props.last_setup_path}")
        print(f"   {len(setup_data['groups'])} Gruppen")
        
        # ============================================================
        # 4. TRACKS LADEN (VOR ENGINE START!)
        # ============================================================
        load_tracks_from_setup(context)
        
        # ============================================================
        # 5. ENGINE STARTEN
        # ============================================================
        try:
            if ipc.is_running():
                self.report({'WARNING'}, "Engine läuft bereits!")
                return {'CANCELLED'}
            
            print(f"🚀 Starte Engine...")
            ipc.start_engine(debug_level=props.engine_debug_level)
            
            for i in range(10):
                time.sleep(0.2)
                if ipc.is_running():
                    break
            
            if not ipc.is_running():
                self.report({'ERROR'}, "Engine Start fehlgeschlagen!")
                return {'CANCELLED'}
            
            # Setup senden
            print("📤 Sende Setup...")
            ipc.send("setup", data=setup_data)
            
            # Polling starten
            if poll_timer is None:
                poll_timer = bpy.app.timers.register(poll_engine_data)
            
            info = ipc.get_engine_info()
            props.engine_pid = info.get('pid', 0)
            props.engine_status = "Läuft"
            props.connection_status = "Verbunden"
            
            self.report({'INFO'}, f"🚀 Engine gestartet mit {len(setup_data['groups'])} Gruppen")
            
        except Exception as e:
            props.engine_status = f"Fehler: {str(e)}"
            self.report({'ERROR'}, f"Fehler: {str(e)}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}
        
        return {'FINISHED'}