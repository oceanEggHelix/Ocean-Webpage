"""Stoppt TSDE Engine"""
import bpy
import sys
from bpy.types import Operator

# TSDE-Pfad für ipc-Modul
TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

# WICHTIG: Globalen Timer aus start_engine importieren
try:
    from .start_engine import poll_timer
except ImportError:
    poll_timer = None

class TSDE_OT_StopEngine(Operator):
    bl_idname = "tsde.stop_engine"
    bl_label = "Engine stoppen"
    bl_description = "Stoppt die laufende TSDE Engine"

    def execute(self, context):
        global poll_timer
        props = context.scene.tsde_engine_props

        try:
            # ============================================================
            # 1. Polling Timer stoppen (falls vorhanden)
            # ============================================================
            if poll_timer is not None:
                try:
                    bpy.app.timers.unregister(poll_timer)
                    print("✅ Polling Timer gestoppt")
                except:
                    print("⚠️ Polling Timer konnte nicht gestoppt werden")
                poll_timer = None
            
            # ============================================================
            # 2. Engine stoppen
            # ============================================================
            if ipc.is_running():
                print("🛑 Stoppe Engine...")
                ipc.stop_engine()
                
                # Status aktualisieren
                props.engine_status = "Gestoppt"
                props.connection_status = "Getrennt"
                props.engine_pid = 0
                
                self.report({'INFO'}, "🛑 Engine gestoppt")
                print("✅ Engine erfolgreich gestoppt")
            else:
                self.report({'WARNING'}, "Engine läuft nicht")
                props.engine_status = "Gestoppt"
                props.connection_status = "Getrennt"
            
            # ============================================================
            # 3. UI updaten
            # ============================================================
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
            
        except Exception as e:
            self.report({'ERROR'}, f"Fehler beim Stoppen: {e}")
            props.engine_status = f"Fehler: {e}"
            import traceback
            traceback.print_exc()

        return {'FINISHED'}