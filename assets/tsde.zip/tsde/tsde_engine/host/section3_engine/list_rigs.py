"""Operator: Listet alle verfügbaren Rigs auf und füllt die Multi-Rig Auswahl"""
import bpy
import os
from bpy.types import Operator

class TSDE_OT_ListRigs(Operator):
    bl_idname = "tsde.list_rigs"
    bl_label = "Rigs laden"
    bl_description = "Alle verfügbaren TSDE Rigs suchen und in die Auswahlliste übernehmen"

    def execute(self, context):
        scene = context.scene
        engine_props = scene.tsde_engine_props
        
        print("\n📋 Verfügbare TSDE Rigs:")
        
        # Alte Liste leeren
        engine_props.rig_selection.clear()
        
        rigs_found = []
        
        # Durch alle Collections suchen
        for collection in bpy.data.collections:
            # Prüfen ob Collection ein Rig enthält
            has_pivot = False
            has_lens = False

            for obj in collection.objects:
                if obj.name.endswith("_Pivot"):
                    has_pivot = True
                elif obj.name.endswith("_Lens"):
                    has_lens = True

            if has_pivot and has_lens:
                rigs_found.append(collection.name)
                
                # Neuen Eintrag in der Collection anlegen
                item = engine_props.rig_selection.add()
                item.name = collection.name
                item.rig_object = collection.name
                item.selected = True  # Standardmäßig ausgewählt
                
                # Vorschlag für Export-Pfad
                if engine_props.common_export_path:
                    # Dateinamen generieren (ohne Leerzeichen)
                    safe_name = collection.name.replace(" ", "_")
                    item.export_filepath = os.path.join(
                        engine_props.common_export_path, 
                        f"{safe_name}_setup.json"
                    )
                
                print(f"   - {collection.name}")

        if not rigs_found:
            print("   Keine Rigs gefunden")
            self.report({'WARNING'}, "Keine TSDE Rigs in der Szene gefunden")
            return {'CANCELLED'}
        
        # Setze aktiven Index
        if len(engine_props.rig_selection) > 0:
            engine_props.active_rig_index = 0
            # Auch das selected_rig für Kompatibilität setzen
            engine_props.selected_rig = rigs_found[0]
        
        print(f"\n✅ {len(rigs_found)} Rigs geladen")
        self.report({'INFO'}, f"{len(rigs_found)} Rigs geladen")
        return {'FINISHED'}