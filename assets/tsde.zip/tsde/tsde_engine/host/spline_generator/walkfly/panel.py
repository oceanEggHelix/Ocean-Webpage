"""Panel für Walk/Fly Mode"""
import bpy
from bpy.types import Panel
from .operator import WALKFLY_PIVOT_POINTS

class TSDE_PT_Walkfly(Panel):
    bl_label = "   Walk/Fly Mode"
    bl_idname = "TSDE_PT_walkfly"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_spline_generator"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_walkfly_props
        
        box = layout.box()
        col = box.column(align=True)
        
        col.prop(props, "speed_multiplier", text="Speed", slider=True)
        col.separator()
        col.operator("tsde.walkfly_recorder", text="🎮 START WALK/FLY", icon='PLAY')
        
        if len(WALKFLY_PIVOT_POINTS) > 0:
            col.separator()
            col.label(text=f"📊 Frames: {len(WALKFLY_PIVOT_POINTS)}")
            col.label(text="→ ESC = Spline generieren")
        
        col.separator()
        col.label(text="Steuerung:", icon='VIEW3D')
        col.label(text="• Linke Maus = Rotation")
        col.label(text="• Rechte Maus = Stopp")
        col.label(text="• Mausrad = Speed")
        col.label(text="• W/A/S/D = Bewegen")
        col.label(text="• Shift/Space = Auf/Ab")