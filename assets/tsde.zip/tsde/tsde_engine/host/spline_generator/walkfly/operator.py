"""Walk/Fly Mode Operator"""
import bpy
import math
from mathutils import Vector
from ...core.spline_utils import resample_spline_points
from ...core.lens_calculator import get_lens_position_exact
from ...utils.blender_utils import create_visible_spline

# Globale Variablen (müssen am Anfang stehen und exportiert werden)
WALKFLY_PIVOT_POINTS = []
WALKFLY_LENS_POINTS = []

class TSDE_OT_WalkflyRecorder(bpy.types.Operator):
    bl_idname = "tsde.walkfly_recorder"
    bl_label = "Walk/Fly Recorder"
    bl_description = "Startet Walk/Fly Modus mit Aufnahme"
    
    _timer = None
    frame_count = 0
    base_speed = 0.05
    min_speed = 0.01
    max_speed = 0.5
    current_speed = 0.05
    rotate_speed = 0.002
    speed_multiplier = 1.0
    
    keys = {
        'W': False, 'A': False, 'S': False, 'D': False,
        'UP_ARROW': False, 'DOWN_ARROW': False,
        'LEFT_ARROW': False, 'RIGHT_ARROW': False,
        'LEFT_SHIFT': False, 'RIGHT_SHIFT': False,
        'SPACE': False
    }
    
    mouse_active = False
    mouse_center_x = 0
    mouse_center_y = 0
    last_dx = 0
    last_dy = 0

    def modal(self, context, event):
        global WALKFLY_PIVOT_POINTS, WALKFLY_LENS_POINTS

        if event.type == 'ESC':
            return self.finish(context)

        if event.type in self.keys:
            if event.value == 'PRESS':
                self.keys[event.type] = True
            if event.value == 'RELEASE':
                self.keys[event.type] = False
        
        if event.type in ('LEFT_SHIFT', 'RIGHT_SHIFT'):
            self.keys['LEFT_SHIFT'] = (event.value == 'PRESS')
            self.keys['RIGHT_SHIFT'] = (event.value == 'PRESS')
        
        if event.type == 'SPACE':
            self.keys['SPACE'] = (event.value == 'PRESS')
        
        if event.type == 'WHEELUPMOUSE':
            self.current_speed = min(self.max_speed * self.speed_multiplier, self.current_speed * 1.2)
            print(f"⚡ Speed: {self.current_speed:.3f}")
        if event.type == 'WHEELDOWNMOUSE':
            self.current_speed = max(self.min_speed, self.current_speed * 0.8)
            print(f"⚡ Speed: {self.current_speed:.3f}")
        
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if context.area and context.area.type == 'VIEW_3D':
                self.mouse_active = True
                self.mouse_center_x = context.area.x + context.area.width // 2
                self.mouse_center_y = context.area.y + context.area.height // 2
                context.window.cursor_warp(self.mouse_center_x, self.mouse_center_y)
                print("🎮 Relative Maus AKTIV")
        
        if self.mouse_active and event.type == 'MOUSEMOVE':
            dx = event.mouse_x - self.mouse_center_x
            dy = event.mouse_y - self.mouse_center_y
            if abs(dx) > 0 or abs(dy) > 0:
                cam = context.scene.camera
                if cam:
                    rot = cam.rotation_euler.copy()
                    rot.z -= dx * self.rotate_speed
                    rot.x += dy * self.rotate_speed
                    rot.x = max(-math.pi/2 + 0.01, min(math.pi/2 - 0.01, rot.x))
                    cam.rotation_euler = rot
                    self.last_dx = dx
                    self.last_dy = dy
                context.window.cursor_warp(self.mouse_center_x, self.mouse_center_y)
        
        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            self.mouse_active = False
            print("🎮 Relative Maus DEAKTIVIERT")

        if event.type == 'TIMER':
            cam = context.scene.camera
            if not cam:
                return {'PASS_THROUGH'}
            
            self.speed_multiplier = context.scene.tsde_speed_multiplier
            speed = self.current_speed * self.speed_multiplier
            loc = cam.location.copy()
            moved = False
            
            forward = self.get_forward(cam)
            if self.keys['W']:
                loc += forward * speed
                moved = True
            if self.keys['S']:
                loc -= forward * speed
                moved = True
            
            right = self.get_right(cam)
            if self.keys['A']:
                loc -= right * speed
                moved = True
            if self.keys['D']:
                loc += right * speed
                moved = True
            
            if self.keys['LEFT_SHIFT'] or self.keys['RIGHT_SHIFT']:
                loc.z += speed
                moved = True
            if self.keys['SPACE']:
                loc.z -= speed
                moved = True
            
            rot = cam.rotation_euler.copy()
            rotated = False
            
            if self.keys['UP_ARROW']:
                rot.x -= self.rotate_speed * 4
                rotated = True
            if self.keys['DOWN_ARROW']:
                rot.x += self.rotate_speed * 4
                rotated = True
            if self.keys['LEFT_ARROW']:
                rot.z -= self.rotate_speed * 4
                rotated = True
            if self.keys['RIGHT_ARROW']:
                rot.z += self.rotate_speed * 4
                rotated = True
            
            if rotated:
                rot.x = max(-math.pi/2 + 0.01, min(math.pi/2 - 0.01, rot.x))
                cam.rotation_euler = rot
            
            if moved:
                cam.location = loc
            
            mouse_moved = self.mouse_active and (abs(self.last_dx) > 0 or abs(self.last_dy) > 0)
            if moved or rotated or mouse_moved:
                pivot_pos = cam.location.copy()
                WALKFLY_PIVOT_POINTS.append(pivot_pos)
                WALKFLY_LENS_POINTS.append(get_lens_position_exact(cam))
                self.frame_count += 1
                if self.frame_count % 10 == 0:
                    print(f"\n🎥 Frame {self.frame_count:4d}")
            
            if context.area:
                context.area.tag_redraw()

        return {'RUNNING_MODAL'}

    def get_forward(self, obj):
        return obj.matrix_world.to_quaternion() @ Vector((0, 0, -1))
    
    def get_right(self, obj):
        return obj.matrix_world.to_quaternion() @ Vector((1, 0, 0))

    def execute(self, context):
        global WALKFLY_PIVOT_POINTS, WALKFLY_LENS_POINTS
        WALKFLY_PIVOT_POINTS = []
        WALKFLY_LENS_POINTS = []
        self.frame_count = 0
        self.mouse_active = False
        self.current_speed = self.base_speed
        
        if not context.scene.camera:
            cam_data = bpy.data.cameras.new("TSDE_Camera")
            cam = bpy.data.objects.new("TSDE_Camera", cam_data)
            context.scene.collection.objects.link(cam)
            context.scene.camera = cam
        
        wm = context.window_manager
        self._timer = wm.event_timer_add(1/60, window=context.window)
        wm.modal_handler_add(self)
        
        print("\n" + "="*70)
        print("🎮 TSDE WALK/FLY MODE")
        print("="*70)
        print("STEUERUNG:")
        print("  Linke Maus  - Rotation")
        print("  Rechte Maus - Stopp")
        print("  Mausrad     - Geschwindigkeit")
        print("  W/A/S/D     - Bewegen")
        print("  SHIFT       - AUF ⬆️")
        print("  LEERTASTE   - RUNTER ⬇️")
        print("  ESC         - Beenden & Spline generieren")
        print("="*70 + "\n")
        
        return {'RUNNING_MODAL'}

    def finish(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)

        from ...core.spline_utils import resample_spline_points
        from ...utils.blender_utils import create_visible_spline
        from .smoothing import gaussian_smooth, smooth_spline_points
        
        global WALKFLY_PIVOT_POINTS, WALKFLY_LENS_POINTS
        pivot_raw = WALKFLY_PIVOT_POINTS
        lens_raw = WALKFLY_LENS_POINTS

        print(f"\n📊 RAW Recording: {len(pivot_raw)} Pivot, {len(lens_raw)} Lens")

        if len(pivot_raw) < 2:
            self.report({'WARNING'}, "Zu wenig Frames!")
            return {'CANCELLED'}

        # Glättung
        print("\n🔄 Glätte Splines...")
        pivot_smoothed = gaussian_smooth(pivot_raw, sigma=1.5)
        lens_smoothed = gaussian_smooth(lens_raw, sigma=1.5)
        pivot_smoothed = smooth_spline_points(pivot_smoothed, factor=0.2, iterations=2)
        lens_smoothed = smooth_spline_points(lens_smoothed, factor=0.2, iterations=2)

        # Resampling
        print("🔄 Resample auf konstante Segmentlänge...")
        target_segment_length = 0.05
        pivot_resampled = resample_spline_points(pivot_smoothed, target_segment_length)
        lens_resampled = resample_spline_points(lens_smoothed, target_segment_length)

        # Alte Splines löschen
        for obj in context.scene.objects:
            if obj.name.startswith("WalkFly_"):
                bpy.data.objects.remove(obj, do_unlink=True)

        # Neue Splines
        print("\n📌 Erstelle Splines...")
        pivot_obj = create_visible_spline(
            "WalkFly_Pivot", 
            pivot_resampled, 
            (1.0, 0.5, 0.0, 1.0),
            context
        )
        lens_obj = create_visible_spline(
            "WalkFly_Lens", 
            lens_resampled, 
            (0.0, 0.8, 1.0, 1.0),
            context
        )

        print(f"\n✅ Fertig: {len(pivot_resampled)} Punkte")
        
        self.report({'INFO'}, f"Walk/Fly: {len(pivot_resampled)} Punkte")
        return {'FINISHED'}