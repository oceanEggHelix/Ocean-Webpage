"""Glättungsfunktionen für Walk/Fly"""
import math
from mathutils import Vector

def smooth_spline_points(points, factor=0.3, iterations=3):
    """Glättet einen Spline mit Moving Average"""
    if len(points) < 3:
        return points
    smoothed = [p.copy() for p in points]
    for _ in range(iterations):
        new_points = [smoothed[0].copy()]
        for i in range(1, len(smoothed) - 1):
            p_prev = smoothed[i-1]
            p_curr = smoothed[i]
            p_next = smoothed[i+1]
            smooth_point = (p_prev * factor + p_curr * (1 - 2*factor) + p_next * factor)
            new_points.append(smooth_point)
        new_points.append(smoothed[-1].copy())
        smoothed = new_points
    return smoothed

def gaussian_smooth(points, sigma=1.0):
    """Gaußsche Glättung"""
    if len(points) < 3:
        return points
    kernel_size = int(3 * sigma)
    kernel = []
    kernel_sum = 0
    for i in range(-kernel_size, kernel_size + 1):
        weight = math.exp(-(i*i) / (2*sigma*sigma))
        kernel.append(weight)
        kernel_sum += weight
    kernel = [w / kernel_sum for w in kernel]
    
    smoothed = []
    half_k = kernel_size
    for i in range(len(points)):
        weighted_sum = Vector((0, 0, 0))
        total_weight = 0
        for j in range(-half_k, half_k + 1):
            idx = i + j
            if 0 <= idx < len(points):
                weight = kernel[j + half_k]
                weighted_sum += points[idx] * weight
                total_weight += weight
        if total_weight > 0:
            smoothed.append(weighted_sum / total_weight)
        else:
            smoothed.append(points[i].copy())
    return smoothed