"""Panel für Keyframe Retter"""
import bpy
from bpy.types import Panel

class TSDE_PT_KeyframeRetter(Panel):
    bl_label = "   Keyframe Retter"
    bl_idname = "TSDE_PT_keyframe_retter"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_spline_generator"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_keyframe_retter_props
        
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="⚙️ EINSTELLUNGEN:", icon='SETTINGS')
        col.prop(props, "target_segment_length")
        col.prop(props, "use_active_camera")
        
        col.separator()
        
        # Info über aktive Kamera
        if context.scene.camera:
            col.label(text=f"📷 Kamera: {context.scene.camera.name}", icon='CAMERA_DATA')
        else:
            col.label(text="⚠️ Keine aktive Kamera", icon='ERROR')
        
        col.separator()
        
        # Info-Box
        box = layout.box()
        col = box.column(align=True)
        col.label(text="ℹ️ AUS ANIMATION:", icon='INFO')
        col.label(text="• Analysiert Keyframes der Kamera")
        col.label(text="• Erzeugt Pivot (orange) & Lens (blau)")
        col.label(text="• Resampling auf konstante Länge")
        col.label(text="• Wie im TSDE-Prototyp")
        
        col.separator()
        
        # Hauptbutton
        row = col.row(align=True)
        row.scale_y = 2.0
        row.operator("tsde.generate_keyframe_splines", text="🎯 SPLINES GENERIEREN", icon='CURVE_DATA')