"""Keyframe Retter - Generiert Splines aus Kamerakeyframes (wie Prototyp)"""
import bpy
import math
import mathutils
from mathutils import Vector
from bpy.props import FloatProperty, BoolProperty
from ...core.spline_utils import resample_spline_points
from ...core.lens_calculator import get_lens_position_exact
from ...utils.blender_utils import create_visible_spline


class TSDE_OT_GenerateKeyframeSplines(bpy.types.Operator):
    bl_idname = "tsde.generate_keyframe_splines"
    bl_label = "Generiere Keyframe Splines"
    bl_description = "Erzeugt Pivot und Lens Splines aus Kamerakeyframes (wie Prototyp)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        props = context.scene.tsde_keyframe_retter_props
        
        TARGET_SEGMENT_LENGTH = props.target_segment_length

        # Kamera finden
        if props.use_active_camera:
            cam = scene.camera
        else:
            for obj in scene.objects:
                if obj.type == 'CAMERA':
                    cam = obj
                    break
            else:
                cam = None

        if not cam:
            self.report({'ERROR'}, "Keine Kamera gefunden!")
            return {'CANCELLED'}

        pivot = bpy.data.objects.get("CameraPivot")

        # Keyframe-Bereich ermitteln
        if cam.animation_data and cam.animation_data.action:
            keyframes = set()
            for fcurve in cam.animation_data.action.fcurves:
                for keyframe in fcurve.keyframe_points:
                    keyframes.add(int(keyframe.co[0]))
            
            if keyframes:
                start = min(keyframes)
                end = max(keyframes)
            else:
                start = scene.frame_start
                end = scene.frame_end
        else:
            start = scene.frame_start
            end = scene.frame_end

        self.report({'INFO'}, f"Verarbeite Frames {start} bis {end}")

        # Originalen Frame merken
        current_frame = scene.frame_current

        # Arrays für die Punkte
        original_lens_points = []
        original_pivot_points = []

        # ALLE Frames durchgehen (wie im Prototyp)
        for f in range(start, end + 1):
            scene.frame_set(f)

            # LENS-PUNKT berechnen (exakt wie Prototyp)
            forward = cam.matrix_world.to_quaternion() @ mathutils.Vector((0, 0, -1))
            lens_mm = cam.data.lens
            sensor_mm = (
                cam.data.sensor_height
                if cam.data.sensor_fit == 'VERTICAL'
                else cam.data.sensor_width
            )
            lens_offset = lens_mm / sensor_mm
            lens_center = cam.matrix_world.translation + forward * lens_offset
            original_lens_points.append(lens_center)

            # PIVOT-PUNKT (wie Prototyp)
            if pivot:
                original_pivot_points.append(pivot.matrix_world.translation.copy())
            else:
                original_pivot_points.append(cam.matrix_world.translation.copy())

        # Zum ursprünglichen Frame zurückkehren
        scene.frame_set(current_frame)

        # RESAMPLE (wie Prototyp)
        resampled_lens_points = resample_spline_points(
            original_lens_points, TARGET_SEGMENT_LENGTH
        )
        resampled_pivot_points = resample_spline_points(
            original_pivot_points, TARGET_SEGMENT_LENGTH
        )

        # Alte Keyframe-Splines löschen
        for obj in list(bpy.data.objects):
            if obj.name.startswith("Keyframe_") and "Spline" in obj.name:
                bpy.data.objects.remove(obj, do_unlink=True)

        # Splines erzeugen
        lens_curve = bpy.data.curves.new("Keyframe_LensSpline", type="CURVE")
        lens_curve.dimensions = '3D'
        lens_spline = lens_curve.splines.new(type='POLY')
        lens_spline.points.add(len(resampled_lens_points) - 1)
        for i, p in enumerate(resampled_lens_points):
            lens_spline.points[i].co = (p.x, p.y, p.z, 1)

        pivot_curve = bpy.data.curves.new("Keyframe_PivotSpline", type="CURVE")
        pivot_curve.dimensions = '3D'
        pivot_spline = pivot_curve.splines.new(type='POLY')
        pivot_spline.points.add(len(resampled_pivot_points) - 1)
        for i, p in enumerate(resampled_pivot_points):
            pivot_spline.points[i].co = (p.x, p.y, p.z, 1)

        lens_obj = bpy.data.objects.new("Keyframe_LensSpline", lens_curve)
        pivot_obj = bpy.data.objects.new("Keyframe_PivotSpline", pivot_curve)
        
        if hasattr(lens_obj, "color"):
            lens_obj.color = (0.0, 0.8, 1.0, 1.0)  # Hellblau
        if hasattr(pivot_obj, "color"):
            pivot_obj.color = (1.0, 0.5, 0.0, 1.0)  # Orange
        
        context.collection.objects.link(lens_obj)
        context.collection.objects.link(pivot_obj)

        self.report({'INFO'}, 
            f"✅ Splines generiert: {len(resampled_pivot_points)} Pivot, {len(resampled_lens_points)} Lens"
        )
        
        print("\n" + "="*60)
        print("🎯 KEYFRAME RETTER")
        print("="*60)
        print(f"📊 Pivot Punkte: {len(resampled_pivot_points)}")
        print(f"📊 Lens Punkte:  {len(resampled_lens_points)}")
        print(f"📐 Segmentlänge: {TARGET_SEGMENT_LENGTH}")
        print("="*60 + "\n")

        return {'FINISHED'}