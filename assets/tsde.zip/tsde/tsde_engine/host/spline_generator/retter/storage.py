"""Storage für Keyframe Retter"""
# (leer oder mit globalen Variablen falls nötig)