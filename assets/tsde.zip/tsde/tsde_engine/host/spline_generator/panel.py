"""Hauptpanel für TSDE Spline Generator Überkategorie"""
import bpy
from bpy.types import Panel

class TSDE_PT_SplineGenerator(Panel):
    bl_label = "1. TSDE Spline Generator"
    bl_idname = "TSDE_PT_spline_generator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="📐 Spline Erzeugung", icon='CURVE_DATA')
        layout.separator()
        #layout.label(text="3 Methoden verfügbar:")
        #layout.label(text="• Walk/Fly Mode - Freie Fahrt")
        #layout.label(text="• Spline Setter - Manuelle Keyframes")
        #layout.label(text="• Keyframe Retter - Aus Animation")