"""TSDE Spline Setter - Manuelle Keyframes mit Interpolation"""
from .panel import TSDE_PT_SplineSetter
from .operator import (
    TSDE_OT_GoToCamera,
    TSDE_OT_SetKeyframe,
    TSDE_OT_DeleteLastKeyframe,
    TSDE_OT_ClearKeyframes,
    TSDE_OT_GenerateSmoothSpline,
    SPLINE_SETTER_PIVOT_POINTS,
    SPLINE_SETTER_LENS_POINTS,
    SPLINE_SETTER_NAMES
)

__all__ = [
    "TSDE_PT_SplineSetter",
    "TSDE_OT_GoToCamera",
    "TSDE_OT_SetKeyframe",
    "TSDE_OT_DeleteLastKeyframe",
    "TSDE_OT_ClearKeyframes",
    "TSDE_OT_GenerateSmoothSpline",
    "SPLINE_SETTER_PIVOT_POINTS",
    "SPLINE_SETTER_LENS_POINTS",
    "SPLINE_SETTER_NAMES"
]