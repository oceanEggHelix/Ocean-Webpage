"""Panel für TSDE Spline Setter"""
import bpy
from bpy.types import Panel
from .operator import SPLINE_SETTER_NAMES, SPLINE_SETTER_PIVOT_POINTS

class TSDE_PT_SplineSetter(Panel):
    bl_label = "   TSDE Spline Setter"
    bl_idname = "TSDE_PT_spline_setter"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_spline_generator"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_spline_setter_props
        
        # Kamera-Info
        if context.scene.camera:
            cam = context.scene.camera
            box = layout.box()
            col = box.column(align=True)
            col.label(text=f"Kamera: {cam.name}", icon='CAMERA_DATA')
            
            # Prüfen ob in Kamera-Ansicht
            in_camera = False
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    if area.spaces[0].region_3d.view_perspective == 'CAMERA':
                        in_camera = True
                        break
            
            if in_camera:
                col.label(text="📷 Kamera-Ansicht", icon='VIEWZOOM')
            else:
                col.label(text="⚠️ Nicht in Kamera-Ansicht", icon='ERROR')
                col.operator("tsde.goto_camera", text="📷 Zur Kamera")
        
        # Keyframe-Steuerung
        box = layout.box()
        col = box.column(align=True)
        col.label(text="📸 SNAPSHOTS:", icon='KEYINGSET')
        
        # Snapshot setzen
        row = col.row(align=True)
        row.prop(props, "keyframe_name", text="")
        row.operator("tsde.set_keyframe", text="Setzen", icon='ADD')
        
        # Snapshots verwalten
        row = col.row(align=True)
        row.operator("tsde.delete_last_keyframe", text="Letzten", icon='REMOVE')
        row.operator("tsde.clear_keyframes", text="Alle", icon='X')
        
        # Liste der Snapshots
        if len(SPLINE_SETTER_NAMES) > 0:
            col.separator()
            for i, name in enumerate(SPLINE_SETTER_NAMES):
                col.label(text=f"{i+1}. {name}")
        
        # Spline-Generierung
        if len(SPLINE_SETTER_PIVOT_POINTS) >= 2:
            col.separator()
            box = layout.box()
            col = box.column(align=True)
            col.label(text="✨ CATMULL-ROM SPLINE:", icon='CURVE_DATA')
            col.prop(props, "steps_between")
            col.separator()
            col.operator("tsde.generate_smooth_spline", text="🎯 SPLINE GENERIEREN", icon='PLAY')