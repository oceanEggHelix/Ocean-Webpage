"""TSDE Spline Setter - Manuelle Keyframes mit Catmull-Rom Interpolation"""
import bpy
import math
from mathutils import Vector
from bpy.props import StringProperty, IntProperty
from ...core.lens_calculator import get_lens_position_exact
from ...utils.blender_utils import create_visible_spline

# Globale Speicher für Spline Setter
SPLINE_SETTER_PIVOT_POINTS = []
SPLINE_SETTER_LENS_POINTS = []
SPLINE_SETTER_NAMES = []

# =====================================================================
# HELPER: UI UPDATE
# =====================================================================
def force_ui_update(context):
    """Erzwingt ein komplettes UI-Update"""
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()
    
    # Zusätzlich: Scene aktualisieren
    context.scene.update_tag()

# =====================================================================
# CATMULL-ROM INTERPOLATION
# =====================================================================

def catmull_rom_spline(p0, p1, p2, p3, t):
    """Catmull-Rom Spline Interpolation"""
    t2 = t * t
    t3 = t2 * t
    v0 = (p2 - p0) * 0.5
    v1 = (p3 - p1) * 0.5
    return (2*t3 - 3*t2 + 1) * p1 + (t3 - 2*t2 + t) * v0 + (-2*t3 + 3*t2) * p2 + (t3 - t2) * v1

def interpolate_catmull_rom(points, steps=20):
    """Interpoliert Punkte mit Catmull-Rom"""
    if len(points) < 2:
        return points
    
    result = []
    
    for i in range(len(points) - 1):
        p1 = points[i]
        p2 = points[i + 1]
        p0 = points[i - 1] if i > 0 else p1
        p3 = points[i + 2] if i + 2 < len(points) else p2
        
        for j in range(steps):
            t = j / steps
            result.append(catmull_rom_spline(p0, p1, p2, p3, t))
    
    result.append(points[-1].copy())
    return result

# =====================================================================
# OPERATOREN
# =====================================================================

class TSDE_OT_GoToCamera(bpy.types.Operator):
    bl_idname = "tsde.goto_camera"
    bl_label = "Zur Kamera"
    bl_description = "Wechselt in die Kamera-Ansicht (Numpad 0)"
    
    def execute(self, context):
        if not context.scene.camera:
            self.report({'ERROR'}, "Keine Kamera in der Szene!")
            return {'CANCELLED'}
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].region_3d.view_perspective = 'CAMERA'
        return {'FINISHED'}


class TSDE_OT_SetKeyframe(bpy.types.Operator):
    bl_idname = "tsde.set_keyframe"
    bl_label = "Snapshot setzen"
    bl_description = "Speichert aktuelle Kameraposition als Keyframe"
    
    name: StringProperty(default="Key")
    
    def execute(self, context):
        global SPLINE_SETTER_PIVOT_POINTS, SPLINE_SETTER_LENS_POINTS, SPLINE_SETTER_NAMES
        
        cam = context.scene.camera
        if not cam:
            self.report({'ERROR'}, "Keine Kamera in der Szene!")
            return {'CANCELLED'}
        
        # Prüfen ob in Kamera-Ansicht
        in_camera_view = False
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                if area.spaces[0].region_3d.view_perspective == 'CAMERA':
                    in_camera_view = True
                    break
        
        if not in_camera_view:
            self.report({'WARNING'}, "Nicht in Kamera-Ansicht! (Numpad 0)")
            return {'CANCELLED'}
        
        pivot_pos = cam.location.copy()
        lens_pos = get_lens_position_exact(cam)
        
        SPLINE_SETTER_PIVOT_POINTS.append(pivot_pos)
        SPLINE_SETTER_LENS_POINTS.append(lens_pos)
        
        # Namen generieren
        name = context.scene.tsde_spline_setter_props.keyframe_name
        if name == "Key":
            key_name = f"Key {len(SPLINE_SETTER_PIVOT_POINTS)}"
        else:
            key_name = f"{name} {len(SPLINE_SETTER_PIVOT_POINTS)}"
        
        SPLINE_SETTER_NAMES.append(key_name)
        
        print(f"\n📸 Snapshot {len(SPLINE_SETTER_PIVOT_POINTS)}: {key_name}")
        self.report({'INFO'}, f"Snapshot {len(SPLINE_SETTER_PIVOT_POINTS)} gespeichert")
        
        # UI sofort aktualisieren
        force_ui_update(context)
        
        return {'FINISHED'}


class TSDE_OT_DeleteLastKeyframe(bpy.types.Operator):
    bl_idname = "tsde.delete_last_keyframe"
    bl_label = "Letzten löschen"
    bl_description = "Löscht den letzten Snapshot"
    
    def execute(self, context):
        global SPLINE_SETTER_PIVOT_POINTS, SPLINE_SETTER_LENS_POINTS, SPLINE_SETTER_NAMES
        
        if len(SPLINE_SETTER_PIVOT_POINTS) > 0:
            SPLINE_SETTER_PIVOT_POINTS.pop()
            SPLINE_SETTER_LENS_POINTS.pop()
            SPLINE_SETTER_NAMES.pop()
            self.report({'INFO'}, f"Letzter Snapshot gelöscht. {len(SPLINE_SETTER_PIVOT_POINTS)} verbleibend")
        else:
            self.report({'WARNING'}, "Keine Snapshots vorhanden")
        
        # UI sofort aktualisieren
        force_ui_update(context)
        
        return {'FINISHED'}


class TSDE_OT_ClearKeyframes(bpy.types.Operator):
    bl_idname = "tsde.clear_keyframes"
    bl_label = "Alle löschen"
    bl_description = "Löscht alle Snapshots"
    
    def execute(self, context):
        global SPLINE_SETTER_PIVOT_POINTS, SPLINE_SETTER_LENS_POINTS, SPLINE_SETTER_NAMES
        
        # WICHTIG: Neue leere Listen zuweisen, nicht nur leeren!
        SPLINE_SETTER_PIVOT_POINTS = []
        SPLINE_SETTER_LENS_POINTS = []
        SPLINE_SETTER_NAMES = []
        
        self.report({'INFO'}, "Alle Snapshots gelöscht")
        
        # UI sofort aktualisieren
        force_ui_update(context)
        
        return {'FINISHED'}


class TSDE_OT_GenerateSmoothSpline(bpy.types.Operator):
    bl_idname = "tsde.generate_smooth_spline"
    bl_label = "Spline generieren"
    bl_description = "Erzeugt Catmull-Rom Spline aus den Snapshots"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        global SPLINE_SETTER_PIVOT_POINTS, SPLINE_SETTER_LENS_POINTS
        
        props = context.scene.tsde_spline_setter_props
        
        if len(SPLINE_SETTER_PIVOT_POINTS) < 2:
            self.report({'ERROR'}, "Mindestens 2 Snapshots benötigt!")
            return {'CANCELLED'}
        
        print(f"\n🎯 Generiere Catmull-Rom Spline aus {len(SPLINE_SETTER_PIVOT_POINTS)} Keyframes...")
        
        # Catmull-Rom Interpolation
        all_pivot = interpolate_catmull_rom(
            SPLINE_SETTER_PIVOT_POINTS, 
            props.steps_between
        )
        
        all_lens = interpolate_catmull_rom(
            SPLINE_SETTER_LENS_POINTS, 
            props.steps_between
        )
        
        # Alte Splines löschen
        for obj in context.scene.objects:
            if obj.name.startswith("SplineSetter_"):
                bpy.data.objects.remove(obj, do_unlink=True)
        
        # Pivot-Spline (Orange)
        pivot_obj = create_visible_spline(
            "SplineSetter_Pivot", 
            all_pivot, 
            (1.0, 0.5, 0.0, 1.0), 
            context
        )
        
        # Lens-Spline (Blau)
        lens_obj = create_visible_spline(
            "SplineSetter_Lens", 
            all_lens, 
            (0.0, 0.8, 1.0, 1.0), 
            context
        )
        
        print(f"\n✅ Fertig: {len(all_pivot)} Punkte")
        self.report({'INFO'}, f"Spline mit {len(all_pivot)} Punkten generiert")
        
        # UI aktualisieren
        force_ui_update(context)
        
        return {'FINISHED'}