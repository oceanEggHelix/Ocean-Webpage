"""TSDE Spline Generator - Überkategorie für alle Spline-Erzeugungs-Tools"""
from .panel import TSDE_PT_SplineGenerator

__all__ = ["TSDE_PT_SplineGenerator"]