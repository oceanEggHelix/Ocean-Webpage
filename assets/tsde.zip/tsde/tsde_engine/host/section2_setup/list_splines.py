"""Operator zum Anzeigen aller Splines"""
import bpy
from bpy.types import Operator

class TSDE_OT_ListSplines(Operator):
    bl_idname = "tsde.list_splines"
    bl_label = "Splines anzeigen"
    bl_description = "Zeigt alle verfügbaren Splines an"
    
    def execute(self, context):
        print("\n📋 Verfügbare Splines:")
        splines = []
        for obj in bpy.data.objects:
            if obj.type == 'CURVE':
                splines.append(obj.name)
                print(f"   - {obj.name}")
        
        if not splines:
            print("   Keine Splines gefunden")
            self.report({'INFO'}, "Keine Splines in der Szene")
        else:
            self.report({'INFO'}, f"{len(splines)} Splines gefunden")
        
        return {'FINISHED'}