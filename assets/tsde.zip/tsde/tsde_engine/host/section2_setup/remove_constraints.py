# section2_setup/remove_constraints.py
import bpy

class TSDE_OT_RemoveConstraints(Operator):
    """Entfernt alle Follow-Path Constraints von Empties"""
    bl_idname = "tsde.remove_constraints"
    bl_label = "Follow-Path Constraints entfernen"
    bl_description = "Entfernt alle Follow-Path Constraints (für neuen Live-Modus)"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        removed = 0
        for obj in bpy.data.objects:
            for constraint in list(obj.constraints):
                if constraint.type == 'FOLLOW_PATH':
                    obj.constraints.remove(constraint)
                    removed += 1
                    print(f"✅ Entfernt: {obj.name} -> {constraint.name}")
        
        self.report({'INFO'}, f"{removed} Follow-Path Constraints entfernt")
        return {'FINISHED'}

def register():
    bpy.utils.register_class(TSDE_OT_RemoveConstraints)

def unregister():
    bpy.utils.unregister_class(TSDE_OT_RemoveConstraints)