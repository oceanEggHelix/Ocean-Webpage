"""Rig Builder - TSDE mit wählbarem Roll-System (Einfach Y-Roll oder Komplex X/Y/Z)"""
import bpy
import math
from bpy.types import Operator
from ..utils.blender_utils import get_spline_points

class TSDE_OT_BuildRig(Operator):
    bl_idname = "tsde.build_rig"
    bl_label = "TSDE Rig bauen"
    bl_description = "Baut TSDE Rig mit Pivot, Lens und wählbarem Roll-System"
    bl_options = {'UNDO'}

    group_name: bpy.props.StringProperty(name="Group Name", default="TSDE_Rig")
    empty_size: bpy.props.FloatProperty(name="Empty Size", default=0.1)
    pivot_spline: bpy.props.StringProperty(name="Pivot Spline", default="")
    pivot_max_speed: bpy.props.FloatProperty(name="Pivot Max Speed", default=100.0)
    lens_spline: bpy.props.StringProperty(name="Lens Spline", default="")
    lens_max_speed: bpy.props.FloatProperty(name="Lens Max Speed", default=100.0)
    create_camera: bpy.props.BoolProperty(name="Kamera erstellen", default=True)
    camera_focal_length: bpy.props.FloatProperty(name="Kamera Brennweite", default=50.0)
    
    # 🔥 NEU: Roll-System Auswahl
    roll_system: bpy.props.EnumProperty(
        name="Roll System",
        items=[
            ('SIMPLE', "Einfach (Y-Roll)", "LookAt → Roll → Kamera - Nur Y-Roll als Effekt"),
            ('COMPLEX', "Komplex (X/Y/Z)", "Drei separate Roll-Gimbals für volle Kontrolle"),
        ],
        default='SIMPLE'
    )
    
    # Für komplexes System: Gimbal Position
    gimbal_position: bpy.props.FloatProperty(
        name="Gimbal Position", 
        default=0.5, 
        min=0.0, 
        max=1.0,
        description="Position des Gimbals zwischen Pivot (0) und Lens (1) - nur für komplexes System"
    )

    def execute(self, context):
        pivot_obj = bpy.data.objects.get(self.pivot_spline)
        lens_obj = bpy.data.objects.get(self.lens_spline)
        
        if not pivot_obj or not lens_obj:
            self.report({'ERROR'}, "Splines nicht gefunden!")
            return {'CANCELLED'}

        # Punkte für Startposition
        pivot_points = get_spline_points(pivot_obj)
        lens_points = get_spline_points(lens_obj)
        
        if len(pivot_points) < 2 or len(lens_points) < 2:
            self.report({'ERROR'}, "Splines haben zu wenig Punkte!")
            return {'CANCELLED'}

        # -----------------------------------------------------------------
        # 1. Collection Setup
        # -----------------------------------------------------------------
        if self.group_name in bpy.data.collections:
            group = bpy.data.collections[self.group_name]
            for obj in list(group.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
        else:
            group = bpy.data.collections.new(self.group_name)
            context.scene.collection.children.link(group)

        # -----------------------------------------------------------------
        # 2. Pivot Empty (Position)
        # -----------------------------------------------------------------
        pivot_empty = bpy.data.objects.new(f"{self.group_name}_Pivot", None)
        pivot_empty.empty_display_size = self.empty_size
        pivot_empty.empty_display_type = 'CUBE'
        pivot_empty.location = pivot_points[0]
        if hasattr(pivot_empty, "color"):
            pivot_empty.color = (1.0, 0.5, 0.0, 1.0)  # Orange
        group.objects.link(pivot_empty)
        
        # Pivot Follow Path
        p_follow = pivot_empty.constraints.new(type='FOLLOW_PATH')
        p_follow.target = pivot_obj
        p_follow.use_fixed_location = True
        p_follow.offset_factor = 0.0

        # -----------------------------------------------------------------
        # 3. Lens Empty (Blickpunkt)
        # -----------------------------------------------------------------
        lens_empty = bpy.data.objects.new(f"{self.group_name}_Lens", None)
        lens_empty.empty_display_size = self.empty_size * 0.7
        lens_empty.empty_display_type = 'SPHERE'
        lens_empty.location = lens_points[0]
        if hasattr(lens_empty, "color"):
            lens_empty.color = (0.0, 0.8, 1.0, 1.0)  # Hellblau
        group.objects.link(lens_empty)
        
        # Lens Follow Path
        l_follow = lens_empty.constraints.new(type='FOLLOW_PATH')
        l_follow.target = lens_obj
        l_follow.use_fixed_location = True
        l_follow.offset_factor = 0.0

        # -----------------------------------------------------------------
        # 4. ROLL SYSTEM - je nach Auswahl
        # -----------------------------------------------------------------
        if self.roll_system == 'SIMPLE':
            # ===== EINFACHES SYSTEM (Nur Y-Roll) =====
            
            # LookAt Empty (TRACK_TO auf Lens)
            lookat = bpy.data.objects.new(f"{self.group_name}_LookAt", None)
            lookat.empty_display_size = self.empty_size * 0.5
            lookat.empty_display_type = 'ARROWS'
            lookat.parent = pivot_empty
            lookat.location = (0, 0, 0)
            if hasattr(lookat, "color"):
                lookat.color = (0.5, 1.0, 0.5, 1.0)  # Hellgrün
            group.objects.link(lookat)
            
            # TRACK_TO Constraint
            track = lookat.constraints.new(type='TRACK_TO')
            track.target = lens_empty
            track.track_axis = 'TRACK_NEGATIVE_Z'
            track.up_axis = 'UP_Y'
            track.use_target_z = False  # Y bleibt frei
            
            # Roll Empty (nur Y-Roll)
            roll = bpy.data.objects.new(f"{self.group_name}_Roll", None)
            roll.empty_display_size = self.empty_size * 0.4
            roll.empty_display_type = 'CIRCLE'
            roll.parent = lookat
            roll.location = (0, 0, 0)
            if hasattr(roll, "color"):
                roll.color = (1.0, 0.0, 0.0, 1.0)  # Rot
            group.objects.link(roll)
            
            print(f"   ✅ Einfaches Roll-System: LookAt → Roll (Y-Roll)")
            
            # Kamera Parent = Roll
            camera_parent = roll
            
        else:
            # ===== KOMPLEXES SYSTEM (X/Y/Z Gimbals) =====
            
            # Gimbal Pos (Position auf Achse)
            gimbal_pos = bpy.data.objects.new(f"{self.group_name}_Gimbal_Pos", None)
            gimbal_pos.empty_display_size = self.empty_size * 0.5
            gimbal_pos.empty_display_type = 'CIRCLE'
            gimbal_pos.parent = pivot_empty
            gimbal_pos.location = (0, 0, 0)
            if hasattr(gimbal_pos, "color"):
                gimbal_pos.color = (1.0, 0.0, 0.0, 1.0)  # Rot
            group.objects.link(gimbal_pos)

            # LOCKED TRACK: Gimbal_Pos zeigt mit Y-Achse auf Lens
            gim_track = gimbal_pos.constraints.new(type='LOCKED_TRACK')
            gim_track.target = lens_empty
            gim_track.track_axis = 'TRACK_Y'   # Y zeigt auf Lens
            gim_track.lock_axis = 'LOCK_Z'      # Z bleibt fix

            # DRIVER für Position auf der Achse
            # X-Position
            fcurve_x = gimbal_pos.driver_add("location", 0)
            driver_x = fcurve_x.driver
            driver_x.type = 'SCRIPTED'
            var_px = driver_x.variables.new()
            var_px.name = "px"
            var_px.type = 'SINGLE_PROP'
            var_px.targets[0].id = pivot_empty
            var_px.targets[0].data_path = 'location[0]'
            var_lx = driver_x.variables.new()
            var_lx.name = "lx"
            var_lx.type = 'SINGLE_PROP'
            var_lx.targets[0].id = lens_empty
            var_lx.targets[0].data_path = 'location[0]'
            driver_x.expression = f"px + (lx - px) * {self.gimbal_position}"

            # Y-Position
            fcurve_y = gimbal_pos.driver_add("location", 1)
            driver_y = fcurve_y.driver
            driver_y.type = 'SCRIPTED'
            var_py = driver_y.variables.new()
            var_py.name = "py"
            var_py.type = 'SINGLE_PROP'
            var_py.targets[0].id = pivot_empty
            var_py.targets[0].data_path = 'location[1]'
            var_ly = driver_y.variables.new()
            var_ly.name = "ly"
            var_ly.type = 'SINGLE_PROP'
            var_ly.targets[0].id = lens_empty
            var_ly.targets[0].data_path = 'location[1]'
            driver_y.expression = f"py + (ly - py) * {self.gimbal_position}"

            # Z-Position
            fcurve_z = gimbal_pos.driver_add("location", 2)
            driver_z = fcurve_z.driver
            driver_z.type = 'SCRIPTED'
            var_pz = driver_z.variables.new()
            var_pz.name = "pz"
            var_pz.type = 'SINGLE_PROP'
            var_pz.targets[0].id = pivot_empty
            var_pz.targets[0].data_path = 'location[2]'
            var_lz = driver_z.variables.new()
            var_lz.name = "lz"
            var_lz.type = 'SINGLE_PROP'
            var_lz.targets[0].id = lens_empty
            var_lz.targets[0].data_path = 'location[2]'
            driver_z.expression = f"pz + (lz - pz) * {self.gimbal_position}"

            print(f"   ✅ Gimbal_Pos: Position auf Achse, Y zeigt auf Lens")

            # Gimbal Roll (für alle Rotationen)
            gimbal_roll = bpy.data.objects.new(f"{self.group_name}_Gimbal_Roll", None)
            gimbal_roll.empty_display_size = self.empty_size * 0.3
            gimbal_roll.empty_display_type = 'CIRCLE'
            gimbal_roll.parent = gimbal_pos
            gimbal_roll.location = (0, 0, 0)
            gimbal_roll.rotation_euler = (0, 0, 0)
            if hasattr(gimbal_roll, "color"):
                gimbal_roll.color = (1.0, 0.0, 1.0, 1.0)  # Pink
            group.objects.link(gimbal_roll)

            print(f"   ✅ Gimbal_Roll: Für X/Y/Z Rotationen")
            
            # Kamera Parent = Gimbal_Roll
            camera_parent = gimbal_roll

        # -----------------------------------------------------------------
        # 5. KAMERA (für beide Systeme gleich)
        # -----------------------------------------------------------------
        if self.create_camera:
            cam_data = bpy.data.cameras.new(name=f"{self.group_name}_Camera")
            camera = bpy.data.objects.new(f"{self.group_name}_Camera", cam_data)
            camera.data.lens = self.camera_focal_length
            
            # Kamera als Child vom gewählten Parent
            camera.parent = camera_parent
            camera.location = (0, 0, 0)
            
            # Kamera schaut in -Z (Standard)
            camera.rotation_euler[0] = math.radians(0)
            camera.rotation_euler[1] = math.radians(0)
            camera.rotation_euler[2] = math.radians(0)
            
            if hasattr(camera, "color"):
                camera.color = (0.0, 1.0, 0.0, 1.0)  # Grün
            
            print(f"   ✅ Kamera erstellt")
            
            group.objects.link(camera)

        # -----------------------------------------------------------------
        # 6. TEST-PFEIL (zeigt Blickrichtung)
        # -----------------------------------------------------------------
        arrow = bpy.data.objects.new(f"{self.group_name}_Direction", None)
        arrow.empty_display_size = self.empty_size * 2
        arrow.empty_display_type = 'SINGLE_ARROW'
        arrow.parent = camera
        arrow.location = (0, 0, -self.empty_size)  # Vor die Kamera
        arrow.rotation_euler = (0, 0, 0)
        group.objects.link(arrow)

        # -----------------------------------------------------------------
        # 7. SPEED-WERTE speichern
        # -----------------------------------------------------------------
        if not hasattr(context.scene, 'tsde_track_speeds'):
            context.scene['tsde_track_speeds'] = {}
        
        context.scene['tsde_track_speeds'][f"{self.group_name}_Pivot"] = self.pivot_max_speed
        context.scene['tsde_track_speeds'][f"{self.group_name}_Lens"] = self.lens_max_speed
        
        # Empties auf Spline clampen
        p_follow.offset_factor = 0.001
        p_follow.offset_factor = 0.0
        l_follow.offset_factor = 0.001
        l_follow.offset_factor = 0.0
        
        # Einmal updaten
        context.view_layer.update()
        
        system_name = "Einfach (Y-Roll)" if self.roll_system == 'SIMPLE' else "Komplex (X/Y/Z)"
        self.report({'INFO'}, f"✅ Rig '{self.group_name}' erstellt ({system_name})")
        
        return {'FINISHED'}