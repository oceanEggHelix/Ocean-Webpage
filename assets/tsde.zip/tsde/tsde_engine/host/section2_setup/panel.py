"""N-Panel UI für Section 2: Setup Builder - JETZT MIT NEUEM ROLL-SYSTEM!"""
import bpy
from bpy.types import Panel

class TSDE_PT_Section2(Panel):
    bl_label = "2. Setup Builder"
    bl_idname = "TSDE_PT_section2"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_setup_props
        
        # Hauptbox
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="🔧 RIG BAUEN", icon='TOOL_SETTINGS')
        col.separator()
        
        # Group Name
        col.prop(props, "group_name")
        
        col.separator()
        
        # =================================================================
        # PIVOT TRACK (Kamera)
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="🎥 PIVOT TRACK", icon='CAMERA_DATA')
        col.separator(factor=0.5)
        
        # Spline-Auswahl
        col.prop_search(props, "pivot_spline", bpy.data, "objects", text="Spline")
        
        # Max Speed für Pivot Track
        col.prop(props, "pivot_max_speed", text="Max Speed (mm/s)")
        
        # =================================================================
        # LENS TRACK (Blickpunkt)
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="👁️ LENS TRACK", icon='VIEWZOOM')
        col.separator(factor=0.5)
        
        # Spline-Auswahl
        col.prop_search(props, "lens_spline", bpy.data, "objects", text="Spline")
        
        # Max Speed für Lens Track
        col.prop(props, "lens_max_speed", text="Max Speed (mm/s)")
        
        # =================================================================
        # EMPTY SETTINGS
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="📦 EMPTY SETTINGS", icon='EMPTY_DATA')
        col.separator(factor=0.5)
        
        col.prop(props, "empty_size")
        
        # =================================================================
        # KAMERA SETTINGS
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="📷 KAMERA", icon='OUTLINER_OB_CAMERA')
        col.separator(factor=0.5)
        
        col.prop(props, "create_camera")
        if props.create_camera:
            col.prop(props, "camera_focal_length")
        
        # =================================================================
        # 🔥 ROLL SYSTEM AUSWAHL
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="🔄 ROLL SYSTEM", icon='DRIVER_ROTATIONAL_DIFFERENCE')
        col.separator(factor=0.5)
        
        # Radio-Buttons für Roll-System
        row = col.row(align=True)
        row.prop(props, "roll_system", expand=True)
        
        # Info-Text je nach Auswahl
        if props.roll_system == 'SIMPLE':
            col.label(text="• Einfaches Y-Roll System", icon='CHECKBOX_HLT')
            col.label(text="• LookAt → Roll → Kamera")
            col.label(text="• Y-Roll als reiner Effekt")
        else:
            col.label(text="• Komplexes X/Y/Z Roll System", icon='CHECKBOX_DEHLT')
            col.label(text="• Für Power-User")
            col.label(text="• Drei separate Roll-Gimbals")
        
        # =================================================================
        # HAUPTBUTTON
        # =================================================================
        layout.separator(factor=1.0)
        row = layout.row(align=True)
        row.scale_y = 2.0
        op = row.operator("tsde.build_rig", text="🏗️ RIG BAUEN", icon='CONSTRAINT')
        
        # Alle Properties an den Operator übergeben
        op.group_name = props.group_name
        op.pivot_spline = props.pivot_spline
        op.pivot_max_speed = props.pivot_max_speed
        op.lens_spline = props.lens_spline
        op.lens_max_speed = props.lens_max_speed
        op.empty_size = props.empty_size
        op.create_camera = props.create_camera
        op.camera_focal_length = props.camera_focal_length
        op.roll_system = props.roll_system  # 🔥 NEU!
        
        # =================================================================
        # INFO
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        col.label(text="ℹ️ INFO:", icon='INFO')
        col.label(text="• Pivot Spline = Kameraposition")
        col.label(text="• Lens Spline = Blickpunkt")
        col.label(text="• Max Speed = Bewegungsgeschwindigkeit")
        col.label(text="• Orange CUBE = Pivot Empty")
        col.label(text="• Blaue SPHERE = Lens Empty")
        
        if props.roll_system == 'SIMPLE':
            col.label(text="• Roter CIRCLE = Y-Roll Empty")
            col.label(text="• Y-Roll als Effekt-Layer")
        else:
            col.label(text="• Rote CIRCLE = X/Y/Z Roll Gimbals")
            col.label(text="• Volle Kontrolle über alle Achsen")