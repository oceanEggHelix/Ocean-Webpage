"""Versionsinformationen für TSDE Host"""
__version__ = "0.1.0"
__engine_version__ = "0.1"
__blender_version__ = (4, 0, 0)