"""
TSDE Blender Host - Live Engine Integration
Version 0.1
"""

bl_info = {
    "name": "TSDE Live Host",
    "author": "Benjamin",
    "version": (0, 9, 0),
    "blender": (4, 0, 0),
    "location": "3D View > Sidebar > TSDE",
    "description": "Time-Space Deformation Engine Live Host",
    "category": "Animation",
}

from .blender_host import register, unregister

__all__ = ["register", "unregister"]