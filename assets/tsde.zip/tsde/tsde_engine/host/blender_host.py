"""TSDE Blender Host - Hauptmodul für die Blender Integration"""
import bpy
import sys
import traceback
from bpy.props import PointerProperty

# =====================================================================
# VERSION
# =====================================================================
from .version import __version__

print("\n" + "="*60)
print(f"🎮 TSDE Blender Host v{__version__} wird geladen...")
print("="*60)

# =====================================================================
# PROPERTIES IMPORT
# =====================================================================
try:
    from .properties.walkfly_props import WalkflyProperties
    from .properties.spline_setter_props import SplineSetterProperties
    from .properties.keyframe_retter_props import KeyframeRetterProperties
    from .properties.setup_props import SetupProperties
    from .properties.engine_props import EngineProperties, EngineRigItem
    from .properties.live_props import LiveProperties, TrackLiveProperties
    from .properties.recorder_props import RecorderProperties
    from .properties.render_props import RenderProperties
    from .properties.settings_props import SettingsProperties
    print("✅ Properties importiert")
except Exception as e:
    print(f"❌ Fehler beim Import der Properties: {e}")
    traceback.print_exc()

# =====================================================================
# SPLINE GENERATOR (Überkategorie mit 3 Unterkategorien)
# =====================================================================
try:
    from .spline_generator.walkfly import TSDE_OT_WalkflyRecorder
    from .spline_generator.setter import (
        TSDE_OT_GoToCamera,
        TSDE_OT_SetKeyframe,
        TSDE_OT_DeleteLastKeyframe,
        TSDE_OT_ClearKeyframes,
        TSDE_OT_GenerateSmoothSpline
    )
    from .spline_generator.retter import TSDE_OT_GenerateKeyframeSplines
    print("✅ Spline Generator importiert")
except Exception as e:
    print(f"❌ Fehler beim Import des Spline Generators: {e}")
    traceback.print_exc()

# =====================================================================
# SECTION 2: SETUP BUILDER
# =====================================================================
try:
    from .section2_setup import TSDE_OT_BuildRig
    print("✅ Section 2 importiert")
except Exception as e:
    print(f"❌ Fehler beim Import von Section 2: {e}")
    traceback.print_exc()

# =====================================================================
# SECTION 3: ENGINE CONTROL
# =====================================================================
try:
    from .section3_engine import (
        TSDE_OT_ExportSetup,
        TSDE_OT_StartEngine,
        TSDE_OT_StopEngine,
        TSDE_OT_TestConnection,
        TSDE_OT_ListRigs
    )
    from .section3_engine.panel import TSDE_UL_RigList, TSDE_OT_SelectAllRigs, TSDE_OT_SelectNoneRigs
    print("✅ Section 3 importiert")
except Exception as e:
    print(f"❌ Fehler beim Import von Section 3: {e}")
    traceback.print_exc()

# =====================================================================
# SECTION 4: LIVE CONTROL
# =====================================================================
try:
    from .section4_live_control import (
        TSDE_OT_Play,
        TSDE_OT_Pause,
        TSDE_OT_Reset,
        TSDE_OT_SetPedal
    )
    print("✅ Section 4 importiert")
except Exception as e:
    print(f"❌ Fehler beim Import von Section 4: {e}")
    traceback.print_exc()

# =====================================================================
# SECTION 5: RECORDER
# =====================================================================
try:
    from .section5_recorder import TSDE_OT_RecorderControl
    from .section5_recorder import TSDE_OT_OpenEditor
    print("✅ Section 5 importiert")
except Exception as e:
    print(f"❌ Fehler beim Import von Section 5: {e}")
    traceback.print_exc()

# =====================================================================
# SECTION 6: RENDER EXPORT
# =====================================================================
try:
    from .section6_render import TSDE_OT_RenderExport, TSDE_OT_SelectRecording
    print("✅ Section 6 importiert")
except Exception as e:
    print(f"❌ Fehler beim Import von Section 6: {e}")
    traceback.print_exc()

# =====================================================================
# SECTION 7: SETTINGS
# =====================================================================
try:
    from .section7_settings import TSDE_OT_ResetSettings
    print("✅ Section 7 importiert")
except Exception as e:
    print(f"❌ Fehler beim Import von Section 7: {e}")
    traceback.print_exc()

# =====================================================================
# MAIN PANEL (Panels werden über register.py registriert)
# =====================================================================
try:
    from .panels.register import register_panels, unregister_panels
    print("✅ Panel-Registrierung importiert")
except Exception as e:
    print(f"❌ Fehler beim Import der Panel-Registrierung: {e}")
    traceback.print_exc()

# =====================================================================
# REGISTER FUNKTION (KOMPLETT)
# =====================================================================
def register():
    print("\n" + "="*60)
    print(f"🎮 TSDE Blender Host v{__version__} Registrierung")
    print("="*60)
    
    registered_classes = []
    
    # -----------------------------------------------------------------
    # PROPERTIES REGISTRIEREN (ALLE!)
    # -----------------------------------------------------------------
    print("\n📦 Registriere Properties...")
    
    property_classes = [
        ("EngineRigItem", EngineRigItem),
        ("WalkflyProperties", WalkflyProperties),
        ("SplineSetterProperties", SplineSetterProperties),
        ("KeyframeRetterProperties", KeyframeRetterProperties),
        ("SetupProperties", SetupProperties),
        ("EngineProperties", EngineProperties),
        ("TrackLiveProperties", TrackLiveProperties),
        ("LiveProperties", LiveProperties),
        ("RecorderProperties", RecorderProperties),
        ("RenderProperties", RenderProperties),
        ("SettingsProperties", SettingsProperties),
    ]
    
    for name, cls in property_classes:
        try:
            bpy.utils.register_class(cls)
            registered_classes.append(cls)
            print(f"   ✅ {name}")
        except Exception as e:
            print(f"   ⚠️ {name}: {e}")
    
    # -----------------------------------------------------------------
    # UI LISTS REGISTRIEREN
    # -----------------------------------------------------------------
    print("\n📋 Registriere UI Lists...")
    try:
        bpy.utils.register_class(TSDE_UL_RigList)
        registered_classes.append(TSDE_UL_RigList)
        print("   ✅ TSDE_UL_RigList")
    except Exception as e:
        print(f"   ⚠️ UI List: {e}")
    
    # -----------------------------------------------------------------
    # HILFS-OPERATOREN FÜR RIG-AUSWAHL
    # -----------------------------------------------------------------
    print("\n➕ Registriere Hilfs-Operatoren...")
    try:
        bpy.utils.register_class(TSDE_OT_SelectAllRigs)
        bpy.utils.register_class(TSDE_OT_SelectNoneRigs)
        registered_classes.append(TSDE_OT_SelectAllRigs)
        registered_classes.append(TSDE_OT_SelectNoneRigs)
        print("   ✅ TSDE_OT_SelectAllRigs / SelectNoneRigs")
    except Exception as e:
        print(f"   ⚠️ Hilfs-Operatoren: {e}")
    
    # -----------------------------------------------------------------
    # SCENE PROPERTIES ZUWEISEN
    # -----------------------------------------------------------------
    try:
        bpy.types.Scene.tsde_walkfly_props = PointerProperty(type=WalkflyProperties)
        bpy.types.Scene.tsde_spline_setter_props = PointerProperty(type=SplineSetterProperties)
        bpy.types.Scene.tsde_keyframe_retter_props = PointerProperty(type=KeyframeRetterProperties)
        bpy.types.Scene.tsde_setup_props = PointerProperty(type=SetupProperties)
        bpy.types.Scene.tsde_engine_props = PointerProperty(type=EngineProperties)
        bpy.types.Scene.tsde_live_props = PointerProperty(type=LiveProperties)
        bpy.types.Scene.tsde_recorder_props = PointerProperty(type=RecorderProperties)
        bpy.types.Scene.tsde_render_props = PointerProperty(type=RenderProperties)
        bpy.types.Scene.tsde_settings_props = PointerProperty(type=SettingsProperties)
        print("✅ Scene Properties zugewiesen")
    except Exception as e:
        print(f"⚠️ Fehler bei Scene Properties: {e}")
    
    # -----------------------------------------------------------------
    # OPERATOREN REGISTRIEREN (ALLE!)
    # -----------------------------------------------------------------
    print("\n🎯 Registriere Operatoren...")
    
    operator_classes = [
        # Spline Generator - Walk/Fly
        ("WalkflyRecorder", TSDE_OT_WalkflyRecorder),
        
        # Spline Generator - Setter
        ("GoToCamera", TSDE_OT_GoToCamera),
        ("SetKeyframe", TSDE_OT_SetKeyframe),
        ("DeleteLastKeyframe", TSDE_OT_DeleteLastKeyframe),
        ("ClearKeyframes", TSDE_OT_ClearKeyframes),
        ("GenerateSmoothSpline", TSDE_OT_GenerateSmoothSpline),
        
        # Spline Generator - Retter
        ("GenerateKeyframeSplines", TSDE_OT_GenerateKeyframeSplines),
        
        # Section 2
        ("BuildRig", TSDE_OT_BuildRig),
        
        # Section 3
        ("ExportSetup", TSDE_OT_ExportSetup),
        ("StartEngine", TSDE_OT_StartEngine),
        ("StopEngine", TSDE_OT_StopEngine),
        ("TestConnection", TSDE_OT_TestConnection),
        ("ListRigs", TSDE_OT_ListRigs),
        
        # Section 4
        ("Play", TSDE_OT_Play),
        ("Pause", TSDE_OT_Pause),
        ("Reset", TSDE_OT_Reset),
        ("SetPedal", TSDE_OT_SetPedal),
        
        # Section 5
        ("RecorderControl", TSDE_OT_RecorderControl),
        ("OpenEditor", TSDE_OT_OpenEditor),
        
        # Section 6
        ("RenderExport", TSDE_OT_RenderExport),
        ("SelectRecording", TSDE_OT_SelectRecording),
        
        # Section 7
        ("ResetSettings", TSDE_OT_ResetSettings),
    ]
    
    for name, cls in operator_classes:
        try:
            bpy.utils.register_class(cls)
            registered_classes.append(cls)
            print(f"   ✅ {name}")
        except Exception as e:
            print(f"   ⚠️ {name}: {e}")
    
    # -----------------------------------------------------------------
    # PANELS REGISTRIEREN
    # -----------------------------------------------------------------
    print("\n🖼️ Registriere Panels...")
    try:
        register_panels()
        print("✅ Panels registriert")
    except Exception as e:
        print(f"⚠️ Fehler bei Panel-Registrierung: {e}")
        traceback.print_exc()
    
    # -----------------------------------------------------------------
    # GLOBALE PROPERTIES
    # -----------------------------------------------------------------
    try:
        bpy.types.Scene.tsde_speed_multiplier = bpy.props.FloatProperty(
            name="Speed Multiplier",
            default=1.0,
            min=0.1,
            max=5.0
        )
        print("✅ Globale Properties registriert")
    except Exception as e:
        print(f"⚠️ Fehler bei globalen Properties: {e}")
    
    print("\n" + "="*60)
    print("✅ TSDE Blender Host Registrierung abgeschlossen!")
    print("="*60 + "\n")
    
    return registered_classes

# =====================================================================
# UNREGISTER FUNKTION (KOMPLETT)
# =====================================================================
def unregister():
    print("\n" + "="*60)
    print("🛑 TSDE Blender Host wird entladen...")
    print("="*60)
    
    # -----------------------------------------------------------------
    # PANELS ENTFERNEN
    # -----------------------------------------------------------------
    print("\n🖼️ Entferne Panels...")
    try:
        unregister_panels()
        print("✅ Panels entfernt")
    except Exception as e:
        print(f"⚠️ Fehler beim Entfernen der Panels: {e}")
    
    # -----------------------------------------------------------------
    # UI LISTS ENTFERNEN
    # -----------------------------------------------------------------
    print("\n📋 Entferne UI Lists...")
    try:
        bpy.utils.unregister_class(TSDE_UL_RigList)
        print("   ✅ TSDE_UL_RigList")
    except Exception as e:
        print(f"   ⚠️ UI List: {e}")
    
    # -----------------------------------------------------------------
    # HILFS-OPERATOREN ENTFERNEN
    # -----------------------------------------------------------------
    print("\n➕ Entferne Hilfs-Operatoren...")
    try:
        bpy.utils.unregister_class(TSDE_OT_SelectNoneRigs)
        bpy.utils.unregister_class(TSDE_OT_SelectAllRigs)
        print("   ✅ TSDE_OT_SelectAllRigs / SelectNoneRigs")
    except Exception as e:
        print(f"   ⚠️ Hilfs-Operatoren: {e}")
    
    # -----------------------------------------------------------------
    # OPERATOREN ENTFERNEN (in umgekehrter Reihenfolge)
    # -----------------------------------------------------------------
    print("\n🎯 Entferne Operatoren...")
    
    operator_classes_reverse = [
        # Section 7
        ("ResetSettings", TSDE_OT_ResetSettings),
        
        # Section 6
        ("RenderExport", TSDE_OT_RenderExport),
        ("SelectRecording", TSDE_OT_SelectRecording),
        
        # Section 5
        ("OpenEditor", TSDE_OT_OpenEditor),
        ("RecorderControl", TSDE_OT_RecorderControl),
        
        # Section 4
        ("SetPedal", TSDE_OT_SetPedal),
        ("Reset", TSDE_OT_Reset),
        ("Pause", TSDE_OT_Pause),
        ("Play", TSDE_OT_Play),
        
        # Section 3
        ("ListRigs", TSDE_OT_ListRigs),
        ("TestConnection", TSDE_OT_TestConnection),
        ("StopEngine", TSDE_OT_StopEngine),
        ("StartEngine", TSDE_OT_StartEngine),
        ("ExportSetup", TSDE_OT_ExportSetup),
        
        # Section 2
        ("BuildRig", TSDE_OT_BuildRig),
        
        # Spline Generator - Retter
        ("GenerateKeyframeSplines", TSDE_OT_GenerateKeyframeSplines),
        
        # Spline Generator - Setter
        ("GenerateSmoothSpline", TSDE_OT_GenerateSmoothSpline),
        ("ClearKeyframes", TSDE_OT_ClearKeyframes),
        ("DeleteLastKeyframe", TSDE_OT_DeleteLastKeyframe),
        ("SetKeyframe", TSDE_OT_SetKeyframe),
        ("GoToCamera", TSDE_OT_GoToCamera),
        
        # Spline Generator - Walk/Fly
        ("WalkflyRecorder", TSDE_OT_WalkflyRecorder),
    ]
    
    for name, cls in operator_classes_reverse:
        try:
            bpy.utils.unregister_class(cls)
            print(f"   ✅ {name}")
        except Exception as e:
            print(f"   ⚠️ {name}: {e}")
    
    # -----------------------------------------------------------------
    # SCENE PROPERTIES ENTFERNEN
    # -----------------------------------------------------------------
    print("\n📦 Entferne Scene Properties...")
    
    props_to_delete = [
        "tsde_render_props",
        "tsde_recorder_props",
        "tsde_live_props",
        "tsde_engine_props",
        "tsde_setup_props",
        "tsde_keyframe_retter_props",
        "tsde_spline_setter_props",
        "tsde_walkfly_props",
        "tsde_settings_props",
    ]
    
    for prop in props_to_delete:
        try:
            if hasattr(bpy.types.Scene, prop):
                delattr(bpy.types.Scene, prop)
                print(f"   ✅ {prop} gelöscht")
        except Exception as e:
            print(f"   ⚠️ {prop}: {e}")
    
    # -----------------------------------------------------------------
    # PROPERTY CLASSES ENTFERNEN
    # -----------------------------------------------------------------
    print("\n📦 Entferne Property Classes...")
    
    property_classes_reverse = [
        ("SettingsProperties", SettingsProperties),
        ("RenderProperties", RenderProperties),
        ("RecorderProperties", RecorderProperties),
        ("LiveProperties", LiveProperties),
        ("TrackLiveProperties", TrackLiveProperties),
        ("EngineProperties", EngineProperties),
        ("SetupProperties", SetupProperties),
        ("KeyframeRetterProperties", KeyframeRetterProperties),
        ("SplineSetterProperties", SplineSetterProperties),
        ("WalkflyProperties", WalkflyProperties),
        ("EngineRigItem", EngineRigItem),
    ]
    
    for name, cls in property_classes_reverse:
        try:
            bpy.utils.unregister_class(cls)
            print(f"   ✅ {name}")
        except Exception as e:
            print(f"   ⚠️ {name}: {e}")
    
    # -----------------------------------------------------------------
    # GLOBALE PROPERTIES ENTFERNEN
    # -----------------------------------------------------------------
    try:
        if hasattr(bpy.types.Scene, "tsde_speed_multiplier"):
            del bpy.types.Scene.tsde_speed_multiplier
            print("✅ tsde_speed_multiplier gelöscht")
    except Exception as e:
        print(f"⚠️ tsde_speed_multiplier: {e}")
    
    print("\n" + "="*60)
    print("✅ TSDE Blender Host erfolgreich entladen!")
    print("="*60 + "\n")

if __name__ == "__main__":
    register()