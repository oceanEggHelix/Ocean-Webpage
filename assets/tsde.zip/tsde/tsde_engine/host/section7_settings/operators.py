# section7_settings/operators.py
import bpy

class TSDE_OT_ResetSettings(bpy.types.Operator):
    """Setzt alle Einstellungen auf Standard zurück"""
    bl_idname = "tsde.reset_settings"
    bl_label = "Einstellungen zurücksetzen"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.tsde_settings_props
        props.reset_to_defaults()
        self.report({'INFO'}, "Einstellungen auf Standard zurückgesetzt")
        return {'FINISHED'}