# section7_settings/panel.py
import bpy
from bpy.types import Panel

class TSDE_PT_Section7_Settings(Panel):
    bl_label = "7. ⚙️ Einstellungen"
    bl_idname = "TSDE_PT_section7"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_settings_props
        
        # =================================================================
        # KURVEN-SAMPLING (DAS WICHTIGSTE)
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="📐 KURVEN-SAMPLING", icon='CURVE_DATA')
        col.separator(factor=0.5)
        
        col.prop(props, "curve_segment_length")
        col.prop(props, "curve_max_points")
        
        # =================================================================
        # EXPORT-PFAD
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="📁 EXPORT-PFAD", icon='EXPORT')
        col.separator(factor=0.5)
        
        col.prop(props, "export_path")
        
        # =================================================================
        # RESET BUTTON
        # =================================================================
        layout.separator(factor=1.0)
        row = layout.row(align=True)
        row.scale_y = 1.2
        row.operator("tsde.reset_settings", text="🔄 STANDARD", icon='LOOP_BACK')