bl_info = {
    "name": "TSDE Rig Builder",
    "author": "Benjamin",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "3D View > Sidebar > TSDE Rig",
    "description": "Baut TSDE Rigs aus Pivot und Lens Splines mit Follow Path",
    "category": "3D View"
}

import bpy
import mathutils
from bpy.props import (
    FloatProperty,
    StringProperty,
    BoolProperty,
    PointerProperty,
)
from bpy.types import Panel, Operator, PropertyGroup


# =====================================================================
# GLOBALE FUNKTIONEN (wie im Prototyp)
# =====================================================================

def get_spline_points(spline_obj):
    """Extrahiert alle Punkte aus einem Spline-Objekt"""
    points = []
    if spline_obj and spline_obj.type == 'CURVE':
        for spline in spline_obj.data.splines:
            for point in spline.points:
                points.append(mathutils.Vector(point.co[:3]))
    return points


# =====================================================================
# MAIN OPERATOR: RIG BAUEN (exakt wie Prototyp - NUR RIG)
# =====================================================================

class TSDE_OT_BuildRig(Operator):
    bl_idname = "tsde.build_rig"
    bl_label = "TSDE Rig bauen"
    bl_description = "Baut TSDE Rig aus Pivot und Lens Splines"
    bl_options = {'REGISTER', 'UNDO'}

    group_name: StringProperty(
        name="Group Name",
        description="Name für die Rig-Gruppe",
        default="TSDE_Rig"
    )
    
    pivot_spline: StringProperty(
        name="Pivot Spline",
        description="Name des Pivot-Spline Objekts",
        default=""
    )
    
    lens_spline: StringProperty(
        name="Lens Spline",
        description="Name des Lens-Spline Objekts",
        default=""
    )
    
    empty_size: FloatProperty(
        name="Empty Size",
        default=0.1,
        min=0.01,
        max=1.0
    )
    
    create_camera: BoolProperty(
        name="Kamera erstellen",
        description="Erstellt eine neue Kamera für das Rig",
        default=True
    )
    
    camera_focal_length: FloatProperty(
        name="Kamera Brennweite",
        default=50.0,
        min=1.0,
        max=500.0
    )

    def execute(self, context):
        # Spline-Objekte finden
        pivot_obj = bpy.data.objects.get(self.pivot_spline)
        lens_obj = bpy.data.objects.get(self.lens_spline)
        
        if not pivot_obj or not lens_obj:
            self.report({'ERROR'}, "Pivot oder Lens Spline nicht gefunden!")
            return {'CANCELLED'}
        
        # Punkte extrahieren
        pivot_points = get_spline_points(pivot_obj)
        lens_points = get_spline_points(lens_obj)
        
        if len(pivot_points) < 2 or len(lens_points) < 2:
            self.report({'ERROR'}, "Splines haben zu wenig Punkte!")
            return {'CANCELLED'}
        
        # -----------------------------------------------------------------
        # 1. GRUPPE (Collection) erstellen
        # -----------------------------------------------------------------
        if self.group_name in bpy.data.collections:
            group = bpy.data.collections[self.group_name]
            # Alte Objekte in der Gruppe löschen
            for obj in list(group.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
        else:
            group = bpy.data.collections.new(self.group_name)
            context.scene.collection.children.link(group)
        
        # -----------------------------------------------------------------
        # 2. EMPTIES erstellen (wie im Prototyp)
        # -----------------------------------------------------------------
        # Pivot Empty (CUBE) - Orange
        pivot_empty = bpy.data.objects.new(f"{self.group_name}_Pivot", None)
        pivot_empty.empty_display_size = self.empty_size
        pivot_empty.empty_display_type = 'CUBE'
        pivot_empty.location = pivot_points[0]
        if hasattr(pivot_empty, "color"):
            pivot_empty.color = (1.0, 0.5, 0.0, 1.0)  # Orange
        group.objects.link(pivot_empty)
        
        # Lens Empty (SPHERE) - Hellblau
        lens_empty = bpy.data.objects.new(f"{self.group_name}_Lens", None)
        lens_empty.empty_display_size = self.empty_size * 0.7
        lens_empty.empty_display_type = 'SPHERE'
        lens_empty.location = lens_points[0]
        if hasattr(lens_empty, "color"):
            lens_empty.color = (0.0, 0.8, 1.0, 1.0)  # Hellblau
        group.objects.link(lens_empty)
        
        # -----------------------------------------------------------------
        # 3. FOLLOW PATH CONSTRAINTS (wie im Prototyp)
        # -----------------------------------------------------------------
        # Pivot Follow Path
        pivot_follow = pivot_empty.constraints.new(type='FOLLOW_PATH')
        pivot_follow.target = pivot_obj
        pivot_follow.use_fixed_location = True
        pivot_follow.offset_factor = 0.0  # Start bei 0
        
        # Lens Follow Path  
        lens_follow = lens_empty.constraints.new(type='FOLLOW_PATH')
        lens_follow.target = lens_obj
        lens_follow.use_fixed_location = True
        lens_follow.offset_factor = 0.0  # Start bei 0
        
        # Empties auf den Spline "clampen"
        pivot_follow.offset_factor = 0.001
        pivot_follow.offset_factor = 0.0
        lens_follow.offset_factor = 0.001
        lens_follow.offset_factor = 0.0
        
        # -----------------------------------------------------------------
        # 4. KAMERA mit TRACKING (wie im Prototyp)
        # -----------------------------------------------------------------
        if self.create_camera:
            cam_data = bpy.data.cameras.new(name=f"{self.group_name}_Camera")
            camera = bpy.data.objects.new(f"{self.group_name}_Camera", cam_data)
            camera.data.lens = self.camera_focal_length
            camera.location = pivot_points[0]
            
            # Tracking Constraint (wie im Prototyp)
            track = camera.constraints.new(type='TRACK_TO')
            track.target = lens_empty
            track.track_axis = 'TRACK_NEGATIVE_Z'
            track.up_axis = 'UP_Y'
            
            group.objects.link(camera)
        
        self.report({'INFO'}, f"✅ Rig '{self.group_name}' gebaut")
        return {'FINISHED'}


# =====================================================================
# OPERATOR: ALLE SPLINES ANZEIGEN (Hilfreich für Auswahl)
# =====================================================================

class TSDE_OT_ListSplines(Operator):
    bl_idname = "tsde.list_splines"
    bl_label = "Splines anzeigen"
    bl_description = "Zeigt alle verfügbaren Splines an"
    
    def execute(self, context):
        print("\n📋 Verfügbare Splines:")
        splines = []
        for obj in bpy.data.objects:
            if obj.type == 'CURVE':
                splines.append(obj.name)
                print(f"   - {obj.name}")
        
        if not splines:
            print("   Keine Splines gefunden")
            self.report({'INFO'}, "Keine Splines in der Szene")
        else:
            self.report({'INFO'}, f"{len(splines)} Splines gefunden")
        
        return {'FINISHED'}


# =====================================================================
# PROPERTIES
# =====================================================================

class TSDE_RigProperties(PropertyGroup):
    group_name: StringProperty(
        name="Group Name",
        default="TSDE_Rig"
    )
    
    pivot_spline: StringProperty(
        name="Pivot Spline",
        description="Spline für die Kameraposition",
        default=""
    )
    
    lens_spline: StringProperty(
        name="Lens Spline",
        description="Spline für den Blickpunkt",
        default=""
    )
    
    empty_size: FloatProperty(
        name="Empty Size",
        default=0.1,
        min=0.01,
        max=1.0
    )
    
    create_camera: BoolProperty(
        name="Kamera erstellen",
        default=True
    )
    
    camera_focal_length: FloatProperty(
        name="Brennweite",
        default=50.0,
        min=1.0,
        max=500.0
    )


# =====================================================================
# PANEL (NUR RIG - KEIN EXPORT/IMPORT)
# =====================================================================

class TSDE_PT_RigBuilder(Panel):
    bl_label = "TSDE Rig Builder"
    bl_idname = "TSDE_PT_rig_builder"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE Rig"
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_rig_props
        
        # Hauptbox
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="🔧 RIG BAUEN", icon='TOOL_SETTINGS')
        col.separator()
        
        # Group Name
        col.prop(props, "group_name")
        
        col.separator()
        
        # Spline-Auswahl
        col.label(text="Splines auswählen:")
        
        # Dropdown für Pivot Spline
        col.prop_search(props, "pivot_spline", bpy.data, "objects", text="Pivot")
        
        # Dropdown für Lens Spline
        col.prop_search(props, "lens_spline", bpy.data, "objects", text="Lens")
        
        col.separator()
        
        # Empty Settings
        col.prop(props, "empty_size")
        
        # Kamera Settings
        col.prop(props, "create_camera")
        if props.create_camera:
            col.prop(props, "camera_focal_length")
        
        col.separator()
        
        # Hauptbutton
        row = col.row(align=True)
        row.scale_y = 2.0
        op = row.operator("tsde.build_rig", text="🏗️ RIG BAUEN", icon='CONSTRAINT')
        op.group_name = props.group_name
        op.pivot_spline = props.pivot_spline
        op.lens_spline = props.lens_spline
        op.empty_size = props.empty_size
        op.create_camera = props.create_camera
        op.camera_focal_length = props.camera_focal_length
        
        # Hilfsbutton
        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("tsde.list_splines", text="📋 Splines anzeigen", icon='VIEWZOOM')
        
        col.separator()
        
        # Info
        box = layout.box()
        col = box.column(align=True)
        col.label(text="ℹ️ INFO:", icon='INFO')
        col.label(text="• Pivot Spline = Kameraposition")
        col.label(text="• Lens Spline = Blickpunkt")
        col.label(text="• Orange CUBE = Pivot Empty")
        col.label(text="• Blaue SPHERE = Lens Empty")
        col.label(text="• Kamera trackt auf Lens Empty")
        col.label(text="• Follow Path Constraints")


# =====================================================================
# REGISTRATION
# =====================================================================

classes = (
    # Properties
    TSDE_RigProperties,
    
    # Operators
    TSDE_OT_BuildRig,
    TSDE_OT_ListSplines,
    
    # Panels
    TSDE_PT_RigBuilder,
)

def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except:
            bpy.utils.unregister_class(cls)
            bpy.utils.register_class(cls)
    
    bpy.types.Scene.tsde_rig_props = PointerProperty(type=TSDE_RigProperties)
    
    print("\n" + "="*60)
    print("🏗️ TSDE RIG BUILDER GELADEN")
    print("="*60)
    print("✅ Baut Rigs wie im Prototyp:")
    print("   - Pivot Empty (CUBE, orange)")
    print("   - Lens Empty (SPHERE, blau)")
    print("   - Follow Path Constraints (auf Spline)")
    print("   - Tracking Kamera")
    print("✅ KEIN Export/Import - NUR Rig")
    print("="*60 + "\n")

def unregister():
    del bpy.types.Scene.tsde_rig_props
    
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass
    
    print("TSDE Rig Builder ENTLADEN")

if __name__ == "__main__":
    register()