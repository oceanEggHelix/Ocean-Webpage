# tsde_gui/external_api.py
"""
Externe API zur Steuerung der TSDE GUI von außen.
"""

import json
import tsde_engine.core.ipc as ipc
import time
from typing import Dict, List, Optional, Any, Union
from pathlib import Path


class TSDE_GUI_Controller:
    """
    Externe Controller-Klasse zur Steuerung der TSDE GUI.
    
    Beispiel:
    ```python
    from tsde_gui.external_api import TSDE_GUI_Controller
    
    # GUI Controller erstellen
    controller = TSDE_GUI_Controller()
    
    # Setup laden
    controller.load_setup("mein_setup.json")
    
    # Pedal pro Track setzen
    controller.set_track_pedal("Track1", 0.5)  # 50% für Track1
    controller.set_track_pedal("Track2", 0.8)  # 80% für Track2
    
    # Oder alle auf einmal
    controller.set_all_tracks_pedal({
        "Track1": 0.5,
        "Track2": 0.8,
        "Track3": 1.0
    })
    
    # Engine starten
    controller.start_engine()
    
    # Während des Laufs Pedal ändern
    time.sleep(2)
    controller.set_track_pedal("Track1", 0.3)  # Runter auf 30%
    
    # Engine stoppen
    controller.stop_engine()
    ```
    """
    
    def __init__(self, debug_level: int = 1):
        """
        Initialisiert den GUI Controller.
        
        Args:
            debug_level: Debug-Level (0-3)
        """
        self.debug_level = debug_level
        self._setup = None
        self._gui_instance = None
        self._track_names = []  # Liste aller Track-Namen
    
    def connect_to_gui(self, gui_instance):
        """
        Verbindet sich mit einer laufenden GUI-Instanz.
        
        Args:
            gui_instance: Die EngineTerminal Instanz
        """
        self._gui_instance = gui_instance
        print(f"[API] Verbunden mit GUI Instanz")
    
    # ============================================================
    # SETUP & KONFIGURATION
    # ============================================================
    
    def load_setup(self, setup_path: str) -> bool:
        """
        Lädt ein Setup von einer JSON-Datei.
        
        Args:
            setup_path: Pfad zur JSON-Setup-Datei
            
        Returns:
            bool: True wenn erfolgreich, False bei Fehler
        """
        try:
            with open(setup_path, "r") as f:
                self._setup = json.load(f)
            
            # Track-Namen extrahieren
            self._track_names = []
            for group in self._setup["groups"]:
                for track in group["tracks"]:
                    self._track_names.append(track["name"])
            
            # Setup in die GUI laden
            if self._gui_instance:
                self._gui_instance.setup = self._setup
                self._gui_instance._build_pedal_ui(None)
                self._gui_instance._load_curves_from_setup()
                self._gui_instance._update_status(f"✅ Externes Setup geladen: {setup_path}")
            
            print(f"[API] Setup geladen: {setup_path}")
            print(f"[API] Anzahl Gruppen: {len(self._setup['groups'])}")
            print(f"[API] Tracks: {', '.join(self._track_names)}")
            
            # Setup an Engine senden (falls läuft)
            if ipc.is_running():
                ipc.send("setup", data=self._setup)
                print(f"[API] Setup an Engine gesendet")
            
            return True
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Laden des Setups: {e}")
            return False
    
    def get_track_names(self) -> List[str]:
        """
        Gibt eine Liste aller Track-Namen zurück.
        
        Returns:
            List[str]: Liste der Track-Namen
        """
        return self._track_names.copy()
    
    # ============================================================
    # PEDAL STEURUNG - INDIVIDUELL PRO TRACK
    # ============================================================
    
    def set_track_pedal(self, track_name: str, value: float) -> bool:
        """
        Setzt den Pedal-Wert für einen bestimmten Track.
        
        Args:
            track_name: Name des Tracks (z.B. "Track1")
            value: Pedal-Wert zwischen 0.0 und 1.0
            
        Returns:
            bool: True wenn erfolgreich
            
        Beispiel:
        ```python
        controller.set_track_pedal("Track1", 0.5)  # 50%
        controller.set_track_pedal("Track2", 0.8)  # 80%
        ```
        """
        try:
            # Prüfen ob Track existiert
            if track_name not in self._track_names:
                print(f"[API ERROR] Track '{track_name}' nicht gefunden. Verfügbare Tracks: {self._track_names}")
                return False
            
            # Wert validieren
            value = max(0.0, min(1.0, value))
            int_value = int(value * 100)
            
            # In GUI aktualisieren (falls verbunden)
            if self._gui_instance and track_name in self._gui_instance.pedal_sliders:
                slider, label, _ = self._gui_instance.pedal_sliders[track_name]
                slider.blockSignals(True)
                slider.setValue(int_value)
                label.setText(f"{int_value}%")
                slider.blockSignals(False)
                print(f"[API] GUI Pedal für '{track_name}' aktualisiert: {value:.2f}")
            
            # An Engine senden
            if ipc.is_running():
                ipc.send("set_pedal", track=track_name, value=value)
                print(f"[API] Pedal für '{track_name}' an Engine gesendet: {value:.2f}")
            
            return True
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Setzen des Pedals für '{track_name}': {e}")
            return False
    
    def set_all_tracks_pedal(self, pedal_values: Dict[str, float]) -> bool:
        """
        Setzt Pedal-Werte für mehrere Tracks auf einmal.
        
        Args:
            pedal_values: Dictionary mit Track-Name -> Wert Paaren
            
        Returns:
            bool: True wenn alle erfolgreich
            
        Beispiel:
        ```python
        controller.set_all_tracks_pedal({
            "Track1": 0.5,
            "Track2": 0.8,
            "Track3": 1.0
        })
        ```
        """
        try:
            all_success = True
            
            for track_name, value in pedal_values.items():
                success = self.set_track_pedal(track_name, value)
                if not success:
                    all_success = False
            
            return all_success
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Setzen mehrerer Pedal-Werte: {e}")
            return False
    
    def set_group_pedal(self, group_name: str, value: float) -> bool:
        """
        Setzt den Pedal-Wert für alle Tracks in einer Gruppe.
        
        Args:
            group_name: Name der Gruppe
            value: Pedal-Wert zwischen 0.0 und 1.0
            
        Returns:
            bool: True wenn erfolgreich
        """
        try:
            if not self._setup:
                print("[API ERROR] Kein Setup geladen")
                return False
            
            # Gruppe finden
            track_names = []
            for group in self._setup["groups"]:
                if group["name"] == group_name:
                    track_names = [track["name"] for track in group["tracks"]]
                    break
            
            if not track_names:
                print(f"[API ERROR] Gruppe '{group_name}' nicht gefunden")
                return False
            
            # Pedal für alle Tracks der Gruppe setzen
            all_success = True
            for track_name in track_names:
                success = self.set_track_pedal(track_name, value)
                if not success:
                    all_success = False
            
            print(f"[API] Pedal für Gruppe '{group_name}' gesetzt: {value:.2f}")
            return all_success
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Setzen des Gruppen-Pedals: {e}")
            return False
    
    def set_global_pedal(self, value: float) -> bool:
        """
        Setzt den globalen Pedal-Wert für ALLE Tracks.
        
        Args:
            value: Pedal-Wert zwischen 0.0 und 1.0
            
        Returns:
            bool: True wenn erfolgreich
            
        Beispiel:
        ```python
        controller.set_global_pedal(0.5)  # Alle Tracks auf 50%
        ```
        """
        try:
            # Wert validieren
            value = max(0.0, min(1.0, value))
            int_value = int(value * 100)
            
            # In GUI aktualisieren (falls verbunden)
            if self._gui_instance:
                # Globalen Slider aktualisieren
                self._gui_instance.global_pedal_slider.blockSignals(True)
                self._gui_instance.global_pedal_slider.setValue(int_value)
                self._gui_instance.global_pedal_label.setText(f"{int_value}%")
                self._gui_instance.global_pedal_slider.blockSignals(False)
                
                # Alle individuellen Slider aktualisieren
                for track_name, (slider, label, _) in self._gui_instance.pedal_sliders.items():
                    slider.blockSignals(True)
                    slider.setValue(int_value)
                    label.setText(f"{int_value}%")
                    slider.blockSignals(False)
                
                print(f"[API] GUI globale Pedal aktualisiert: {value:.2f}")
            
            # An alle Tracks in Engine senden
            if ipc.is_running() and self._track_names:
                for track_name in self._track_names:
                    ipc.send("set_pedal", track=track_name, value=value)
                print(f"[API] Globaler Pedal an Engine gesendet für {len(self._track_names)} Tracks: {value:.2f}")
            
            return True
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Setzen des globalen Pedals: {e}")
            return False
    
    def get_track_pedal(self, track_name: str) -> Optional[float]:
        """
        Holt den aktuellen Pedal-Wert eines Tracks.
        
        Args:
            track_name: Name des Tracks
            
        Returns:
            float: Pedal-Wert oder None bei Fehler
        """
        try:
            if self._gui_instance and track_name in self._gui_instance.pedal_sliders:
                slider, _, _ = self._gui_instance.pedal_sliders[track_name]
                return slider.value() / 100.0
            
            # Falls GUI nicht verbunden, von Engine abfragen
            if ipc.is_running():
                # Hier müsste die Engine eine Abfrage-Funktion haben
                # Aktuell nur über GUI möglich
                pass
            
            return None
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Abrufen des Pedal-Werts: {e}")
            return None
    
    # ============================================================
    # ENGINE CONTROL
    # ============================================================
    
    def start_engine(self) -> bool:
        """
        Startet die Engine.
        
        Returns:
            bool: True wenn erfolgreich
        """
        try:
            if not self._setup:
                print("[API ERROR] Kein Setup geladen. Bitte zuerst load_setup() aufrufen.")
                return False
            
            # Engine starten
            ipc.start_engine(debug_level=self.debug_level)
            time.sleep(0.5)  # Kurz warten für Initialisierung
            
            # Setup senden
            ipc.send("setup", data=self._setup)
            time.sleep(3.0)  # Warten bis Setup geladen
            
            # Alle Pedal-Werte auf 100% setzen (Standard)
            for track_name in self._track_names:
                ipc.send("set_pedal", track=track_name, value=1.0)
            
            # Play senden
            ipc.send("play")
            
            # GUI aktualisieren (falls verbunden)
            if self._gui_instance:
                self._gui_instance.btn_start.setEnabled(False)
                self._gui_instance.btn_stop.setEnabled(True)
                self._gui_instance.btn_reset.setEnabled(True)
                self._gui_instance._update_status("✅ Engine gestartet (extern)", "#4CAF50")
                
                # Timer starten
                self._gui_instance.timer.start(33)
            
            print("[API] Engine gestartet")
            return True
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Starten der Engine: {e}")
            return False
    
    def stop_engine(self) -> bool:
        """
        Stoppt die Engine.
        
        Returns:
            bool: True wenn erfolgreich
        """
        try:
            # Engine stoppen
            ipc.stop_engine()
            
            # GUI aktualisieren (falls verbunden)
            if self._gui_instance:
                self._gui_instance.timer.stop()
                self._gui_instance.btn_start.setEnabled(True)
                self._gui_instance.btn_stop.setEnabled(False)
                self._gui_instance.btn_reset.setEnabled(False)
                self._gui_instance._update_status("⏹️ Engine gestoppt (extern)", "white")
            
            print("[API] Engine gestoppt")
            return True
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Stoppen der Engine: {e}")
            return False
    
    def reset_tracks(self) -> bool:
        """
        Setzt alle Tracks zurück.
        
        Returns:
            bool: True wenn erfolgreich
        """
        try:
            if not ipc.is_running():
                print("[API ERROR] Engine läuft nicht")
                return False
            
            # Reset senden
            ipc.send("reset")
            
            # Pedal-Werte zurücksetzen auf 100%
            for track_name in self._track_names:
                ipc.send("set_pedal", track=track_name, value=1.0)
            
            # GUI aktualisieren (falls verbunden)
            if self._gui_instance:
                self._gui_instance.global_pedal_slider.setValue(100)
                self._gui_instance.start_times.clear()
                self._gui_instance._update_status("🔄 Tracks zurückgesetzt (extern)", "#4a86e8")
            
            print("[API] Tracks zurückgesetzt")
            return True
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Zurücksetzen der Tracks: {e}")
            return False
    
    # ============================================================
    # STATUS & DATEN
    # ============================================================
    
    def get_status(self) -> Dict[str, Any]:
        """
        Gibt den aktuellen Status der Engine zurück.
        
        Returns:
            Dict mit Status-Informationen
        """
        try:
            info = ipc.get_engine_info()
            
            status = {
                "engine_running": ipc.is_running(),
                "debug_level": info.get("debug_level", 1),
                "pid": info.get("pid"),
                "queue_sizes": info.get("queue_sizes", {"out": 0, "in": 0}),
                "setup_loaded": self._setup is not None,
                "track_count": len(self._track_names) if self._track_names else 0
            }
            
            if self._setup:
                status["setup_info"] = {
                    "groups": len(self._setup["groups"]),
                    "tracks": self._track_names
                }
            
            return status
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Abrufen des Status: {e}")
            return {"error": str(e)}
    
    def get_track_data(self) -> List[Dict[str, Any]]:
        """
        Holt aktuelle Track-Daten von der Engine.
        
        Returns:
            Liste mit Track-Daten (t_local, dist, pedal, etc.)
        """
        try:
            if not ipc.is_running():
                return []
            
            data = ipc.poll()
            return data if data else []
            
        except Exception as e:
            print(f"[API ERROR] Fehler beim Abrufen der Track-Daten: {e}")
            return []
    
    def is_engine_running(self) -> bool:
        """
        Prüft ob die Engine läuft.
        
        Returns:
            bool: True wenn Engine läuft
        """
        return ipc.is_running()


# Globale Instanz für einfachen Zugriff
_global_controller = None


def get_controller() -> TSDE_GUI_Controller:
    """
    Gibt die globale Controller-Instanz zurück.
    
    Returns:
        TSDE_GUI_Controller Instanz
    """
    global _global_controller
    if _global_controller is None:
        _global_controller = TSDE_GUI_Controller()
    return _global_controller


def init_controller(gui_instance=None, debug_level=1):
    """
    Initialisiert den globalen Controller.
    
    Args:
        gui_instance: Optional: GUI-Instanz für direkte Steuerung
        debug_level: Debug-Level (0-3)
    """
    global _global_controller
    _global_controller = TSDE_GUI_Controller(debug_level=debug_level)
    
    if gui_instance:
        _global_controller.connect_to_gui(gui_instance)
    
    return _global_controller