bl_info = {
    "name": "TSDE Complete Suite",
    "author": "Benjamin",
    "version": (3, 5, 0),
    "blender": (3, 0, 0),
    "location": "3D View > Sidebar > TSDE",
    "description": "Walk/Fly Recorder, Smooth Keyframe Recorder & Keyframe Generator",
    "category": "3D View"
}

import bpy
import math
import mathutils
from mathutils import Vector, Euler
from math import ceil
from bpy.props import (
    FloatProperty, IntProperty, BoolProperty, 
    StringProperty, EnumProperty, PointerProperty
)


# =====================================================================
# GLOBALE HILFSFUNKTIONEN
# =====================================================================

def resample_spline_points(points, segment_length):
    """EXAKT wie im Prototyp: Gleicht Spline-Punkte auf konstante Segmentlänge an"""
    if len(points) < 2:
        return points.copy()
    new_points = []
    for i in range(len(points) - 1):
        start_pt = points[i]
        end_pt = points[i + 1]
        distance = (end_pt - start_pt).length
        if distance == 0:
            continue
        num_segments = max(1, int(ceil(distance / segment_length)))
        direction = (end_pt - start_pt).normalized()
        for j in range(num_segments):
            t = j / num_segments
            point = start_pt + direction * (distance * t)
            new_points.append(point)
    new_points.append(points[-1].copy())
    return new_points

def create_visible_spline(name, points, color, context):
    """Erstellt einen Spline mit sichtbaren Punkten"""
    curve = bpy.data.curves.new(name, type='CURVE')
    curve.dimensions = '3D'
    spline = curve.splines.new('POLY')
    spline.points.add(len(points) - 1)
    for i, p in enumerate(points):
        spline.points[i].co = (p.x, p.y, p.z, 1.0)
    obj = bpy.data.objects.new(name, curve)
    if hasattr(obj, "color"):
        obj.color = color
    context.scene.collection.objects.link(obj)
    return obj


# =====================================================================
# EXAKTE LENS-BERECHNUNG (wie im Prototyp)
# =====================================================================

def get_lens_position_exact(cam):
    """
    Berechnet die optische Linsenposition EXAKT wie im Prototyp:
    lens_center = cam.matrix_world.translation + forward * (lens_mm / sensor_mm)
    """
    cam_matrix = cam.matrix_world
    
    # Forward-Vektor (lokale -Z Achse)
    forward = cam_matrix.to_quaternion() @ mathutils.Vector((0, 0, -1))
    
    # Aktuelle Brennweite
    lens_mm = cam.data.lens
    
    # Sensorgröße (horizontal oder vertikal)
    if cam.data.sensor_fit == 'VERTICAL':
        sensor_mm = cam.data.sensor_height
    else:
        sensor_mm = cam.data.sensor_width
    
    # Offset in Blender Units (physikalisch plausibel)
    lens_offset = lens_mm / sensor_mm
    
    # Optisches Zentrum = Kameraposition + Blickrichtung * Offset
    lens_center = cam_matrix.translation + forward * lens_offset
    
    return lens_center


# =====================================================================
# MODUL 1: WALK/FLY RECORDER (Version 1.8.0)
# =====================================================================

WALKFLY_PIVOT_POINTS = []
WALKFLY_LENS_POINTS = []

def smooth_spline_points(points, factor=0.3, iterations=3):
    if len(points) < 3:
        return points
    smoothed = [p.copy() for p in points]
    for _ in range(iterations):
        new_points = [smoothed[0].copy()]
        for i in range(1, len(smoothed) - 1):
            p_prev = smoothed[i-1]
            p_curr = smoothed[i]
            p_next = smoothed[i+1]
            smooth_point = (p_prev * factor + p_curr * (1 - 2*factor) + p_next * factor)
            new_points.append(smooth_point)
        new_points.append(smoothed[-1].copy())
        smoothed = new_points
    return smoothed

def gaussian_smooth(points, sigma=1.0):
    if len(points) < 3:
        return points
    kernel_size = int(3 * sigma)
    kernel = []
    kernel_sum = 0
    for i in range(-kernel_size, kernel_size + 1):
        weight = math.exp(-(i*i) / (2*sigma*sigma))
        kernel.append(weight)
        kernel_sum += weight
    kernel = [w / kernel_sum for w in kernel]
    smoothed = []
    half_k = kernel_size
    for i in range(len(points)):
        weighted_sum = Vector((0, 0, 0))
        total_weight = 0
        for j in range(-half_k, half_k + 1):
            idx = i + j
            if 0 <= idx < len(points):
                weight = kernel[j + half_k]
                weighted_sum += points[idx] * weight
                total_weight += weight
        if total_weight > 0:
            smoothed.append(weighted_sum / total_weight)
        else:
            smoothed.append(points[i].copy())
    return smoothed

class TSDE_OT_WalkflyRecorder(bpy.types.Operator):
    bl_idname = "tsde.walkfly_recorder"
    bl_label = "Walk/Fly Recorder"
    bl_description = "Startet Walk/Fly Modus mit Aufnahme"
    
    _timer = None
    frame_count = 0
    base_speed = 0.05
    min_speed = 0.01
    max_speed = 0.5
    current_speed = 0.05
    rotate_speed = 0.002
    speed_multiplier = 1.0
    
    keys = {
        'W': False, 'A': False, 'S': False, 'D': False,
        'UP_ARROW': False, 'DOWN_ARROW': False,
        'LEFT_ARROW': False, 'RIGHT_ARROW': False,
        'LEFT_SHIFT': False, 'RIGHT_SHIFT': False,
        'SPACE': False
    }
    
    mouse_active = False
    mouse_center_x = 0
    mouse_center_y = 0
    last_dx = 0
    last_dy = 0

    def modal(self, context, event):
        global WALKFLY_PIVOT_POINTS, WALKFLY_LENS_POINTS

        if event.type == 'ESC':
            return self.finish(context)

        if event.type in self.keys:
            if event.value == 'PRESS':
                self.keys[event.type] = True
            if event.value == 'RELEASE':
                self.keys[event.type] = False
        
        if event.type in ('LEFT_SHIFT', 'RIGHT_SHIFT'):
            self.keys['LEFT_SHIFT'] = (event.value == 'PRESS')
            self.keys['RIGHT_SHIFT'] = (event.value == 'PRESS')
        
        if event.type == 'SPACE':
            self.keys['SPACE'] = (event.value == 'PRESS')
        
        if event.type == 'WHEELUPMOUSE':
            self.current_speed = min(self.max_speed * self.speed_multiplier, self.current_speed * 1.2)
            print(f"⚡ Speed: {self.current_speed:.3f}")
        if event.type == 'WHEELDOWNMOUSE':
            self.current_speed = max(self.min_speed, self.current_speed * 0.8)
            print(f"⚡ Speed: {self.current_speed:.3f}")
        
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if context.area and context.area.type == 'VIEW_3D':
                self.mouse_active = True
                self.mouse_center_x = context.area.x + context.area.width // 2
                self.mouse_center_y = context.area.y + context.area.height // 2
                context.window.cursor_warp(self.mouse_center_x, self.mouse_center_y)
                print("🎮 Relative Maus AKTIV")
        
        if self.mouse_active and event.type == 'MOUSEMOVE':
            dx = event.mouse_x - self.mouse_center_x
            dy = event.mouse_y - self.mouse_center_y
            if abs(dx) > 0 or abs(dy) > 0:
                cam = context.scene.camera
                if cam:
                    rot = cam.rotation_euler.copy()
                    rot.z -= dx * self.rotate_speed
                    rot.x += dy * self.rotate_speed
                    rot.x = max(-math.pi/2 + 0.01, min(math.pi/2 - 0.01, rot.x))
                    cam.rotation_euler = rot
                    self.last_dx = dx
                    self.last_dy = dy
                context.window.cursor_warp(self.mouse_center_x, self.mouse_center_y)
        
        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            self.mouse_active = False
            print("🎮 Relative Maus DEAKTIVIERT")

        if event.type == 'TIMER':
            cam = context.scene.camera
            if not cam:
                return {'PASS_THROUGH'}
            
            self.speed_multiplier = context.scene.tsde_speed_multiplier
            speed = self.current_speed * self.speed_multiplier
            loc = cam.location.copy()
            moved = False
            
            forward = self.get_forward(cam)
            if self.keys['W']:
                loc += forward * speed
                moved = True
            if self.keys['S']:
                loc -= forward * speed
                moved = True
            
            right = self.get_right(cam)
            if self.keys['A']:
                loc -= right * speed
                moved = True
            if self.keys['D']:
                loc += right * speed
                moved = True
            
            if self.keys['LEFT_SHIFT'] or self.keys['RIGHT_SHIFT']:
                loc.z += speed
                moved = True
            if self.keys['SPACE']:
                loc.z -= speed
                moved = True
            
            rot = cam.rotation_euler.copy()
            rotated = False
            
            if self.keys['UP_ARROW']:
                rot.x -= self.rotate_speed * 4
                rotated = True
            if self.keys['DOWN_ARROW']:
                rot.x += self.rotate_speed * 4
                rotated = True
            if self.keys['LEFT_ARROW']:
                rot.z -= self.rotate_speed * 4
                rotated = True
            if self.keys['RIGHT_ARROW']:
                rot.z += self.rotate_speed * 4
                rotated = True
            
            if rotated:
                rot.x = max(-math.pi/2 + 0.01, min(math.pi/2 - 0.01, rot.x))
                cam.rotation_euler = rot
            
            if moved:
                cam.location = loc
            
            mouse_moved = self.mouse_active and (abs(self.last_dx) > 0 or abs(self.last_dy) > 0)
            if moved or rotated or mouse_moved:
                pivot_pos = cam.location.copy()
                # EXAKTE Lens-Berechnung
                WALKFLY_PIVOT_POINTS.append(pivot_pos)
                WALKFLY_LENS_POINTS.append(get_lens_position_exact(cam))
                self.frame_count += 1
                if self.frame_count % 10 == 0:
                    print(f"\n🎥 Frame {self.frame_count:4d}")
            
            if context.area:
                context.area.tag_redraw()

        return {'RUNNING_MODAL'}

    def get_forward(self, obj):
        return obj.matrix_world.to_quaternion() @ Vector((0, 0, -1))
    
    def get_right(self, obj):
        return obj.matrix_world.to_quaternion() @ Vector((1, 0, 0))

    def execute(self, context):
        global WALKFLY_PIVOT_POINTS, WALKFLY_LENS_POINTS
        WALKFLY_PIVOT_POINTS = []
        WALKFLY_LENS_POINTS = []
        self.frame_count = 0
        self.mouse_active = False
        self.current_speed = self.base_speed
        
        if not context.scene.camera:
            cam_data = bpy.data.cameras.new("TSDE_Camera")
            cam = bpy.data.objects.new("TSDE_Camera", cam_data)
            context.scene.collection.objects.link(cam)
            context.scene.camera = cam
        
        wm = context.window_manager
        self._timer = wm.event_timer_add(1/60, window=context.window)
        wm.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}

    def finish(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)

        pivot_raw = WALKFLY_PIVOT_POINTS
        lens_raw = WALKFLY_LENS_POINTS

        if len(pivot_raw) < 2:
            self.report({'WARNING'}, "Zu wenig Frames!")
            return {'CANCELLED'}

        # Glättung
        pivot_smoothed = gaussian_smooth(pivot_raw, sigma=1.5)
        lens_smoothed = gaussian_smooth(lens_raw, sigma=1.5)
        pivot_smoothed = smooth_spline_points(pivot_smoothed, factor=0.2, iterations=2)
        lens_smoothed = smooth_spline_points(lens_smoothed, factor=0.2, iterations=2)

        # Resampling
        target_segment_length = 0.05
        pivot_resampled = resample_spline_points(pivot_smoothed, target_segment_length)
        lens_resampled = resample_spline_points(lens_smoothed, target_segment_length)

        # Alte Splines löschen
        for obj in context.scene.objects:
            if obj.name.startswith("WalkFly_"):
                bpy.data.objects.remove(obj, do_unlink=True)

        # Neue Splines
        create_visible_spline("WalkFly_Pivot", pivot_resampled, (1.0, 0.5, 0.0, 1.0), context)
        create_visible_spline("WalkFly_Lens", lens_resampled, (0.0, 0.8, 1.0, 1.0), context)

        self.report({'INFO'}, f"Walk/Fly: {len(pivot_resampled)} Punkte")
        return {'FINISHED'}


# =====================================================================
# MODUL 2: SMOOTH KEYFRAME RECORDER (Version 2.0.0 - mit exakter Lens)
# =====================================================================

SMOOTH_KEYFRAME_PIVOT_POINTS = []
SMOOTH_KEYFRAME_LENS_POINTS = []
SMOOTH_KEYFRAME_NAMES = []

# Smooth Interpolation Funktionen
def ease_in_out(t):
    return t * t * (3 - 2 * t)

def ease_in(t):
    return t * t

def ease_out(t):
    return 1 - (1 - t) * (1 - t)

def ease_elastic(t):
    return -2 * math.exp(-5*t) * math.cos(10*t) + 1

def ease_bounce(t):
    if t < 0.5:
        return 4 * t * t * t
    else:
        return 1 - math.pow(-2 * t + 2, 3) / 2

def catmull_rom_spline(p0, p1, p2, p3, t):
    t2 = t * t
    t3 = t2 * t
    v0 = (p2 - p0) * 0.5
    v1 = (p3 - p1) * 0.5
    return (2*t3 - 3*t2 + 1) * p1 + (t3 - 2*t2 + t) * v0 + (-2*t3 + 3*t2) * p2 + (t3 - t2) * v1

def bezier_interpolate(p0, p1, p2, p3, t):
    t2 = t * t
    t3 = t2 * t
    mt = 1 - t
    mt2 = mt * mt
    mt3 = mt2 * mt
    return mt3 * p0 + 3 * mt2 * t * p1 + 3 * mt * t2 * p2 + t3 * p3

def interpolate_points_smooth(points, steps_per_segment=10, method='CATMULL_ROM'):
    if len(points) < 2:
        return points
    
    result = []
    
    for i in range(len(points) - 1):
        p1 = points[i]
        p2 = points[i + 1]
        p0 = points[i - 1] if i > 0 else p1
        p3 = points[i + 2] if i + 2 < len(points) else p2
        
        for j in range(steps_per_segment):
            t = j / steps_per_segment
            
            if method == 'CATMULL_ROM':
                pt = catmull_rom_spline(p0, p1, p2, p3, t)
            elif method == 'BEZIER':
                pt = bezier_interpolate(p0, p1, p2, p3, t)
            elif method == 'EASE_IN_OUT':
                t_smooth = ease_in_out(t)
                pt = p1.lerp(p2, t_smooth)
            elif method == 'EASE_IN':
                t_smooth = ease_in(t)
                pt = p1.lerp(p2, t_smooth)
            elif method == 'EASE_OUT':
                t_smooth = ease_out(t)
                pt = p1.lerp(p2, t_smooth)
            elif method == 'ELASTIC':
                t_smooth = ease_elastic(t)
                pt = p1.lerp(p2, t_smooth)
            elif method == 'BOUNCE':
                t_smooth = ease_bounce(t)
                pt = p1.lerp(p2, t_smooth)
            else:
                pt = p1.lerp(p2, t)
            
            result.append(pt)
    
    result.append(points[-1].copy())
    return result

class TSDE_OT_SmoothGoToCamera(bpy.types.Operator):
    bl_idname = "tsde.smooth_goto_camera"
    bl_label = "Zur Kamera"
    bl_description = "Wechselt in die Kamera-Ansicht (Numpad 0)"
    
    def execute(self, context):
        if not context.scene.camera:
            self.report({'ERROR'}, "Keine Kamera in der Szene!")
            return {'CANCELLED'}
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].region_3d.view_perspective = 'CAMERA'
        return {'FINISHED'}

class TSDE_OT_SmoothSetKeyframe(bpy.types.Operator):
    bl_idname = "tsde.smooth_set_keyframe"
    bl_label = "Snapshot setzen"
    bl_description = "Speichert aktuelle Kameraposition als Keyframe"
    
    name: StringProperty(default="Key")
    
    def execute(self, context):
        global SMOOTH_KEYFRAME_PIVOT_POINTS, SMOOTH_KEYFRAME_LENS_POINTS, SMOOTH_KEYFRAME_NAMES
        
        cam = context.scene.camera
        if not cam:
            self.report({'ERROR'}, "Keine Kamera in der Szene!")
            return {'CANCELLED'}
        
        # Prüfen ob wir in der Kamera-Ansicht sind
        in_camera_view = False
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                if area.spaces[0].region_3d.view_perspective == 'CAMERA':
                    in_camera_view = True
                    break
        
        if not in_camera_view:
            self.report({'WARNING'}, "Nicht in Kamera-Ansicht! (Numpad 0)")
            return {'CANCELLED'}
        
        pivot_pos = cam.location.copy()
        # EXAKTE Lens-Berechnung
        lens_pos = get_lens_position_exact(cam)
        
        SMOOTH_KEYFRAME_PIVOT_POINTS.append(pivot_pos)
        SMOOTH_KEYFRAME_LENS_POINTS.append(lens_pos)
        
        if self.name == "Key":
            key_name = f"Key {len(SMOOTH_KEYFRAME_PIVOT_POINTS)}"
        else:
            key_name = f"{self.name} {len(SMOOTH_KEYFRAME_PIVOT_POINTS)}"
        
        SMOOTH_KEYFRAME_NAMES.append(key_name)
        
        self.report({'INFO'}, f"Snapshot {len(SMOOTH_KEYFRAME_PIVOT_POINTS)} gespeichert")
        return {'FINISHED'}

class TSDE_OT_SmoothDeleteLastKeyframe(bpy.types.Operator):
    bl_idname = "tsde.smooth_delete_last_keyframe"
    bl_label = "Letzten löschen"
    
    def execute(self, context):
        global SMOOTH_KEYFRAME_PIVOT_POINTS, SMOOTH_KEYFRAME_LENS_POINTS, SMOOTH_KEYFRAME_NAMES
        if SMOOTH_KEYFRAME_PIVOT_POINTS:
            SMOOTH_KEYFRAME_PIVOT_POINTS.pop()
            SMOOTH_KEYFRAME_LENS_POINTS.pop()
            SMOOTH_KEYFRAME_NAMES.pop()
        return {'FINISHED'}

class TSDE_OT_SmoothClearKeyframes(bpy.types.Operator):
    bl_idname = "tsde.smooth_clear_keyframes"
    bl_label = "Alle löschen"
    
    def execute(self, context):
        global SMOOTH_KEYFRAME_PIVOT_POINTS, SMOOTH_KEYFRAME_LENS_POINTS, SMOOTH_KEYFRAME_NAMES
        SMOOTH_KEYFRAME_PIVOT_POINTS = []
        SMOOTH_KEYFRAME_LENS_POINTS = []
        SMOOTH_KEYFRAME_NAMES = []
        return {'FINISHED'}

class TSDE_OT_GenerateSmoothSpline(bpy.types.Operator):
    bl_idname = "tsde.generate_smooth_spline"
    bl_label = "Smooth Spline generieren"
    bl_description = "Erzeugt smooth interpolierte Splines aus den Snapshots"
    
    steps_between: IntProperty(default=20, min=5, max=200)
    interpolation_method: EnumProperty(
        items=[
            ('LINEAR', "Linear", ""),
            ('EASE_IN_OUT', "Ease In/Out", ""),
            ('EASE_IN', "Ease In", ""),
            ('EASE_OUT', "Ease Out", ""),
            ('CATMULL_ROM', "Catmull-Rom", ""),
            ('BEZIER', "Bezier", ""),
            ('ELASTIC', "Elastic", ""),
            ('BOUNCE', "Bounce", "")
        ],
        default='CATMULL_ROM'
    )
    use_resample: BoolProperty(default=True)
    segment_length: FloatProperty(default=0.005, min=0.001, max=0.1, precision=3)
    
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="🎯 INTERPOLATION:")
        col.prop(self, "interpolation_method")
        col.prop(self, "steps_between")
        
        col.separator()
        col.label(text="🔄 RESAMPLING:")
        col.prop(self, "use_resample")
        if self.use_resample:
            col.prop(self, "segment_length")
    
    def execute(self, context):
        global SMOOTH_KEYFRAME_PIVOT_POINTS, SMOOTH_KEYFRAME_LENS_POINTS
        
        if len(SMOOTH_KEYFRAME_PIVOT_POINTS) < 2:
            self.report({'ERROR'}, "Mindestens 2 Snapshots benötigt!")
            return {'CANCELLED'}
        
        # Smooth Interpolation
        all_pivot = interpolate_points_smooth(
            SMOOTH_KEYFRAME_PIVOT_POINTS, 
            self.steps_between,
            self.interpolation_method
        )
        all_lens = interpolate_points_smooth(
            SMOOTH_KEYFRAME_LENS_POINTS, 
            self.steps_between,
            self.interpolation_method
        )
        
        # Optional: Resampling
        if self.use_resample:
            all_pivot = resample_spline_points(all_pivot, self.segment_length)
            all_lens = resample_spline_points(all_lens, self.segment_length)
        
        # Alte Splines löschen
        for obj in context.scene.objects:
            if obj.name.startswith("Smooth_Spline"):
                bpy.data.objects.remove(obj, do_unlink=True)
        
        # Pivot-Spline
        pivot_obj = create_visible_spline("Smooth_Spline_Pivot", all_pivot, (1.0, 0.5, 0.0, 1.0), context)
        lens_obj = create_visible_spline("Smooth_Spline_Lens", all_lens, (0.0, 0.8, 1.0, 1.0), context)
        
        self.report({'INFO'}, f"Smooth Spline mit {len(all_pivot)} Punkten generiert")
        return {'FINISHED'}


# =====================================================================
# MODUL 3: KEYFRAME GENERATOR (Der Retter - NUR SPLINES)
# =====================================================================

class TSDE_KeyframeRetterProperties(bpy.types.PropertyGroup):
    target_segment_length: FloatProperty(
        name="Segmentlänge",
        description="Ziel-Länge der Segmente nach Resampling (wie Prototyp: 0.005)",
        default=0.005,
        min=0.001,
        max=0.1,
        precision=3,
        step=0.001
    )
    
    use_active_camera: BoolProperty(
        name="Aktive Kamera verwenden",
        description="Die aktuell aktive Kamera verwenden",
        default=True
    )

class TSDE_OT_GenerateKeyframeSplines(bpy.types.Operator):
    bl_idname = "tsde.generate_keyframe_splines"
    bl_label = "Generiere Keyframe Splines"
    bl_description = "Erzeugt Pivot und Lens Splines aus Kamerakeyframes (wie Prototyp)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        props = context.scene.tsde_keyframe_retter_props
        
        TARGET_SEGMENT_LENGTH = props.target_segment_length

        # Kamera finden
        if props.use_active_camera:
            cam = scene.camera
        else:
            for obj in scene.objects:
                if obj.type == 'CAMERA':
                    cam = obj
                    break
            else:
                cam = None

        if not cam:
            self.report({'ERROR'}, "Keine Kamera gefunden!")
            return {'CANCELLED'}

        pivot = bpy.data.objects.get("CameraPivot")

        # Keyframe-Bereich ermitteln
        if cam.animation_data and cam.animation_data.action:
            keyframes = set()
            for fcurve in cam.animation_data.action.fcurves:
                for keyframe in fcurve.keyframe_points:
                    keyframes.add(int(keyframe.co[0]))
            
            if keyframes:
                start = min(keyframes)
                end = max(keyframes)
            else:
                start = scene.frame_start
                end = scene.frame_end
        else:
            start = scene.frame_start
            end = scene.frame_end

        current_frame = scene.frame_current

        # Punkte sammeln (wie Prototyp)
        original_lens_points = []
        original_pivot_points = []

        for f in range(start, end + 1):
            scene.frame_set(f)

            forward = cam.matrix_world.to_quaternion() @ mathutils.Vector((0, 0, -1))
            lens_mm = cam.data.lens
            sensor_mm = (
                cam.data.sensor_height
                if cam.data.sensor_fit == 'VERTICAL'
                else cam.data.sensor_width
            )
            lens_offset = lens_mm / sensor_mm
            lens_center = cam.matrix_world.translation + forward * lens_offset
            original_lens_points.append(lens_center)

            if pivot:
                original_pivot_points.append(pivot.matrix_world.translation.copy())
            else:
                original_pivot_points.append(cam.matrix_world.translation.copy())

        scene.frame_set(current_frame)

        # Resample
        resampled_lens_points = resample_spline_points(original_lens_points, TARGET_SEGMENT_LENGTH)
        resampled_pivot_points = resample_spline_points(original_pivot_points, TARGET_SEGMENT_LENGTH)

        # Alte Keyframe-Splines löschen
        for obj in list(bpy.data.objects):
            if obj.name.startswith("Keyframe_") and "Spline" in obj.name:
                bpy.data.objects.remove(obj, do_unlink=True)

        # Splines erzeugen
        lens_curve = bpy.data.curves.new("Keyframe_LensSpline", type="CURVE")
        lens_curve.dimensions = '3D'
        lens_spline = lens_curve.splines.new(type='POLY')
        lens_spline.points.add(len(resampled_lens_points) - 1)
        for i, p in enumerate(resampled_lens_points):
            lens_spline.points[i].co = (p.x, p.y, p.z, 1)

        pivot_curve = bpy.data.curves.new("Keyframe_PivotSpline", type="CURVE")
        pivot_curve.dimensions = '3D'
        pivot_spline = pivot_curve.splines.new(type='POLY')
        pivot_spline.points.add(len(resampled_pivot_points) - 1)
        for i, p in enumerate(resampled_pivot_points):
            pivot_spline.points[i].co = (p.x, p.y, p.z, 1)

        lens_obj = bpy.data.objects.new("Keyframe_LensSpline", lens_curve)
        pivot_obj = bpy.data.objects.new("Keyframe_PivotSpline", pivot_curve)
        
        if hasattr(lens_obj, "color"):
            lens_obj.color = (0.0, 0.8, 1.0, 1.0)
        if hasattr(pivot_obj, "color"):
            pivot_obj.color = (1.0, 0.5, 0.0, 1.0)
        
        context.collection.objects.link(lens_obj)
        context.collection.objects.link(pivot_obj)

        self.report({'INFO'}, 
            f"✅ Splines generiert: {len(resampled_pivot_points)} Pivot, {len(resampled_lens_points)} Lens"
        )
        
        return {'FINISHED'}


# =====================================================================
# PROPERTIES
# =====================================================================

class TSDE_Properties(bpy.types.PropertyGroup):
    # Walk/Fly
    walkfly_speed: FloatProperty(name="Speed Multiplier", default=1.0, min=0.1, max=5.0)
    
    # Smooth Keyframe
    smooth_keyframe_name: StringProperty(name="Name", default="Key")


# =====================================================================
# PANELS (3 perfekte Sektionen)
# =====================================================================

class TSDE_PT_MainPanel(bpy.types.Panel):
    bl_label = "TSDE Suite"
    bl_idname = "TSDE_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="🎮 TSDE Tools", icon='TOOL_SETTINGS')


# SEKTION 1: Walk/Fly Recorder
class TSDE_PT_Walkfly(bpy.types.Panel):
    bl_label = "1. Walk/Fly Recorder"
    bl_idname = "TSDE_PT_walkfly"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_props
        
        box = layout.box()
        col = box.column(align=True)
        
        col.prop(props, "walkfly_speed")
        col.separator()
        col.operator("tsde.walkfly_recorder", text="🎮 START WALK/FLY", icon='PLAY')
        
        if WALKFLY_PIVOT_POINTS:
            col.label(text=f"Frames: {len(WALKFLY_PIVOT_POINTS)}")
        
        col.separator()
        col.label(text="Steuerung:")
        col.label(text="• Linke Maus = Rotation")
        col.label(text="• Mausrad = Speed")
        col.label(text="• W/A/S/D = Bewegen")
        col.label(text="• Shift/Space = Auf/Ab")
        col.label(text="• ESC = Beenden")


# SEKTION 2: Smooth Keyframe Recorder (Version 2.0.0)
class TSDE_PT_SmoothKeyframe(bpy.types.Panel):
    bl_label = "2. Smooth Keyframe Recorder"
    bl_idname = "TSDE_PT_smooth_keyframe"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_props
        global SMOOTH_KEYFRAME_NAMES
        
        # Kamera-Info
        if context.scene.camera:
            cam = context.scene.camera
            box = layout.box()
            col = box.column(align=True)
            col.label(text=f"Kamera: {cam.name}", icon='CAMERA_DATA')
            
            # Prüfen ob in Kamera-Ansicht
            in_camera = False
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    if area.spaces[0].region_3d.view_perspective == 'CAMERA':
                        in_camera = True
                        break
            
            if in_camera:
                col.label(text="📷 Kamera-Ansicht", icon='VIEWZOOM')
            else:
                col.label(text="⚠️ Nicht in Kamera-Ansicht", icon='ERROR')
                col.operator("tsde.smooth_goto_camera", text="📷 Zur Kamera")
        
        # Keyframe-Steuerung
        box = layout.box()
        col = box.column(align=True)
        col.label(text="📸 SNAPSHOTS:", icon='KEYINGSET')
        
        # Snapshot setzen
        row = col.row(align=True)
        row.prop(props, "smooth_keyframe_name", text="")
        row.operator("tsde.smooth_set_keyframe", text="Setzen", icon='ADD')
        
        # Snapshots verwalten
        row = col.row(align=True)
        row.operator("tsde.smooth_delete_last_keyframe", text="Letzten", icon='REMOVE')
        row.operator("tsde.smooth_clear_keyframes", text="Alle", icon='X')
        
        # Liste der Snapshots
        if len(SMOOTH_KEYFRAME_NAMES) > 0:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="📋 GESPEICHERTE SNAPSHOTS:")
            for i, name in enumerate(SMOOTH_KEYFRAME_NAMES):
                col.label(text=f"{i+1}. {name}")
        
        # Smooth Spline-Generierung
        if len(SMOOTH_KEYFRAME_PIVOT_POINTS) >= 2:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="✨ SMOOTH SPLINE:", icon='CURVE_DATA')
            
            # Operator mit eigener UI
            op = col.operator("tsde.generate_smooth_spline", 
                            text="🎯 SMOOTH SPLINE ERSTELLEN", 
                            icon='PLAY')
            
            col.separator()
            col.label(text="Empfehlung: Catmull-Rom")


# SEKTION 3: Keyframe Generator (Der Retter - NUR SPLINES)
class TSDE_PT_KeyframeGenerator(bpy.types.Panel):
    bl_label = "3. Keyframe Generator (Retter)"
    bl_idname = "TSDE_PT_keyframe_generator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_keyframe_retter_props
        
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="⚙️ EINSTELLUNGEN:", icon='SETTINGS')
        col.prop(props, "target_segment_length")
        col.prop(props, "use_active_camera")
        
        col.separator()
        
        # Info über aktive Kamera
        if context.scene.camera:
            col.label(text=f"📷 Kamera: {context.scene.camera.name}", icon='CAMERA_DATA')
        else:
            col.label(text="⚠️ Keine aktive Kamera", icon='ERROR')
        
        col.separator()
        
        # Info-Box
        box = layout.box()
        col = box.column(align=True)
        col.label(text="ℹ️ NUR SPLINES:", icon='INFO')
        col.label(text="• Analysiert Keyframes der Kamera")
        col.label(text="• Erzeugt Pivot (orange) & Lens (blau)")
        col.label(text="• Resampling auf konstante Länge")
        col.label(text="• Wie im TSDE-Prototyp")
        
        col.separator()
        
        # Hauptbutton
        row = col.row(align=True)
        row.scale_y = 2.0
        row.operator("tsde.generate_keyframe_splines", text="🎯 SPLINES GENERIEREN", icon='CURVE_DATA')


# =====================================================================
# REGISTRATION
# =====================================================================

classes = (
    # Properties
    TSDE_Properties,
    TSDE_KeyframeRetterProperties,
    
    # Walk/Fly
    TSDE_OT_WalkflyRecorder,
    
    # Smooth Keyframe Recorder
    TSDE_OT_SmoothGoToCamera,
    TSDE_OT_SmoothSetKeyframe,
    TSDE_OT_SmoothDeleteLastKeyframe,
    TSDE_OT_SmoothClearKeyframes,
    TSDE_OT_GenerateSmoothSpline,
    
    # Keyframe Generator (Retter)
    TSDE_OT_GenerateKeyframeSplines,
    
    # Panels
    TSDE_PT_MainPanel,
    TSDE_PT_Walkfly,
    TSDE_PT_SmoothKeyframe,
    TSDE_PT_KeyframeGenerator,
)

def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except:
            bpy.utils.unregister_class(cls)
            bpy.utils.register_class(cls)
    
    # Globale Properties
    bpy.types.Scene.tsde_props = PointerProperty(type=TSDE_Properties)
    bpy.types.Scene.tsde_keyframe_retter_props = PointerProperty(type=TSDE_KeyframeRetterProperties)
    
    # Einzelne Properties
    bpy.types.Scene.tsde_speed_multiplier = FloatProperty(default=1.0)
    
    print("\n" + "="*60)
    print("🎮 TSDE COMPLETE SUITE")
    print("="*60)
    print("✅ Walk/Fly Recorder (v1.8.0)")
    print("✅ Smooth Keyframe Recorder (v2.0.0)")
    print("✅ Keyframe Generator (NUR SPLINES)")
    print("✅ EXAKTE Lens-Berechnung: cam_pos + forward * (lens_mm / sensor_mm)")
    print("="*60 + "\n")

def unregister():
    del bpy.types.Scene.tsde_props
    del bpy.types.Scene.tsde_keyframe_retter_props
    del bpy.types.Scene.tsde_speed_multiplier
    
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass

if __name__ == "__main__":
    register()