# blender_tsde_connector.py
"""
Blender Add-on zur Steuerung der TSDE Engine.
"""

bl_info = {
    "name": "TSDE Engine Connector",
    "author": "Dein Name",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > TSDE",
    "description": "Steuert die TSDE Motion Control Engine von Blender aus",
    "category": "Animation"
}

import bpy
import sys
import os
from pathlib import Path
import json

# TSDE API importieren
try:
    # Pfad zur TSDE Installation anpassen
    tsde_path = Path("/pfad/zu/tsde")  # Anpassen!
    if tsde_path.exists():
        sys.path.append(str(tsde_path))
    
    from tsde_gui.external_api import get_controller
    TSDE_AVAILABLE = True
except ImportError:
    TSDE_AVAILABLE = False
    print("TSDE API nicht gefunden")


# ============================================================
# BLENDER OPERATORS
# ============================================================

class TSDE_OT_Connect(bpy.types.Operator):
    """Verbinde mit TSDE Engine"""
    bl_idname = "tsde.connect"
    bl_label = "Verbinde mit TSDE"
    bl_description = "Stellt Verbindung zur TSDE Engine her"
    
    def execute(self, context):
        if not TSDE_AVAILABLE:
            self.report({'ERROR'}, "TSDE API nicht verfügbar")
            return {'CANCELLED'}
        
        controller = get_controller()
        context.scene.tsde_controller = controller
        
        self.report({'INFO'}, "TSDE Verbindung hergestellt")
        return {'FINISHED'}


class TSDE_OT_LoadSetup(bpy.types.Operator):
    """Lade TSDE Setup"""
    bl_idname = "tsde.load_setup"
    bl_label = "Setup laden"
    bl_description = "Lädt ein TSDE Setup"
    
    filepath: bpy.props.StringProperty(
        name="Setup Datei",
        description="Pfad zur JSON Setup-Datei",
        subtype='FILE_PATH'
    )
    
    def execute(self, context):
        controller = context.scene.tsde_controller
        if not controller:
            self.report({'ERROR'}, "Nicht mit TSDE verbunden")
            return {'CANCELLED'}
        
        success = controller.load_setup(self.filepath)
        if success:
            self.report({'INFO'}, f"Setup geladen: {self.filepath}")
            
            # Track-Namen in Blender Properties speichern
            tracks = controller.get_track_names()
            context.scene.tsde_tracks.clear()
            for track in tracks:
                item = context.scene.tsde_tracks.add()
                item.name = track
                item.value = 1.0  # Default 100%
        else:
            self.report({'ERROR'}, "Setup konnte nicht geladen werden")
        
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class TSDE_OT_StartEngine(bpy.types.Operator):
    """Starte TSDE Engine"""
    bl_idname = "tsde.start_engine"
    bl_label = "Engine starten"
    bl_description = "Startet die TSDE Engine"
    
    def execute(self, context):
        controller = context.scene.tsde_controller
        if not controller:
            self.report({'ERROR'}, "Nicht mit TSDE verbunden")
            return {'CANCELLED'}
        
        success = controller.start_engine()
        if success:
            self.report({'INFO'}, "Engine gestartet")
            context.scene.tsde_engine_running = True
        else:
            self.report({'ERROR'}, "Engine konnte nicht gestartet werden")
        
        return {'FINISHED'}


class TSDE_OT_StopEngine(bpy.types.Operator):
    """Stoppe TSDE Engine"""
    bl_idname = "tsde.stop_engine"
    bl_label = "Engine stoppen"
    bl_description = "Stoppt die TSDE Engine"
    
    def execute(self, context):
        controller = context.scene.tsde_controller
        if not controller:
            self.report({'ERROR'}, "Nicht mit TSDE verbunden")
            return {'CANCELLED'}
        
        success = controller.stop_engine()
        if success:
            self.report({'INFO'}, "Engine gestoppt")
            context.scene.tsde_engine_running = False
        else:
            self.report({'ERROR'}, "Engine konnte nicht gestoppt werden")
        
        return {'FINISHED'}


class TSDE_OT_ResetTracks(bpy.types.Operator):
    """Setze Tracks zurück"""
    bl_idname = "tsde.reset_tracks"
    bl_label = "Tracks zurücksetzen"
    bl_description = "Setzt alle Tracks zurück"
    
    def execute(self, context):
        controller = context.scene.tsde_controller
        if not controller:
            self.report({'ERROR'}, "Nicht mit TSDE verbunden")
            return {'CANCELLED'}
        
        success = controller.reset_tracks()
        if success:
            self.report({'INFO'}, "Tracks zurückgesetzt")
        else:
            self.report({'ERROR'}, "Tracks konnten nicht zurückgesetzt werden")
        
        return {'FINISHED'}


class TSDE_OT_SetTrackPedal(bpy.types.Operator):
    """Setze Pedal für einen Track"""
    bl_idname = "tsde.set_track_pedal"
    bl_label = "Pedal setzen"
    bl_description = "Setzt Pedal-Wert für einen Track"
    
    track_name: bpy.props.StringProperty()
    value: bpy.props.FloatProperty(min=0.0, max=1.0, default=1.0)
    
    def execute(self, context):
        controller = context.scene.tsde_controller
        if not controller:
            self.report({'ERROR'}, "Nicht mit TSDE verbunden")
            return {'CANCELLED'}
        
        success = controller.set_track_pedal(self.track_name, self.value)
        if success:
            self.report({'INFO'}, f"Pedal für {self.track_name}: {self.value:.1%}")
        else:
            self.report({'ERROR'}, f"Pedal für {self.track_name} konnte nicht gesetzt werden")
        
        return {'FINISHED'}


class TSDE_OT_SetGlobalPedal(bpy.types.Operator):
    """Setze globales Pedal"""
    bl_idname = "tsde.set_global_pedal"
    bl_label = "Globales Pedal"
    bl_description = "Setzt Pedal für alle Tracks"
    
    value: bpy.props.FloatProperty(
        name="Pedal Wert",
        description="Pedal Wert (0.0 - 1.0)",
        min=0.0,
        max=1.0,
        default=1.0,
        subtype='FACTOR'
    )
    
    def execute(self, context):
        controller = context.scene.tsde_controller
        if not controller:
            self.report({'ERROR'}, "Nicht mit TSDE verbunden")
            return {'CANCELLED'}
        
        success = controller.set_global_pal(self.value)
        if success:
            self.report({'INFO'}, f"Globales Pedal: {self.value:.1%}")
        else:
            self.report({'ERROR'}, "Globales Pedal konnte nicht gesetzt werden")
        
        return {'FINISHED'}


# ============================================================
# BLENDER PROPERTIES
# ============================================================

class TSDE_TrackProperty(bpy.types.PropertyGroup):
    """Property für einen TSDE Track"""
    name: bpy.props.StringProperty(name="Track Name")
    value: bpy.props.FloatProperty(
        name="Pedal",
        min=0.0,
        max=1.0,
        default=1.0,
        subtype='FACTOR',
        update=lambda self, context: self.update_pedal(context)
    )
    
    def update_pedal(self, context):
        """Wird aufgerufen wenn sich der Pedal-Wert ändert"""
        bpy.ops.tsde.set_track_pedal(track_name=self.name, value=self.value)


# ============================================================
# BLENDER UI PANEL
# ============================================================

class TSDE_PT_MainPanel(bpy.types.Panel):
    """Haupt-Panel für TSDE Steuerung"""
    bl_label = "TSDE Engine Control"
    bl_idname = "TSDE_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        # Verbindungs-Status
        box = layout.box()
        box.label(text="Verbindung", icon='CONSOLE')
        
        if not TSDE_AVAILABLE:
            box.label(text="TSDE nicht verfügbar", icon='ERROR')
            return
        
        if not scene.tsde_controller:
            box.operator("tsde.connect", icon='PLUGIN')
        else:
            box.label(text="Verbunden", icon='CHECKMARK')
            
            # Setup laden
            box.operator("tsde.load_setup", icon='FILE_FOLDER')
            
            if scene.tsde_tracks:
                box.label(text=f"Tracks: {len(scene.tsde_tracks)}", icon='ANIM')
            
            # Engine Control
            box = layout.box()
            box.label(text="Engine Control", icon='PLAY')
            
            row = box.row()
            if not scene.tsde_engine_running:
                row.operator("tsde.start_engine", icon='PLAY')
            else:
                row.operator("tsde.stop_engine", icon='PAUSE')
                row.operator("tsde.reset_tracks", icon='LOOP_BACK')
            
            # Globales Pedal
            if scene.tsde_tracks:
                box = layout.box()
                box.label(text="Global Control", icon='WORLD')
                
                row = box.row()
                row.prop(scene, "tsde_global_pedal", slider=True)
                row.operator("tsde.set_global_pedal", text="", icon='CHECKMARK').value = scene.tsde_global_pedal
            
            # Individuelle Tracks
            if scene.tsde_tracks:
                box = layout.box()
                box.label(text="Track Control", icon='GRAPH')
                
                for track in scene.tsde_tracks:
                    row = box.row()
                    row.label(text=track.name)
                    row.prop(track, "value", slider=True, text="")
            
            # Status Info
            if scene.tsde_engine_running:
                box = layout.box()
                box.label(text="Status: Laufend", icon='TIME')
                
                # Hier könntest du regelmäßig Track-Daten abfragen
                # und in Blender anzeigen (als Timer)
                box.operator("tsde.refresh_status", text="Status aktualisieren", icon='FILE_REFRESH')


# ============================================================
# REGISTRIERUNG
# ============================================================

classes = [
    TSDE_TrackProperty,
    TSDE_OT_Connect,
    TSDE_OT_LoadSetup,
    TSDE_OT_StartEngine,
    TSDE_OT_StopEngine,
    TSDE_OT_ResetTracks,
    TSDE_OT_SetTrackPedal,
    TSDE_OT_SetGlobalPedal,
    TSDE_PT_MainPanel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Blender Properties
    bpy.types.Scene.tsde_controller = None
    bpy.types.Scene.tsde_tracks = bpy.props.CollectionProperty(type=TSDE_TrackProperty)
    bpy.types.Scene.tsde_engine_running = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.tsde_global_pedal = bpy.props.FloatProperty(
        name="Global Pedal",
        min=0.0,
        max=1.0,
        default=1.0,
        subtype='FACTOR'
    )

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    
    # Properties löschen
    del bpy.types.Scene.tsde_controller
    del bpy.types.Scene.tsde_tracks
    del bpy.types.Scene.tsde_engine_running
    del bpy.types.Scene.tsde_global_pedal

if __name__ == "__main__":
    register()