bl_info = {
    "name": "TSDE Live Connect",
    "author": "Benjamin",
    "version": (1, 0, 1),
    "blender": (3, 0, 0),
    "location": "3D View > Sidebar > TSDE Live",
    "description": "Verbindet Blender mit der TSDE Live Engine",
    "category": "3D View"
}

import bpy
import os
import json
import subprocess
import tempfile
from mathutils import Vector
from bpy.props import (
    StringProperty,
    BoolProperty,
    FloatProperty,
    IntProperty,  # <-- WICHTIG: Dieser Import fehlte!
    PointerProperty,
    EnumProperty
)
from bpy.types import Panel, Operator, PropertyGroup


# =====================================================================
# HILFSFUNKTIONEN: SPLINE → CSV
# =====================================================================

def spline_to_csv_data(spline_obj, num_points=100):
    """
    Konvertiert einen Blender Spline in CSV-Daten
    Format: x,y,z (eine Zeile pro Punkt)
    """
    if not spline_obj or spline_obj.type != 'CURVE':
        return []
    
    # Alle Punkte aus dem Spline sammeln
    points = []
    for spline in spline_obj.data.splines:
        if spline.type == 'POLY':
            for point in spline.points:
                points.append(Vector(point.co[:3]))
        elif spline.type == 'BEZIER':
            for point in spline.bezier_points:
                points.append(point.co.copy())
    
    # Wenn wir mehr Punkte wollen, interpolieren wir
    if len(points) < 2:
        return []
    
    if len(points) >= num_points:
        # Genug Punkte vorhanden
        step = len(points) / num_points
        csv_data = []
        for i in range(num_points):
            idx = min(int(i * step), len(points) - 1)
            p = points[idx]
            csv_data.append(f"{p.x:.6f},{p.y:.6f},{p.z:.6f}")
        return csv_data
    else:
        # Weniger Punkte -> linear interpolieren
        csv_data = []
        for i in range(num_points):
            t = i / (num_points - 1)
            # Lineare Interpolation entlang der Kurve
            pos = len(points) - 1
            idx = t * pos
            i1 = int(idx)
            i2 = min(i1 + 1, len(points) - 1)
            frac = idx - i1
            
            if i1 == i2:
                p = points[i1]
            else:
                p = points[i1].lerp(points[i2], frac)
            
            csv_data.append(f"{p.x:.6f},{p.y:.6f},{p.z:.6f}")
        
        return csv_data


def save_csv_file(csv_data, filepath):
    """Speichert CSV-Daten in eine Datei"""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w') as f:
        for line in csv_data:
            f.write(line + '\n')
    return filepath


# =====================================================================
# HILFSFUNKTIONEN: RIG ANALYSIEREN
# =====================================================================

def find_rig_objects(context, group_name):
    """Findet alle Objekte einer Rig-Gruppe"""
    group = bpy.data.collections.get(group_name)
    if not group:
        return None, None, None
    
    pivot_empty = None
    lens_empty = None
    camera = None
    
    for obj in group.objects:
        if obj.name.endswith("_Pivot"):
            pivot_empty = obj
        elif obj.name.endswith("_Lens"):
            lens_empty = obj
        elif obj.type == 'CAMERA':
            camera = obj
    
    # Splines finden (Follow Path Targets)
    pivot_spline = None
    lens_spline = None
    
    if pivot_empty and pivot_empty.constraints:
        for c in pivot_empty.constraints:
            if c.type == 'FOLLOW_PATH' and c.target:
                pivot_spline = c.target.name
    
    if lens_empty and lens_empty.constraints:
        for c in lens_empty.constraints:
            if c.type == 'FOLLOW_PATH' and c.target:
                lens_spline = c.target.name
    
    return {
        'group': group,
        'pivot_empty': pivot_empty,
        'lens_empty': lens_empty,
        'camera': camera,
        'pivot_spline': pivot_spline,
        'lens_spline': lens_spline
    }


# =====================================================================
# OPERATOR: SETUP FÜR ENGINE EXPORTIEREN
# =====================================================================

class TSDE_OT_ExportSetup(Operator):
    bl_idname = "tsde.export_setup"
    bl_label = "Setup exportieren"
    bl_description = "Exportiert Rig als Setup für die TSDE Engine"
    bl_options = {'REGISTER'}

    group_name: StringProperty(
        name="Group Name",
        description="Name der Rig-Gruppe",
        default="TSDE_Rig"
    )

    num_csv_points: IntProperty(  # <-- Jetzt funktioniert das!
        name="CSV Punkte",
        description="Anzahl der Punkte in den CSV-Dateien",
        default=100,
        min=10,
        max=1000
    )

    def execute(self, context):
        props = context.scene.tsde_live_props

        # Rig-Objekte finden
        rig = find_rig_objects(context, self.group_name)

        if not rig['pivot_spline'] or not rig['lens_spline']:
            self.report({'ERROR'}, "Keine gültigen Splines im Rig gefunden!")
            return {'CANCELLED'}

        # Spline-Objekte holen
        pivot_spline_obj = bpy.data.objects.get(rig['pivot_spline'])
        lens_spline_obj = bpy.data.objects.get(rig['lens_spline'])

        if not pivot_spline_obj or not lens_spline_obj:
            self.report({'ERROR'}, "Spline-Objekte nicht gefunden!")
            return {'CANCELLED'}

        # System-Verzeichnis für die Engine
        system_dir = props.engine_system_path
        if not system_dir:
            system_dir = os.path.join(tempfile.gettempdir(), "tsde_setups")

        os.makedirs(system_dir, exist_ok=True)

        # CSV-Dateien erstellen
        pivot_csv = os.path.join(system_dir, f"{self.group_name}_pivot.csv")
        lens_csv = os.path.join(system_dir, f"{self.group_name}_lens.csv")

        pivot_data = spline_to_csv_data(pivot_spline_obj, self.num_csv_points)
        lens_data = spline_to_csv_data(lens_spline_obj, self.num_csv_points)

        if not pivot_data or not lens_data:
            self.report({'ERROR'}, "Konnte keine CSV-Daten generieren!")
            return {'CANCELLED'}

        save_csv_file(pivot_data, pivot_csv)
        save_csv_file(lens_data, lens_csv)

        # JSON-Setup erstellen (wie in der Beispiel-Datei)
        setup_data = {
            "groups": [
                {
                    "name": self.group_name,
                    "tracks": [
                        {
                            "name": f"{self.group_name}_Pivot",
                            "max_speed": props.max_speed,
                            "focal_length": 0.0,
                            "curve": {
                                "source": "csv",
                                "path": pivot_csv,
                                "segment_length": props.segment_length
                            },
                            "track_type": "motion"
                        },
                        {
                            "name": f"{self.group_name}_Lens",
                            "max_speed": props.max_speed,
                            "focal_length": 0.0,
                            "curve": {
                                "source": "csv",
                                "path": lens_csv,
                                "segment_length": props.segment_length
                            },
                            "track_type": "motion"
                        },
                        {
                            "name": f"{self.group_name}_Camera",
                            "track_type": "empty",
                            "max_speed": 0.0,
                            "focal_length": rig['camera'].data.lens if rig['camera'] else 50.0,
                            "curve": {
                                "source": "empty",
                                "path": "",
                                "segment_length": 0.0
                            }
                        }
                    ]
                }
            ]
        }

        # Setup-JSON speichern
        setup_json = os.path.join(system_dir, f"{self.group_name}_setup.json")
        with open(setup_json, 'w') as f:
            json.dump(setup_data, f, indent=4)

        # Pfad speichern für später
        props.last_setup_path = setup_json
        props.setup_status = f"Setup gespeichert: {os.path.basename(setup_json)}"

        self.report({'INFO'}, f"✅ Setup exportiert: {setup_json}")
        return {'FINISHED'}


# =====================================================================
# OPERATOR: ENGINE STARTEN
# =====================================================================

class TSDE_OT_StartEngine(Operator):
    bl_idname = "tsde.start_engine"
    bl_label = "Engine starten"
    bl_description = "Startet die TSDE Engine mit dem aktuellen Setup"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.tsde_live_props

        # Prüfen ob Engine-Pfad existiert
        engine_path = props.engine_executable_path
        if not engine_path or not os.path.exists(engine_path):
            self.report({'ERROR'}, "Engine-Pfad nicht gefunden! Bitte in Einstellungen angeben.")
            return {'CANCELLED'}

        # Prüfen ob Setup existiert
        setup_path = props.last_setup_path
        if not setup_path or not os.path.exists(setup_path):
            self.report({'ERROR'}, "Kein gültiges Setup gefunden! Bitte zuerst exportieren.")
            return {'CANCELLED'}

        try:
            # Engine als Subprozess starten
            if props.engine_mode == 'BACKGROUND':
                # Im Hintergrund starten (kein Fenster)
                process = subprocess.Popen(
                    [engine_path, "--setup", setup_path, "--headless"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=os.path.dirname(engine_path)
                )
            else:
                # Mit Fenster starten
                process = subprocess.Popen(
                    [engine_path, "--setup", setup_path],
                    cwd=os.path.dirname(engine_path)
                )

            props.engine_pid = process.pid
            props.engine_status = f"Engine läuft (PID: {process.pid})"

            self.report({'INFO'}, f"🚀 Engine gestartet mit Setup: {os.path.basename(setup_path)}")

        except Exception as e:
            props.engine_status = f"Fehler: {str(e)}"
            self.report({'ERROR'}, f"Fehler beim Starten der Engine: {str(e)}")
            return {'CANCELLED'}

        return {'FINISHED'}


# =====================================================================
# OPERATOR: ENGINE STOPPEN
# =====================================================================

class TSDE_OT_StopEngine(Operator):
    bl_idname = "tsde.stop_engine"
    bl_label = "Engine stoppen"
    bl_description = "Stoppt die laufende TSDE Engine"

    def execute(self, context):
        props = context.scene.tsde_live_props

        if props.engine_pid > 0:
            try:
                # Prozess beenden
                import signal
                os.kill(props.engine_pid, signal.SIGTERM)
                props.engine_status = "Engine gestoppt"
                props.engine_pid = 0
                self.report({'INFO'}, "🛑 Engine gestoppt")
            except:
                props.engine_status = "Fehler beim Stoppen"
                props.engine_pid = 0

        return {'FINISHED'}


# =====================================================================
# OPERATOR: LIVE VERBINDUNG TESTEN
# =====================================================================

class TSDE_OT_TestConnection(Operator):
    bl_idname = "tsde.test_connection"
    bl_label = "Verbindung testen"
    bl_description = "Testet die Verbindung zur TSDE Engine"

    def execute(self, context):
        props = context.scene.tsde_live_props

        # Hier später: Echte IPC-Kommunikation
        # Für jetzt: Nur Test

        if props.engine_pid > 0:
            # Prüfen ob Prozess noch läuft
            try:
                os.kill(props.engine_pid, 0)
                props.connection_status = "Verbunden"
                self.report({'INFO'}, "✅ Verbindung zur Engine OK")
            except:
                props.connection_status = "Nicht verbunden"
                props.engine_pid = 0
                self.report({'WARNING'}, "⚠️ Engine nicht erreichbar")
        else:
            props.connection_status = "Nicht verbunden"
            self.report({'WARNING'}, "⚠️ Engine läuft nicht")

        return {'FINISHED'}


# =====================================================================
# OPERATOR: ALLE RIGS ANZEIGEN
# =====================================================================

class TSDE_OT_ListRigs(Operator):
    bl_idname = "tsde.list_rigs"
    bl_label = "Rigs anzeigen"
    bl_description = "Zeigt alle verfügbaren TSDE Rigs an"

    def execute(self, context):
        print("\n📋 Verfügbare TSDE Rigs:")
        rigs = []

        for collection in bpy.data.collections:
            # Prüfen ob Collection ein Rig enthält
            has_pivot = False
            has_lens = False

            for obj in collection.objects:
                if obj.name.endswith("_Pivot"):
                    has_pivot = True
                elif obj.name.endswith("_Lens"):
                    has_lens = True

            if has_pivot and has_lens:
                rigs.append(collection.name)
                print(f"   - {collection.name}")

        if not rigs:
            print("   Keine Rigs gefunden")
            self.report({'INFO'}, "Keine Rigs in der Szene")
        else:
            self.report({'INFO'}, f"{len(rigs)} Rigs gefunden")

        return {'FINISHED'}


# =====================================================================
# PROPERTIES
# =====================================================================

class TSDE_LiveProperties(PropertyGroup):
    # Engine Pfade
    engine_executable_path: StringProperty(
        name="Engine Pfad",
        description="Pfad zur TSDE Engine ausführbaren Datei",
        default="C:/TSDE/tsde_engine.exe",
        subtype='FILE_PATH'
    )

    engine_system_path: StringProperty(
        name="System Pfad",
        description="Verzeichnis für Setup-Dateien",
        default="",
        subtype='DIR_PATH'
    )

    # Engine Modus
    engine_mode: EnumProperty(
        name="Modus",
        description="Startmodus der Engine",
        items=[
            ('NORMAL', "Normal", "Engine mit Fenster starten"),
            ('BACKGROUND', "Hintergrund", "Engine im Hintergrund starten")
        ],
        default='NORMAL'
    )

    # Setup Parameter
    max_speed: FloatProperty(
        name="Max Speed",
        description="Maximale Geschwindigkeit für Tracks",
        default=100.0,
        min=1.0,
        max=1000.0
    )

    segment_length: FloatProperty(
        name="Segment Länge",
        description="Länge der Kurvensegmente",
        default=0.01,
        min=0.001,
        max=0.1,
        precision=3
    )

    # Status
    last_setup_path: StringProperty(
        name="Letztes Setup",
        default=""
    )

    engine_pid: IntProperty(
        name="Engine PID",
        default=0
    )

    engine_status: StringProperty(
        name="Engine Status",
        default="Bereit"
    )

    connection_status: StringProperty(
        name="Verbindung",
        default="Getrennt"
    )

    # Ausgewähltes Rig
    selected_rig: StringProperty(
        name="Rig",
        description="Name des zu exportierenden Rigs",
        default=""
    )


# =====================================================================
# PANEL: LIVE CONNECT
# =====================================================================

class TSDE_PT_LiveConnect(Panel):
    bl_label = "TSDE Live Connect"
    bl_idname = "TSDE_PT_live_connect"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE Live"

    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_live_props

        # =================================================================
        # RIG AUSWAHL
        # =================================================================
        box = layout.box()
        col = box.column(align=True)

        col.label(text="🎯 RIG AUSWAHL", icon='OUTLINER_COLLECTION')
        col.separator()

        # Dropdown für Rig-Auswahl
        col.prop_search(props, "selected_rig", bpy.data, "collections", text="Rig")

        # Rigs anzeigen Button
        row = col.row(align=True)
        row.operator("tsde.list_rigs", text="📋 Rigs anzeigen", icon='VIEWZOOM')

        # =================================================================
        # SETUP EXPORT
        # =================================================================
        box = layout.box()
        col = box.column(align=True)

        col.label(text="⚙️ SETUP", icon='SETTINGS')
        col.separator()

        col.prop(props, "max_speed")
        col.prop(props, "segment_length")

        col.separator()

        # Export Button
        row = col.row(align=True)
        row.scale_y = 1.5
        op = row.operator("tsde.export_setup", text="📤 SETUP EXPORTIEREN", icon='EXPORT')
        op.group_name = props.selected_rig
        op.num_csv_points = 100

        if props.last_setup_path:
            col.label(text=f"✅ {os.path.basename(props.last_setup_path)}")

        # =================================================================
        # ENGINE STEUERUNG
        # =================================================================
        box = layout.box()
        col = box.column(align=True)

        col.label(text="🚀 ENGINE", icon='PLAY')
        col.separator()

        col.prop(props, "engine_executable_path")
        col.prop(props, "engine_system_path")
        col.prop(props, "engine_mode")

        col.separator()

        # Engine Buttons
        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("tsde.start_engine", text="🚀 ENGINE STARTEN", icon='PLAY')

        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("tsde.stop_engine", text="🛑 ENGINE STOPPEN", icon='CANCEL')

        row = col.row(align=True)
        row.operator("tsde.test_connection", text="🔌 Verbindung testen", icon='NETWORK_DRIVER')

        # Status
        col.separator()
        col.label(text=f"Status: {props.engine_status}")
        col.label(text=f"Verbindung: {props.connection_status}")

        # =================================================================
        # INFO
        # =================================================================
        box = layout.box()
        col = box.column(align=True)

        col.label(text="ℹ️ WORKFLOW:", icon='INFO')
        col.label(text="1. Rig auswählen")
        col.label(text="2. Setup exportieren")
        col.label(text="3. Engine starten")
        col.label(text="4. Verbindung testen")
        col.label(text="5. Live-Daten von Engine")


# =====================================================================
# REGISTRATION
# =====================================================================

classes = (
    TSDE_LiveProperties,
    TSDE_OT_ExportSetup,
    TSDE_OT_StartEngine,
    TSDE_OT_StopEngine,
    TSDE_OT_TestConnection,
    TSDE_OT_ListRigs,
    TSDE_PT_LiveConnect,
)

def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except:
            bpy.utils.unregister_class(cls)
            bpy.utils.register_class(cls)

    bpy.types.Scene.tsde_live_props = PointerProperty(type=TSDE_LiveProperties)

    print("\n" + "="*60)
    print("🚀 TSDE LIVE CONNECT GELADEN")
    print("="*60)
    print("✅ Rig → CSV Konverter")
    print("✅ Setup Generator (JSON)")
    print("✅ Engine Starter")
    print("✅ Verbindungstest")
    print("="*60 + "\n")

def unregister():
    del bpy.types.Scene.tsde_live_props

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass

    print("TSDE Live Connect ENTLADEN")

if __name__ == "__main__":
    register()