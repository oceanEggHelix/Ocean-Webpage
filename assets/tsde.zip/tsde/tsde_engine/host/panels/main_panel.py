"""Haupt-N-Panel für TSDE Host"""
import bpy
from bpy.types import Panel

class TSDE_PT_MainPanel(Panel):
    bl_label = "TSDE Live Host"
    bl_idname = "TSDE_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="🎮 TSDE Live Engine v0.1", icon='TOOL_SETTINGS')
        layout.separator()
       