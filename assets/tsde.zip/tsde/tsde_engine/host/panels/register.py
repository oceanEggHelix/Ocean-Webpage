# panels/register.py
import bpy

# Import ALL panel classes
from ..section2_setup.panel import TSDE_PT_Section2
from ..section3_engine.panel import TSDE_PT_Section3
from ..section4_live_control.panel import TSDE_PT_Section4
from ..section5_recorder.panel import TSDE_PT_Section5
from ..section6_render.panel import TSDE_PT_Section6
from ..section7_settings.panel import TSDE_PT_Section7_Settings  # 🔥 WICHTIG!
from ..spline_generator.panel import TSDE_PT_SplineGenerator
from ..spline_generator.walkfly.panel import TSDE_PT_Walkfly
from ..spline_generator.setter.panel import TSDE_PT_SplineSetter
from ..spline_generator.retter.panel import TSDE_PT_KeyframeRetter
from .main_panel import TSDE_PT_MainPanel

# List ALL panels in registration order
panels = [
    TSDE_PT_MainPanel,
    TSDE_PT_SplineGenerator,
    TSDE_PT_Walkfly,
    TSDE_PT_SplineSetter,
    TSDE_PT_KeyframeRetter,
    TSDE_PT_Section2,
    TSDE_PT_Section3,
    TSDE_PT_Section4,
    TSDE_PT_Section5,
    TSDE_PT_Section6,
    TSDE_PT_Section7_Settings,  # 🔥 Hier fehlte es!
]

def register_panels():
    """Registriert alle Panels"""
    for panel in panels:
        try:
            bpy.utils.register_class(panel)
            print(f"   ✅ {panel.__name__}")
        except Exception as e:
            print(f"   ⚠️ Fehler bei {panel.__name__}: {e}")

def unregister_panels():
    """Entfernt alle Panels (umgekehrte Reihenfolge)"""
    for panel in reversed(panels):
        try:
            bpy.utils.unregister_class(panel)
            print(f"   ✅ {panel.__name__}")
        except Exception as e:
            print(f"   ⚠️ Fehler bei {panel.__name__}: {e}")