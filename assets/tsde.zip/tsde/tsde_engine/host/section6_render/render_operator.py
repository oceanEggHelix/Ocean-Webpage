# tsde_engine/host/section6_render/render_operator.py

import bpy
import os
import math
from bpy.types import Operator
from mathutils import Vector
from ..core import ipc_client  # 🔥 KOMPLETTES MODUL IMPORTIEREN!





class TSDE_OT_RenderExport(Operator):
    bl_idname = "tsde.render_export"
    bl_label = "Render Export"
    bl_description = "Startet deterministischen Render aus Recording"
    bl_options = {'REGISTER'}
    
    # 🔥 WIRD VOM PANEL GESETZT
    recording_path: bpy.props.StringProperty(
        name="Recording",
        description="Pfad zur Recording-JSON",
        default="",
        subtype='FILE_PATH'
    )
    
        # 🔥 EINE EINFACHE FLAG!
    preview_only: bpy.props.BoolProperty(
        name="Preview Only",
        description="Nur Preview, kein Rendern",
        default=False
    )


    def execute(self, context):
        props = context.scene.tsde_render_props
        
        # ============================================================
        # 1. PRÜFEN OB RECORDING EXISTIERT
        # ============================================================
        if not self.recording_path or not os.path.exists(self.recording_path):
            self.report({'ERROR'}, "Kein gültiges Recording ausgewählt!")
            return {'CANCELLED'}
        
        # ============================================================
        # 2. AUSGABEORDNER VORBEREITEN
        # ============================================================
        output_dir = bpy.path.abspath(props.output_path)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        # ============================================================
        # 3. ZEIT-STRETCHING BERECHNEN
        # ============================================================
        time_factor = props.time_factor if props.use_time_stretch else 1.0
        
        # ============================================================
        # 4. RENDER-BEREICH BERECHNEN
        # ============================================================
        if props.render_range == 'CUSTOM':
            t_start = props.frame_start / 100.0
            t_end = props.frame_end / 100.0
        else:
            t_start = 0.0
            t_end = 1.0
        
        print(f"\n🎬 RENDER GESTARTET")
        print(f"   Recording: {os.path.basename(self.recording_path)}")
        print(f"   FPS: {props.render_fps}")
        print(f"   Time Factor: {time_factor}")
        print(f"   Bereich: {t_start:.1%} - {t_end:.1%}")
        print(f"   Ausgabe: {output_dir}")
        
        # ============================================================
        # 5. 🔥 IPC AN ENGINE SENDEN - MIT MODUL-FUNKTIONEN!
        # ============================================================
        success = ipc_client.start_render(
            recording_path=self.recording_path,
            fps=props.render_fps,
            time_factor=time_factor,
            t_start=t_start,
            t_end=t_end
        )
        
        if not success:
            self.report({'ERROR'}, "Render konnte nicht gestartet werden!")
            return {'CANCELLED'}
        
        # ============================================================
        # 6. MODALEN OPERATOR STARTEN
        # ============================================================
        context.window_manager.modal_handler_add(self)
        self.timer = context.window_manager.event_timer_add(0.01, window=context.window)
        self.current_frame = 0
        self.total_frames = 0
        self.output_dir = output_dir
        self.camera_initialized = False  # 🔥 Flag für Kamera-Initialisierung
        
        return {'RUNNING_MODAL'}
    
    def _init_camera_from_recording(self, context):
        """Initialisiert Kamera auf ersten t-Wert aus Recording"""
        print("\n🎯 INITIALISIERE KAMERA AUF START-T AUS RECORDING")
        
        # 🔥 RIG FINDEN
        possible_rig_names = [
            self.rig_name,
            "TSDE_Rig_1",
            "Rig",
            "TSDE_Rig.001",
            "TSDE_Rig_1.001",
        ]
        
        rig = None
        for name in possible_rig_names:
            rig = bpy.data.objects.get(name)
            if rig:
                print(f"✅ Rig gefunden als: {name}")
                self.rig_name = name
                break
        
        if not rig:
            print(f"❌ Rig nicht gefunden!")
            return False
        
        pivot = bpy.data.objects.get(f"{self.rig_name}_Pivot")
        lens = bpy.data.objects.get(f"{self.rig_name}_Lens")
        camera = bpy.data.objects.get("Camera")
        
        if not pivot or not lens or not camera:
            print("❌ Pivot, Lens oder Kamera nicht gefunden!")
            return False
        
        # ============================================================
        # ERSTEN t-WERT AUS RECORDING HOLEN
        # ============================================================
        first_pivot_t = None
        first_lens_t = None
        
        if hasattr(self, 'pivot_samples') and len(self.pivot_samples) > 0:
            first_pivot_t = self.pivot_samples[0]["t"]
            print(f"📊 Erster Pivot t: {first_pivot_t:.6f}")
        
        if hasattr(self, 'lens_samples') and len(self.lens_samples) > 0:
            first_lens_t = self.lens_samples[0]["t"]
            print(f"📊 Erster Lens t: {first_lens_t:.6f}")
        
        # ============================================================
        # 🔥 REIHENFOLGE: ERST LENS, DANN PIVOT
        # ============================================================
        
        # 1. ZUERST LENS AKTUALISIEREN (Zielposition)
        if first_lens_t is not None:
            for constraint in lens.constraints:
                if constraint.type == 'FOLLOW_PATH':
                    constraint.offset_factor = first_lens_t
                    print(f"   ✅ Lens auf t={first_lens_t:.6f}")
        
        # 2. VIEWLAYER UPDATEN
        bpy.context.view_layer.update()
        
        # 3. DANN PIVOT AKTUALISIEREN (Kameraposition)
        if first_pivot_t is not None:
            for constraint in pivot.constraints:
                if constraint.type == 'FOLLOW_PATH':
                    constraint.offset_factor = first_pivot_t
                    print(f"   ✅ Pivot auf t={first_pivot_t:.6f}")
        
        # 4. VIEWLAYER UPDATEN
        bpy.context.view_layer.update()
        
        # ============================================================
        # KAMERA MANUELL POSITIONIEREN
        # ============================================================
        print(f"\n📍 Kamera positionieren...")
        camera.location = pivot.location.copy()
        print(f"   Kamera Position: {camera.location}")
        
        # ============================================================
        # KAMERA AUF LENS AUSRICHTEN
        # ============================================================
        direction = lens.location - camera.location
        if direction.length > 0:
            rot_quat = direction.to_track_quat('-Z', 'Y')
            camera.rotation_euler = rot_quat.to_euler()
            print(f"   Kamera zeigt zu Lens: {lens.location}")
        else:
            print("⚠️  Lens und Kamera sind am gleichen Ort!")
            return False
        
        # ============================================================
        # FINAL UPDATE
        # ============================================================
        bpy.context.view_layer.update()
        
        print(f"\n📍 Nach Initialisierung:")
        print(f"   Pivot: {pivot.location}")
        print(f"   Lens:  {lens.location}")
        print(f"   Cam:   {camera.location}")
        print("✅ KAMERA INITIALISIERT")
        
        return True
    
    def modal(self, context, event):
        # 🔥 ESC = Abbrechen (Blender verwendet 'ESCKEY'!)
        if event.type == 'ESCKEY':  # ← NICHT 'ESC'!
            print("\n⛔ RENDER ABGESPROCHEN")
            if hasattr(self, 'timer'):
                context.window_manager.event_timer_remove(self.timer)
            # Optional: Engine stoppen
            # ipc_client.stop_render()
            return {'CANCELLED'}
        


        ################################## wichtig nicht anrühren ##########################
        if event.type == 'TIMER':
            frame_data = ipc_client.poll_render_frame()
            
            if frame_data is None:
                context.window_manager.event_timer_remove(self.timer)
                self.report({'INFO'}, f"✅ Render abgeschlossen: {self.current_frame} Frames")
                return {'FINISHED'}
            
            if frame_data is not None:
                # 🔥 Beim ersten Frame total_frames vom Replayer holen
                if self.current_frame == 0:
                    progress = ipc_client.get_render_progress()
                    self.total_frames = progress.get("total", 0)
                    print(f"📊 Total Frames: {self.total_frames}")
                    
                    # rig_name setzen
                    data = frame_data.get("data", {})
                    for track_name in data.keys():
                        if track_name.endswith("_Pivot"):
                            self.rig_name = track_name.replace("_Pivot", "")
                            print(f"🔍 Rig erkannt: {self.rig_name}")
                            break
                    
                    # Samples laden
                    if hasattr(self, 'rig_name'):
                        import json
                        with open(self.recording_path, 'r') as f:
                            recording = json.load(f)
                        
                        pivot_track = recording["tracks"].get(f"{self.rig_name}_Pivot", {})
                        self.pivot_samples = pivot_track.get("samples", [])
                        
                        lens_track = recording["tracks"].get(f"{self.rig_name}_Lens", {})
                        self.lens_samples = lens_track.get("samples", [])
                        
                        print(f"📊 Pivot: {len(self.pivot_samples)} Samples")
                        print(f"📊 Lens: {len(self.lens_samples)} Samples")
                        
                        # ============================================================
                        # 🔥 KAMERA AUF START-T AUS RECORDING INITIALISIEREN
                        # ============================================================
                        self.camera_initialized = self._init_camera_from_recording(context)
                
                self._apply_frame_data(context, frame_data, self.current_frame)
                self._render_current_frame(context)
                self.current_frame += 1
        
        return {'PASS_THROUGH'}
        
    def _apply_frame_data(self, context, frame_data, frame_idx):
            """Setzt die t-Werte UND dreht die Roll-Emptys wie im Live-Betrieb"""
            import math
            
            if not hasattr(self, 'rig_name') or not self.rig_name:
                return

            # 1. REFERENZEN HOLEN
            pivot = bpy.data.objects.get(f"{self.rig_name}_Pivot")
            lens = bpy.data.objects.get(f"{self.rig_name}_Lens")
            roll_obj = bpy.data.objects.get(f"{self.rig_name}_Roll")
            camera = bpy.data.objects.get("Camera")
            
            if not pivot or not lens:
                return

            # 2. PFAD-POSITIONEN SETZEN (Aus deinen Samples)
            frame_t = frame_idx / self.total_frames if self.total_frames > 0 else 0.0
            
            if hasattr(self, 'pivot_samples') and self.pivot_samples:
                idx = min(int(frame_t * len(self.pivot_samples)), len(self.pivot_samples) - 1)
                for c in pivot.constraints:
                    if c.type == 'FOLLOW_PATH':
                        c.offset_factor = self.pivot_samples[idx]["t"]

            if hasattr(self, 'lens_samples') and self.lens_samples:
                idx = min(int(frame_t * len(self.lens_samples)), len(self.lens_samples) - 1)
                for c in lens.constraints:
                    if c.type == 'FOLLOW_PATH':
                        c.offset_factor = self.lens_samples[idx]["t"]

            # 3. 🔥 ROLL-LOGIK (Eins-zu-Eins aus deinem Live-Skript)
            if "data" in frame_data:
                for track_name, value in frame_data["data"].items():
                    if track_name.endswith("_Roll"):
                        # Den Pedal-Wert holen (vielleicht direkt oder in einem Dict)
                        pedal = value.get("t", 0.0) if isinstance(value, dict) else value
                        
                        if roll_obj:
                            # Die exakte Formel aus deinem Live-Skript
                            roll_deg = pedal * 450
                            roll_rad = roll_deg * math.pi / 180.0
                            roll_obj.rotation_euler.z = roll_rad # Z-Achse wie im Live-Script
                            
                            if frame_idx % 10 == 0:
                                print(f"🎥 {self.rig_name}: Roll-Empty {roll_deg:.1f}°")

            # 4. UPDATE
            # Hier verlassen wir uns darauf, dass die Kamera per Constraint 
            # (Track To / Copy Location) am Rig hängt!
            context.view_layer.update()
            
            # Falls die Kamera NICHT per Constraint am Rig hängt, erzwingen wir es hier:
            if camera:
                camera.location = pivot.location.copy()
                # Nur ausrichten, wenn keine Constraints da sind
                if not camera.constraints:
                    direction = lens.location - camera.location
                    if direction.length > 0.001:
                        camera.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()


    def _render_current_frame(self, context):
        """Rendert aktuellen Frame - oder nur Preview"""
        if self.preview_only:
            # 🔥 NUR PREVIEW - KEIN RENDERN!
            print(f"👁️ Preview Frame {self.current_frame}")
            return
        
        # 🔥 RICHTIGES RENDERN
        scene = context.scene
        props = scene.tsde_render_props
        
        filename = f"{props.file_prefix}{self.current_frame:04d}.png"
        filepath = os.path.join(self.output_dir, filename)
        
        scene.render.filepath = filepath
        bpy.ops.render.render(write_still=True)