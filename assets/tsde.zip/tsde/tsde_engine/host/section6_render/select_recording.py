# tsde_engine/host/section6_render/select_recording.py

import bpy
import os
from bpy.types import Operator

class TSDE_OT_SelectRecording(Operator):
    """Wählt ein Recording für den Render aus"""
    bl_idname = "tsde.select_recording"
    bl_label = "Recording auswählen"
    bl_description = "Wählt eine Recording-JSON-Datei aus"
    bl_options = {'REGISTER'}
    
    filepath: bpy.props.StringProperty(
        name="Recording",
        description="Pfad zur Recording-JSON",
        default="",
        subtype='FILE_PATH'
    )
    
    def execute(self, context):
        props = context.scene.tsde_render_props
        props.custom_recording_path = self.filepath
        self.report({'INFO'}, f"Recording ausgewählt: {os.path.basename(self.filepath)}")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}