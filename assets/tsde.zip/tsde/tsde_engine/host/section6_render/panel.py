"""N-Panel UI für Section 6: Render Export"""
import bpy
import os
from bpy.types import Panel

class TSDE_PT_Section6(Panel):
    bl_label = "6. Render Export"
    bl_idname = "TSDE_PT_section6"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_render_props
        engine_props = context.scene.tsde_engine_props
        
        # =================================================================
        # RECORDING AUSWAHL
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="📼 RECORDING", icon='FILE_MOVIE')
        col.separator()
        
        # Letztes Setup/Recording anzeigen
        if engine_props.last_setup_path and os.path.exists(engine_props.last_setup_path):
            row = col.row(align=True)
            row.label(text=f"📁 {os.path.basename(engine_props.last_setup_path)}")
            
            # Manuelle Auswahl
            row = col.row(align=True)
            row.prop(props, "custom_recording_path", text="")
            row.operator("tsde.select_recording", text="", icon='FILE_FOLDER')
            
            col.separator()
            
            # 🔥 PREVIEW BUTTON (OHNE RENDERN)
            row = col.row(align=True)
            row.scale_y = 1.5
            
            op_preview = row.operator("tsde.render_export", text="👁️ PREVIEW", icon='HIDE_OFF')
            op_preview.recording_path = props.custom_recording_path if props.custom_recording_path else engine_props.last_setup_path
            op_preview.preview_only = True  # 🔥 EINFACHE FLAG!
            
            # 🔥 RENDER BUTTON
            op_render = row.operator("tsde.render_export", text="🎬 RENDER", icon='RENDER_ANIMATION')
            op_render.recording_path = props.custom_recording_path if props.custom_recording_path else engine_props.last_setup_path
            op_render.preview_only = False
        else:
            col.label(text="Kein Recording geladen", icon='INFO')
            col.operator("tsde.select_recording", text="Recording auswählen...", icon='FILE_FOLDER')
        
        # =================================================================
        # RENDER EINSTELLUNGEN
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.label(text="⚙️ EINSTELLUNGEN", icon='SETTINGS')
        col.separator()
        
        # FPS
        row = col.row(align=True)
        row.label(text="FPS:")
        row.prop(props, "render_fps", text="")
        
        # Ausgabeordner
        col.prop(props, "output_path")
        col.prop(props, "file_prefix")
        
        # =================================================================
        # ZEIT-STRETCHING
        # =================================================================
        col.separator()
        col.prop(props, "use_time_stretch")
        if props.use_time_stretch:
            col.prop(props, "time_factor", slider=True)
        
        # =================================================================
        # RENDER BEREICH
        # =================================================================
        col.separator()
        col.prop(props, "render_range", expand=True)
        
        if props.render_range == 'CUSTOM':
            row = col.row(align=True)
            row.prop(props, "frame_start", text="Start %")
            row.prop(props, "frame_end", text="End %")
        
        # =================================================================
        # INFO
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        col.label(text="ℹ️ INFO:", icon='INFO')
        col.label(text="• PREVIEW = Kamerabewegung ohne Rendern")
        col.label(text="• RENDER = Speichert PNGs")
        col.label(text="• Deterministisch & Frame-genau")
        col.label(text="• Time Stretch = Zeitlupe/Zeitraffer")