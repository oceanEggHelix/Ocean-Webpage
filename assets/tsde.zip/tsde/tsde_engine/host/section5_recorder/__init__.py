# section5_recorder/__init__.py
from .panel import TSDE_PT_Section5
from .panel import TSDE_OT_OpenEditor  # 🔥 NEU!
from .recorder_operator import TSDE_OT_RecorderControl

__all__ = [
    "TSDE_PT_Section5",
    "TSDE_OT_RecorderControl",
    "TSDE_OT_OpenEditor",  # 🔥 NEU!
]