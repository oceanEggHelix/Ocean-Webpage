"""Recorder Control Operator"""
import bpy
import os
import sys
import time
from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper, ImportHelper
from datetime import datetime

TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

class TSDE_OT_RecorderControl(Operator, ExportHelper, ImportHelper):
    bl_idname = "tsde.recorder_control"
    bl_label = "Recorder Control"
    bl_description = "Steuert den TSDE Recorder"
    bl_options = {'REGISTER'}
    
    action: bpy.props.EnumProperty(
        items=[
            ('START', "Start", "Recording starten"),
            ('STOP', "Stop", "Recording stoppen"),
            ('SAVE', "Save", "Recording speichern"),
            ('LOAD', "Load", "Recording laden"),
        ]
    )
    
    # FileBrowser Filter
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(
        default="*.json",
        options={'HIDDEN'}
    )
    
    # Optionen (nur für SAVE relevant)
    decimate: bpy.props.IntProperty(
        name="Dezimierung",
        description="1 = alle Samples, 2 = jeden zweiten, usw.",
        default=1,
        min=1,
        max=240
    )
    normalize: bpy.props.BoolProperty(
        name="Normalisieren",
        description="t auf 0-1 normalisieren",
        default=True
    )
    
    def execute(self, context):
        props = context.scene.tsde_recorder_props
        
        if not ipc.is_running():
            self.report({'ERROR'}, "Engine läuft nicht!")
            return {'CANCELLED'}
        
        if self.action == 'START':
            # Session-Name generieren
            session_name = f"Recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            props.session_name = session_name
            props.is_recording = True
            props.recording_start = time.time()
            
            ipc.send("start_recording", session_name=session_name)
            self.report({'INFO'}, f"🔴 Recording gestartet: {session_name}")
            
        elif self.action == 'STOP':
            props.is_recording = False
            ipc.send("stop_recording")
            self.report({'INFO'}, "⏹ Recording gestoppt")
            
        elif self.action == 'SAVE':
            # Recording speichern - Datei wurde schon via FileBrowser ausgewählt
            filepath = self.filepath
            if not filepath:
                return {'CANCELLED'}
            
            # Optionen aus Properties
            decimate = props.decimate
            normalize = props.normalize
            
            ipc.send("save_recording",
                filepath=filepath,
                trim_start=0.0,
                trim_end=1.0,
                normalize=normalize,
                decimate=decimate
            )
            self.report({'INFO'}, f"💾 Recording gespeichert: {os.path.basename(filepath)}")
            
        elif self.action == 'LOAD':
            # Recording laden
            filepath = self.filepath
            if not filepath:
                return {'CANCELLED'}
            
            ipc.send("load_recording", filepath=filepath)
            self.report({'INFO'}, f"📂 Recording geladen: {os.path.basename(filepath)}")
        
        return {'FINISHED'}
    
    def invoke(self, context, event):
        props = context.scene.tsde_recorder_props
        
        if self.action == 'SAVE':
            # Default-Dateiname
            self.filepath = props.session_name or f"recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            # FileBrowser öffnen (ohne extra Panel)
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}
            
        elif self.action == 'LOAD':
            # FileBrowser zum Laden öffnen
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}
        
        return self.execute(context)