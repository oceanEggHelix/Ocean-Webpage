# section5_recorder/open_editor.py
import bpy
import subprocess
import sys
import os
from bpy.types import Operator

TSDE_PATH = "E:/TSDE"

class TSDE_OT_OpenEditor(Operator):
    """Öffnet den TSDE Editor als externe Anwendung (unsichtbar)"""
    bl_idname = "tsde.open_editor"
    bl_label = "TSDE Editor öffnen"
    bl_description = "Öffnet den TSDE Editor als externe Anwendung"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        print("\n🔴 EDITOR BUTTON GEDRÜCKT!")
        
        editor_script = os.path.join(TSDE_PATH, "tsde_engine", "editor_gui", "tests", "test_editor_panel_final.py")
        
        if not os.path.exists(editor_script):
            print("❌ Editor nicht gefunden!")
            self.report({'ERROR'}, "Editor nicht gefunden")
            return {'CANCELLED'}
        
        try:
            # System Python
            system_python = "C:/Program Files/Python313/python.exe"
            
            print(f"🐍 Python: {system_python}")
            
            # 🔥 KOMPLETT UNSICHTBAR!
            subprocess.Popen(
                [system_python, editor_script],
                creationflags=subprocess.CREATE_NO_WINDOW,  # Windows: kein Fenster
                cwd=TSDE_PATH
            )
            
            print("✅ Editor-Prozess gestartet (unsichtbar)")
            self.report({'INFO'}, "✅ Editor gestartet")
            return {'FINISHED'}
            
        except Exception as e:
            print(f"❌ Fehler: {e}")
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}