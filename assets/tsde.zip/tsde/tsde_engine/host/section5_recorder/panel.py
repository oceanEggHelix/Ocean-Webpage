"""N-Panel UI für Section 5: Recorder"""
import bpy
import sys
import subprocess
import os
from bpy.types import Panel

TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

# 🔥 Nur importieren, NICHT neu definieren!
from .open_editor import TSDE_OT_OpenEditor

class TSDE_PT_Section5(Panel):
    bl_label = "5. Recorder"
    bl_idname = "TSDE_PT_section5"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    @classmethod
    def poll(cls, context):
        return ipc.is_running()
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_recorder_props
        
        # =================================================================
        # STATUS
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        if props.is_recording:
            col.label(text="🔴 RECORDING AKTIV", icon='REC')
            col.label(text=f"Session: {props.session_name}")
            col.label(text=f"Dauer: {props.duration:.1f}s")
        else:
            col.label(text="⏹ Bereit", icon='INFO')
        
        # =================================================================
        # RECORDER BUTTONS
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        row = col.row(align=True)
        row.scale_y = 1.5
        
        if not props.is_recording:
            row.operator("tsde.recorder_control", text="● RECORD START", icon='REC').action = 'START'
        else:
            row.operator("tsde.recorder_control", text="■ RECORD STOP", icon='CANCEL').action = 'STOP'
        
        # =================================================================
        # EXPORT OPTIONS
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        col.prop(props, "decimate", text="Dezimierung (1 = alle)")
        col.prop(props, "normalize", text="Auf 0-1 normalisieren")
        
        col.separator()
        
        row = col.row(align=True)
        row.operator("tsde.recorder_control", text="💾 SAVE", icon='FILE_TICK').action = 'SAVE'
        
        # 🔥 EDITOR Button - jetzt korrekt!
        row.operator("tsde.open_editor", text="✏️ EDITOR", icon='GREASEPENCIL')