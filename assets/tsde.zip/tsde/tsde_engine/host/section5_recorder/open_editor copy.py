# section5_recorder/open_editor.py
import bpy
import subprocess
import sys
import os
from bpy.types import Operator

TSDE_PATH = "E:/TSDE"

class TSDE_OT_OpenEditor(Operator):
    """Öffnet den TSDE Editor als externe Anwendung"""
    bl_idname = "tsde.open_editor"
    bl_label = "TSDE Editor öffnen"
    bl_description = "Öffnet den TSDE Editor als externe Anwendung"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        print("\n🔴 EDITOR BUTTON GEDRÜCKT!")
        
        editor_script = os.path.join(TSDE_PATH, "tsde_engine", "editor_gui", "tests", "test_editor_panel_final.py")
        
        if not os.path.exists(editor_script):
            print("❌ Editor nicht gefunden!")
            self.report({'ERROR'}, "Editor nicht gefunden")
            return {'CANCELLED'}
        
        try:
            # System Python
            system_python = "C:/Program Files/Python313/python.exe"
            
            # Stelle sicher dass das Arbeitsverzeichnis richtig ist
            work_dir = TSDE_PATH
            
            print(f"🐍 Python: {system_python}")
            print(f"📂 Arbeitsverzeichnis: {work_dir}")
            
            # 🔥 /c statt /k = schließt nach Ausführung!
            subprocess.Popen(
                f'start cmd /c cd /d "{work_dir}" && "{system_python}" "{editor_script}"',
                shell=True
            )
            
            print("✅ Editor-Prozess gestartet")
            self.report({'INFO'}, "✅ Editor gestartet")
            return {'FINISHED'}
            
        except Exception as e:
            print(f"❌ Fehler: {e}")
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}