"""Play Operator - startet Bewegung"""
import bpy
import sys
from bpy.types import Operator

TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

class TSDE_OT_Play(Operator):
    bl_idname = "tsde.play"
    bl_label = "Play"
    bl_description = "Startet die Bewegung (wie im Terminal)"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        if ipc.is_running():
            ipc.send("play")
            self.report({'INFO'}, "▶ Play")
        else:
            self.report({'WARNING'}, "Engine läuft nicht")
        return {'FINISHED'}