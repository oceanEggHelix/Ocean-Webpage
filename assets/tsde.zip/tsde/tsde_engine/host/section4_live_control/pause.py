"""Pause Operator - pausiert Bewegung"""
import bpy
import sys
from bpy.types import Operator

TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

class TSDE_OT_Pause(Operator):
    bl_idname = "tsde.pause"
    bl_label = "Pause"
    bl_description = "Pausiert die Bewegung (wie im Terminal)"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        if ipc.is_running():
            ipc.send("pause")
            self.report({'INFO'}, "⏸ Pause")
        else:
            self.report({'WARNING'}, "Engine läuft nicht")
        return {'FINISHED'}