"""Reset Operator - setzt alle Tracks zurück"""
import bpy
import sys
import math
from bpy.types import Operator

TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

class TSDE_OT_Reset(Operator):
    bl_idname = "tsde.reset"
    bl_label = "Reset"
    bl_description = "Setzt alle Tracks zurück"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        if ipc.is_running():
            # Engine-Reset senden
            ipc.send("reset")
            
            # 🔥 ALLE Pedal-Werte in Blender auf 0 setzen!
            if hasattr(context.scene, 'tsde_live_props'):
                for track in context.scene.tsde_live_props.tracks:
                    track.pedal = 0.0
                    print(f"   ✅ {track.name} auf 0 gesetzt")
            
            # 🔥 Gimbal-Constraints neu triggern!
            for collection in bpy.data.collections:
                if collection.name.startswith("TSDE_Rig"):
                    gimbal = collection.objects.get(f"{collection.name}_Gimbal")
                    if gimbal:
                        # Locked Track kurz deaktivieren/aktivieren
                        for constraint in gimbal.constraints:
                            if constraint.type == 'LOCKED_TRACK':
                                constraint.influence = 0.0
                                context.view_layer.update()
                                constraint.influence = 1.0
                                context.view_layer.update()
                                print(f"   ✅ {collection.name} Gimbal neu ausgerichtet")
            
            self.report({'INFO'}, "🔄 Reset - Alle Pedals = 0, Gimbal neu ausgerichtet")
        else:
            self.report({'WARNING'}, "Engine läuft nicht")
        return {'FINISHED'}