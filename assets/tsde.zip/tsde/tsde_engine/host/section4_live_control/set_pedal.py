"""Set Pedal Operator - wird von Slidern aufgerufen"""
import bpy
import sys
from bpy.types import Operator

TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

class TSDE_OT_SetPedal(Operator):
    bl_idname = "tsde.set_pedal"
    bl_label = "Set Pedal"
    bl_description = "Setzt Pedal-Wert für Track"
    bl_options = {'REGISTER'}
    
    track_name: bpy.props.StringProperty()
    pedal_value: bpy.props.FloatProperty(min=-100, max=100, default=0)
    
    def execute(self, context):
        if ipc.is_running():
            # Konvertiere -100..100 zu -1..1 für Engine
            value = self.pedal_value / 100.0
            #print(f"🎮 Pedal {self.track_name}: {self.pedal_value}% -> {value:.2f}")
            ipc.send("set_pedal", track=self.track_name, value=value)
        else:
            print(f"⚠️ Engine nicht verbunden - Pedal {self.track_name} nicht gesendet")
        return {'FINISHED'}