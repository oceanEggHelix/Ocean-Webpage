"""Section 4: Live Control - Pedal Slider für jeden Track"""
from .panel import TSDE_PT_Section4
from .play import TSDE_OT_Play
from .pause import TSDE_OT_Pause
from .reset import TSDE_OT_Reset
from .set_pedal import TSDE_OT_SetPedal

__all__ = [
    "TSDE_PT_Section4",
    "TSDE_OT_Play",
    "TSDE_OT_Pause", 
    "TSDE_OT_Reset",
    "TSDE_OT_SetPedal",
]