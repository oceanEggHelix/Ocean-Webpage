"""N-Panel UI für Section 4: Live Control - wie im Terminal"""
import bpy
import sys
from bpy.types import Panel

# TSDE-Pfad für ipc
TSDE_PATH = "E:/TSDE"
if TSDE_PATH not in sys.path:
    sys.path.insert(0, TSDE_PATH)

import tsde_engine.core.ipc as ipc

class TSDE_PT_Section4(Panel):
    bl_label = "4. Live Control"
    bl_idname = "TSDE_PT_section4"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "TSDE"
    bl_parent_id = "TSDE_PT_main"
    bl_options = {'DEFAULT_CLOSED'}
    
    @classmethod
    def poll(cls, context):
        """Panel nur anzeigen wenn Engine läuft"""
        return ipc.is_running()
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.tsde_live_props
        
        # =================================================================
        # VERBINDUNGSSTATUS
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        col.label(text="✅ Engine verbunden", icon='CHECKBOX_HLT')
        
        # =================================================================
        # PLAY/PAUSE/RESET BUTTONS (wie im Terminal)
        # =================================================================
        box = layout.box()
        col = box.column(align=True)
        
        row = col.row(align=True)
        row.scale_y = 1.5
        row.operator("tsde.play", text="▶ PLAY", icon='PLAY')
        row.operator("tsde.pause", text="⏸ PAUSE", icon='PAUSE')
        row.operator("tsde.reset", text="🔄 RESET", icon='FILE_REFRESH')
        
        # =================================================================
        # PEDAL SLIDER FÜR JEDEN TRACK (wie im Terminal)
        # =================================================================
        if len(props.tracks) > 0:
            for track in props.tracks:
                box = layout.box()
                col = box.column(align=True)
                
                # Track Name
                col.label(text=track.name, icon='TRACKING')
                
                # Pedal Slider (-100 bis +100 wie im Terminal)
                row = col.row(align=True)
                row.prop(track, "pedal", text="", slider=True)
                
                # Aktueller Wert mit Vorzeichen
                if track.pedal > 0:
                    col.label(text=f"+{track.pedal}%", icon='TRIA_UP')
                elif track.pedal < 0:
                    col.label(text=f"{track.pedal}%", icon='TRIA_DOWN')
                else:
                    col.label(text="0%", icon='DOT')
        else:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="Keine Tracks geladen", icon='INFO')
            col.label(text="→ Engine neu starten")