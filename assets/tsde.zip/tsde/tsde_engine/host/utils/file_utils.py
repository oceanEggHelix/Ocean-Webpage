"""Datei-Hilfsfunktionen"""
import os
import json

def ensure_directory(path):
    """Stellt sicher dass ein Verzeichnis existiert"""
    os.makedirs(path, exist_ok=True)
    return path

def save_json(data, filepath):
    """Speichert Daten als JSON"""
    ensure_directory(os.path.dirname(filepath))
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4)
    return filepath

def save_csv(lines, filepath):
    """Speichert CSV-Daten"""
    ensure_directory(os.path.dirname(filepath))
    with open(filepath, 'w', encoding='utf-8') as f:
        for line in lines:
            f.write(line + '\n')
    return filepath

def load_json(filepath):
    """Lädt JSON-Daten"""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)