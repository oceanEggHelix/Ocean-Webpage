"""Blender-spezifische Hilfsfunktionen"""
import bpy
import mathutils
from mathutils import Vector

def create_visible_spline(name, points, color, context):
    """
    Erstellt einen Spline mit sichtbaren Punkten
    
    Args:
        name: Name des Spline-Objekts
        points: Liste von Vektoren (Punkte)
        color: RGBA-Farbe als Tuple (r,g,b,a)
        context: Blender Context
    
    Returns:
        Das erstellte Spline-Objekt
    """
    if not points:
        print(f"⚠️ Keine Punkte für Spline '{name}' übergeben!")
        return None
        
    # Kurve erstellen
    curve = bpy.data.curves.new(name, type='CURVE')
    curve.dimensions = '3D'
    
    # Spline als POLY (sichtbare Punkte)
    spline = curve.splines.new('POLY')
    spline.points.add(len(points) - 1)
    
    # Punkte setzen
    for i, p in enumerate(points):
        spline.points[i].co = (p.x, p.y, p.z, 1.0)
    
    # Kurven-Objekt erstellen
    obj = bpy.data.objects.new(name, curve)
    
    # Farbe setzen (für bessere Sichtbarkeit)
    if hasattr(obj, "color"):
        obj.color = color
    
    # In Szene einfügen
    context.scene.collection.objects.link(obj)
    
    print(f"   ✅ {name}: {len(points)} Punkte")
    return obj

def get_spline_points(spline_obj):
    """
    Extrahiert alle Punkte aus einem Spline-Objekt
    
    Args:
        spline_obj: Das Spline-Objekt
    
    Returns:
        Liste von Vektoren (Punkte)
    """
    points = []
    if not spline_obj:
        return points
        
    if spline_obj.type != 'CURVE':
        return points
        
    for spline in spline_obj.data.splines:
        if spline.type == 'POLY':
            for point in spline.points:
                points.append(Vector(point.co[:3]))
        elif spline.type == 'BEZIER':
            for point in spline.bezier_points:
                points.append(point.co.copy())
    
    return points

def get_viewport_position(context):
    """
    Holt die aktuelle Position der Viewport-Kamera
    
    Returns:
        Position als Vector oder None
    """
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    if space.region_3d:
                        view_matrix = space.region_3d.view_matrix.inverted()
                        return view_matrix.translation.copy()
    return None

def get_viewport_rotation(context):
    """
    Holt die aktuelle Rotation der Viewport-Kamera
    
    Returns:
        Rotation als Quaternion oder None
    """
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    if space.region_3d:
                        return space.region_3d.view_rotation.copy()
    return None

def ensure_camera(context):
    """
    Stellt sicher dass eine Kamera existiert
    
    Returns:
        Die Kamera (neu oder vorhanden)
    """
    if context.scene.camera:
        return context.scene.camera
    
    # Neue Kamera erstellen
    cam_data = bpy.data.cameras.new("TSDE_Camera")
    cam = bpy.data.objects.new("TSDE_Camera", cam_data)
    context.scene.collection.objects.link(cam)
    context.scene.camera = cam
    return cam

def force_ui_update(context):
    """
    Erzwingt ein komplettes UI-Update
    """
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()
    context.scene.update_tag()