class Point:
    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)

    def copy(self):
        return Point(self.x, self.y, self.z)

    def lerp(self, other, t):
        return Point(
            self.x + (other.x - self.x) * t,
            self.y + (other.y - self.y) * t,
            self.z + (other.z - self.z) * t,
        )

    def to_tuple(self):
        return (self.x, self.y, self.z)

    @classmethod
    def from_tuple(cls, tup):
        return cls(tup[0], tup[1], tup[2])