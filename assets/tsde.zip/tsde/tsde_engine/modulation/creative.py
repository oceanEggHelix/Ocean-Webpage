def organic_flow(ch):
    k = ch.curve.curvature_at(ch.t_local)
    return 1.0 + 0.3 * k