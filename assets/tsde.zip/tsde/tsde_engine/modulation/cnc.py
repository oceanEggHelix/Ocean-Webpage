def constant_lens_feed(ch):
    k = ch.curve.curvature_at(ch.t_local)
    R_p = 1.0 / k
    R_l = R_p - ch.focal_length
    return R_p / R_l

def constant_lens_feed_outer(ch):
    k = ch.curve.curvature_at(ch.t_local)
    R_p = 1.0 / k
    R_l = R_p + ch.focal_length   # ⭐ außen statt innen
    return R_p / R_l