def milo_wander(ch):
    return 1.0 + noise(ch.distance * 0.1)